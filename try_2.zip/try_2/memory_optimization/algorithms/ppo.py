from .networks import PolicyNetwork, ValueNetwork
import torch
import numpy as np

class PPO:
    def __init__(self, state_dim, action_dim, lr=3e-4, gamma=0.99, epsilon=0.2):
        self.policy_net = PolicyNetwork(state_dim, action_dim)
        self.value_net = ValueNetwork(state_dim)
        self.optimizer = torch.optim.Adam([
            {'params': self.policy_net.parameters()},
            {'params': self.value_net.parameters()}
        ], lr=lr)
        
        self.gamma = gamma  # 折扣因子
        self.epsilon = epsilon  # PPO裁剪参数
        
    def select_action(self, state):
        """选择动作"""
        state = torch.FloatTensor(state)
        with torch.no_grad():
            action_probs = self.policy_net(state)
            action = torch.multinomial(action_probs, 1).item()
        return action
        
    def compute_returns(self, rewards, dones):
        """计算回报"""
        returns = []
        R = 0
        for r, d in zip(reversed(rewards), reversed(dones)):
            R = r + self.gamma * R * (1-d)
            returns.insert(0, R)
        return torch.tensor(returns)
        
    def update(self, states, actions, rewards, next_states, dones):
        """PPO更新逻辑"""
        # 转换为tensor
        states = torch.FloatTensor(states)
        actions = torch.LongTensor(actions)
        rewards = torch.FloatTensor(rewards)
        next_states = torch.FloatTensor(next_states)
        dones = torch.FloatTensor(dones)
        
        # 计算优势函数
        with torch.no_grad():
            values = self.value_net(states)
            next_values = self.value_net(next_states)
            returns = self.compute_returns(rewards, dones)
            advantages = returns - values
            
        # 计算旧策略的动作概率
        with torch.no_grad():
            old_probs = self.policy_net(states)
            old_action_probs = old_probs.gather(1, actions.unsqueeze(1))
        
        # PPO更新
        for _ in range(10):  # 多次更新
            # 计算新策略的动作概率
            new_probs = self.policy_net(states)
            new_action_probs = new_probs.gather(1, actions.unsqueeze(1))
            
            # 计算比率
            ratio = new_action_probs / old_action_probs
            
            # 计算PPO目标
            surr1 = ratio * advantages.unsqueeze(1)
            surr2 = torch.clamp(ratio, 1-self.epsilon, 1+self.epsilon) * advantages.unsqueeze(1)
            policy_loss = -torch.min(surr1, surr2).mean()
            
            # 计算价值损失
            value_loss = 0.5 * (returns - self.value_net(states)).pow(2).mean()
            
            # 总损失
            loss = policy_loss + value_loss
            
            # 优化
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
            
    def save(self, path):
        """保存模型"""
        torch.save({
            'policy_net': self.policy_net.state_dict(),
            'value_net': self.value_net.state_dict(),
            'optimizer': self.optimizer.state_dict()
        }, path)
        
    def load(self, path):
        """加载模型"""
        checkpoint = torch.load(path)
        self.policy_net.load_state_dict(checkpoint['policy_net'])
        self.value_net.load_state_dict(checkpoint['value_net'])
        self.optimizer.load_state_dict(checkpoint['optimizer'])