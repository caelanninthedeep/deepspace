import os
import json
import yaml
from dataclasses import dataclass, asdict
from typing import Dict, Any, Optional

@dataclass
class EnvironmentConfig:
    """环境配置"""
    # 内存配置
    memory_size: int = 1024  # 内存大小
    page_size: int = 4  # 页大小
    num_pages: int = 256  # 页数
    
    # 工作负载配置
    workload_type: str = "random"  # 工作负载类型
    workload_size: int = 100  # 工作负载大小
    access_pattern: str = "random"  # 访问模式
    
    # 奖励配置
    reward_weights: Dict[str, float] = None  # 奖励权重
    
    def __post_init__(self):
        if self.reward_weights is None:
            self.reward_weights = {
                "hit_rate": 1.0,
                "memory_usage": 0.5,
                "fragmentation": 0.3
            }

@dataclass
class TrainingConfig:
    """训练配置"""
    # 算法配置
    algorithm: str = "ppo"  # 算法类型
    learning_rate: float = 3e-4  # 学习率
    gamma: float = 0.99  # 折扣因子
    gae_lambda: float = 0.95  # GAE参数
    
    # PPO特定配置
    ppo_epochs: int = 10  # PPO更新轮数
    clip_ratio: float = 0.2  # PPO裁剪参数
    value_coef: float = 0.5  # 价值损失系数
    entropy_coef: float = 0.01  # 熵正则化系数
    
    # 训练过程配置
    num_episodes: int = 1000  # 训练回合数
    batch_size: int = 64  # 批次大小
    max_steps: int = 1000  # 每回合最大步数
    
    # 评估配置
    eval_interval: int = 100  # 评估间隔
    eval_episodes: int = 10  # 评估回合数
    
    # 日志配置
    log_interval: int = 10  # 日志记录间隔
    save_interval: int = 100  # 模型保存间隔

class ConfigManager:
    """配置管理器"""
    def __init__(self, config_dir: str = "configs"):
        self.config_dir = config_dir
        self.env_config = EnvironmentConfig()
        self.train_config = TrainingConfig()
        
        # 创建配置目录
        os.makedirs(config_dir, exist_ok=True)
    
    def save_config(self, filename: str, format: str = "yaml"):
        """保存配置到文件"""
        config = {
            "environment": asdict(self.env_config),
            "training": asdict(self.train_config)
        }
        
        filepath = os.path.join(self.config_dir, filename)
        
        if format.lower() == "yaml":
            with open(filepath, "w") as f:
                yaml.dump(config, f, default_flow_style=False)
        elif format.lower() == "json":
            with open(filepath, "w") as f:
                json.dump(config, f, indent=4)
        else:
            raise ValueError(f"不支持的格式: {format}")
    
    def load_config(self, filename: str, format: str = "yaml"):
        """从文件加载配置"""
        filepath = os.path.join(self.config_dir, filename)
        
        if format.lower() == "yaml":
            with open(filepath, "r") as f:
                config = yaml.safe_load(f)
        elif format.lower() == "json":
            with open(filepath, "r") as f:
                config = json.load(f)
        else:
            raise ValueError(f"不支持的格式: {format}")
        
        # 更新配置
        self.env_config = EnvironmentConfig(**config["environment"])
        self.train_config = TrainingConfig(**config["training"])
    
    def update_env_config(self, **kwargs):
        """更新环境配置"""
        for key, value in kwargs.items():
            if hasattr(self.env_config, key):
                setattr(self.env_config, key, value)
    
    def update_train_config(self, **kwargs):
        """更新训练配置"""
        for key, value in kwargs.items():
            if hasattr(self.train_config, key):
                setattr(self.train_config, key, value)
    
    def get_env_config(self) -> EnvironmentConfig:
        """获取环境配置"""
        return self.env_config
    
    def get_train_config(self) -> TrainingConfig:
        """获取训练配置"""
        return self.train_config
    
    def create_default_configs(self):
        """创建默认配置文件"""
        # 创建默认环境配置
        self.save_config("default_env.yaml", "yaml")
        
        # 创建默认训练配置
        self.save_config("default_train.yaml", "yaml")
        
        # 创建完整配置
        self.save_config("default_full.yaml", "yaml") 