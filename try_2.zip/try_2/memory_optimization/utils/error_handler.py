import os
import json
import logging
from typing import Dict, Any, Optional, Callable
from .config import ConfigManager

class ErrorHandler:
    """错误处理器"""
    def __init__(self, config_manager: ConfigManager, log_dir: str = "logs"):
        self.config_manager = config_manager
        self.log_dir = log_dir
        self.backup_config = None
        
        # 设置日志
        self.logger = logging.getLogger("ErrorHandler")
        self.logger.setLevel(logging.INFO)
        
        # 创建日志目录
        os.makedirs(log_dir, exist_ok=True)
        
        # 添加文件处理器
        fh = logging.FileHandler(os.path.join(log_dir, "error.log"))
        fh.setLevel(logging.INFO)
        self.logger.addHandler(fh)
        
        # 参数安全范围
        self.safe_ranges = {
            "memory_size": (1024, 1024 * 1024),  # 1KB to 1MB
            "page_size": (4, 4096),  # 4B to 4KB
            "num_pages": (64, 1024),  # 最小64页，最大1024页
            "learning_rate": (1e-6, 1e-2),  # 学习率范围
            "gamma": (0.9, 0.999),  # 折扣因子范围
            "batch_size": (16, 512),  # 批次大小范围
            "max_steps": (100, 10000)  # 最大步数范围
        }
    
    def backup_config(self):
        """备份当前配置"""
        self.backup_config = {
            "environment": self.config_manager.get_env_config().__dict__,
            "training": self.config_manager.get_train_config().__dict__
        }
        
        # 保存备份
        with open(os.path.join(self.log_dir, "config_backup.json"), "w") as f:
            json.dump(self.backup_config, f, indent=4)
    
    def restore_config(self):
        """恢复备份的配置"""
        if self.backup_config:
            self.config_manager.update_env_config(**self.backup_config["environment"])
            self.config_manager.update_train_config(**self.backup_config["training"])
            self.logger.info("配置已恢复到备份状态")
    
    def check_parameter_safety(self, params: Dict[str, Any]) -> bool:
        """检查参数是否在安全范围内"""
        for key, value in params.items():
            if key in self.safe_ranges:
                min_val, max_val = self.safe_ranges[key]
                if not (min_val <= value <= max_val):
                    self.logger.warning(f"参数 {key} 的值 {value} 超出安全范围 [{min_val}, {max_val}]")
                    return False
        return True
    
    def handle_error(self, error: Exception, recovery_strategy: Optional[Callable] = None):
        """处理错误"""
        # 记录错误
        self.logger.error(f"发生错误: {str(error)}")
        
        # 检查是否需要恢复配置
        if isinstance(error, (ValueError, RuntimeError)):
            self.logger.info("尝试恢复配置...")
            self.restore_config()
        
        # 执行自定义恢复策略
        if recovery_strategy:
            try:
                recovery_strategy()
                self.logger.info("自定义恢复策略执行成功")
            except Exception as e:
                self.logger.error(f"自定义恢复策略执行失败: {str(e)}")
    
    def validate_environment(self, env) -> bool:
        """验证环境状态"""
        try:
            # 检查环境是否可重置
            state = env.reset()
            if state is None:
                raise ValueError("环境重置失败")
            
            # 检查动作空间
            action = env.action_space.sample()
            if action is None:
                raise ValueError("无法采样动作")
            
            # 检查状态转移
            next_state, reward, done, info = env.step(action)
            if next_state is None:
                raise ValueError("状态转移失败")
            
            return True
        except Exception as e:
            self.logger.error(f"环境验证失败: {str(e)}")
            return False
    
    def monitor_metrics(self, metrics: Dict[str, float], thresholds: Dict[str, float]):
        """监控指标是否超过阈值"""
        for metric, value in metrics.items():
            if metric in thresholds:
                threshold = thresholds[metric]
                if value > threshold:
                    self.logger.warning(f"指标 {metric} 超过阈值: {value} > {threshold}")
                    return False
        return True
    
    def create_snapshot(self, state: Dict[str, Any]):
        """创建系统状态快照"""
        snapshot = {
            "config": {
                "environment": self.config_manager.get_env_config().__dict__,
                "training": self.config_manager.get_train_config().__dict__
            },
            "state": state
        }
        
        # 保存快照
        with open(os.path.join(self.log_dir, "system_snapshot.json"), "w") as f:
            json.dump(snapshot, f, indent=4)
        
        self.logger.info("系统状态快照已创建")
    
    def load_snapshot(self) -> Optional[Dict[str, Any]]:
        """加载系统状态快照"""
        snapshot_path = os.path.join(self.log_dir, "system_snapshot.json")
        if os.path.exists(snapshot_path):
            with open(snapshot_path, "r") as f:
                snapshot = json.load(f)
            
            # 恢复配置
            self.config_manager.update_env_config(**snapshot["config"]["environment"])
            self.config_manager.update_train_config(**snapshot["config"]["training"])
            
            self.logger.info("系统状态快照已加载")
            return snapshot["state"]
        return None 