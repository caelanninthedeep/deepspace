"""
内存相关工作负载模块
"""

import random
import time
import psutil

class MemoryWorkload:
    def __init__(self):
        pass
        
    def run_memory_intensive(self):
        """内存密集型工作负载"""
        # 创建和访问大数组
        size_mb = random.randint(100, int(psutil.virtual_memory().total / (4 * 1024 * 1024)))  # 使用系统内存的1/4
        print(f"[Memory Workload] Creating and accessing {size_mb}MB array...")
        
        # 创建大数组并访问它
        data = bytearray(size_mb * 1024 * 1024)
        
        # 随机读写操作
        for _ in range(10000):
            index = random.randint(0, len(data) - 1)
            data[index] = 1
            
        # 释放内存
        del data
        
    def parallel_memory_allocations(self):
        """并发内存分配测试"""
        import multiprocessing
        
        print("[Parallel Load] Spawning memory-heavy processes...")
        
        def worker():
            """工作进程函数：分配并操作内存块"""
            size_mb = random.randint(100, 500)
            data = bytearray(size_mb * 1024 * 1024)
            # 随机访问
            for _ in range(1000):
                index = random.randint(0, len(data) - 1)
                data[index] = 1
            time.sleep(2)
            
        # 创建多个工作进程
        procs = [multiprocessing.Process(target=worker) for _ in range(3)]
        for p in procs:
            p.start()
        
        # 等待所有进程完成
        for p in procs:
            p.join()
            
    def memory_fragmentation_test(self):
        """内存碎片测试"""
        print("[Memory] Running fragmentation test...")
        
        # 创建多个不同大小的内存块
        blocks = []
        for _ in range(100):
            size = random.randint(1, 50) * 1024 * 1024  # 1MB到50MB
            blocks.append(bytearray(size))
            
        # 释放一半的块
        for i in range(0, len(blocks), 2):
            blocks[i] = None
            
        # 重新分配一些块
        for _ in range(25):
            size = random.randint(5, 30) * 1024 * 1024
            blocks.append(bytearray(size))
            
        # 最后释放所有块
        blocks.clear()