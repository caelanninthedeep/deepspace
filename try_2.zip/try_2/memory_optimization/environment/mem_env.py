"""
内存子系统优化强化学习环境的核心类
"""

import time
import random
from collections import deque

import numpy as np
import gym
from gym import spaces
from .state_collector import StateCollector
from .action_handler import ActionHandler
from .reward_calculator import RewardCalculator
from memory_optimization.workloads.memory_workloads import MemoryWorkload
from memory_optimization.workloads.io_workloads import IOWorkload
from memory_optimization.workloads.mixed_workloads import MixedWorkload
from memory_optimization.utils.safety_checks import SafetyChecker

class MemoryOptimizationEnv:
    def __init__(self, params={}):
        self.params = params
        
        # 初始化组件
        self.state_collector = StateCollector()
        self.action_handler = ActionHandler()
        self.reward_calculator = RewardCalculator()
        self.safety_checker = SafetyChecker()
        
        # 工作负载实例
        self.memory_workload = MemoryWorkload()
        self.io_workload = IOWorkload()
        self.mixed_workload = MixedWorkload()
        
        # 初始化历史记录
        self.action_history = deque(maxlen=100)
        self.state_history = deque(maxlen=100)
        self.reward_history = deque(maxlen=100)
        self.runtime_history = deque(maxlen=10)
        
        # 初始状态
        self.state = None
        self.previous_workload_runtime = None
        
        # 记录初始参数值以便恢复
        self.initial_params = self.action_handler.get_current_parameters()
        
    def reset(self):
        """重置环境状态"""
        print("[RL Env] Resetting environment...")
        
        # 恢复初始参数
        if hasattr(self, 'initial_params'):
            for param, value in self.initial_params.items():
                self.action_handler.set_parameter(param, value)
                
        # 清空历史记录
        self.action_history.clear()
        self.state_history.clear()
        self.reward_history.clear()
        self.runtime_history.clear()
        
        # 初始状态
        self.state = self.state_collector.get_state()
        self.state_history.append(self.state)
        
        # 运行初始工作负载以建立基准
        self.run_test_workload()
        self.previous_workload_runtime = self.last_workload_runtime
        
        # 更新状态以包含工作负载运行时间
        self.state = self.state_collector.get_state()
        
        return self.state
        
    def step(self, action):
        """执行一步动作"""
        # 安全检查
        if not self.safety_checker.is_safe_to_proceed(self.state):
            print("[SAFETY] Unsafe system state detected. Skipping this step.")
            return self.state, -100, False, {"skipped": True}
        
        # 记录动作
        self.action_history.append(action)
        
        # 执行参数调整
        self.action_handler.execute_action(action)
        
        # 运行测试工作负载
        self.run_test_workload()
        
        # 获取新状态
        new_state = self.state_collector.get_state()
        self.state = new_state
        self.state_history.append(new_state)
        
        # 计算奖励
        reward = self.reward_calculator.calculate_reward(new_state, self.previous_workload_runtime, 
                                                        self.last_workload_runtime)
        self.reward_history.append(reward)
        
        # 更新前一次工作负载运行时间
        self.previous_workload_runtime = self.last_workload_runtime
        
        # 判断是否结束
        done = False
        # 可以根据实际需求设置结束条件
        
        info = {
            'last_workload_type': getattr(self, 'last_workload_type', None),
            'last_workload_runtime': getattr(self, 'last_workload_runtime', None),
        }
        
        return new_state, reward, done, info
    
    def run_test_workload(self):
        """运行测试负载并测量性能"""
        # 随机选择一种工作负载类型
        workload_types = [
            'memory_intensive',
            'io_intensive',
            'mixed_workload',
            'file_cache_intensive'
        ]
        workload_type = random.choice(workload_types)
        
        # 记录开始时间
        start_time = time.time()
        
        # 根据选择的类型运行对应工作负载
        if workload_type == 'memory_intensive':
            self.memory_workload.run_memory_intensive()
        elif workload_type == 'io_intensive':
            self.io_workload.run_io_intensive()
        elif workload_type == 'mixed_workload':
            self.mixed_workload.run_mixed_workload()
        elif workload_type == 'file_cache_intensive':
            self.io_workload.run_file_cache_intensive()
        
        # 记录结束时间和运行时长
        end_time = time.time()
        self.last_workload_runtime = end_time - start_time
        self.last_workload_type = workload_type
        
        print(f"[Workload] {workload_type} completed in {self.last_workload_runtime:.2f} seconds")
    
    def get_action_space_sample(self):
        """获取随机动作样本，用于测试和探索"""
        return self.action_handler.get_random_action()
        
    def close(self):
        """关闭环境，恢复初始参数"""
        print("[RL Env] Closing environment and restoring parameters...")
        if hasattr(self, 'initial_params'):
            for param, value in self.initial_params.items():
                self.action_handler.set_parameter(param, value)