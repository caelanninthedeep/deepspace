#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re, csv, argparse, ast
from collections import OrderedDict

EPISODE_SUMMARY_RE = re.compile(r"(基线)?回合\s+(\d+)\s*总结[:：]?")
EPISODE_HEADER_RE  = re.compile(r"-{3,}\s*(基线)?回合\s+(\d+)(?:/\d+)?\s*-{3,}")
TOTAL_REWARD_RE    = re.compile(r"总奖励:\s*([-+]?\d+(?:\.\d+)?),\s*步数:\s*(\d+),\s*最终运行时间:\s*([-+]?\d+(?:\.\d+)?)s")
AVG_MAX_REWARD_RE  = re.compile(r"平均步奖励:\s*([-+]?\d+(?:\.\d+)?),\s*最大奖励:\s*([-+]?\d+(?:\.\d+)?)")
WORKLOAD_LINE_RE   = re.compile(r"当前回合工作负载统计:\s*(\{.*\})")
DIFFICULTY_LINE_RE = re.compile(r"当前回合难度统计:\s*(\{.*\})")
NPSTR_FIX_RE       = re.compile(r"np\.str_\('([^']+)'\)")

def clean_npstr(s): return NPSTR_FIX_RE.sub(r"'\1'", s)

def safe_parse_dict(s):
    s = clean_npstr(s)
    try:
        d = ast.literal_eval(s)
        if isinstance(d, dict):
            return {str(k): int(v) for k,v in d.items()}
    except Exception:
        pass
    return {}

def parse_log(lines):
    rows = []                 # 每发现一个“回合开始”就 append 一个 dict
    workload_cols = set()
    difficulty_cols = set()

    current = None            # 指向 rows[-1]
    pending = {"episode": None, "phase": None}  # 先遇到 header 再遇到指标时用

    def ensure_row():
        """如果当前没有row，但我们开始遇到指标了，就用pending开一个"""
        nonlocal current
        if current is None and pending["episode"] is not None:
            current = {"episode": pending["episode"], "phase": pending["phase"] or "mappo"}
            rows.append(current)

    for raw in lines:
        line = raw.strip()
        if not line:
            continue

        m = EPISODE_SUMMARY_RE.search(line)
        if m:
            # 明确出现“(基线)回合 X 总结”
            phase = 'baseline' if m.group(1) else 'mappo'
            ep = int(m.group(2))
            current = {"episode": ep, "phase": phase}
            rows.append(current)
            pending = {"episode": ep, "phase": phase}
            continue

        m = EPISODE_HEADER_RE.search(line)
        if m:
            # 仅记住，等真正出现指标再落一行（避免 header + 总结 各开一行导致重复）
            phase = 'baseline' if m.group(1) else None
            ep = int(m.group(2))
            current = None
            pending = {"episode": ep, "phase": phase}
            continue

        m = TOTAL_REWARD_RE.search(line)
        if m:
            ensure_row()
            if current:
                total_reward, steps, runtime = m.groups()
                current["total_reward"] = float(total_reward)
                current["steps"] = int(steps)
                current["final_runtime_sec"] = float(runtime)
            continue

        m = AVG_MAX_REWARD_RE.search(line)
        if m:
            ensure_row()
            if current:
                avg_step_reward, max_reward = m.groups()
                current["avg_step_reward"] = float(avg_step_reward)
                current["max_step_reward"] = float(max_reward)
            continue

        m = WORKLOAD_LINE_RE.search(line)
        if m:
            ensure_row()
            if current:
                d = safe_parse_dict(m.group(1))
                for k, v in d.items():
                    col = f"workload:{k}"
                    current[col] = int(v)
                    workload_cols.add(col)
            continue

        m = DIFFICULTY_LINE_RE.search(line)
        if m:
            ensure_row()
            if current:
                d = safe_parse_dict(m.group(1))
                for k, v in d.items():
                    col = f"difficulty:{k}"
                    current[col] = int(v)
                    difficulty_cols.add(col)
            continue

    fixed = ["episode","phase","total_reward","steps","final_runtime_sec","avg_step_reward","max_step_reward"]
    dynamic = sorted(workload_cols) + sorted(difficulty_cols)
    headers = fixed + dynamic

    # 归并成表（缺失填0/空）
    out = []
    for r in rows:
        row = {h: None for h in fixed}
        row.update({"episode": r.get("episode"),
                    "phase": r.get("phase","mappo"),
                    "total_reward": r.get("total_reward"),
                    "steps": r.get("steps"),
                    "final_runtime_sec": r.get("final_runtime_sec"),
                    "avg_step_reward": r.get("avg_step_reward"),
                    "max_step_reward": r.get("max_step_reward")})
        for c in dynamic:
            row[c] = r.get(c, 0)
        out.append(row)
    return headers, out

def main():
    ap = argparse.ArgumentParser(description="Parse MAPPO & baseline logs into per-episode CSV.")
    ap.add_argument("logfile")
    ap.add_argument("--out", default="episodes_summary.csv")
    args = ap.parse_args()

    with open(args.logfile, "r", encoding="utf-8", errors="ignore") as f:
        headers, rows = parse_log(f.readlines())

    with open(args.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=headers)
        w.writeheader()
        w.writerows(rows)

    import os
    print("✅ 已生成:", os.path.abspath(args.out))
    print("  行数(应含基线+MAPPO):", len(rows))

if __name__ == "__main__":
    main()

