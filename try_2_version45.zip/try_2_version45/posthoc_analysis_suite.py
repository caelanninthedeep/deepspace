# posthoc_analysis_suite.py
import os, json, argparse, warnings
import numpy as np
import pandas as pd

# ============ 工具函数 ============
def ensure_cols(df, cols, fill=0):
    for c in cols:
        if c not in df.columns:
            df[c] = fill
    return df

def to_numeric(df, cols):
    for c in cols:
        df[c] = pd.to_numeric(df[c], errors='coerce').fillna(0)
    return df

def norm_cols(df, comp_cols):
    """为每个特征生成归一化列，除以 steps；返回归一化后的矩阵 X (n, d)"""
    s = df['steps'].replace(0, 1.0).astype(float)
    X = df[comp_cols].astype(float).div(s, axis=0).to_numpy()
    return X

def smd(a, b):
    """标准化均值差 SMD for 每列： (mean_a-mean_b)/sqrt((var_a+var_b)/2)"""
    am = np.nanmean(a, axis=0)
    bm = np.nanmean(b, axis=0)
    av = np.nanvar(a, axis=0, ddof=1)
    bv = np.nanvar(b, axis=0, ddof=1)
    denom = np.sqrt((av + bv) / 2.0 + 1e-12)
    return (am - bm) / denom

def bootstrap_ci(x, n_boot=5000, seed=42):
    x = np.asarray(x, dtype=float)
    if x.size < 2:
        return float(np.mean(x)), np.nan, np.nan
    rng = np.random.default_rng(seed)
    boots = []
    for _ in range(n_boot):
        idx = rng.integers(0, len(x), len(x))
        boots.append(np.mean(x[idx]))
    boots = np.sort(boots)
    return float(np.mean(x)), float(boots[int(0.025*n_boot)]), float(boots[int(0.975*n_boot)])

def dist_fn_factory(metric):
    metric = metric.lower()
    if metric == 'l1':
        return lambda a,b: float(np.abs(a-b).sum(axis=1))
    if metric == 'l2':
        return lambda a,b: float(np.sqrt(((a-b)**2).sum(axis=1)))
    if metric in ('cos','cosine'):
        def cos(a,b):
            num = float((a*b).sum())
            den = float(np.linalg.norm(a)*np.linalg.norm(b) + 1e-12)
            return 1.0 - num/den
        return lambda a,b: cos(a,b)
    raise ValueError(f"unknown metric {metric}")

# ============ 匹配（贪心 & 匈牙利） ============
def match_greedy(Xm, Xb, replace=False, caliper=None, metric='l1', seed=42):
    """返回 pairs, gaps；pairs 是 (i_mappo, j_base) 列表；gaps 是对应距离"""
    rng = np.random.default_rng(seed)
    idx_m = list(range(len(Xm)))
    rng.shuffle(idx_m)

    used = set()
    pairs, gaps = [], []
    if metric.lower() in ('l1','l2'):
        # 向量化加速
        for im in idx_m:
            if not replace and len(used) == len(Xb):
                break
            diffs = np.abs(Xb - Xm[im]) if metric=='l1' else (Xb - Xm[im])**2
            dists = diffs.sum(axis=1) if metric=='l1' else np.sqrt(diffs.sum(axis=1))
            # 未使用的候选
            cand = ([j for j in range(len(Xb)) if j not in used] if not replace else range(len(Xb)))
            if not cand:
                break
            cand = np.array(cand, dtype=int)
            dsub = dists[cand]
            jbest = cand[np.argmin(dsub)]
            gap = float(dists[jbest])
            if caliper is not None and gap > caliper:
                continue
            pairs.append((im, int(jbest)))
            gaps.append(gap)
            used.add(int(jbest))
    else:
        # 余弦距离逐个算
        cos = dist_fn_factory('cosine')
        for im in idx_m:
            if not replace and len(used) == len(Xb):
                break
            best_j, best_d = None, 1e12
            for j in range(len(Xb)):
                if (not replace) and (j in used):
                    continue
                d = cos(Xm[im], Xb[j])
                if d < best_d:
                    best_d, best_j = d, j
            if best_j is None:
                break
            if caliper is not None and best_d > caliper:
                continue
            pairs.append((im, best_j))
            gaps.append(float(best_d))
            used.add(best_j)
    return pairs, np.asarray(gaps, dtype=float)

def match_hungarian(Xm, Xb, metric='l1', caliper=None):
    """匈牙利匹配；需要 SciPy。返回 pairs, gaps。不可用时抛出 ImportError。"""
    from scipy.optimize import linear_sum_assignment  # 可能不存在
    M, B = len(Xm), len(Xb)
    # 构造代价矩阵（M x B）
    C = np.zeros((M, B), dtype=float)
    if metric.lower() in ('l1','l2'):
        for i in range(M):
            if metric=='l1':
                C[i] = np.abs(Xb - Xm[i]).sum(axis=1)
            else:
                C[i] = np.sqrt(((Xb - Xm[i])**2).sum(axis=1))
    else:
        cos = dist_fn_factory('cosine')
        for i in range(M):
            C[i] = [cos(Xm[i], Xb[j]) for j in range(B)]

    if caliper is not None:
        C = np.where(C > caliper, 1e9, C)

    row_ind, col_ind = linear_sum_assignment(C)  # 矩形矩阵也可
    pairs, gaps = [], []
    for i, j in zip(row_ind, col_ind):
        gap = C[i, j]
        if caliper is not None and gap > caliper:
            continue
        pairs.append((int(i), int(j)))
        gaps.append(float(gap))
    return pairs, np.asarray(gaps, dtype=float)

# ============ 主流程 ============
def run_once(base, mappo, comp_cols, n_boot=5000, metric='l1',
             replace=False, caliper=None, seed=42, use_hungarian=False):
    # 归一化向量（按 steps）
    Xm = norm_cols(mappo, comp_cols)
    Xb = norm_cols(base,  comp_cols)

    # 匹配
    if use_hungarian:
        try:
            pairs, gaps = match_hungarian(Xm, Xb, metric=metric, caliper=caliper)
        except Exception as e:
            warnings.warn(f"Hungarian unavailable ({e}), fallback to greedy.")
            pairs, gaps = match_greedy(Xm, Xb, replace=replace, caliper=caliper, metric=metric, seed=seed)
    else:
        pairs, gaps = match_greedy(Xm, Xb, replace=replace, caliper=caliper, metric=metric, seed=seed)

    if len(pairs) == 0:
        return {
            "n_pairs": 0, "gaps_stats": None,
            "delta_runtime": None, "delta_reward": None,
            "ci_runtime": (np.nan, np.nan, np.nan),
            "ci_reward": (np.nan, np.nan, np.nan),
            "smd_pre": None, "smd_post": None
        }

    # 配对差值
    drt, drew = [], []
    idx_m, idx_b = [], []
    for (im, jb) in pairs:
        rm = mappo.iloc[im]; rb = base.iloc[jb]
        drt.append(float(rb.get('final_runtime_sec',0)) - float(rm.get('final_runtime_sec',0)))
        drew.append(float(rm.get('total_reward',0)) - float(rb.get('total_reward',0)))
        idx_m.append(im); idx_b.append(jb)
    drt = np.asarray(drt, dtype=float)
    drew = np.asarray(drew, dtype=float)

    # CI
    mR, loR, hiR = bootstrap_ci(drt, n_boot=n_boot, seed=seed)
    mW, loW, hiW = bootstrap_ci(drew, n_boot=n_boot, seed=seed)

    # 平衡诊断（SMD）：匹配前 vs 匹配后
    Xb_all = norm_cols(base,  comp_cols)
    Xm_all = norm_cols(mappo, comp_cols)
    smd_pre  = smd(Xm_all, Xb_all)

    Xb_mat  = Xb[idx_b]
    Xm_mat  = Xm[idx_m]
    smd_post = smd(Xm_mat, Xb_mat)

    # 距离分布统计
    gap_stats = {
        "mean": float(np.mean(gaps)),
        "median": float(np.median(gaps)),
        "p10": float(np.percentile(gaps, 10)),
        "p90": float(np.percentile(gaps, 90)),
        "p95": float(np.percentile(gaps, 95)),
        "max": float(np.max(gaps))
    }

    return {
        "n_pairs": len(pairs),
        "gaps_stats": gap_stats,
        "delta_runtime": drt,       # 便于后续保存
        "delta_reward": drew,
        "ci_runtime": (mR, loR, hiR),
        "ci_reward": (mW, loW, hiW),
        "smd_pre": smd_pre,
        "smd_post": smd_post,
        "pairs": pairs
    }

def sensitivity_grid(base, mappo, comp_cols, n_boot=5000,
                     metrics=('l1','l2','cosine'),
                     replaces=(False, True),
                     calipers=(None, 0.3),
                     seeds=(42, 202, 1234),
                     use_hungarian=False):
    rows = []
    for metric in metrics:
        for rp in replaces:
            for cal in calipers:
                for sd in seeds:
                    res = run_once(base, mappo, comp_cols, n_boot=n_boot, metric=metric,
                                   replace=rp, caliper=cal, seed=sd, use_hungarian=use_hungarian)
                    rows.append({
                        "metric": metric,
                        "replace": rp,
                        "caliper": cal,
                        "seed": sd,
                        "n_pairs": res["n_pairs"],
                        "gap_mean": None if res["gaps_stats"] is None else res["gaps_stats"]["mean"],
                        "rt_mean": res["ci_runtime"][0],
                        "rt_lo":   res["ci_runtime"][1],
                        "rt_hi":   res["ci_runtime"][2],
                        "rt_sig":  (res["ci_runtime"][1] > 0) or (res["ci_runtime"][2] < 0),
                        "rw_mean": res["ci_reward"][0],
                        "rw_lo":   res["ci_reward"][1],
                        "rw_hi":   res["ci_reward"][2],
                        "rw_sig":  (res["ci_reward"][1] > 0) or (res["ci_reward"][2] < 0),
                    })
    return pd.DataFrame(rows)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", type=str, required=True,
                        help="episodes_summary.csv 路径")
    parser.add_argument("--outdir", type=str, default=None,
                        help="输出目录，默认与 csv 同目录下的 posthoc_analysis")
    parser.add_argument("--n-boot", type=int, default=5000)
    parser.add_argument("--caliper", type=float, default=None,
                        help="主分析卡尺（如 0.3）。不设则不限")
    parser.add_argument("--use-hungarian", action="store_true",
                        help="主分析用匈牙利（若不可用自动回退）")
    args = parser.parse_args()

    csv_path = args.csv
    outdir = args.outdir or os.path.join(os.path.dirname(csv_path), "posthoc_analysis")
    os.makedirs(outdir, exist_ok=True)

    df = pd.read_csv(csv_path)

    # 列定义（按你导出的列）
    diff_cols = [
        'difficulty:easy','difficulty:medium','difficulty:hard','difficulty:extreme','difficulty:unknown'
    ]
    wl_cols = [
        'workload:file_cache_intensive','workload:io_intensive',
        'workload:memory_intensive','workload:mixed_workload','workload:unknown'
    ]
    comp_cols = diff_cols + wl_cols

    df['phase'] = df['phase'].astype(str).str.strip().str.lower()
    ensure_cols(df, comp_cols, fill=0)
    num_cols = comp_cols + ['steps','total_reward','final_runtime_sec']
    df = to_numeric(df, num_cols)

    base = df[df['phase']=='baseline'].copy().reset_index(drop=True)
    mappo= df[df['phase']=='mappo'].copy().reset_index(drop=True)
    if base.empty or mappo.empty:
        raise ValueError("baseline 或 mappo 数据为空。")

    # —— 主分析（默认：L1、不放回、可选卡尺/匈牙利）——
    main_res = run_once(
        base, mappo, comp_cols,
        n_boot=args.n_boot,
        metric='l1',
        replace=False,
        caliper=args.caliper,
        seed=42,
        use_hungarian=args.use_hungarian
    )

    # 平衡诊断表：匹配前/后 SMD
    smd_df = pd.DataFrame({
        "feature": comp_cols,
        "SMD_pre": np.round(main_res["smd_pre"], 4),
        "SMD_post": np.round(main_res["smd_post"], 4)
    })
    smd_df.to_csv(os.path.join(outdir, "balance_smd_pre_post.csv"), index=False)

    # 距离分布
    if main_res["gaps_stats"] is not None:
        with open(os.path.join(outdir, "match_gap_stats.json"), "w") as f:
            json.dump(main_res["gaps_stats"], f, indent=2)

    # 核心结果（配对差 + 95%CI）
    headline = {
        "n_pairs": main_res["n_pairs"],
        "runtime_pair_mean": main_res["ci_runtime"][0],
        "runtime_CI95": [main_res["ci_runtime"][1], main_res["ci_runtime"][2]],
        "reward_pair_mean": main_res["ci_reward"][0],
        "reward_CI95": [main_res["ci_reward"][1], main_res["ci_reward"][2]],
        "significance_runtime": not (main_res["ci_runtime"][1] <= 0 <= main_res["ci_runtime"][2]),
        "significance_reward":  not (main_res["ci_reward"][1]  <= 0 <= main_res["ci_reward"][2]),
    }
    with open(os.path.join(outdir, "headline_results.json"), "w") as f:
        json.dump(headline, f, indent=2)

    # —— 敏感性分析（网格）——
    sens = sensitivity_grid(
        base, mappo, comp_cols,
        n_boot=args.n_boot,
        metrics=('l1','l2','cosine'),
        replaces=(False, True),
        calipers=(None, 0.3),
        seeds=(42, 202, 1234),
        use_hungarian=args.use_hungarian
    )
    sens.to_csv(os.path.join(outdir, "sensitivity_grid.csv"), index=False)

    # —— 参考：未配对粗均值 —— 
    ref = {
        "mean_runtime_baseline": float(base['final_runtime_sec'].mean()),
        "mean_runtime_mappo": float(mappo['final_runtime_sec'].mean()),
        "diff_runtime_b_minus_a": float(base['final_runtime_sec'].mean() - mappo['final_runtime_sec'].mean()),
        "mean_reward_baseline": float(base['total_reward'].mean()),
        "mean_reward_mappo": float(mappo['total_reward'].mean()),
        "diff_reward_a_minus_b": float(mappo['total_reward'].mean() - base['total_reward'].mean()),
    }
    with open(os.path.join(outdir, "unpaired_reference.json"), "w") as f:
        json.dump(ref, f, indent=2)

    # 控制台输出（简版）
    print("=== 主分析（L1, 不放回{}）===".format(f", 卡尺={args.caliper}" if args.caliper is not None else ""))
    print(f"配对数: {main_res['n_pairs']}")
    if main_res['gaps_stats'] is not None:
        g = main_res['gaps_stats']
        print(f"匹配距离 L1: mean={g['mean']:.4f}, median={g['median']:.4f}, p90={g['p90']:.4f}, max={g['max']:.4f}")
    mR, loR, hiR = main_res['ci_runtime']
    mW, loW, hiW = main_res['ci_reward']
    print(f"→ 运行时间（基线 - MAPPO），秒：mean={mR:.4f}  95%CI[{loR:.4f},{hiR:.4f}]  "
          f"{'显著' if not(loR<=0<=hiR) else '非显著'}")
    print(f"→ 奖励（MAPPO - 基线）：      mean={mW:.2f}   95%CI[{loW:.2f},{hiW:.2f}]  "
          f"{'显著' if not(loW<=0<=hiW) else '非显著'}")
    print("\nSMD 结果已保存：balance_smd_pre_post.csv")
    print("敏感性网格已保存：sensitivity_grid.csv")
    print("其它摘要见：headline_results.json, match_gap_stats.json, unpaired_reference.json")
    print(f"输出目录：{outdir}")

if __name__ == "__main__":
    main()

