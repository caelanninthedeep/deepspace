# posthoc_match_compare.py
import pandas as pd
import numpy as np

CSV_PATH = r"saved_models/memory_management_20250808_121204/models/test_results/episodes_summary.csv"  # 改成你的csv路径
N_BOOT = 5000  # 自助法重采样次数

# 读数据
df = pd.read_csv(CSV_PATH)

# 需要的列
diff_cols = [
    'difficulty:easy','difficulty:medium','difficulty:hard','difficulty:extreme','difficulty:unknown'
]
wl_cols = [
    'workload:file_cache_intensive','workload:io_intensive',
    'workload:memory_intensive','workload:mixed_workload','workload:unknown'
]
comp_cols = diff_cols + wl_cols

# 确保分布列都存在（缺失就补0）
for c in comp_cols:
    if c not in df.columns:
        df[c] = 0

# 统一 phase 大小写
if 'phase' not in df.columns:
    raise ValueError("CSV 缺少 'phase' 列")
df['phase'] = df['phase'].astype(str).str.strip().str.lower()

# 清洗数值列
num_cols = comp_cols + ['steps','total_reward','final_runtime_sec']
for c in num_cols:
    if c in df.columns:
        df[c] = pd.to_numeric(df[c], errors='coerce').fillna(0)
    else:
        df[c] = 0

# 只保留 baseline / mappo
base = df[df['phase'] == 'baseline'].copy().reset_index(drop=True)
mappo = df[df['phase'] == 'mappo'].copy().reset_index(drop=True)

if base.empty or mappo.empty:
    raise ValueError("baseline 或 mappo 数据为空，检查CSV。")

# 组成向量（按 steps 归一化为比例）
def norm_vec(row):
    s = row['steps'] if 'steps' in row and float(row['steps']) > 0 else 1.0
    v = row[comp_cols].to_numpy(dtype=float) / float(s)
    return v

base['comp'] = base.apply(norm_vec, axis=1)
mappo['comp'] = mappo.apply(norm_vec, axis=1)

# 距离函数：L1 距离
def l1(a, b): 
    return float(np.abs(a - b).sum())

# 贪心一对一匹配（先不放回；当基线用尽时允许放回）
used = set()
pairs = []
for i, r in mappo.iterrows():
    best_j, best_d = None, 1e9
    for j, rb in base.iterrows():
        if j in used:
            continue
        d = l1(r['comp'], rb['comp'])
        if d < best_d:
            best_d, best_j = d, j
    if best_j is None:
        # 基线不够：允许放回，从全部基线中找最近的
        dlist = [(j, l1(r['comp'], rb['comp'])) for j, rb in base.iterrows()]
        best_j = min(dlist, key=lambda x: x[1])[0]
    used.add(best_j)
    pairs.append((i, best_j))

# 计算配对差值
delta_runtime = []   # 基线 runtime - MAPPO runtime（越大越好）
delta_reward  = []   # MAPPO reward - 基线 reward（越大越好）
match_gaps    = []   # 匹配距离（L1），越小越接近

for i, j in pairs:
    rA = mappo.loc[i]
    rB = base.loc[j]
    # 运行时间
    rtA = float(rA.get('final_runtime_sec', 0))
    rtB = float(rB.get('final_runtime_sec', 0))
    delta_runtime.append(rtB - rtA)
    # 奖励
    rewA = float(rA.get('total_reward', 0))
    rewB = float(rB.get('total_reward', 0))
    delta_reward.append(rewA - rewB)
    # 匹配距离
    match_gaps.append(l1(rA['comp'], rB['comp']))

delta_runtime = np.asarray(delta_runtime, dtype=float)
delta_reward  = np.asarray(delta_reward, dtype=float)
match_gaps    = np.asarray(match_gaps, dtype=float)

def ci95(x):
    if len(x) < 2:
        return (np.nan, np.nan, np.nan)
    boots = []
    n = len(x)
    rng = np.random.default_rng(42)
    for _ in range(N_BOOT):
        idx = rng.integers(0, n, n)
        boots.append(np.mean(x[idx]))
    boots = np.sort(boots)
    return (float(np.mean(x)), float(boots[int(0.025*N_BOOT)]), float(boots[int(0.975*N_BOOT)]))

mR, loR, hiR = ci95(delta_runtime)
mW, loW, hiW = ci95(delta_reward)

print("=== 事后配对（按难度+负载分布最近邻匹配）===")
print(f"配对数: {len(pairs)}")
print(f"匹配分布距离（L1）: mean={match_gaps.mean():.4f}, median={np.median(match_gaps):.4f}, max={match_gaps.max():.4f}")

print("\n→ 运行时间（基线 - MAPPO），单位秒：")
print(f"  平均配对改进 = {mR:.4f}  (95% CI: {loR:.4f} ~ {hiR:.4f})")

print("\n→ 奖励（MAPPO - 基线）：")
print(f"  平均配对改进 = {mW:.2f}  (95% CI: {loW:.2f} ~ {hiW:.2f})")

# 参考：未配对的简单均值
mean_rt_base = float(base['final_runtime_sec'].mean())
mean_rt_mappo = float(mappo['final_runtime_sec'].mean())
mean_rew_base = float(base['total_reward'].mean())
mean_rew_mappo = float(mappo['total_reward'].mean())

print("\n--- 参考：未配对的粗均值 ---")
print(f"  Runtime: baseline={mean_rt_base:.3f}s, mappo={mean_rt_mappo:.3f}s, diff(b-a)={mean_rt_base-mean_rt_mappo:.3f}s")
print(f"  Reward : baseline={mean_rew_base:.1f}, mappo={mean_rew_mappo:.1f}, diff(a-b)={mean_rew_mappo-mean_rew_base:.1f}")

