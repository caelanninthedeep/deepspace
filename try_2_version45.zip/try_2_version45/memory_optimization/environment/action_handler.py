import subprocess
import numpy as np
import logging
from typing import Dict, List, Any, Optional, Union

class MultiAgentActionHandler:
    """
    处理内存参数调整的执行
    支持多智能体架构，每个智能体负责不同的参数
    兼容PPO连续动作空间
    """
    def __init__(self):
        # 定义参数范围
        self.param_ranges = {
            'swappiness': {'min': 0, 'max': 100, 'type': int},
            'vfs_cache_pressure': {'min': 0, 'max': 500, 'type': int},
            'dirty_ratio': {'min': 1, 'max': 60, 'type': int},
            'dirty_background_ratio': {'min': 1, 'max': 50, 'type': int},
            'min_free_kbytes': {'min': 1024, 'max': 1048576, 'type': int},  # 1MB ~ 1GB
            'watermark_scale_factor': {'min': 10, 'max': 1000, 'type': int},
            'compaction_proactiveness': {'min': 0, 'max': 100, 'type': int}  # 新增参数
        }
        
        # 设置日志
        logging.basicConfig(level=logging.INFO, 
                           format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger('MultiAgentActionHandler')
        
        # 定义每个智能体负责的参数
        self.agent_params = {
            "page_cache": ["vfs_cache_pressure", "dirty_ratio", "dirty_background_ratio"],
            "memory_reclaim": ["swappiness", "min_free_kbytes"],
            "memory_scheduler": ["watermark_scale_factor", "compaction_proactiveness"]
        }
        
        # 参数约束关系（用于处理相互依赖的参数）
        self.param_constraints = [
            {
                'params': ['dirty_ratio', 'dirty_background_ratio'],
                'condition': lambda p: p['dirty_ratio'] > p['dirty_background_ratio'],
                'fix': lambda p: {'dirty_ratio': max(p['dirty_ratio'], p['dirty_background_ratio'] + 1)}
            }
        ]
    
    def execute_action(self, action_values):
        """
        执行参数调整动作
        
        Args:
            action_values: 字典，包含参数名和目标值的映射，例如 {'swappiness': 60, 'vfs_cache_pressure': 100}
        
        Returns:
            dict: 实际设置的参数值
        """
        # 获取当前参数
        current_params = self.get_current_parameters()
        applied_values = {}
        
        # 验证并调整参数值，确保满足约束条件
        validated_values = self.validate_parameters(action_values)
        
        # 应用动作
        for param, target_value in validated_values.items():
            if param not in self.param_ranges:
                self.logger.warning(f"Parameter {param} not in defined ranges, skipping")
                continue
                
            # 只有在新值与当前值不同时才设置
            if target_value != current_params.get(param):
                success = self.set_parameter(param, target_value)
                if success:
                    applied_values[param] = target_value
        
        # 返回实际应用的参数值
        return applied_values
    
    def execute_agent_actions(self, actions_dict):
        """
        执行多个智能体的动作
        
        Args:
            actions_dict: 字典，键为智能体ID，值为该智能体的动作数组
        
        Returns:
            dict: 实际设置的参数值
        """
        # 转换每个智能体的动作为参数值
        param_values = {}
        
        for agent_id, action in actions_dict.items():
            # 获取该智能体负责的参数
            if agent_id in self.agent_params:
                agent_param_values = self._convert_agent_action_to_param_values(agent_id, action)
                param_values.update(agent_param_values)
        
        # 执行所有参数调整
        return self.execute_action(param_values)
    
    def _convert_agent_action_to_param_values(self, agent_id, action):
        """
        将单个智能体的动作转换为参数值字典
        
        Args:
            agent_id: 智能体ID
            action: 智能体的动作数组（标准化值[-1,1]）
            
        Returns:
            dict: 参数名到实际值的映射
        """
        param_values = {}
        
        # 获取智能体负责的参数列表
        agent_params = self.agent_params.get(agent_id, [])
        
        # 确保动作维度与参数数量匹配
        if len(action) != len(agent_params):
            self.logger.warning(
                f"Action dimension mismatch for agent {agent_id}: got {len(action)}, expected {len(agent_params)}"
            )
            # 如果维度不匹配，尽可能使用已有的维度
            action = action[:len(agent_params)]
        
        # 将动作值转换为参数值
        for i, param_name in enumerate(agent_params):
            if i < len(action):
                # 获取参数配置
                param_range = self.param_ranges.get(param_name)
                if not param_range:
                    continue
                    
                min_val = param_range['min']
                max_val = param_range['max']
                
                # 将[-1,1]映射到[min_val,max_val]
                normalized_val = (action[i] + 1) / 2.0
                param_val = min_val + normalized_val * (max_val - min_val)
                
                # 对于整数参数，四舍五入
                if param_range['type'] == int:
                    param_val = int(round(param_val))
                
                param_values[param_name] = param_val
        
        return param_values
    
    def get_current_parameters(self):
        """获取当前内存子系统参数"""
        params = {}
        
        # 读取所有支持的参数
        param_paths = {
            'swappiness': '/proc/sys/vm/swappiness',
            'vfs_cache_pressure': '/proc/sys/vm/vfs_cache_pressure',
            'dirty_ratio': '/proc/sys/vm/dirty_ratio',
            'dirty_background_ratio': '/proc/sys/vm/dirty_background_ratio',
            'min_free_kbytes': '/proc/sys/vm/min_free_kbytes',
            'watermark_scale_factor': '/proc/sys/vm/watermark_scale_factor'
        }
        
        for param, path in param_paths.items():
            try:
                with open(path, 'r') as f:
                    value = f.read().strip()
                    value_type = self.param_ranges[param]['type']
                    params[param] = value_type(value)
            except Exception as e:
                self.logger.error(f"Error reading parameter {param}: {e}")
        
        # 特殊处理某些参数
        try:
            # compaction_proactiveness可能需要从其他地方读取，或设置默认值
            params['compaction_proactiveness'] = 20  # 默认值
        except Exception as e:
            self.logger.warning(f"Using default value for compaction_proactiveness: {e}")
        
        return params
    
    def set_parameter(self, param, value):
        """
        设置内存子系统参数
        
        Args:
            param: 参数名称
            value: 参数值
            
        Returns:
            bool: 是否成功设置参数
        """
        # 特殊参数处理
        if param == 'compaction_proactiveness':
            return self._set_compaction_proactiveness(value)
            
        try:
            # 使用sysctl命令设置
            subprocess.run(['sudo', 'sysctl', f'vm.{param}={value}'], 
                         check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
            self.logger.info(f"Set {param} to {value}")
            return True
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Error setting parameter {param}: {e}")
            return False
    
    def _set_compaction_proactiveness(self, value):
        """
        特殊处理compaction_proactiveness参数
        实际系统中可能没有这个直接参数，需要通过其他方式实现
        
        Args:
            value: 参数值
            
        Returns:
            bool: 是否成功设置
        """
        try:
            # 这里是模拟实现，实际情况可能需要通过组合多个参数或其他方式实现
            # 例如，可能需要设置/proc/sys/vm/compact_memory或类似参数
            self.logger.info(f"Set compaction_proactiveness to {value} (simulated)")
            return True
        except Exception as e:
            self.logger.error(f"Error setting compaction_proactiveness: {e}")
            return False
    
    def get_normalized_state(self):
        """
        获取当前参数的归一化状态向量
        用于观察空间
        
        Returns:
            np.array: 归一化的参数值数组
        """
        params = self.get_current_parameters()
        norm_state = []
        
        for param, config in self.param_ranges.items():
            if param in params:
                # 将参数归一化到[-1, 1]范围
                min_val = config['min']
                max_val = config['max']
                value = params[param]
                norm_value = 2 * (value - min_val) / (max_val - min_val) - 1
                norm_state.append(norm_value)
            else:
                # 如果无法获取参数，使用0（中间值）
                norm_state.append(0)
        
        return np.array(norm_state)
    
    def get_agent_normalized_state(self, agent_id):
        """
        获取特定智能体负责的参数的归一化状态
        
        Args:
            agent_id: 智能体ID
            
        Returns:
            np.array: 该智能体参数的归一化值数组
        """
        params = self.get_current_parameters()
        norm_state = []
        
        # 获取该智能体负责的参数
        agent_params = self.agent_params.get(agent_id, [])
        
        for param in agent_params:
            if param in params and param in self.param_ranges:
                config = self.param_ranges[param]
                min_val = config['min']
                max_val = config['max']
                value = params[param]
                norm_value = 2 * (value - min_val) / (max_val - min_val) - 1
                norm_state.append(norm_value)
            else:
                norm_state.append(0)
        
        return np.array(norm_state)
    
    def apply_param_values(self, param_dict):
        """
        应用一组参数值
        
        Args:
            param_dict: 字典，参数名称和值的映射
            
        Returns:
            dict: 实际应用的参数值
        """
        return self.execute_action(param_dict)
    
    def validate_parameters(self, params):
        """
        验证参数值是否合法，并应用约束条件
        
        Args:
            params: 字典，参数名称和值的映射
            
        Returns:
            dict: 经过验证和调整后的参数值
        """
        # 克隆参数字典，避免修改原字典
        validated = params.copy()
        
        # 基本范围验证
        for param, value in validated.items():
            if param in self.param_ranges:
                param_range = self.param_ranges[param]
                if param_range['type'] == int:
                    value = int(round(value))
                value = max(param_range['min'], min(value, param_range['max']))
                validated[param] = value
        
        # 应用参数约束
        current_params = self.get_current_parameters()
        # 合并当前参数和新参数，确保约束条件检查能访问所有需要的参数
        all_params = {**current_params, **validated}
        
        # 检查并应用所有约束
        changes_made = True
        while changes_made:
            changes_made = False
            for constraint in self.param_constraints:
                # 检查是否有所有需要的参数
                if all(p in all_params for p in constraint['params']):
                    # 检查约束条件是否满足
                    if not constraint['condition'](all_params):
                        # 应用修复函数
                        fixes = constraint['fix'](all_params)
                        # 更新参数
                        for param, value in fixes.items():
                            if param in validated:  # 只更新即将设置的参数
                                validated[param] = value
                                all_params[param] = value
                                changes_made = True
        
        # 特殊处理：确保dirty_ratio > dirty_background_ratio
        if 'dirty_ratio' in validated and 'dirty_background_ratio' in validated:
            if validated['dirty_ratio'] <= validated['dirty_background_ratio']:
                validated['dirty_ratio'] = validated['dirty_background_ratio'] + 1
                self.logger.info(f"Adjusted dirty_ratio to {validated['dirty_ratio']} to maintain consistency")
        elif 'dirty_ratio' in validated and 'dirty_background_ratio' in current_params:
            if validated['dirty_ratio'] <= current_params['dirty_background_ratio']:
                validated['dirty_ratio'] = current_params['dirty_background_ratio'] + 1
                self.logger.info(f"Adjusted dirty_ratio to {validated['dirty_ratio']} to maintain consistency with current dirty_background_ratio")
        elif 'dirty_background_ratio' in validated and 'dirty_ratio' in current_params:
            if current_params['dirty_ratio'] <= validated['dirty_background_ratio']:
                validated['dirty_background_ratio'] = current_params['dirty_ratio'] - 1
                self.logger.info(f"Adjusted dirty_background_ratio to {validated['dirty_background_ratio']} to maintain consistency with current dirty_ratio")
        
        return validated
    
    def get_parameter_dimensions(self):
        """
        返回参数空间总维度
        
        Returns:
            int: 参数数量
        """
        return len(self.param_ranges)
    
    def get_agent_parameter_dimensions(self, agent_id):
        """
        返回特定智能体的参数空间维度
        
        Args:
            agent_id: 智能体ID
            
        Returns:
            int: 该智能体负责的参数数量
        """
        if agent_id in self.agent_params:
            return len(self.agent_params[agent_id])
        return 0
    
    def get_agent_action_space(self, agent_id):
        """
        获取特定智能体的动作空间信息
        
        Args:
            agent_id: 智能体ID
            
        Returns:
            dict: 包含维度和参数名称的字典
        """
        if agent_id not in self.agent_params:
            return {'dim': 0, 'params': []}
            
        params = self.agent_params[agent_id]
        return {
            'dim': len(params),
            'params': params
        }
    
    def simulate_actions(self, actions_dict):
        """
        模拟多个智能体的动作，但不实际执行
        用于测试和调试
        
        Args:
            actions_dict: 字典，键为智能体ID，值为该智能体的动作数组
        
        Returns:
            dict: 会被设置的参数值
        """
        param_values = {}
        
        for agent_id, action in actions_dict.items():
            # 获取该智能体负责的参数
            if agent_id in self.agent_params:
                agent_param_values = self._convert_agent_action_to_param_values(agent_id, action)
                param_values.update(agent_param_values)
        
        # 验证参数，但不执行
        return self.validate_parameters(param_values)
