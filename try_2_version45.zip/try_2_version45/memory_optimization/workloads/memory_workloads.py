"""
内存相关工作负载模块 - 针对3.5GB可用内存优化
"""
import random
import time
import psutil
import logging

# 配置日志
logger = logging.getLogger('MultiAgentMemoryEnv')

class MemoryWorkload:
    # 定义难度等级
    DIFFICULTY_LEVELS = ["easy", "medium", "hard", "extreme"]
    
    def __init__(self):
        self.total_memory = psutil.virtual_memory().total / (1024 * 1024)  # 总内存(MB)
        self.update_memory_info()
        logger.debug(f"系统总内存: {self.total_memory:.0f}MB, 可用内存: {self.available_memory:.0f}MB")
    
    def update_memory_info(self):
        """更新当前内存信息"""
        memory = psutil.virtual_memory()
        self.available_memory = memory.available / (1024 * 1024)  # 可用内存(MB)
        self.used_percent = memory.percent
    
    def calculate_safe_memory(self, difficulty=None):
        """
        计算安全的内存分配量，结合总内存和可用内存
        """
        self.update_memory_info()
        
        # 基于可用内存的目标范围
        if difficulty == "easy":
            min_percent, max_percent = 20, 30  # 可用内存的20-30%
        elif difficulty == "medium":
            min_percent, max_percent = 35, 45  # 可用内存的35-45%
        elif difficulty == "hard":
            min_percent, max_percent = 50, 60  # 可用内存的50-60%
        elif difficulty == "extreme":
            min_percent, max_percent = 65, 75  # 可用内存的65-75%
        else:
            min_percent, max_percent = 20, 30  # 默认为easy
        
        # 计算目标值范围 (MB)
        min_size = int(self.available_memory * min_percent / 100)
        max_size = int(self.available_memory * max_percent / 100)
        
        # 添加安全检查，确保至少保留500MB可用内存
        safe_limit = self.available_memory - 500
        if max_size > safe_limit:
            max_size = int(safe_limit) if safe_limit > 0 else min_size
            if min_size > max_size:
                min_size = max_size
        
        # 随机选择范围内的值
        if min_size >= max_size:
            size_mb = min_size
        else:
            size_mb = random.randint(min_size, max_size)
        
        logger.debug(f"难度: {difficulty}, 分配内存: {size_mb}MB (可用内存的{size_mb/self.available_memory*100:.1f}%)")
        return size_mb
    
    def run_memory_intensive(self, difficulty=None):
        """
        内存密集型工作负载
        """
        start_time = time.time()
        
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 计算安全的内存分配量
        size_mb = self.calculate_safe_memory(difficulty)
        
        try:
            # 创建大数组并访问它
            data = bytearray(size_mb * 1024 * 1024)
            
            # 根据难度调整随机读写操作次数
            operations = {
                "easy": 8000,
                "medium": 15000,
                "hard": 25000,
                "extreme": 40000
            }
            
            # 随机读写操作
            for i in range(operations[difficulty]):
                index = random.randint(0, len(data) - 1)
                data[index] = 1
            
            # 释放内存
            del data
            
            runtime = time.time() - start_time
            logger.info(f"Workload: memory_intensive, Difficulty: {difficulty}, Runtime: {runtime}s")
            return difficulty, size_mb
            
        except MemoryError as e:
            logger.warning(f"内存分配失败，降低难度并重试...")
            
            # 如果分配失败，尝试更低难度
            if difficulty == "extreme":
                return self.run_memory_intensive("hard")
            elif difficulty == "hard":
                return self.run_memory_intensive("medium")
            elif difficulty == "medium":
                return self.run_memory_intensive("easy")
            else:
                logger.warning("即使在easy难度下也无法分配内存，放弃...")
                return difficulty, 0
    
    def parallel_memory_allocations(self, difficulty=None):
        """
        并发内存分配测试
        """
        import multiprocessing
        start_time = time.time()
        
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 更新内存信息
        self.update_memory_info()
        
        # 根据难度确定进程数
        if difficulty == "easy":
            num_processes = 3
            percent_per_process = 8
        elif difficulty == "medium":
            num_processes = 4
            percent_per_process = 10
        elif difficulty == "hard":
            num_processes = 5
            percent_per_process = 12
        elif difficulty == "extreme":
            num_processes = 6
            percent_per_process = 14
        
        # 计算每个进程的内存分配范围
        mem_per_process = int(self.available_memory * percent_per_process / 100)
        min_size = int(mem_per_process * 0.8)
        max_size = int(mem_per_process * 1.2)
        
        def worker():
            """工作进程函数：分配并操作内存块"""
            size_mb = random.randint(min_size, max_size)
            try:
                data = bytearray(size_mb * 1024 * 1024)
                # 根据难度调整随机访问次数
                ops = {
                    "easy": 800,
                    "medium": 1500,
                    "hard": 3000,
                    "extreme": 5000
                }
                # 随机访问
                for _ in range(ops[difficulty]):
                    index = random.randint(0, len(data) - 1)
                    data[index] = 1
                time.sleep(3 if difficulty == "easy" else 5)
            except MemoryError:
                pass
        
        # 创建多个工作进程
        procs = [multiprocessing.Process(target=worker) for _ in range(num_processes)]
        for p in procs:
            p.start()
        
        # 等待所有进程完成
        for p in procs:
            p.join()
        
        runtime = time.time() - start_time
        logger.info(f"Workload: parallel_memory, Difficulty: {difficulty}, Runtime: {runtime}s")
        return difficulty, num_processes
    
    def memory_fragmentation_test(self, difficulty=None):
        """
        内存碎片测试
        """
        start_time = time.time()
        
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 更新内存信息
        self.update_memory_info()
        
        # 根据难度级别确定内存块数量和可用内存百分比
        if difficulty == "easy":
            num_blocks = 80
            mem_percent = 25
        elif difficulty == "medium":
            num_blocks = 120
            mem_percent = 40
        elif difficulty == "hard":
            num_blocks = 160
            mem_percent = 55
        elif difficulty == "extreme":
            num_blocks = 200
            mem_percent = 70
        
        # 计算每个块的平均大小
        total_allocation = int(self.available_memory * mem_percent / 100)
        avg_block_size = total_allocation / num_blocks
        
        # 计算最小和最大块大小
        min_size_mb = max(1, int(avg_block_size * 0.5))
        max_size_mb = int(avg_block_size * 1.5)
        
        try:
            # 创建多个不同大小的内存块
            blocks = []
            actual_allocated = 0
            for i in range(num_blocks):
                size_mb = random.randint(min_size_mb, max_size_mb)
                size = size_mb * 1024 * 1024  # 转换为字节
                blocks.append(bytearray(size))
                actual_allocated += size_mb
            
            # 释放一半的块
            for i in range(0, len(blocks), 2):
                blocks[i] = None
            
            # 重新分配一些块
            realloc_blocks = {
                "easy": 20,
                "medium": 40,
                "hard": 60,
                "extreme": 90
            }
            
            additional_allocated = 0
            for _ in range(realloc_blocks[difficulty]):
                size_mb = random.randint(min_size_mb, max_size_mb)
                size = size_mb * 1024 * 1024
                blocks.append(bytearray(size))
                additional_allocated += size_mb
            
            # 最后释放所有块
            blocks.clear()
            
            runtime = time.time() - start_time
            logger.info(f"Workload: memory_fragmentation, Difficulty: {difficulty}, Runtime: {runtime}s")
            return difficulty, num_blocks
            
        except MemoryError:
            logger.warning("内存分配失败，清理所有块并退出测试")
            blocks = []  # 清空所有块
            
            # 如果是高难度，尝试较低难度
            if difficulty != "easy":
                lower_difficulty = {
                    "extreme": "hard",
                    "hard": "medium",
                    "medium": "easy"
                }
                return self.memory_fragmentation_test(lower_difficulty[difficulty])
            return difficulty, 0

    def maintain_pressure(self, duration_seconds=60, percent=30):
        """
        在完成主要负载后维持系统压力
        """
        start_time = time.time()
        self.update_memory_info()
        
        # 创建一个中等大小的内存块
        pressure_size_mb = int(self.available_memory * percent / 100)
        
        try:
            pressure_data = bytearray(pressure_size_mb * 1024 * 1024)
            
            # 每10秒访问一次内存，确保它不被释放
            iterations = duration_seconds // 10
            for i in range(iterations):
                # 访问内存
                for j in range(0, len(pressure_data), 4096):
                    pressure_data[j] = 1
                time.sleep(10)
            
            # 释放内存
            del pressure_data
            
            runtime = time.time() - start_time
            logger.info(f"Workload: pressure_maintenance, Duration: {duration_seconds}s, Runtime: {runtime}s")
        except MemoryError:
            logger.warning("无法分配足够内存来维持压力")
    
    def run_intensive_sequence(self):
        """执行一系列连续的高强度工作负载"""
        start_time = time.time()
        logger.debug("开始执行连续高强度工作负载序列...")
        
        try:
            # 第一阶段：内存密集型
            self.run_memory_intensive("hard")
            
            # 不完全释放压力
            self.maintain_pressure(30, 30)
            
            # 第二阶段：内存碎片化
            self.memory_fragmentation_test("hard")
            
            # 继续保持压力
            self.maintain_pressure(30, 25)
            
            # 第三阶段：并行内存分配
            self.parallel_memory_allocations("medium")
            
            # 最终阶段：极端测试（如果内存状况允许）
            self.update_memory_info()
            if self.available_memory > 2000:
                self.run_memory_intensive("extreme")
            
            runtime = time.time() - start_time
            logger.info(f"Workload: intensive_sequence, Runtime: {runtime}s")
            
        except Exception as e:
            logger.error(f"执行过程中出错: {e}")
