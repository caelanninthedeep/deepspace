"""
I/O相关工作负载模块 - 针对页面缓存和内存回收优化
"""
import os
import random
import time
import mmap
import subprocess
import psutil
import logging

# 配置日志
logger = logging.getLogger('MultiAgentMemoryEnv')

class IOWorkload:
    # 定义难度等级
    DIFFICULTY_LEVELS = ["easy", "medium", "hard", "extreme"]
    
    def __init__(self):
        self.temp_root = "/tmp/rl_mem_test"
        os.makedirs(self.temp_root, exist_ok=True)
        # 获取系统内存信息
        self.update_memory_info()
    
    def update_memory_info(self):
        """更新当前内存信息"""
        memory = psutil.virtual_memory()
        self.total_memory = memory.total / (1024 * 1024)  # 总内存(MB)
        self.available_memory = memory.available / (1024 * 1024)  # 可用内存(MB)
        self.used_percent = memory.percent
        self.buffer_cache = (psutil.virtual_memory().buffers + 
                            psutil.virtual_memory().cached) / (1024 * 1024)  # 缓冲与缓存(MB)
        
        logger.debug(f"系统总内存: {self.total_memory:.0f}MB, 可用内存: {self.available_memory:.0f}MB, 缓冲/缓存: {self.buffer_cache:.0f}MB")
    
    def run_io_intensive(self, difficulty=None):
        """
        I/O密集型工作负载
        """
        start_time = time.time()
        
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 更新内存信息
        self.update_memory_info()
        
        # 根据难度级别和可用内存确定文件数量和大小
        if difficulty == "easy":
            num_files = random.randint(5, 10)
            file_size_percent = 10
            read_operations = 50
        elif difficulty == "medium":
            num_files = random.randint(8, 15)
            file_size_percent = 15
            read_operations = 100
        elif difficulty == "hard":
            num_files = random.randint(12, 18)
            file_size_percent = 20
            read_operations = 200
        elif difficulty == "extreme":
            num_files = random.randint(15, 20)
            file_size_percent = 25
            read_operations = 300
        
        # 计算文件大小，但设置上限以避免过大
        file_size_mb = int(self.available_memory * file_size_percent / 100)
        max_size = 500  # 最大文件大小500MB
        file_size_mb = min(file_size_mb, max_size)
        
        # 计算总IO操作量
        total_io_mb = file_size_mb * num_files
        
        # 创建临时文件夹
        temp_dir = os.path.join(self.temp_root, f"io_test_{difficulty}")
        os.makedirs(temp_dir, exist_ok=True)
        
        logger.debug(f"难度: {difficulty}, 创建 {num_files} 个文件，每个 {file_size_mb}MB, 总IO量: {total_io_mb}MB")
        
        # 创建文件
        files = []
        try:
            for i in range(num_files):
                filename = f"{temp_dir}/test_file_{i}.dat"
                
                # 分块写入大文件，以减轻内存压力
                with open(filename, 'wb') as f:
                    chunk_size = 10 * 1024 * 1024  # 10MB块
                    remaining = file_size_mb * 1024 * 1024
                    while remaining > 0:
                        write_size = min(chunk_size, remaining)
                        f.write(os.urandom(write_size))
                        remaining -= write_size
                
                files.append(filename)
                
                # 每创建3个文件检查一次内存状态
                if (i + 1) % 3 == 0:
                    self.update_memory_info()
                    if self.available_memory < 1000:  # 少于1GB可用内存时减少文件数量
                        logger.debug("可用内存不足，减少文件数量")
                        num_files = i + 1
                        break
            
            # 随机读取文件，增加页面缓存压力
            for i in range(read_operations):
                filename = random.choice(files)
                filesize = os.path.getsize(filename)
                
                with open(filename, 'rb') as f:
                    # 随机读取多个位置，增加缓存压力
                    for _ in range(3):  # 每次操作读取3个位置
                        pos = random.randint(0, filesize - 102400)  # 确保可以读取100KB
                        f.seek(pos)
                        _ = f.read(102400)  # 读取100KB
            
            # 在清理文件前更新内存信息
            self.update_memory_info()
            
        except Exception as e:
            logger.error(f"I/O密集型工作负载错误: {e}")
        finally:
            # 清理文件
            for filename in files:
                try:
                    os.remove(filename)
                except Exception:
                    pass
            
            try:
                os.rmdir(temp_dir)
            except Exception:
                pass
        
        runtime = time.time() - start_time
        logger.info(f"Workload: io_intensive, Difficulty: {difficulty}, Runtime: {runtime}s")
        return difficulty, len(files), file_size_mb
    
    def run_file_cache_intensive(self, difficulty=None):
        """
        文件缓存密集型工作负载 - 创建大量小文件填充文件缓存
        """
        start_time = time.time()
        
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 更新内存信息
        self.update_memory_info()
        
        # 根据难度级别确定文件数量和内容大小
        if difficulty == "easy":
            num_files = random.randint(500, 1000)
            content_size = 4096  # 每个文件4KB
            access_percent = 60
            reaccess_percent = 30
        elif difficulty == "medium":
            num_files = random.randint(1000, 2000)
            content_size = 8192  # 每个文件8KB
            access_percent = 70
            reaccess_percent = 40
        elif difficulty == "hard":
            num_files = random.randint(2000, 3000)
            content_size = 16384  # 每个文件16KB
            access_percent = 80
            reaccess_percent = 50
        elif difficulty == "extreme":
            num_files = random.randint(3000, 5000)
            content_size = 32768  # 每个文件32KB
            access_percent = 90
            reaccess_percent = 60
        
        # 计算总文件大小
        total_size_mb = num_files * content_size / (1024 * 1024)
        
        # 确保总文件大小不超过可用内存的80%
        max_size_mb = self.available_memory * 0.8
        if total_size_mb > max_size_mb:
            # 如果超过，减少文件数量
            num_files = int(max_size_mb * 1024 * 1024 / content_size)
            total_size_mb = num_files * content_size / (1024 * 1024)
            logger.debug(f"调整文件数量以适应可用内存: {num_files} 文件")
        
        # 计算实际要访问的文件数
        access_ops = int(num_files * access_percent / 100)
        reaccess_ops = int(num_files * reaccess_percent / 100)
        
        temp_dir = os.path.join(self.temp_root, f"cache_test_{difficulty}")
        os.makedirs(temp_dir, exist_ok=True)
        
        logger.debug(f"难度: {difficulty}, 创建 {num_files} 个小文件, 总大小: {total_size_mb:.2f}MB")
        
        # 生成随机内容
        contents = []
        for _ in range(10):  # 创建10种不同内容
            contents.append(os.urandom(content_size))
        
        try:
            # 创建文件
            filenames = []
            for i in range(num_files):
                filename = f"{temp_dir}/small_file_{i}.dat"
                with open(filename, 'wb') as f:
                    f.write(random.choice(contents))
                filenames.append(filename)
            
            # 随机访问文件
            accessed = set()
            for i in range(access_ops):
                filename = random.choice(filenames)
                with open(filename, 'rb') as f:
                    _ = f.read()
                accessed.add(filename)
            
            # 清理一半的文件
            to_remove = num_files // 2
            
            for filename in random.sample(filenames, to_remove):
                try:
                    os.remove(filename)
                    filenames.remove(filename)
                except Exception:
                    pass
            
            # 再次随机访问剩余文件
            for i in range(reaccess_ops):
                if filenames:  # 确保还有文件可访问
                    filename = random.choice(filenames)
                    with open(filename, 'rb') as f:
                        _ = f.read()
            
            # 更新内存信息，显示缓存变化
            self.update_memory_info()
            
        except Exception as e:
            logger.error(f"文件缓存工作负载错误: {e}")
        finally:
            # 清理所有文件
            for filename in filenames:
                try:
                    os.remove(filename)
                except Exception:
                    pass
            
            try:
                os.rmdir(temp_dir)
            except Exception:
                pass
        
        runtime = time.time() - start_time
        logger.info(f"Workload: file_cache_intensive, Difficulty: {difficulty}, Runtime: {runtime}s")
        return difficulty, num_files
    
    def mmap_test(self, difficulty=None):
        """
        mmap文件模拟测试 - 使用内存映射文件增加页面缓存压力
        """
        start_time = time.time()
        
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 更新内存信息
        self.update_memory_info()
        
        # 根据难度级别和可用内存确定mmap文件大小和操作次数
        if difficulty == "easy":
            file_size_percent = 25
            operations_factor = 10000
        elif difficulty == "medium":
            file_size_percent = 40
            operations_factor = 15000
        elif difficulty == "hard":
            file_size_percent = 60
            operations_factor = 20000
        elif difficulty == "extreme":
            file_size_percent = 80
            operations_factor = 30000
        
        # 计算文件大小，但设置上限和下限
        file_size_mb = int(self.available_memory * file_size_percent / 100)
        file_size_mb = max(50, min(file_size_mb, 2000))  # 最小50MB，最大2GB
        
        # 操作次数基于文件大小
        operations = file_size_mb * operations_factor // 1000
        
        logger.debug(f"难度: {difficulty}, mmap访问 {file_size_mb}MB 文件, 执行 {operations} 次操作")
        
        mmap_file = os.path.join(self.temp_root, f"mmap_test_{difficulty}")
        
        try:
            # 分块创建大文件
            with open(mmap_file, "wb") as f:
                chunk_size = 50 * 1024 * 1024  # 50MB块
                remaining = file_size_mb * 1024 * 1024
                while remaining > 0:
                    write_size = min(chunk_size, remaining)
                    f.write(b'\x00' * write_size)
                    remaining -= write_size
            
            # 使用内存映射访问文件
            with open(mmap_file, "r+b") as f:
                # 获取文件大小
                file_size = os.path.getsize(mmap_file)
                
                # 映射整个文件
                mm = mmap.mmap(f.fileno(), 0)
                
                # 随机访问文件的不同位置
                page_size = 4096  # 假设页面大小为4KB
                pages = file_size // page_size
                
                for i in range(operations):
                    # 随机选择一个页面并修改其中一个字节
                    page = random.randint(0, pages - 1)
                    offset = page * page_size + random.randint(0, page_size - 1)
                    if offset < file_size:
                        mm[offset] = b'\x01'[0]
                
                # 确保修改被写回文件系统
                mm.flush()
                mm.close()
            
            # 更新内存状态
            self.update_memory_info()
            
        except Exception as e:
            logger.error(f"mmap测试错误: {e}")
        finally:
            # 清理文件
            try:
                os.remove(mmap_file)
            except Exception:
                pass
        
        runtime = time.time() - start_time
        logger.info(f"Workload: mmap_test, Difficulty: {difficulty}, Runtime: {runtime}s")
        return difficulty, file_size_mb
    
    def drop_caches(self):
        """清除文件系统缓存"""
        logger.debug("清除文件系统缓存...")
        try:
            # 先同步，确保所有待写数据都写入磁盘
            subprocess.run(['sudo', 'sync'], check=True)
            
            # 清除页面缓存、dentries和inodes
            subprocess.run(['sudo', 'bash', '-c', 'echo 3 > /proc/sys/vm/drop_caches'], 
                           check=True)
            
            # 更新并显示内存状态变化
            before = self.buffer_cache
            self.update_memory_info()
            after = self.buffer_cache
            
            logger.debug(f"缓存清除前后: {before:.0f}MB -> {after:.0f}MB (减少 {before-after:.0f}MB)")
            return True
            
        except subprocess.CalledProcessError as e:
            logger.error(f"清除缓存出错: {e}")
            return False
    
    def run_sequential_io(self, difficulty=None):
        """
        顺序I/O测试 - 创建大文件并顺序读取
        """
        start_time = time.time()
        
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 更新内存信息
        self.update_memory_info()
        
        # 根据难度级别和可用内存确定文件大小
        if difficulty == "easy":
            file_size_percent = 30
            read_passes = 2
        elif difficulty == "medium":
            file_size_percent = 45
            read_passes = 3
        elif difficulty == "hard":
            file_size_percent = 60
            read_passes = 4
        elif difficulty == "extreme":
            file_size_percent = 75
            read_passes = 5
        
        # 计算文件大小，但设置上限
        file_size_mb = int(self.available_memory * file_size_percent / 100)
        max_size = 1500  # 最大1.5GB
        file_size_mb = min(file_size_mb, max_size)
        
        logger.debug(f"难度: {difficulty}, 创建 {file_size_mb}MB 文件, 顺序读取 {read_passes} 次")
        
        seq_file = os.path.join(self.temp_root, f"seq_io_test_{difficulty}")
        
        try:
            # 创建大文件
            with open(seq_file, "wb") as f:
                chunk_size = 50 * 1024 * 1024  # 50MB块
                remaining = file_size_mb * 1024 * 1024
                while remaining > 0:
                    write_size = min(chunk_size, remaining)
                    f.write(os.urandom(write_size))
                    remaining -= write_size
            
            # 顺序读取文件多次
            for pass_num in range(read_passes):
                with open(seq_file, "rb") as f:
                    chunk_size = 10 * 1024 * 1024  # 10MB块
                    bytes_read = 0
                    total_size = file_size_mb * 1024 * 1024
                    
                    while bytes_read < total_size:
                        data = f.read(chunk_size)
                        if not data:
                            break
                        bytes_read += len(data)
                
                # 每次读取后检查一次内存状态
                self.update_memory_info()
            
        except Exception as e:
            logger.error(f"顺序IO测试错误: {e}")
        finally:
            # 清理文件
            try:
                os.remove(seq_file)
            except Exception:
                pass
        
        runtime = time.time() - start_time
        logger.info(f"Workload: sequential_io, Difficulty: {difficulty}, Runtime: {runtime}s")
        return difficulty, file_size_mb
    
    def run_mixed_io_pattern(self, duration_seconds=60, difficulty=None):
        """
        混合IO模式 - 模拟真实工作负载
        """
        start_time = time.time()
        
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 更新内存信息
        self.update_memory_info()
        
        # 根据难度确定参数
        if difficulty == "easy":
            num_small_files = 200
            num_medium_files = 10
            large_file_size_mb = int(self.available_memory * 0.2)
            small_file_size_kb = 8
            medium_file_size_mb = 5
        elif difficulty == "medium":
            num_small_files = 500
            num_medium_files = 20
            large_file_size_mb = int(self.available_memory * 0.3)
            small_file_size_kb = 16
            medium_file_size_mb = 10
        elif difficulty == "hard":
            num_small_files = 1000
            num_medium_files = 30
            large_file_size_mb = int(self.available_memory * 0.4)
            small_file_size_kb = 32
            medium_file_size_mb = 20
        elif difficulty == "extreme":
            num_small_files = 2000
            num_medium_files = 40
            large_file_size_mb = int(self.available_memory * 0.5)
            small_file_size_kb = 64
            medium_file_size_mb = 30
        
        # 限制大文件大小
        large_file_size_mb = min(large_file_size_mb, 1000)  # 最大1GB
        
        logger.debug(f"难度: {difficulty}, 运行混合IO: {num_small_files}个小文件, {num_medium_files}个中型文件, 1个大文件({large_file_size_mb}MB)")
        
        # 创建临时目录
        mixed_dir = os.path.join(self.temp_root, f"mixed_io_{difficulty}")
        os.makedirs(mixed_dir, exist_ok=True)
        
        files = []  # 跟踪所有创建的文件
        
        try:
            # 创建大文件
            large_file = f"{mixed_dir}/large_file.dat"
            
            with open(large_file, "wb") as f:
                chunk_size = 50 * 1024 * 1024  # 50MB块
                remaining = large_file_size_mb * 1024 * 1024
                while remaining > 0:
                    write_size = min(chunk_size, remaining)
                    f.write(b'\x00' * write_size)
                    remaining -= write_size
            
            files.append(large_file)
            
            # 创建中型文件
            for i in range(num_medium_files):
                filename = f"{mixed_dir}/medium_file_{i}.dat"
                with open(filename, "wb") as f:
                    f.write(os.urandom(medium_file_size_mb * 1024 * 1024))
                files.append(filename)
            
            # 创建小文件
            for i in range(num_small_files):
                filename = f"{mixed_dir}/small_file_{i}.dat"
                with open(filename, "wb") as f:
                    f.write(os.urandom(small_file_size_kb * 1024))
                files.append(filename)
                
                # 每创建200个小文件检查一次内存状态
                if (i + 1) % 200 == 0:
                    self.update_memory_info()
            
            # 执行混合IO操作直到达到指定时间
            operations_done = 0
            
            while time.time() - start_time < duration_seconds:
                # 随机选择操作类型
                op_type = random.choice(["read_small", "read_medium", "read_large", 
                                       "write_small", "write_medium"])
                
                if op_type == "read_small" and num_small_files > 0:
                    # 读取一个随机小文件
                    file_idx = random.randint(num_medium_files + 1, len(files) - 1)
                    with open(files[file_idx], "rb") as f:
                        _ = f.read()
                
                elif op_type == "read_medium" and num_medium_files > 0:
                    # 读取一个随机中型文件的部分内容
                    file_idx = random.randint(1, num_medium_files)
                    with open(files[file_idx], "rb") as f:
                        f.seek(random.randint(0, medium_file_size_mb * 1024 * 1024 - 102400))
                        _ = f.read(102400)  # 读取100KB
                
                elif op_type == "read_large":
                    # 读取大文件的一部分
                    with open(large_file, "rb") as f:
                        f.seek(random.randint(0, large_file_size_mb * 1024 * 1024 - 1024*1024))
                        _ = f.read(1024*1024)  # 读取1MB
                
                elif op_type == "write_small":
                    # 更新一个随机小文件
                    file_idx = random.randint(num_medium_files + 1, len(files) - 1)
                    with open(files[file_idx], "r+b") as f:
                        f.write(os.urandom(small_file_size_kb * 1024))
                
                elif op_type == "write_medium":
                    # 更新一个随机中型文件的部分内容
                    file_idx = random.randint(1, num_medium_files)
                    with open(files[file_idx], "r+b") as f:
                        f.seek(random.randint(0, medium_file_size_mb * 1024 * 1024 - 102400))
                        f.write(os.urandom(102400))  # 写入100KB
                
                operations_done += 1
                
                # 每200次操作更新一次内存状态
                if operations_done % 200 == 0:
                    self.update_memory_info()
            
            # 最终内存状态更新
            self.update_memory_info()
            
        except Exception as e:
            logger.error(f"混合IO测试错误: {e}")
        finally:
            # 清理所有文件
            for filename in files:
                try:
                    os.remove(filename)
                except Exception:
                    pass
            
            try:
                os.rmdir(mixed_dir)
            except Exception:
                pass
        
        runtime = time.time() - start_time
        logger.info(f"Workload: mixed_io_pattern, Difficulty: {difficulty}, Runtime: {runtime}s, Operations: {operations_done}")
        return difficulty
