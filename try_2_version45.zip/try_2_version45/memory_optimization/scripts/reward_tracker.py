import numpy as np
import matplotlib.pyplot as plt
import pickle
import os
import traceback
from datetime import datetime
import pandas as pd
from collections import defaultdict

class RewardTracker:
    def __init__(self, save_dir='./training_logs'):
        # 创建保存目录
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
        self.save_dir = save_dir
        
        # 初始化记录容器
        self.episode_rewards = []  # 每个episode的总奖励
        self.agent_rewards = {}  # 每个智能体的奖励
        self.moving_avg_rewards = []  # 奖励移动平均
        self.runtime_history = []  # 运行时间历史
        self.improvement_history = []  # 性能改进百分比
        self.workload_types = []  # 工作负载类型
        self.difficulty_levels = []  # 难度级别
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # 新增: 智能体特定指标记录 - 使用嵌套的defaultdict
        # 结构: agent_metrics[agent_id][episode_idx][metric_name] = value
        self.agent_metrics = defaultdict(lambda: defaultdict(dict))
        
    def add_record(self, episode, rewards_dict, global_reward, runtime, prev_runtime, workload_type, difficulty):
        """添加一条记录"""
        try:
            # 记录奖励
            self.episode_rewards.append(global_reward)
            
            # 记录每个智能体的奖励
            for agent_id, reward in rewards_dict.items():
                if agent_id not in self.agent_rewards:
                    self.agent_rewards[agent_id] = []
                self.agent_rewards[agent_id].append(reward)
            
            # 计算移动平均（最近50个episode）
            window = min(50, len(self.episode_rewards))
            if window > 0:
                self.moving_avg_rewards.append(np.mean(self.episode_rewards[-window:]))
            else:
                self.moving_avg_rewards.append(0)  # 防止空列表
            
            # 记录运行时间
            self.runtime_history.append(runtime)
            
            # 记录工作负载信息
            self.workload_types.append(workload_type)
            self.difficulty_levels.append(difficulty)
            
            # 计算性能改进
            if prev_runtime is not None and prev_runtime > 0:
                improvement = (prev_runtime - runtime) / prev_runtime * 100
            else:
                improvement = 0
            self.improvement_history.append(improvement)
            
            # 定期保存和可视化
            if len(self.episode_rewards) % 100 == 0:
                self.save_data()
                self.plot_progress(episode)
                
        except Exception as e:
            print(f"添加记录时出错: {e}")
            traceback.print_exc()
    
    def add_agent_metrics(self, episode, agent_id, metrics):
        """
        添加智能体特定指标
        
        Args:
            episode: 回合编号
            agent_id: 智能体ID
            metrics: 指标字典，如 {'reclaimed_pages_per_sec': 123, 'kswapd_cpu_usage': 45}
        """
        try:
            # 确保episode索引存在（episode从1开始，索引从0开始）
            ep_idx = episode - 1
            
            # 直接将指标添加到字典中（不需要append）
            for metric_name, value in metrics.items():
                self.agent_metrics[agent_id][ep_idx][metric_name] = value
                
        except Exception as e:
            print(f"添加智能体指标时出错: {e}")
            traceback.print_exc()
            
    def get_agent_metrics_stats(self, agent_id, n_episodes=10):
        """获取智能体最近N回合的指标统计"""
        try:
            if agent_id not in self.agent_metrics:
                return {}
                
            # 获取所有episode索引，按降序排列（最新的在前）
            episode_indices = sorted(self.agent_metrics[agent_id].keys(), reverse=True)
            
            # 只取最近的n_episodes个
            recent_indices = episode_indices[:n_episodes]
            
            # 收集所有指标名称
            all_metrics = set()
            for ep_idx in recent_indices:
                all_metrics.update(self.agent_metrics[agent_id][ep_idx].keys())
                
            # 计算每个指标的统计信息
            stats = {}
            for metric_name in all_metrics:
                values = []
                for ep_idx in recent_indices:
                    if metric_name in self.agent_metrics[agent_id][ep_idx]:
                        values.append(self.agent_metrics[agent_id][ep_idx][metric_name])
                        
                if values:
                    stats[metric_name] = {
                        'mean': np.mean(values),
                        'min': np.min(values),
                        'max': np.max(values),
                        'std': np.std(values) if len(values) > 1 else 0
                    }
            
            return stats
            
        except Exception as e:
            print(f"获取智能体指标统计时出错: {e}")
            traceback.print_exc()
            return {}
            
    def save_data(self):
        """保存记录数据"""
        try:
            data = {
                'episode_rewards': self.episode_rewards,
                'agent_rewards': self.agent_rewards,
                'moving_avg_rewards': self.moving_avg_rewards,
                'runtime_history': self.runtime_history,
                'improvement_history': self.improvement_history,
                'workload_types': self.workload_types,
                'difficulty_levels': self.difficulty_levels,
                'agent_metrics': {agent_id: dict(episodes) for agent_id, episodes in self.agent_metrics.items()}
            }
            
            filename = f"{self.save_dir}/training_data_{self.timestamp}_ep{len(self.episode_rewards)}.pkl"
            with open(filename, 'wb') as f:
                pickle.dump(data, f)
                
            # 也保存CSV格式便于查看
            df = pd.DataFrame({
                'episode': range(1, len(self.episode_rewards) + 1),
                'global_reward': self.episode_rewards,
                'moving_avg_reward': self.moving_avg_rewards,
                'runtime': self.runtime_history,
                'improvement': self.improvement_history,
                'workload_type': self.workload_types,
                'difficulty': self.difficulty_levels
            })
            
            for agent_id, rewards in self.agent_rewards.items():
                # 确保长度一致，可能需要填充
                if len(rewards) < len(self.episode_rewards):
                    rewards = rewards + [None] * (len(self.episode_rewards) - len(rewards))
                df[f'{agent_id}_reward'] = rewards
            
            # 新增: 添加智能体指标到数据框
            for agent_id, episodes_data in self.agent_metrics.items():
                # 找出所有指标名
                all_metrics = set()
                for ep_data in episodes_data.values():
                    all_metrics.update(ep_data.keys())
                    
                # 为每个指标创建列
                for metric_name in all_metrics:
                    column_name = f'{agent_id}_{metric_name}'
                    values = []
                    
                    # 填充所有行
                    for ep_idx in range(len(self.episode_rewards)):
                        if ep_idx in episodes_data and metric_name in episodes_data[ep_idx]:
                            values.append(episodes_data[ep_idx][metric_name])
                        else:
                            values.append(None)
                    
                    df[column_name] = values
                
            df.to_csv(f"{self.save_dir}/training_data_{self.timestamp}.csv", index=False)
            print(f"成功保存训练数据 (Episode {len(self.episode_rewards)})")
            
        except Exception as e:
            print(f"保存数据时出错: {e}")
            traceback.print_exc()
            
    def plot_progress(self, episode):
        """绘制训练进度图"""
        try:
            plt.figure(figsize=(15, 10))
            
            # 绘制总奖励
            plt.subplot(2, 2, 1)
            if len(self.episode_rewards) > 0:
                plt.plot(self.episode_rewards, alpha=0.3, color='blue', label='Episode Reward')
                plt.plot(self.moving_avg_rewards, linewidth=2, color='red', label='Moving Avg (50 ep)')
                plt.title('Reward History')
                plt.xlabel('Episode')
                plt.ylabel('Reward')
                plt.legend()
                plt.grid(True, linestyle='--', alpha=0.5)
            else:
                plt.text(0.5, 0.5, 'No reward data available', 
                        horizontalalignment='center', verticalalignment='center',
                        transform=plt.gca().transAxes)
            
            # 绘制每个智能体的奖励
            plt.subplot(2, 2, 2)
            has_agent_data = False
            for agent_id, rewards in self.agent_rewards.items():
                if len(rewards) > 0:
                    has_agent_data = True
                    # 计算每个智能体的移动平均
                    agent_window = min(50, len(rewards))
                    agent_moving_avg = [np.mean(rewards[max(0, i-agent_window):i+1]) 
                                      for i in range(len(rewards))]
                    plt.plot(agent_moving_avg, label=f'{agent_id}')
            
            if has_agent_data:
                plt.title('Agent Rewards (Moving Avg)')
                plt.xlabel('Episode')
                plt.ylabel('Reward')
                plt.legend()
                plt.grid(True, linestyle='--', alpha=0.5)
            else:
                plt.text(0.5, 0.5, 'No agent reward data available', 
                        horizontalalignment='center', verticalalignment='center',
                        transform=plt.gca().transAxes)
            
            # 绘制运行时间
            plt.subplot(2, 2, 3)
            if len(self.runtime_history) > 0:
                # 按难度级别区分颜色
                difficulty_colors = {'easy': 'green', 'medium': 'blue', 'hard': 'orange', 'extreme': 'red'}
                unique_difficulties = set(self.difficulty_levels)
                
                for diff in unique_difficulties:
                    indices = [i for i, d in enumerate(self.difficulty_levels) if d == diff]
                    if indices:  # 确保有数据
                        plt.scatter([i for i in indices], 
                                  [self.runtime_history[i] for i in indices],
                                  alpha=0.5, label=diff, 
                                  color=difficulty_colors.get(diff, 'gray'))
                
                # 添加移动平均线
                window = min(50, len(self.runtime_history))
                runtime_moving_avg = [np.mean(self.runtime_history[max(0, i-window):i+1]) 
                                    for i in range(len(self.runtime_history))]
                plt.plot(runtime_moving_avg, color='black', linewidth=2, label='Moving Avg')
                
                plt.title('Runtime History')
                plt.xlabel('Episode')
                plt.ylabel('Runtime (s)')
                plt.legend()
                plt.grid(True, linestyle='--', alpha=0.5)
            else:
                plt.text(0.5, 0.5, 'No runtime data available', 
                        horizontalalignment='center', verticalalignment='center',
                        transform=plt.gca().transAxes)
            
            # 绘制性能改进百分比
            plt.subplot(2, 2, 4)
            if len(self.improvement_history) > 0:
                plt.plot(self.improvement_history, alpha=0.3, color='green')
                
                # 添加移动平均线
                window = min(50, len(self.improvement_history))
                improvement_moving_avg = [np.mean(self.improvement_history[max(0, i-window):i+1]) 
                                        for i in range(len(self.improvement_history))]
                plt.plot(improvement_moving_avg, linewidth=2, color='darkgreen', label='Moving Avg')
                
                plt.axhline(y=0, color='r', linestyle='-', alpha=0.3)
                plt.title('Performance Improvement')
                plt.xlabel('Episode')
                plt.ylabel('Improvement (%)')
                plt.legend()
                plt.grid(True, linestyle='--', alpha=0.5)
            else:
                plt.text(0.5, 0.5, 'No improvement data available', 
                        horizontalalignment='center', verticalalignment='center',
                        transform=plt.gca().transAxes)
            
            plt.tight_layout()
            plt.savefig(f"{self.save_dir}/training_progress_{self.timestamp}_ep{episode}.png")
            
            # 新增: 如果有内存回收指标，绘制额外图表
            self._plot_memory_reclaim_metrics(episode)
            
            plt.close()
            print(f"成功生成训练进度图 (Episode {episode})")
            
        except Exception as e:
            print(f"绘制进度图时出错: {e}")
            traceback.print_exc()
            plt.close()  # 确保关闭图形
    
    def _plot_memory_reclaim_metrics(self, episode):
        """绘制内存回收指标图表"""
        try:
            # 检查是否有内存回收指标数据
            if 'memory_reclaim' not in self.agent_metrics or not self.agent_metrics['memory_reclaim']:
                return
                
            # 确定所有可用指标
            all_metrics = set()
            for ep_data in self.agent_metrics['memory_reclaim'].values():
                all_metrics.update(ep_data.keys())
                
            # 只有当有数据时才绘图
            if not all_metrics:
                return
                
            # 创建新的图表
            plt.figure(figsize=(15, 10))
            
            # 为每个指标准备数据
            metrics_data = {metric: {} for metric in all_metrics}
            
            for ep_idx, ep_data in self.agent_metrics['memory_reclaim'].items():
                for metric in all_metrics:
                    if metric in ep_data:
                        metrics_data[metric][ep_idx] = ep_data[metric]
            
            # 按照类型组织图表
            reclaimed_pages_metrics = [m for m in all_metrics if 'page' in m]
            cpu_usage_metrics = [m for m in all_metrics if 'cpu' in m]
            ratio_metrics = [m for m in all_metrics if 'ratio' in m]
            other_metrics = [m for m in all_metrics if m not in reclaimed_pages_metrics and 
                            m not in cpu_usage_metrics and m not in ratio_metrics]
            
            # 绘制页面回收指标
            if reclaimed_pages_metrics:
                plt.subplot(2, 2, 1)
                for metric in reclaimed_pages_metrics:
                    data = metrics_data[metric]
                    x_values = sorted(data.keys())
                    y_values = [data[x] for x in x_values]
                    plt.plot(x_values, y_values, label=metric)
                
                plt.title('Page Reclamation Metrics')
                plt.xlabel('Episode')
                plt.ylabel('Pages/sec')
                plt.legend()
                plt.grid(True, linestyle='--', alpha=0.5)
            
            # 绘制CPU使用率指标
            if cpu_usage_metrics:
                plt.subplot(2, 2, 2)
                for metric in cpu_usage_metrics:
                    data = metrics_data[metric]
                    x_values = sorted(data.keys())
                    y_values = [data[x] for x in x_values]
                    plt.plot(x_values, y_values, label=metric)
                
                plt.title('CPU Usage Metrics')
                plt.xlabel('Episode')
                plt.ylabel('CPU %')
                plt.legend()
                plt.grid(True, linestyle='--', alpha=0.5)
            
            # 绘制比率指标
            if ratio_metrics:
                plt.subplot(2, 2, 3)
                for metric in ratio_metrics:
                    data = metrics_data[metric]
                    x_values = sorted(data.keys())
                    y_values = [data[x] for x in x_values]
                    plt.plot(x_values, y_values, label=metric)
                
                plt.title('Ratio Metrics')
                plt.xlabel('Episode')
                plt.ylabel('Ratio')
                plt.legend()
                plt.grid(True, linestyle='--', alpha=0.5)
            
            # 绘制其他指标
            if other_metrics:
                plt.subplot(2, 2, 4)
                for metric in other_metrics:
                    data = metrics_data[metric]
                    x_values = sorted(data.keys())
                    y_values = [data[x] for x in x_values]
                    plt.plot(x_values, y_values, label=metric)
                
                plt.title('Other Memory Reclaim Metrics')
                plt.xlabel('Episode')
                plt.ylabel('Value')
                plt.legend()
                plt.grid(True, linestyle='--', alpha=0.5)
            
            plt.tight_layout()
            plt.savefig(f"{self.save_dir}/memory_reclaim_metrics_{self.timestamp}_ep{episode}.png")
            plt.close()
            print(f"成功生成内存回收指标图表 (Episode {episode})")
            
        except Exception as e:
            print(f"绘制内存回收指标图表时出错: {e}")
            traceback.print_exc()
            plt.close()  # 确保关闭图形
            
    def check_convergence(self, window=200, threshold=0.01):
        """检查模型是否收敛"""
        try:
            if len(self.moving_avg_rewards) < window * 2:
                return False, 0
                
            # 比较最近两个窗口的平均奖励
            recent_window = np.mean(self.moving_avg_rewards[-window:])
            previous_window = np.mean(self.moving_avg_rewards[-2*window:-window])
            
            # 计算相对变化
            if abs(previous_window) > 1e-6:  # 避免除以零
                relative_change = abs(recent_window - previous_window) / abs(previous_window)
            else:
                relative_change = abs(recent_window - previous_window)
                
            # 如果变化小于阈值，认为已收敛
            is_converged = relative_change < threshold
            
            return is_converged, relative_change
            
        except Exception as e:
            print(f"检查收敛时出错: {e}")
            traceback.print_exc()
            return False, 1.0  # 返回默认值

    def print_summary(self, episode):
        """打印训练摘要"""
        try:
            print(f"\n===== Training Summary (Episode {episode}) =====")
            
            # 处理奖励数据
            print(f"Recent rewards (last {min(50, len(self.episode_rewards))} episodes):")
            if len(self.episode_rewards) > 0:
                window = min(50, len(self.episode_rewards))
                recent_rewards = self.episode_rewards[-window:]
                print(f"  Mean: {np.mean(recent_rewards):.4f}")
                print(f"  Min: {np.min(recent_rewards):.4f}")
                print(f"  Max: {np.max(recent_rewards):.4f}")
            else:
                print("  No reward data available")
            
            # 处理改进数据
            print(f"Recent improvements (last {min(50, len(self.improvement_history))} episodes):")
            if len(self.improvement_history) > 0:
                window = min(50, len(self.improvement_history))
                recent_improvements = self.improvement_history[-window:]
                print(f"  Mean: {np.mean(recent_improvements):.2f}%")
                print(f"  Min: {np.min(recent_improvements):.2f}%")
                print(f"  Max: {np.max(recent_improvements):.2f}%")
            else:
                print("  No improvement data available")
            
            # 按智能体打印奖励
            print("\nPer-agent recent rewards:")
            for agent_id, rewards in self.agent_rewards.items():
                if len(rewards) > 0:
                    window = min(50, len(rewards))
                    recent = rewards[-window:]
                    print(f"  {agent_id} - Mean: {np.mean(recent):.4f}, Min: {np.min(recent):.4f}, Max: {np.max(recent):.4f}")
                else:
                    print(f"  {agent_id} - No data available")
            
            # 新增: 打印内存回收指标统计
            if 'memory_reclaim' in self.agent_metrics and self.agent_metrics['memory_reclaim']:
                metrics_stats = self.get_agent_metrics_stats('memory_reclaim', n_episodes=50)
                if metrics_stats:
                    print("\nMemory reclaim metrics (last 50 episodes):")
                    for metric_name, stats in metrics_stats.items():
                        print(f"  {metric_name} - Mean: {stats['mean']:.2f}, Max: {stats['max']:.2f}")
            
            # 检查收敛情况
            if len(self.moving_avg_rewards) >= 400:
                converged, change = self.check_convergence()
                print(f"\nConvergence check: {'Converged' if converged else 'Not converged'} (change: {change:.4f})")
            else:
                needed = 400 - len(self.moving_avg_rewards)
                print(f"\nConvergence check: Need {needed} more episodes (total of 400) for convergence analysis")
            
            print("="*40)
            
        except Exception as e:
            print(f"打印摘要时出错: {e}")
            traceback.print_exc()
            print("="*40)
