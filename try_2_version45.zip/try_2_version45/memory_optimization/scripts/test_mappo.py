#!/usr/bin/env python3

"""
MAPPO内存管理系统测试脚本 - 测试MAPPO多智能体在内存管理任务上的性能
支持模型加载、性能评估与基线比较
"""

import os
import sys
import time
import json
import argparse
import traceback
from datetime import datetime
from collections import defaultdict
import numpy as np
import torch
import matplotlib.pyplot as plt


# 导入必要的模块
from ..environment.mem_env import MultiAgentMemoryEnv
from ..algorithms.network import MAPPONetworkManager, PageCacheNetwork, MemoryReclaimNetwork, MemorySchedulerNetwork
from ..algorithms.mappo1 import MAPPO


# 屏蔽matplotlib警告
import warnings
warnings.filterwarnings("ignore", category=UserWarning, module="matplotlib")


class MAPPOTester:
    """MAPPO多智能体内存管理系统测试器"""
    
    def __init__(self, model_dir, output_dir=None, verbose=True, device=None):
        """
        初始化MAPPO测试器
        
        Args:
            model_dir (str): 包含智能体模型文件的目录路径
            output_dir (str, optional): 输出结果的目录路径
            verbose (bool): 是否输出详细信息
            device (str, optional): 计算设备 ('cuda' 或 'cpu')
        """
        self.model_dir = model_dir
        self.output_dir = output_dir or os.path.join(model_dir, 'test_results')
        self.verbose = verbose
        
        # 确保输出目录存在
        os.makedirs(self.output_dir, exist_ok=True)
        
        # 设置设备
        self.device = device or ('cuda' if torch.cuda.is_available() else 'cpu')
        self.device = torch.device(self.device)
        
        # 创建日志文件
        self.log_file = os.path.join(self.output_dir, f'test_log_{datetime.now().strftime("%Y%m%d_%H%M%S")}.txt')
        
        # 初始化环境和网络
        self.env = None
        self.network_manager = None
        
        # 记录测试指标
        self.metrics = defaultdict(list)
        self.baseline_metrics = defaultdict(list)
        
        # 初始化
        self._setup_logger()
        self._setup_matplotlib()
        self._log(f"MAPPO测试器初始化, 设备: {self.device}")
        self._log(f"模型目录: {model_dir}")
        self._log(f"输出目录: {self.output_dir}")
        
        # 加载环境和模型
        self._initialize_environment()
        self._initialize_models()
    
    def _setup_logger(self):
        """设置日志记录器"""
        import logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(self.log_file),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger('MAPPOTester')
    
    def _setup_matplotlib(self):
        """设置matplotlib以解决中文字体和时间显示问题"""
        try:
            # 检查系统是否有中文字体
            from matplotlib.font_manager import FontProperties, findfont
            
            # 常见中文字体列表
            chinese_fonts = [
                'SimHei', 'Microsoft YaHei', 'WenQuanYi Micro Hei',
                'Noto Sans CJK SC', 'Noto Sans CJK TC', 'Source Han Sans CN'
            ]
            
            font_found = False
            for font in chinese_fonts:
                try:
                    font_path = findfont(FontProperties(family=font))
                    if font_path and 'DejaVu' not in font_path:
                        plt.rcParams['font.family'] = ['sans-serif']
                        plt.rcParams['font.sans-serif'] = [font] + plt.rcParams['font.sans-serif']
                        plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
                        self.use_chinese_labels = True
                        self._log(f"找到并使用中文字体: {font}")
                        font_found = True
                        break
                except:
                    continue
            
            if not font_found:
                self._log("未找到中文字体，将使用英文标签", 'warning')
                self.use_chinese_labels = False
        except Exception as e:
            self._log(f"配置中文字体失败，将使用英文标签: {e}", 'warning')
            self.use_chinese_labels = False
    
    def _log(self, message, level='info'):
        """记录日志信息"""
        if hasattr(self, 'logger'):
            if level == 'info':
                self.logger.info(message)
            elif level == 'error':
                self.logger.error(message)
            elif level == 'warning':
                self.logger.warning(message)
        else:
            print(message)
    
    def _initialize_environment(self):
        """初始化测试环境"""
        try:
            self._log("初始化内存管理环境...")
            self.env = MultiAgentMemoryEnv()
            
            # 获取环境信息
            self.agent_ids = getattr(self.env, 'agent_ids', ['page_cache', 'memory_reclaim', 'memory_scheduler'])
            
            # 处理观察空间和动作空间
            if hasattr(self.env, 'observation_space'):
                obs_space = self.env.observation_space
                if hasattr(obs_space, 'spaces') and isinstance(obs_space.spaces, dict):
                    # Dict空间格式
                    self.obs_dims = {agent_id: obs_space.spaces[agent_id].shape[0] 
                                   for agent_id in self.agent_ids if agent_id in obs_space.spaces}
                elif isinstance(obs_space, dict):
                    # 字典格式
                    self.obs_dims = {agent_id: obs_space[agent_id].shape[0] 
                                   for agent_id in self.agent_ids if agent_id in obs_space}
                else:
                    # Box格式 - 单一观察空间，需要分配给不同智能体
                    if hasattr(obs_space, 'shape'):
                        # 默认给所有智能体相同的观察维度
                        self.obs_dims = {agent_id: obs_space.shape[0] for agent_id in self.agent_ids}
                        self._log(f"使用相同的观察维度: {obs_space.shape[0]} 为所有智能体")
                    else:
                        # 无法确定观察维度，使用默认值
                        self.obs_dims = {agent_id: 64 for agent_id in self.agent_ids}
                        self._log(f"无法确定观察维度，使用默认值: 64")
            else:
                # 如果没有observation_space属性，使用默认值
                self.obs_dims = {agent_id: 64 for agent_id in self.agent_ids}
                self._log(f"环境没有observation_space属性，使用默认值: 64")
            
            # 类似地处理动作空间
            if hasattr(self.env, 'action_space'):
                act_space = self.env.action_space
                if hasattr(act_space, 'spaces') and isinstance(act_space.spaces, dict):
                    # Dict空间格式
                    self.action_dims = {agent_id: act_space.spaces[agent_id].shape[0] 
                                      for agent_id in self.agent_ids if agent_id in act_space.spaces}
                elif isinstance(act_space, dict):
                    # 字典格式
                    self.action_dims = {agent_id: act_space[agent_id].shape[0] 
                                      for agent_id in self.agent_ids if agent_id in act_space}
                else:
                    # Box格式 - 单一动作空间
                    if hasattr(act_space, 'shape'):
                        # 默认给所有智能体相同的动作维度
                        self.action_dims = {agent_id: act_space.shape[0] for agent_id in self.agent_ids}
                        self._log(f"使用相同的动作维度: {act_space.shape[0]} 为所有智能体")
                    else:
                        # 无法确定动作维度，使用默认值
                        self.action_dims = {agent_id: 3 for agent_id in self.agent_ids}
                        self._log(f"无法确定动作维度，使用默认值: 3")
            else:
                # 如果没有action_space属性，使用默认值
                self.action_dims = {agent_id: 3 for agent_id in self.agent_ids}
                self._log(f"环境没有action_space属性，使用默认值: 3")
                
            # 手动覆盖维度信息，使用模型的实际维度
            self.obs_dims = {
                'page_cache': 13,       # 从模型文件分析得出
                'memory_reclaim': 20,   # 从模型文件分析得出
                'memory_scheduler': 12  # 从模型文件分析得出
            }
            self.action_dims = {
                'page_cache': 3,        # 从模型文件分析得出
                'memory_reclaim': 2,    # 从模型文件分析得出
                'memory_scheduler': 2   # 从模型文件分析得出
            }
            self._log("手动设置维度信息:")
            self._log(f"观察维度: {self.obs_dims}")
            self._log(f"动作维度: {self.action_dims}")
            
            # 设置默认工作负载和难度属性（如果环境未定义）
            if not hasattr(self.env, 'current_workload_type'):
                self.env.current_workload_type = 'memory_intensive'  # 设置一个默认值
            if not hasattr(self.env, 'current_difficulty'):
                self.env.current_difficulty = 'medium'  # 设置一个默认值
            
            self._log(f"环境初始化成功, 智能体: {self.agent_ids}")
            
        except Exception as e:
            self._log(f"环境初始化失败: {e}", 'error')
            traceback.print_exc()
            raise
    
    def _extract_model_dims(self, model_files):
        """从模型文件中提取观察和动作维度信息"""
        obs_dims = {}
        action_dims = {}
        
        for agent_id in self.agent_ids:
            if agent_id not in model_files:
                continue
                
            try:
                file_path = model_files[agent_id]
                checkpoint = torch.load(file_path, map_location=self.device)
                
                # 新格式模型
                if isinstance(checkpoint, dict) and "state_dict" in checkpoint:
                    state_dict = checkpoint["state_dict"]
                    
                    # 从输入层提取观察维度
                    if "base.0.weight" in state_dict:
                        input_dim = state_dict["base.0.weight"].shape[1]
                        obs_dims[agent_id] = input_dim
                        self._log(f"从模型提取 {agent_id} 观察维度: {input_dim}")
                    elif "lstm.weight_ih_l0" in state_dict:
                        input_dim = state_dict["lstm.weight_ih_l0"].shape[1]
                        obs_dims[agent_id] = input_dim
                        self._log(f"从模型提取 {agent_id} 观察维度: {input_dim}")
                    elif "pressure_encoder.0.weight" in state_dict:
                        input_dim = state_dict["pressure_encoder.0.weight"].shape[1]
                        obs_dims[agent_id] = input_dim
                        self._log(f"从模型提取 {agent_id} 观察维度: {input_dim}")
                        
                    # 从输出层提取动作维度
                    if "actor_mean.bias" in state_dict:
                        output_dim = state_dict["actor_mean.bias"].shape[0]
                        action_dims[agent_id] = output_dim
                        self._log(f"从模型提取 {agent_id} 动作维度: {output_dim}")
                    elif "actor_std" in state_dict and len(state_dict["actor_std"].shape) > 0:
                        output_dim = state_dict["actor_std"].shape[0]
                        action_dims[agent_id] = output_dim
                        self._log(f"从模型提取 {agent_id} 动作维度: {output_dim}")
                
                # 旧格式模型 - 类似处理
                else:
                    state_dict = checkpoint
                    # 类似的提取逻辑...
                    
            except Exception as e:
                self._log(f"提取 {agent_id} 模型维度时出错: {e}", 'warning')
        
        return obs_dims, action_dims
    
    def _initialize_models(self):
        """初始化模型网络"""
        try:
            self._log("初始化网络模型...")
            
            # 检查必要的模型文件
            model_files = self._check_model_files()
            
            # 从模型文件提取维度信息
            model_obs_dims, model_action_dims = self._extract_model_dims(model_files)
            
            # 更新维度信息 - 优先使用模型维度，其次是已设置的维度
            for agent_id in self.agent_ids:
                if agent_id in model_obs_dims:
                    self.obs_dims[agent_id] = model_obs_dims[agent_id]
                if agent_id in model_action_dims:
                    self.action_dims[agent_id] = model_action_dims[agent_id]
            
            # 配置智能体网络
            agent_configs = {}
            for agent_id in self.agent_ids:
                agent_configs[agent_id] = {
                    'type': agent_id,
                    'obs_dim': self.obs_dims.get(agent_id, 64),
                    'action_dim': self.action_dims.get(agent_id, 3),
                    'hidden_dims': [128, 128]
                }
                
                # 为memory_scheduler添加LSTM配置
                if agent_id == 'memory_scheduler':
                    agent_configs[agent_id].update({
                        'lstm_hidden': 64,
                        'lstm_layers': 1
                    })
            
            # 输出最终使用的维度
            self._log("使用以下维度初始化网络:")
            self._log(f"观察维度: {self.obs_dims}")
            self._log(f"动作维度: {self.action_dims}")
            
            # 创建网络管理器
            self.network_manager = MAPPONetworkManager(
                agent_configs=agent_configs,
                use_centralized_critic=False,  # 测试时不需要中央化Critic
                device=self.device
            )
            
            # 加载模型权重
            self._load_model_weights(model_files)
            
            # 设置为评估模式
            for agent_id in self.agent_ids:
                self.network_manager.actor_networks[agent_id].eval()
            
            # 重置LSTM状态
            self.network_manager.reset_lstm_states()
            
            self._log("模型初始化成功")
            
        except Exception as e:
            self._log(f"模型初始化失败: {e}", 'error')
            traceback.print_exc()
            raise
    
    def _check_model_files(self):
        """检查模型文件是否存在"""
        # 检查标准文件命名模式
        standard_files = {
            'page_cache': "final_checkpoint_actor_page_cache.pth",
            'memory_reclaim': "final_checkpoint_actor_memory_reclaim.pth",
            'memory_scheduler': "final_checkpoint_actor_memory_scheduler.pth"
        }
        
        # 检查MAPPO保存格式
        mappo_files = {
            'page_cache': f"{self.model_dir}_actor_page_cache.pth",
            'memory_reclaim': f"{self.model_dir}_actor_memory_reclaim.pth",
            'memory_scheduler': f"{self.model_dir}_actor_memory_scheduler.pth"
        }
        
        # 检查元数据
        metadata_path = os.path.join(self.model_dir, "metadata.pth")
        mappo_metadata_path = f"{self.model_dir}_metadata.pth"
        
        # 优先使用标准文件
        result_files = {}
        for agent_id in self.agent_ids:
            standard_path = os.path.join(self.model_dir, standard_files.get(agent_id, f"final_checkpoint_actor_{agent_id}.pth"))
            mappo_path = mappo_files.get(agent_id, f"{self.model_dir}_actor_{agent_id}.pth")
            
            if os.path.exists(standard_path):
                result_files[agent_id] = standard_path
                self._log(f"找到智能体 {agent_id} 的标准模型文件: {standard_path}")
            elif os.path.exists(mappo_path):
                result_files[agent_id] = mappo_path
                self._log(f"找到智能体 {agent_id} 的MAPPO格式模型文件: {mappo_path}")
            else:
                # 尝试在目录中寻找包含该智能体名称的任何文件
                found = False
                for file in os.listdir(self.model_dir):
                    if agent_id in file and file.endswith('.pth'):
                        result_files[agent_id] = os.path.join(self.model_dir, file)
                        self._log(f"找到智能体 {agent_id} 的替代模型文件: {file}")
                        found = True
                        break
                
                if not found:
                    self._log(f"警告: 找不到智能体 {agent_id} 的模型文件，将跳过加载", 'warning')
        
        # 加载元数据（如果存在）
        if os.path.exists(metadata_path):
            result_files['metadata'] = metadata_path
            self._log(f"找到标准元数据文件: {metadata_path}")
        elif os.path.exists(mappo_metadata_path):
            result_files['metadata'] = mappo_metadata_path
            self._log(f"找到MAPPO元数据文件: {mappo_metadata_path}")
        
        return result_files
    
    def _load_model_weights(self, model_files):
        """加载模型权重"""
        # 首先尝试加载元数据获取更多信息
        if 'metadata' in model_files:
            try:
                metadata = torch.load(model_files['metadata'], map_location=self.device)
                self._log(f"加载元数据: {model_files['metadata']}")
                
                # 可能的元数据格式分析
                if isinstance(metadata, dict):
                    if "agent_ids" in metadata:
                        self._log(f"元数据中的智能体ID: {metadata['agent_ids']}")
                    if "use_centralized_critic" in metadata:
                        self._log(f"使用中央化Critic: {metadata['use_centralized_critic']}")
                    if "obs_dims" in metadata:
                        self._log(f"元数据中的观察维度: {metadata['obs_dims']}")
                        # 更新观察维度
                        for agent_id, dim in metadata["obs_dims"].items():
                            if agent_id in self.agent_ids:
                                self.obs_dims[agent_id] = dim
                                self._log(f"从元数据更新智能体 {agent_id} 的观察维度: {dim}")
                    if "action_dims" in metadata:
                        self._log(f"元数据中的动作维度: {metadata['action_dims']}")
                        # 更新动作维度
                        for agent_id, dim in metadata["action_dims"].items():
                            if agent_id in self.agent_ids:
                                self.action_dims[agent_id] = dim
                                self._log(f"从元数据更新智能体 {agent_id} 的动作维度: {dim}")
            except Exception as e:
                self._log(f"加载元数据失败: {e}", 'warning')
                traceback.print_exc()
        
        # 加载各智能体模型
        for agent_id in self.agent_ids:
            if agent_id not in model_files:
                self._log(f"跳过智能体 {agent_id}，未找到模型文件", 'warning')
                continue
                
            try:
                file_path = model_files[agent_id]
                self._log(f"加载智能体 {agent_id} 模型: {file_path}")
                
                checkpoint = torch.load(file_path, map_location=self.device)
                
                # 处理不同格式的模型文件
                if isinstance(checkpoint, dict) and "state_dict" in checkpoint:
                    # 新格式: 包含额外信息的字典
                    network_type = checkpoint.get("network_type", "未知")
                    self._log(f"智能体 {agent_id} 网络类型: {network_type}")
                    
                    # 处理LSTM特殊情况
                    network = self.network_manager.actor_networks[agent_id]
                    if "lstm_info" in checkpoint and hasattr(network, 'lstm_hidden'):
                        lstm_info = checkpoint["lstm_info"]
                        self._log(f"发现LSTM信息: {lstm_info}")
                        
                        # 初始化LSTM (如果需要)
                        if lstm_info.get("lstm_initialized", False) and not hasattr(network, 'lstm'):
                            dummy_input = torch.zeros(1, self.obs_dims[agent_id]).to(self.device)
                            with torch.no_grad():
                                _ = network(dummy_input)
                                self._log(f"已初始化LSTM网络")
                    
                    # 加载状态字典
                    try:
                        self.network_manager.actor_networks[agent_id].load_state_dict(
                            checkpoint["state_dict"], strict=False)
                        self._log(f"成功加载智能体 {agent_id} 模型 (新格式)")
                    except Exception as e:
                        self._log(f"加载状态字典失败 (非严格模式): {e}", 'warning')
                        # 尝试适应不同的键名
                        self._adapt_and_load_state_dict(self.network_manager.actor_networks[agent_id], 
                                                      checkpoint["state_dict"])
                        
                else:
                    # 旧格式: 直接是状态字典
                    try:
                        self.network_manager.actor_networks[agent_id].load_state_dict(
                            checkpoint, strict=False)
                        self._log(f"成功加载智能体 {agent_id} 模型 (旧格式)")
                    except Exception as e:
                        self._log(f"加载状态字典失败 (旧格式): {e}", 'warning')
                        # 尝试适应不同的键名
                        self._adapt_and_load_state_dict(self.network_manager.actor_networks[agent_id], 
                                                      checkpoint)
                
            except Exception as e:
                self._log(f"加载智能体 {agent_id} 模型失败: {e}", 'error')
                traceback.print_exc()
    
    def _adapt_and_load_state_dict(self, network, state_dict):
        """尝试适应不同的键名，加载状态字典"""
        try:
            # 获取网络当前状态字典
            target_dict = network.state_dict()
            
            # 创建新的状态字典，仅保留匹配的键
            matched_dict = {}
            
            # 直接匹配
            for key in target_dict:
                if key in state_dict:
                    # 检查形状是否匹配
                    if target_dict[key].shape == state_dict[key].shape:
                        matched_dict[key] = state_dict[key]
                    else:
                        self._log(f"形状不匹配，跳过: {key} (目标: {target_dict[key].shape}, 源: {state_dict[key].shape})")
            
            # 尝试通过键的部分匹配
            for target_key in target_dict:
                if target_key in matched_dict:
                    continue  # 已经匹配
                    
                # 查找包含相同部分名称的键
                for source_key in state_dict:
                    if source_key not in matched_dict.values():
                        # 检查键的最后一部分是否匹配
                        if source_key.split('.')[-1] == target_key.split('.')[-1]:
                            # 检查形状是否匹配
                            if state_dict[source_key].shape == target_dict[target_key].shape:
                                matched_dict[target_key] = state_dict[source_key]
                                self._log(f"键匹配: {source_key} -> {target_key}")
                                break
            
            # 加载匹配的状态字典
            if matched_dict:
                network.load_state_dict(matched_dict, strict=False)
                self._log(f"成功加载 {len(matched_dict)}/{len(target_dict)} 层参数")
            else:
                self._log("没有找到匹配的参数", 'warning')
                
        except Exception as e:
            self._log(f"适应性加载失败: {e}", 'error')
            traceback.print_exc()
    
    def select_actions(self, observations, deterministic=True):
        """
        为所有智能体选择动作
        
        Args:
            observations (dict 或 ndarray): 各智能体的观察，可能是字典或单一数组
            deterministic (bool): 是否使用确定性策略
            
        Returns:
            dict: 各智能体的动作
        """
        actions = {}
        
        try:
            with torch.no_grad():
                # 处理不同格式的观察
                if isinstance(observations, dict):
                    # 字典格式的观察
                    for agent_id in self.agent_ids:
                        if agent_id not in observations:
                            self._log(f"警告: 观察中缺少智能体 {agent_id}", 'warning')
                            continue
                        
                        # 转换观察为张量
                        obs = observations[agent_id]
                        if isinstance(obs, np.ndarray):
                            obs = torch.FloatTensor(obs).to(self.device)
                        elif not isinstance(obs, torch.Tensor):
                            obs = torch.FloatTensor([obs]).to(self.device)
                        
                        # 确保维度正确
                        if obs.dim() == 1:
                            obs = obs.unsqueeze(0)  # 添加批次维度
                        
                        try:
                            # 获取动作
                            action, log_prob, value = self.network_manager.get_action(
                                agent_id, 
                                obs,
                                deterministic=deterministic
                            )
                            
                            # 转换为numpy数组
                            if isinstance(action, torch.Tensor):
                                action = action.cpu().numpy()
                            
                            actions[agent_id] = action
                            
                        except Exception as e:
                            self._log(f"获取智能体 {agent_id} 动作时出错: {e}", 'error')
                            traceback.print_exc()
                            # 提供默认动作以继续测试
                            action_dim = self.action_dims.get(agent_id, 3)
                            actions[agent_id] = np.zeros(action_dim)
                else:
                    # 单一数组格式的观察，需要分配给各智能体
                    obs = observations
                    if isinstance(obs, np.ndarray):
                        obs = torch.FloatTensor(obs).to(self.device)
                    elif not isinstance(obs, torch.Tensor):
                        obs = torch.FloatTensor([obs]).to(self.device)
                    
                    # 确保维度正确
                    if obs.dim() == 1:
                        obs = obs.unsqueeze(0)  # 添加批次维度
                    
                    for agent_id in self.agent_ids:
                        try:
                            # 获取动作
                            action, log_prob, value = self.network_manager.get_action(
                                agent_id, 
                                obs,
                                deterministic=deterministic
                            )
                            
                            # 转换为numpy数组
                            if isinstance(action, torch.Tensor):
                                action = action.cpu().numpy()
                            
                            actions[agent_id] = action
                            
                        except Exception as e:
                            self._log(f"获取智能体 {agent_id} 动作时出错: {e}", 'error')
                            traceback.print_exc()
                            # 提供默认动作以继续测试
                            action_dim = self.action_dims.get(agent_id, 3)
                            actions[agent_id] = np.zeros(action_dim)
        except Exception as e:
            self._log(f"选择动作时出错: {e}", 'error')
            traceback.print_exc()
            # 为所有智能体提供默认动作
            for agent_id in self.agent_ids:
                action_dim = self.action_dims.get(agent_id, 3)
                actions[agent_id] = np.zeros(action_dim)
        
        return actions
    
    # 添加环境种子控制方法
    def _set_env_seed(self, seed):
        """设置环境随机种子"""
        try:
            # 首先尝试使用专用的seed方法
            if hasattr(self.env, 'seed'):
                self.env.seed(seed)
                self._log(f"使用环境seed方法设置随机种子: {seed}")
                return True
                
            # 否则检查reset方法是否支持seed参数
            import inspect
            if hasattr(self.env, 'reset'):
                reset_params = inspect.signature(self.env.reset).parameters
                if 'seed' in reset_params:
                    self._log(f"环境reset方法支持seed参数")
                    # seed将在reset时设置
                    return True
                    
            self._log("环境不支持随机种子控制，性能比较可能不一致", 'warning')
            return False
        except Exception as e:
            self._log(f"设置环境种子失败: {e}", 'error')
            return False
            
    # 添加验证种子控制有效性的方法
    def verify_seed_control(self, test_seed=42):
        """验证环境的随机种子控制是否有效"""
        self._log("\n===== 验证随机种子控制有效性 =====")
        
        # 第一次运行
        if hasattr(self.env, 'seed'):
            self.env.seed(test_seed)
            observations1 = self.env.reset()
        else:
            observations1 = self.env.reset(seed=test_seed)
            
        workload1 = getattr(self.env, 'current_workload_type', None)
        difficulty1 = getattr(self.env, 'current_difficulty', None)
        
        self._log(f"第一次运行: 工作负载={workload1}, 难度={difficulty1}")
        
        # 执行一个步骤
        actions = {}
        for agent_id in self.agent_ids:
            action_dim = self.action_dims.get(agent_id, 3)
            actions[agent_id] = np.zeros(action_dim)
            
        next_obs1, rewards1, dones1, info1 = self.env.step(actions)
        
        # 第二次运行（使用相同的种子）
        if hasattr(self.env, 'seed'):
            self.env.seed(test_seed)
            observations2 = self.env.reset()
        else:
            observations2 = self.env.reset(seed=test_seed)
            
        workload2 = getattr(self.env, 'current_workload_type', None)
        difficulty2 = getattr(self.env, 'current_difficulty', None)
        
        self._log(f"第二次运行: 工作负载={workload2}, 难度={difficulty2}")
        
        # 执行同样的步骤
        next_obs2, rewards2, dones2, info2 = self.env.step(actions)
        
        # 验证工作负载和难度是否一致
        workload_match = workload1 == workload2
        difficulty_match = difficulty1 == difficulty2
            
        self._log(f"工作负载匹配: {'✓' if workload_match else '✗'}")
        self._log(f"难度匹配: {'✓' if difficulty_match else '✗'}")
        
        is_seed_effective = workload_match and difficulty_match
        
        if is_seed_effective:
            self._log("✅ 种子控制有效，可以进行控制变量测试", 'info')
        else:
            self._log("❌ 种子控制无效，测试结果可能不可靠", 'warning')
            
        return is_seed_effective

    def test_performance(self, episodes=3, render=True, deterministic=True, max_steps=50, seeds=None):
        """
        测试MAPPO智能体的性能
        
        Args:
            episodes (int): 测试回合数
            render (bool): 是否渲染环境
            deterministic (bool): 是否使用确定性策略
            max_steps (int): 每个回合最大步数
            seeds (list): 可选的随机种子列表，用于控制环境随机性
            
        Returns:
            dict: 测试指标
        """
        self._log(f"\n===== 开始性能测试 ({episodes} 回合) =====")
        
        # 初始化测试指标 - 使用一维列表存储工作负载和难度
        metrics = {
            'episode_rewards': [],
            'episode_lengths': [],
            'episode_final_runtimes': [],
            'episode_measured_times': [],  # 添加测量的时间
            'workloads': [],              # 一维列表存储所有步骤的工作负载
            'difficulties': [],           # 一维列表存储所有步骤的难度
            'system_stats': [],
            'parameters': [],
            'actions': [],
            'rewards': [],
            'step_runtimes': [],
            'seeds': []  # 新增：记录使用的种子
        }
        
        # 测试回合
        for episode in range(1, episodes + 1):
            self._log(f"\n--- 回合 {episode}/{episodes} ---")
            
            # 重置环境和LSTM状态
            self.network_manager.reset_lstm_states()
            
            # 如果提供了种子，使用对应种子
            if seeds and episode <= len(seeds):
                seed = seeds[episode - 1]
                self._log(f"使用预定种子: {seed}")
                
                # 根据环境API选择正确的方式传递种子
                if hasattr(self.env, 'seed'):
                    self.env.seed(seed)
                    observations = self.env.reset()
                else:
                    observations = self.env.reset(seed=seed)
                
                # 记录使用的种子
                metrics['seeds'].append(seed)
            else:
                observations = self.env.reset()
                metrics['seeds'].append(None)  # 记录为None表示没有使用指定种子
            
            # 记录回合开始时间
            episode_start_time = time.time()
            
            # 记录回合数据
            episode_reward = 0
            episode_rewards = []
            episode_actions = []
            episode_parameters = []
            episode_system_stats = []
            episode_step_runtimes = []
            
            # 运行回合
            done = False
            step = 0
            
            while not done and step < max_steps:
                # 选择动作
                actions = self.select_actions(observations, deterministic)
                episode_actions.append(actions)
                
                # 执行动作
                try:
                    next_observations, rewards, dones, infos = self.env.step(actions)
                except Exception as e:
                    self._log(f"环境step方法出错: {e}", 'error')
                    traceback.print_exc()
                    break
                
                # 统一奖励（如果返回的是字典）
                if isinstance(rewards, dict):
                    reward = sum(rewards.values())  # 总奖励
                else:
                    reward = rewards
                
                episode_rewards.append(reward)
                
                # 统一完成状态
                if isinstance(dones, dict):
                    done = dones.get("__all__", False) or all(d for k, d in dones.items() if k != "__all__")
                else:
                    done = dones
                
                # 收集系统状态和运行时间
                step_stats = {}
                
                # 从info中提取数据
                if isinstance(infos, dict):
                    # 首先检查info的根级别获取关键信息 - 根据环境代码，这些应该位于根级别
                    workload_type = infos.get('workload_type', 'unknown')
                    difficulty = infos.get('difficulty', 'unknown')
                    runtime = infos.get('runtime', 0)
                    
                    # 参数信息
                    applied_params = {}
                    if 'applied_params' in infos:
                        applied_params = infos['applied_params']
                    else:
                        for agent_id in self.agent_ids:
                            if agent_id in infos and isinstance(infos[agent_id], dict) and 'applied_params' in infos[agent_id]:
                                applied_params[agent_id] = infos[agent_id]['applied_params']
                    
                    episode_parameters.append(applied_params)
                    
                    # 如果根级别没有关键信息，尝试从其他位置提取
                    if workload_type == 'unknown' or difficulty == 'unknown' or runtime == 0:
                        # 检查 __all__ 键
                        if '__all__' in infos and isinstance(infos['__all__'], dict):
                            all_info = infos['__all__']
                            if 'workload_type' in all_info and workload_type == 'unknown':
                                workload_type = all_info['workload_type']
                            if 'difficulty' in all_info and difficulty == 'unknown':
                                difficulty = all_info['difficulty']
                            if 'runtime' in all_info and runtime == 0:
                                runtime = all_info['runtime']
                        
                        # 如果仍未找到，检查每个智能体的信息
                        if workload_type == 'unknown' or difficulty == 'unknown' or runtime == 0:
                            for agent_id, agent_info in infos.items():
                                if agent_id == '__all__':
                                    continue
                                
                                if isinstance(agent_info, dict):
                                    if 'workload_type' in agent_info and workload_type == 'unknown':
                                        workload_type = agent_info['workload_type']
                                    if 'difficulty' in agent_info and difficulty == 'unknown':
                                        difficulty = agent_info['difficulty']
                                    if runtime == 0 and 'runtime' in agent_info:
                                        runtime += agent_info.get('runtime', 0)
                    
                    # 如果是第一个回合的第一步，添加详细调试日志
                    if episode == 1 and step == 0:
                        self._log(f"调试 - info 结构: {list(infos.keys())}")
                        self._log(f"调试 - 工作负载类型: {workload_type}, 难度: {difficulty}, 运行时间: {runtime}")
                        if '__all__' in infos:
                            self._log(f"调试 - __all__ 内容: {list(infos['__all__'].keys()) if isinstance(infos['__all__'], dict) else '非字典'}")
                        # 尝试输出第一个智能体的信息
                        if self.agent_ids and self.agent_ids[0] in infos:
                            agent_id = self.agent_ids[0]
                            self._log(f"调试 - {agent_id} 信息: {list(infos[agent_id].keys()) if isinstance(infos[agent_id], dict) else '非字典'}")
                    
                    # 保存提取到的信息
                    metrics['workloads'].append(workload_type)
                    metrics['difficulties'].append(difficulty)
                    episode_step_runtimes.append(runtime)
                    
                    # 提取系统统计信息
                    if 'system_stats' in infos:
                        step_stats = infos['system_stats']
                    elif '__all__' in infos and isinstance(infos['__all__'], dict) and 'system_stats' in infos['__all__']:
                        step_stats = infos['__all__']['system_stats']
                    else:
                        # 尝试从任何智能体获取系统统计
                        for agent_id, agent_info in infos.items():
                            if isinstance(agent_info, dict) and 'system_stats' in agent_info:
                                step_stats = agent_info['system_stats']
                                break
                    
                    # 如果没有系统统计，构建简单的统计
                    if not step_stats:
                        step_stats = {
                            'memory_usage_percent': infos.get('memory_usage_percent', 
                                                         infos.get('__all__', {}).get('memory_usage_percent', 0)),
                            'cpu_usage_percent': infos.get('cpu_usage_percent', 
                                                      infos.get('__all__', {}).get('cpu_usage_percent', 0)),
                            'swap_percent': infos.get('swap_percent', 
                                                 infos.get('__all__', {}).get('swap_percent', 0)),
                            'page_fault_rate': infos.get('page_fault_rate', 
                                                    infos.get('__all__', {}).get('page_fault_rate', 0))
                        }
                
                episode_system_stats.append(step_stats)

                # 渲染环境
                if render and hasattr(self.env, 'render') and step % 5 == 0:
                    try:
                        self.env.render()
                    except Exception as e:
                        self._log(f"渲染环境时出错: {e}", 'warning')
                
                # 记录步骤信息
                if self.verbose and (step % 5 == 0 or step == 0):
                    self._log(f"步骤 {step}: 奖励 = {reward:.2f}, 累计奖励 = {episode_reward + reward:.2f}")
                    self._log(f"  工作负载: {workload_type}, 难度: {difficulty}, 运行时间: {runtime:.2f}s")
                    
                    # 打印重要系统指标
                    if step_stats:
                        self._log(f"  内存使用率: {step_stats.get('memory_usage_percent', 0):.1f}%, "
                                 f"CPU使用率: {step_stats.get('cpu_usage_percent', 0):.1f}%, "
                                 f"交换分区: {step_stats.get('swap_percent', 0):.1f}%")
                
                # 更新状态和奖励
                observations = next_observations
                episode_reward += reward
                step += 1
            
            # 计算总回合时间
            episode_total_time = time.time() - episode_start_time
            
            # 记录回合指标
            metrics['episode_rewards'].append(episode_reward)
            metrics['episode_lengths'].append(step)
            metrics['rewards'].append(episode_rewards)
            metrics['actions'].append(episode_actions)
            metrics['parameters'].append(episode_parameters)
            metrics['system_stats'].append(episode_system_stats)
            metrics['step_runtimes'].append(episode_step_runtimes)
            
            # 记录总测量时间
            metrics['episode_measured_times'].append(episode_total_time)
            
            # 记录最终运行时间
            final_runtime = episode_step_runtimes[-1] if episode_step_runtimes else 0
            # 检查最终运行时间是否为0或太小
            if final_runtime <= 0.001 and len(episode_step_runtimes) > 1:
                # 如果为0或太小，使用累计运行时间作为替代
                cumulative_runtime = sum(episode_step_runtimes)
                # 如果累计仍然太小，使用测量时间
                if cumulative_runtime <= 0.001:
                    final_runtime = episode_total_time
                    self._log(f"注意: 最终和累计运行时间均太小，使用测量时间 {final_runtime:.6f}s 代替")
                else:
                    final_runtime = cumulative_runtime
                    self._log(f"注意: 最终运行时间太小，使用累计运行时间 {final_runtime:.6f}s 代替")
            
            metrics['episode_final_runtimes'].append(final_runtime)
            
            # 打印回合总结
            self._log(f"\n回合 {episode} 总结:")
            self._log(f"总奖励: {episode_reward:.2f}, 步数: {step}, 最终运行时间: {final_runtime:.6f}s")
            self._log(f"平均步奖励: {np.mean(episode_rewards):.2f}, 最大奖励: {np.max(episode_rewards) if episode_rewards else 0:.2f}")
            
            # 打印该回合的工作负载统计
            workload_counts = {}
            for wl in metrics['workloads'][-step:]:  # 只取当前回合添加的工作负载
                workload_counts[wl] = workload_counts.get(wl, 0) + 1
            self._log(f"当前回合工作负载统计: {workload_counts}")
            
            # 打印该回合的难度统计
            difficulty_counts = {}
            for d in metrics['difficulties'][-step:]:  # 只取当前回合添加的难度
                difficulty_counts[d] = difficulty_counts.get(d, 0) + 1
            self._log(f"当前回合难度统计: {difficulty_counts}")


        # 总结测试结果
        if metrics['episode_rewards']:
            avg_reward = np.mean(metrics['episode_rewards'])
            std_reward = np.std(metrics['episode_rewards'])
            self._log(f"平均回合奖励: {avg_reward:.2f} ± {std_reward:.2f}")
        
        if metrics['episode_final_runtimes']:
            avg_runtime = np.mean(metrics['episode_final_runtimes'])
            std_runtime = np.std(metrics['episode_final_runtimes'])
            self._log(f"平均最终运行时间: {avg_runtime:.6f}s ± {std_runtime:.6f}s")
        
        if metrics['episode_lengths']:
            self._log(f"平均回合长度: {np.mean(metrics['episode_lengths']):.1f} ± {np.std(metrics['episode_lengths']):.1f}")
        
        # 保存测试指标
        self._save_metrics(metrics, 'test_metrics.json')
        
        return metrics
    
    def test_baseline(self, episodes=3, render=False, max_steps=50, seeds=None):
        """
        测试基线策略（默认参数）
        
        Args:
            episodes (int): 测试回合数
            render (bool): 是否渲染环境
            max_steps (int): 每个回合最大步数
            seeds (list): 可选的随机种子列表，用于控制环境随机性
            
        Returns:
            dict: 测试指标
        """
        self._log(f"\n===== 开始基线测试 ({episodes} 回合) =====")
        
        # 初始化基线指标 - 使用一维列表存储工作负载和难度
        metrics = {
            'episode_rewards': [],
            'episode_lengths': [],
            'episode_final_runtimes': [],
            'episode_measured_times': [],  # 添加测量的时间
            'workloads': [],               # 一维列表存储所有步骤的工作负载
            'difficulties': [],            # 一维列表存储所有步骤的难度
            'system_stats': [],
            'parameters': [],
            'seeds': []  # 新增：记录使用的种子
        }
        
        # 重置环境以获取默认参数
        _ = self.env.reset()
        default_params = None
        if hasattr(self.env, 'action_handler') and hasattr(self.env.action_handler, 'get_default_parameters'):
            default_params = self.env.action_handler.get_default_parameters()
            self._log(f"使用默认参数: {default_params}")
        else:
            self._log("无法获取默认参数", 'warning')
        
        # 测试回合
        for episode in range(1, episodes + 1):
            self._log(f"\n--- 基线回合 {episode}/{episodes} ---")
            
            # 如果提供了种子，使用对应种子
            if seeds and episode <= len(seeds):
                seed = seeds[episode - 1]
                self._log(f"使用预定种子: {seed}")
                
                # 根据环境API选择正确的方式传递种子
                if hasattr(self.env, 'seed'):
                    self.env.seed(seed)
                    observations = self.env.reset()
                else:
                    observations = self.env.reset(seed=seed)
                
                # 记录使用的种子
                metrics['seeds'].append(seed)
            else:
                observations = self.env.reset()
                metrics['seeds'].append(None)  # 记录为None表示没有使用指定种子
            
            # 记录回合开始时间
            episode_start_time = time.time()
            
            # 如果有默认参数，重置为默认参数
            if default_params and hasattr(self.env, 'action_handler') and hasattr(self.env.action_handler, 'set_parameters'):
                self.env.action_handler.set_parameters(default_params)
                self._log("已重置为默认参数")
            
            # 记录回合数据
            episode_reward = 0
            episode_system_stats = []
            episode_step_runtimes = []
            
            # 运行回合
            done = False
            step = 0
            
            while not done and step < max_steps:
                # 对于基线，我们使用默认动作（全零）
                actions = {}
                for agent_id in self.agent_ids:
                    action_dim = self.action_dims.get(agent_id, 3)
                    actions[agent_id] = np.zeros(action_dim)
                
                # 执行动作
                try:
                    next_observations, rewards, dones, infos = self.env.step(actions)
                except Exception as e:
                    self._log(f"环境step方法出错: {e}", 'error')
                    traceback.print_exc()
                    break
                
                # 统一奖励
                if isinstance(rewards, dict):
                    reward = sum(rewards.values())
                else:
                    reward = rewards
                
                episode_reward += reward
                
                # 统一完成状态
                if isinstance(dones, dict):
                    done = dones.get("__all__", False) or all(d for k, d in dones.items() if k != "__all__")
                else:
                    done = dones
                
                # 收集系统状态和运行时间
                step_stats = {}
                
                # 从info中提取数据
                if isinstance(infos, dict):
                    # 首先检查info的根级别获取关键信息 - 根据环境代码，这些应该位于根级别
                    workload_type = infos.get('workload_type', 'unknown')
                    difficulty = infos.get('difficulty', 'unknown')
                    runtime = infos.get('runtime', 0)
                    
                    # 如果根级别没有关键信息，尝试从其他位置提取
                    if workload_type == 'unknown' or difficulty == 'unknown' or runtime == 0:
                        # 检查 __all__ 键
                        if '__all__' in infos and isinstance(infos['__all__'], dict):
                            all_info = infos['__all__']
                            if 'workload_type' in all_info and workload_type == 'unknown':
                                workload_type = all_info['workload_type']
                            if 'difficulty' in all_info and difficulty == 'unknown':
                                difficulty = all_info['difficulty']
                            if 'runtime' in all_info and runtime == 0:
                                runtime = all_info['runtime']
                        
                        # 如果仍未找到，检查每个智能体的信息
                        if workload_type == 'unknown' or difficulty == 'unknown' or runtime == 0:
                            for agent_id, agent_info in infos.items():
                                if agent_id == '__all__':
                                    continue
                                
                                if isinstance(agent_info, dict):
                                    if 'workload_type' in agent_info and workload_type == 'unknown':
                                        workload_type = agent_info['workload_type']
                                    if 'difficulty' in agent_info and difficulty == 'unknown':
                                        difficulty = agent_info['difficulty']
                                    if runtime == 0 and 'runtime' in agent_info:
                                        runtime += agent_info.get('runtime', 0)
                    
                    # 如果是第一个回合的第一步，添加详细调试日志
                    if episode == 1 and step == 0:
                        self._log(f"调试 - info 结构: {list(infos.keys())}")
                        self._log(f"调试 - 工作负载类型: {workload_type}, 难度: {difficulty}, 运行时间: {runtime}")
                        if '__all__' in infos:
                            self._log(f"调试 - __all__ 内容: {list(infos['__all__'].keys()) if isinstance(infos['__all__'], dict) else '非字典'}")
                    
                    # 保存提取到的信息
                    metrics['workloads'].append(workload_type)
                    metrics['difficulties'].append(difficulty)
                    episode_step_runtimes.append(runtime)
                    
                    # 提取系统统计信息
                    if 'system_stats' in infos:
                        step_stats = infos['system_stats']
                    elif '__all__' in infos and isinstance(infos['__all__'], dict) and 'system_stats' in infos['__all__']:
                        step_stats = infos['__all__']['system_stats']
                    else:
                        # 尝试从任何智能体获取系统统计
                        for agent_id, agent_info in infos.items():
                            if isinstance(agent_info, dict) and 'system_stats' in agent_info:
                                step_stats = agent_info['system_stats']
                                break
                    
                    episode_system_stats.append(step_stats)
                
                # 渲染环境
                if render and hasattr(self.env, 'render') and step % 5 == 0:
                    try:
                        self.env.render()
                    except Exception as e:
                        self._log(f"渲染环境时出错: {e}", 'warning')
                
                # 记录步骤信息
                if self.verbose and (step % 5 == 0 or step == 0):
                    self._log(f"步骤 {step}: 奖励 = {reward:.2f}, 累计奖励 = {episode_reward:.2f}")
                    self._log(f"  工作负载: {workload_type}, 难度: {difficulty}, 运行时间: {runtime:.2f}s")
                
                # 更新状态
                observations = next_observations
                step += 1
            
            # 计算总回合时间
            episode_total_time = time.time() - episode_start_time
            
            # 记录回合指标
            metrics['episode_rewards'].append(episode_reward)
            metrics['episode_lengths'].append(step)
            metrics['system_stats'].append(episode_system_stats)
            
            # 记录总测量时间
            metrics['episode_measured_times'].append(episode_total_time)
            
            # 记录最终运行时间
            final_runtime = episode_step_runtimes[-1] if episode_step_runtimes else 0
            # 检查最终运行时间是否为0或太小
            if final_runtime <= 0.001 and len(episode_step_runtimes) > 1:
                # 如果为0或太小，使用累计运行时间作为替代
                cumulative_runtime = sum(episode_step_runtimes)
                # 如果累计仍然太小，使用测量时间
                if cumulative_runtime <= 0.001:
                    final_runtime = episode_total_time
                    self._log(f"注意: 最终和累计运行时间均太小，使用测量时间 {final_runtime:.6f}s 代替")
                else:
                    final_runtime = cumulative_runtime
                    self._log(f"注意: 最终运行时间太小，使用累计运行时间 {final_runtime:.6f}s 代替")
            
            metrics['episode_final_runtimes'].append(final_runtime)
            
            # 打印回合总结
            self._log(f"\n基线回合 {episode} 总结:")
            self._log(f"总奖励: {episode_reward:.2f}, 步数: {step}, 最终运行时间: {final_runtime:.6f}s")
            
            # 打印该回合的工作负载统计
            workload_counts = {}
            for wl in metrics['workloads'][-step:]:  # 只取当前回合添加的工作负载
                workload_counts[wl] = workload_counts.get(wl, 0) + 1
            self._log(f"当前回合工作负载统计: {workload_counts}")
            
            # 打印该回合的难度统计
            difficulty_counts = {}
            for d in metrics['difficulties'][-step:]:  # 只取当前回合添加的难度
                difficulty_counts[d] = difficulty_counts.get(d, 0) + 1
            self._log(f"当前回合难度统计: {difficulty_counts}")
        
        # 总结测试结果
        if metrics['episode_rewards']:
            avg_reward = np.mean(metrics['episode_rewards'])
            std_reward = np.std(metrics['episode_rewards'])
            self._log(f"基线平均回合奖励: {avg_reward:.2f} ± {std_reward:.2f}")
        
        if metrics['episode_final_runtimes']:
            avg_runtime = np.mean(metrics['episode_final_runtimes'])
            std_runtime = np.std(metrics['episode_final_runtimes'])
            self._log(f"基线平均最终运行时间: {avg_runtime:.6f}s ± {std_runtime:.6f}s")
        
        # 保存基线指标
        self._save_metrics(metrics, 'baseline_metrics.json')
        
        # 保存基线指标作为类属性
        self.baseline_metrics = metrics
        
        return metrics
    
    def compare_performance(self, agent_metrics=None, baseline_metrics=None):
        """
        比较MAPPO和基线的性能
        
        Args:
            agent_metrics (dict, optional): MAPPO智能体的指标
            baseline_metrics (dict, optional): 基线的指标
            
        Returns:
            dict: 包含比较结果的字典
        """
        # 如果没有提供指标，使用已存在的数据
        agent_metrics = agent_metrics or getattr(self, 'metrics', {})
        baseline_metrics = baseline_metrics or getattr(self, 'baseline_metrics', {})
        
        # 检查数据是否存在
        if not agent_metrics or not baseline_metrics:
            self._log("缺少比较数据，请先运行test_performance和test_baseline", 'warning')
            return {}
        
        self._log("\n===== 性能比较：MAPPO vs 基线 =====")
        
        # 检查种子一致性
        if 'seeds' in agent_metrics and 'seeds' in baseline_metrics:
            agent_seeds = agent_metrics['seeds']
            baseline_seeds = baseline_metrics['seeds']
            
            # 计算有多少回合使用了相同的种子
            common_length = min(len(agent_seeds), len(baseline_seeds))
            same_seed_count = sum(1 for i in range(common_length) 
                                if agent_seeds[i] is not None and agent_seeds[i] == baseline_seeds[i])
            
            if same_seed_count > 0:
                self._log(f"注意: {same_seed_count}/{common_length}回合使用了相同的随机种子，比较结果更可靠", 'info')
            else:
                self._log("警告: 没有回合使用相同的随机种子，比较结果可能不可靠", 'warning')
        
        comparison = {}
        
        # 比较奖励
        if 'episode_rewards' in agent_metrics and 'episode_rewards' in baseline_metrics:
            agent_mean_reward = np.mean(agent_metrics['episode_rewards'])
            baseline_mean_reward = np.mean(baseline_metrics['episode_rewards'])
            
            reward_diff = agent_mean_reward - baseline_mean_reward
            reward_improvement = (reward_diff / abs(baseline_mean_reward)) * 100 if baseline_mean_reward != 0 else 0
            
            comparison['reward_improvement'] = float(reward_diff)
            comparison['reward_improvement_percent'] = float(reward_improvement)
            
            self._log(f"奖励改进: {reward_diff:.2f} ({reward_improvement:.1f}%)")
        
        # 比较运行时间
        if 'episode_final_runtimes' in agent_metrics and 'episode_final_runtimes' in baseline_metrics:
            # 优先使用环境返回的运行时间
            agent_runtimes = agent_metrics['episode_final_runtimes']
            baseline_runtimes = baseline_metrics['episode_final_runtimes']
            
            # 如果运行时间太小或为0，尝试使用测量的时间
            if (np.mean(agent_runtimes) <= 0.001 or np.mean(baseline_runtimes) <= 0.001) and \
               'episode_measured_times' in agent_metrics and 'episode_measured_times' in baseline_metrics:
                self._log("环境返回的运行时间太小，使用测量的时间进行比较", 'warning')
                agent_runtimes = agent_metrics['episode_measured_times']
                baseline_runtimes = baseline_metrics['episode_measured_times']
            
            agent_mean_runtime = np.mean(agent_runtimes)
            baseline_mean_runtime = np.mean(baseline_runtimes)
            
            runtime_diff = baseline_mean_runtime - agent_mean_runtime
            runtime_improvement = (runtime_diff / baseline_mean_runtime) * 100 if baseline_mean_runtime > 0 else 0
            
            comparison['runtime_improvement'] = float(runtime_diff)
            comparison['runtime_improvement_percent'] = float(runtime_improvement)
            
            self._log(f"运行时间改进: {runtime_diff:.6f}s ({runtime_improvement:.1f}%)")
        
        # 分析并展示工作负载分布
        try:
            if 'workloads' in agent_metrics:
                workload_counts = {}
                for wl in agent_metrics['workloads']:
                    if wl != 'unknown':
                        workload_counts[wl] = workload_counts.get(wl, 0) + 1
                
                if workload_counts:
                    comparison['workload_distribution'] = workload_counts
                    self._log("\n工作负载分布:")
                    for wl, count in sorted(workload_counts.items()):
                        self._log(f"  - {wl}: {count}次 ({count/len(agent_metrics['workloads'])*100:.1f}%)")
        except Exception as e:
            self._log(f"分析工作负载分布失败: {e}", 'warning')
            traceback.print_exc()
        
        # 分析并展示难度分布
        try:
            if 'difficulties' in agent_metrics:
                difficulty_counts = {}
                for d in agent_metrics['difficulties']:
                    if d != 'unknown':
                        difficulty_counts[d] = difficulty_counts.get(d, 0) + 1
                
                if difficulty_counts:
                    comparison['difficulty_distribution'] = difficulty_counts
                    self._log("\n难度级别分布:")
                    for d, count in sorted(difficulty_counts.items()):
                        self._log(f"  - {d}: {count}次 ({count/len(agent_metrics['difficulties'])*100:.1f}%)")
        except Exception as e:
            self._log(f"分析难度分布失败: {e}", 'warning')
            traceback.print_exc()
        
        # 获取最终参数
        comparison['final_parameters'] = self._get_final_parameters()
        self._log(f"\n最终参数配置: {comparison['final_parameters']}")
        
        # 保存比较结果
        try:
            comparison_path = os.path.join(self.output_dir, 'performance_comparison.json')
            with open(comparison_path, 'w', encoding='utf-8') as f:
                json.dump(comparison, f, indent=2, ensure_ascii=False)
            self._log(f"\n性能比较结果已保存到: {comparison_path}")
        except Exception as e:
            self._log(f"保存比较结果失败: {e}", 'error')
            traceback.print_exc()
        
        # 生成可视化
        self.visualize_comparison(agent_metrics, baseline_metrics, comparison)
        
        return comparison

    def _get_final_parameters(self):
        """获取当前环境参数"""
        try:
            if hasattr(self.env, 'action_handler') and hasattr(self.env.action_handler, 'get_current_parameters'):
                params = self.env.action_handler.get_current_parameters()
                self._log(f"\n最终参数配置: {params}")
                return params
            else:
                self._log("无法获取当前参数", 'warning')
                return {}
        except Exception as e:
            self._log(f"获取参数失败: {e}", 'warning')
            return {}
    
    def visualize_comparison(self, agent_metrics, baseline_metrics, comparison):
        """
        可视化性能比较结果
        
        Args:
            agent_metrics (dict): MAPPO智能体的指标
            baseline_metrics (dict): 基线的指标
            comparison (dict): 比较结果
        """
        try:
            # 设置图表风格
            plt.style.use('ggplot')
            
            # 创建多子图
            fig = plt.figure(figsize=(18, 10))
            
            # 决定标签语言
            labels = {
                'title': '多智能体MAPPO内存优化性能分析' if self.use_chinese_labels else 'Multi-Agent MAPPO Memory Optimization Performance',
                'runtime_title': '运行时间比较' if self.use_chinese_labels else 'Runtime Comparison',
                'reward_title': '奖励比较' if self.use_chinese_labels else 'Reward Comparison',
                'difficulty_title': '难度级别分布' if self.use_chinese_labels else 'Difficulty Distribution',
                'workload_title': '工作负载分布' if self.use_chinese_labels else 'Workload Distribution',
                'param_title': '参数调整百分比' if self.use_chinese_labels else 'Parameter Adjustment Percentage',
                'agent_contrib_title': '智能体参数控制占比' if self.use_chinese_labels else 'Agent Parameter Control Distribution',
                'runtime_label': '运行时间 (秒)' if self.use_chinese_labels else 'Runtime (s)',
                'reward_label': '奖励' if self.use_chinese_labels else 'Reward',
                'improvement_label': '改进百分比 (%)' if self.use_chinese_labels else 'Improvement (%)',
                'param_change_label': '变化百分比 (%)' if self.use_chinese_labels else 'Change (%)',
                'baseline': '基线' if self.use_chinese_labels else 'Baseline',
                'mappo': 'MAPPO',
                'no_data': '无数据' if self.use_chinese_labels else 'No data'
            }
            
            # 1. 运行时间比较
            ax1 = plt.subplot(2, 3, 1)
            if 'episode_final_runtimes' in agent_metrics and 'episode_final_runtimes' in baseline_metrics:
                agent_runtimes = agent_metrics['episode_final_runtimes']
                baseline_runtimes = baseline_metrics['episode_final_runtimes']
                
                # 检查是否需要使用测量的时间
                if (np.mean(agent_runtimes) <= 0.001 or np.mean(baseline_runtimes) <= 0.001) and \
                   'episode_measured_times' in agent_metrics and 'episode_measured_times' in baseline_metrics:
                    agent_runtimes = agent_metrics['episode_measured_times']
                    baseline_runtimes = baseline_metrics['episode_measured_times']
                
                # 条形图比较
                x = [labels['baseline'], labels['mappo']]
                y = [np.mean(baseline_runtimes), np.mean(agent_runtimes)]
                
                bars = ax1.bar(x, y, color=['#ff9999', '#66b3ff'])
                
                # 添加数值标签
                for bar in bars:
                    height = bar.get_height()
                    ax1.text(bar.get_x() + bar.get_width()/2., height,
                            f'{height:.3f}s', ha='center', va='bottom')
                
                # 添加改进百分比
                if np.mean(baseline_runtimes) > 0:
                    improvement = ((np.mean(baseline_runtimes) - np.mean(agent_runtimes)) / np.mean(baseline_runtimes)) * 100
                    plt.title(f"{labels['runtime_title']} ({improvement:.1f}% 改进)" if self.use_chinese_labels else 
                              f"{labels['runtime_title']} ({improvement:.1f}% improvement)")
                else:
                    plt.title(labels['runtime_title'])
                    
                plt.ylabel(labels['runtime_label'])
                plt.grid(axis='y', linestyle='--', alpha=0.7)
            
            # 2. 奖励比较
            ax2 = plt.subplot(2, 3, 2)
            if 'episode_rewards' in agent_metrics and 'episode_rewards' in baseline_metrics:
                x = [labels['baseline'], labels['mappo']]
                y = [np.mean(baseline_metrics['episode_rewards']), np.mean(agent_metrics['episode_rewards'])]
                
                bars = ax2.bar(x, y, color=['#ff9999', '#66b3ff'])
                
                # 添加数值标签
                for bar in bars:
                    height = bar.get_height()
                    ax2.text(bar.get_x() + bar.get_width()/2., height,
                            f'{height:.1f}', ha='center', va='bottom')
                
                # 添加改进百分比
                if baseline_metrics['episode_rewards'] and baseline_metrics['episode_rewards'][0] != 0:
                    improvement = ((np.mean(agent_metrics['episode_rewards']) - np.mean(baseline_metrics['episode_rewards'])) / 
                                abs(np.mean(baseline_metrics['episode_rewards']))) * 100
                    plt.title(f"{labels['reward_title']} ({improvement:.1f}% 改进)" if self.use_chinese_labels else 
                              f"{labels['reward_title']} ({improvement:.1f}% improvement)")
                else:
                    plt.title(labels['reward_title'])
                    
                plt.ylabel(labels['reward_label'])
                plt.grid(axis='y', linestyle='--', alpha=0.7)
            
            # 3. 难度分布饼图
            ax3 = plt.subplot(2, 3, 3)
            try:
                if 'difficulty_distribution' in comparison and comparison['difficulty_distribution']:
                    diff_dist = comparison['difficulty_distribution']
                    labels_diff = list(diff_dist.keys())
                    values_diff = list(diff_dist.values())
                    
                    # 绘制饼图
                    ax3.pie(values_diff, labels=labels_diff, autopct='%1.1f%%', startangle=90, shadow=True)
                    ax3.set_title(labels['difficulty_title'])
                    ax3.axis('equal')  # 保持饼图为圆形
                else:
                    ax3.text(0.5, 0.5, labels['no_data'], ha='center', va='center')
                    ax3.axis('off')
            except Exception as e:
                self._log(f"绘制难度饼图失败: {e}", 'warning')
                traceback.print_exc()
                ax3.text(0.5, 0.5, f'绘制失败: {str(e)}', ha='center', va='center', wrap=True)
                ax3.axis('off')
            
            # 4. 智能体参数控制占比饼图
            ax4 = plt.subplot(2, 3, 4)
            try:
                # 定义智能体参数映射
                agent_params = {
                    "page_cache": ["vfs_cache_pressure", "dirty_ratio", "dirty_background_ratio"],
                    "memory_reclaim": ["swappiness", "min_free_kbytes"],
                    "memory_scheduler": ["watermark_scale_factor", "compaction_proactiveness"]
                }
                
                # 计算每个智能体的参数数量
                param_counts = [len(params) for agent_id, params in agent_params.items()]
                agent_names = list(agent_params.keys())
                
                # 中文化智能体名称
                if self.use_chinese_labels:
                    agent_name_map = {
                        "page_cache": "页面缓存",
                        "memory_reclaim": "内存回收",
                        "memory_scheduler": "内存调度"
                    }
                    agent_names = [agent_name_map.get(name, name) for name in agent_names]
                
                # 确保数据有效
                if sum(param_counts) > 0:
                    wedges, texts, autotexts = ax4.pie(
                        param_counts, 
                        labels=agent_names, 
                        autopct='%1.1f%%',
                        textprops={'fontsize': 9},
                        colors=['#ff9999', '#66b3ff', '#99ff99']
                    )
                    
                    # 设置自动文本的属性
                    for autotext in autotexts:
                        autotext.set_fontsize(8)
                        autotext.set_color('black')
                        
                    plt.title(labels['agent_contrib_title'])
                else:
                    self._log("绘制饼图失败，参数数量总和为0", 'warning')
            except Exception as e:
                self._log(f"绘制饼图失败，可能是数据问题: {e}", 'warning')
                traceback.print_exc()
                ax4.text(0.5, 0.5, f'绘制失败: {str(e)}', ha='center', va='center', wrap=True)
                ax4.axis('off')
            
            # 5. 参数调整百分比
            ax5 = plt.subplot(2, 3, 5)
            try:
                final_params = comparison.get('final_parameters', {})
                if final_params and hasattr(self.env, 'action_handler') and hasattr(self.env.action_handler, 'get_default_parameters'):
                    default_params = self.env.action_handler.get_default_parameters()
                    
                    # 计算参数变化百分比
                    param_changes = []
                    param_names = []
                    
                    for name, value in final_params.items():
                        if name in default_params and default_params[name] != 0:
                            change = ((value - default_params[name]) / default_params[name]) * 100
                            param_changes.append(change)
                            param_names.append(name)
                    
                    if param_changes:
                        # 创建颜色映射
                        colors = []
                        for change in param_changes:
                            if change > 50:
                                colors.append('#5cb85c')  # 绿色 - 大幅增加
                            elif change > 10:
                                colors.append('#5bc0de')  # 蓝色 - 中等增加
                            elif change >= 0:
                                colors.append('#f0ad4e')  # 黄色 - 小幅增加
                            elif change > -10:
                                colors.append('#d9534f')  # 红色 - 小幅减少
                            else:
                                colors.append('#d9534f')  # 红色 - 大幅减少
                        
                        bars = ax5.bar(param_names, param_changes, color=colors)
                        
                        # 添加数值标签
                        for bar in bars:
                            height = bar.get_height()
                            ax5.text(bar.get_x() + bar.get_width()/2., height,
                                   f'{height:.1f}%', ha='center', va='bottom' if height > 0 else 'top')
                        
                        plt.title(labels['param_title'])
                        plt.ylabel(labels['param_change_label'])
                        plt.grid(axis='y', linestyle='--', alpha=0.7)
                        plt.xticks(rotation=90)
            except Exception as e:
                self._log(f"绘制参数变化图失败: {e}", 'warning')
                traceback.print_exc()
                ax5.text(0.5, 0.5, f'绘制失败: {str(e)}', ha='center', va='center', wrap=True)
                ax5.axis('off')
            
            # 6. 工作负载分布饼图
            ax6 = plt.subplot(2, 3, 6)
            try:
                if 'workload_distribution' in comparison and comparison['workload_distribution']:
                    wl_dist = comparison['workload_distribution']
                    labels_wl = list(wl_dist.keys())
                    values_wl = list(wl_dist.values())
                    
                    # 绘制饼图
                    ax6.pie(values_wl, labels=labels_wl, autopct='%1.1f%%', startangle=90, shadow=True)
                    ax6.set_title(labels['workload_title'])
                    ax6.axis('equal')  # 保持饼图为圆形
                else:
                    ax6.text(0.5, 0.5, labels['no_data'], ha='center', va='center')
                    ax6.axis('off')
            except Exception as e:
                self._log(f"绘制工作负载饼图失败: {e}", 'warning')
                traceback.print_exc()
                ax6.text(0.5, 0.5, f'绘制失败: {str(e)}', ha='center', va='center', wrap=True)
                ax6.axis('off')
            
            # 添加总标题
            plt.suptitle(labels['title'], fontsize=16)
            plt.tight_layout(rect=[0, 0, 1, 0.96])  # 为suptitle留出空间
            
            # 保存图表
            output_path = os.path.join(self.output_dir, 'mappo_performance.png')
            plt.savefig(output_path, dpi=300)
            self._log(f"性能比较图表已保存到: {output_path}")
            plt.close()
            
        except ImportError:
            self._log("未安装matplotlib，无法生成可视化结果", 'warning')
        except Exception as e:
            self._log(f"生成可视化图表时出错: {str(e)}", 'error')
            traceback.print_exc()
    
    def _save_metrics(self, metrics, filename):
        """保存测试指标到JSON文件"""
        try:
            # 将numpy数组转换为列表以便JSON序列化
            metrics_copy = self._convert_numpy_to_list(metrics)
            
            file_path = os.path.join(self.output_dir, filename)
            self._save_json(metrics_copy, file_path)
            self._log(f"指标已保存至: {file_path}")
            
        except Exception as e:
            self._log(f"保存指标失败: {e}", 'error')
            traceback.print_exc()
    
    def _save_json(self, data, file_path):
        """保存字典到JSON文件"""
        with open(file_path, 'w') as f:
            json.dump(data, f, indent=2)
    
    def _load_metrics(self, filename):
        """从JSON文件加载测试指标"""
        file_path = os.path.join(self.output_dir, filename)
        if os.path.exists(file_path):
            with open(file_path, 'r') as f:
                return json.load(f)
        return {}
    
    def _convert_numpy_to_list(self, obj):
        """将字典中的numpy数组转换为列表"""
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, dict):
            return {k: self._convert_numpy_to_list(v) for k, v in obj.items()}
        elif isinstance(obj, list) or isinstance(obj, tuple):
            return [self._convert_numpy_to_list(x) for x in obj]
        else:
            return obj    
    
    # 添加测试性能比较方法，使用相同随机种子
    def test_performance_comparison(self, episodes=10, render=False):
        """
        使用相同的随机种子进行性能比较测试
        
        Args:
            episodes: 测试轮数
            render: 是否渲染环境
            
        Returns:
            tuple: (baseline_metrics, agent_metrics)
        """
        self._log("\n===== 开始控制变量性能比较测试 =====")
        
        # 首先验证环境的种子控制是否有效
        seed_control_effective = self.verify_seed_control()
        
        if not seed_control_effective:
            self._log("警告: 种子控制可能无效，但仍将尝试使用一致的种子进行测试", 'warning')
        
        # 生成随机种子序列
        shared_seeds = [1000 + i for i in range(episodes)]
        self._log(f"生成{len(shared_seeds)}个共享随机种子")
        
        # 使用相同的种子序列进行基线测试
        self._log("\n运行基线测试（使用控制种子）...")
        baseline_metrics = self.test_baseline(episodes=episodes, render=render, seeds=shared_seeds)
        
        # 使用相同的种子序列进行MAPPO测试
        self._log("\n运行MAPPO测试（使用控制种子）...")
        agent_metrics = self.test_performance(episodes=episodes, render=render, seeds=shared_seeds)
        
        # 比较性能
        comparison = self.compare_performance(agent_metrics, baseline_metrics)
        
        self._log("\n控制变量测试完成！")
        
        return baseline_metrics, agent_metrics
    
    def run_full_test(self, agent_episodes=10, baseline_episodes=10, render=False):
        """
        运行完整的测试流程，包括MAPPO测试、基线测试和性能比较
        
        Args:
            agent_episodes (int): MAPPO测试回合数
            baseline_episodes (int): 基线测试回合数
            render (bool): 是否渲染环境
            
        Returns:
            dict: 性能比较结果
        """
        self._log(f"开始完整测试流程 (MAPPO: {agent_episodes}回合, 基线: {baseline_episodes}回合)")
        
        # 使用控制变量的方法进行测试
        # 确保两种测试使用相同的随机种子序列
        min_episodes = min(agent_episodes, baseline_episodes)
        shared_seeds = [1000 + i for i in range(min_episodes)]
        
        # 首先验证种子控制有效性
        seed_control_effective = self.verify_seed_control()
        
        if seed_control_effective:
            # 如果种子控制有效，使用相同种子序列进行测试
            self._log(f"使用相同种子序列进行控制变量测试 ({min_episodes}回合)")
            baseline_metrics, agent_metrics = self.test_performance_comparison(episodes=min_episodes, render=render)
            
            # 如果需要更多回合，分别补充测试
            if baseline_episodes > min_episodes:
                self._log(f"运行额外{baseline_episodes - min_episodes}回合基线测试...")
                extra_baseline = self.test_baseline(episodes=baseline_episodes - min_episodes, render=render)
                # 合并指标
                for key in baseline_metrics:
                    if key in extra_baseline and isinstance(baseline_metrics[key], list):
                        baseline_metrics[key].extend(extra_baseline[key])
            
            if agent_episodes > min_episodes:
                self._log(f"运行额外{agent_episodes - min_episodes}回合MAPPO测试...")
                extra_agent = self.test_performance(episodes=agent_episodes - min_episodes, render=render)
                # 合并指标
                for key in agent_metrics:
                    if key in extra_agent and isinstance(agent_metrics[key], list):
                        agent_metrics[key].extend(extra_agent[key])
        else:
            # 如果种子控制无效，采用传统测试方式
            self._log("种子控制无效，使用传统测试方法")
            
            # 测试基线性能
            baseline_metrics = self.test_baseline(episodes=baseline_episodes, render=render)
            
            # 测试MAPPO性能
            agent_metrics = self.test_performance(episodes=agent_episodes, render=render)
        
        # 比较性能
        comparison = self.compare_performance(agent_metrics, baseline_metrics)
        
        self._log("测试完成！")
        return comparison


def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description='MAPPO内存管理系统测试工具')
    
    parser.add_argument('--model_dir', type=str, required=True,
                       help='包含模型文件的目录路径')
    
    parser.add_argument('--output_dir', type=str, default=None,
                       help='输出结果的目录路径')
    
    parser.add_argument('--agent_episodes', type=int, default=100,
                       help='MAPPO测试回合数')
    
    parser.add_argument('--baseline_episodes', type=int, default=100,
                       help='基线测试回合数')
    
    parser.add_argument('--render', action='store_true',
                       help='是否渲染环境')
    
    parser.add_argument('--device', type=str, default=None,
                       help='计算设备 (cuda 或 cpu)')
    
    parser.add_argument('--verbose', action='store_true',
                       help='是否输出详细信息')
    
    # 添加种子控制参数
    parser.add_argument('--use_seed_control', action='store_true',
                       help='是否使用随机种子控制环境一致性')
    
    parser.add_argument('--base_seed', type=int, default=1000,
                       help='随机种子基础值')
    
    return parser.parse_args()


def main():
    """主函数"""
    args = parse_args()
    
    try:
        # 初始化测试器
        tester = MAPPOTester(
            model_dir=args.model_dir,
            output_dir=args.output_dir,
            verbose=args.verbose,
            device=args.device
        )
        
        # 如果指定使用种子控制，先验证种子控制有效性
        if args.use_seed_control:
            seed_control_effective = tester.verify_seed_control()
            if seed_control_effective:
                # 使用种子控制的比较测试
                tester.test_performance_comparison(
                    episodes=min(args.agent_episodes, args.baseline_episodes),
                    render=args.render
                )
            else:
                print("警告：种子控制无效，将使用普通测试方法")
                # 退回到普通测试方法
                tester.run_full_test(
                    agent_episodes=args.agent_episodes,
                    baseline_episodes=args.baseline_episodes,
                    render=args.render
                )
        else:
            # 运行普通测试
            tester.run_full_test(
                agent_episodes=args.agent_episodes,
                baseline_episodes=args.baseline_episodes,
                render=args.render
            )
        
    except Exception as e:
        print(f"测试过程中出错: {e}")
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
