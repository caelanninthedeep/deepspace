"""
内存回收智能体 - 负责内存回收和交换参数优化
"""

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from torch.distributions import Normal

class MemoryReclaimAgent(nn.Module):
    """
    内存回收智能体 - 负责优化Linux内存回收和交换相关参数
    调整swappiness和min_free_kbytes
    """
    def __init__(self, input_dim, hidden_dim=128, device=None):
        super(MemoryReclaimAgent, self).__init__()
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # 输出维度: 2 (swappiness, min_free_kbytes)
        self.output_dim = 2
        
        # Actor网络 - 确定性部分
        self.actor_backbone = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
        )
        
        # 注意力层，用于关注内存压力相关指标
        self.attention = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, input_dim),
            nn.Softmax(dim=-1)
        )
        
        # 输出均值
        self.mu_head = nn.Linear(hidden_dim, self.output_dim)
        
        # 输出标准差
        self.sigma_head = nn.Linear(hidden_dim, self.output_dim)
        
        # Critic网络
        self.critic = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1)
        )
        
        # 为回收参数定义合理的动作幅度
        self.action_scales = torch.tensor([
            1.0,   # swappiness变化幅度中等
            5.0    # min_free_kbytes变化幅度较大
        ]).to(self.device)
        
        # 初始化网络参数
        self._init_weights()
    
    def _init_weights(self):
        """初始化网络权重"""
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.orthogonal_(module.weight, gain=1)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
    
    def forward(self, state):
        """前向传播，返回动作分布参数和状态值"""
        if isinstance(state, np.ndarray):
            state = torch.FloatTensor(state).to(self.device)
        
        # 计算注意力权重
        attention_weights = self.attention(state)
        
        # 应用注意力
        attended_state = state * attention_weights
        
        # 获取共享特征
        features = self.actor_backbone(attended_state)
        
        # 动作分布参数
        mu = torch.tanh(self.mu_head(features))  # 范围限制在[-1, 1]
        
        # 使用softplus确保标准差为正，并根据内存压力适当调整
        sigma = torch.nn.functional.softplus(self.sigma_head(features)) * 0.1 + 0.01
        
        # 计算状态值
        value = self.critic(state)
        
        return mu, sigma, value, attention_weights
    
    def get_action(self, state, deterministic=False):
        """获取动作，可选择确定性或随机策略"""
        mu, sigma, value, attention_weights = self.forward(state)
        
        if deterministic:
            # 确定性策略直接返回均值
            action = mu
        else:
            # 创建正态分布并采样
            dist = Normal(mu, sigma)
            action = dist.sample()
            
            # 根据不同参数使用不同缩放
            action = action * self.action_scales
        
        # 限制动作在[-1, 1]范围内
        action = torch.clamp(action, -1.0, 1.0)
        
        # 计算对数概率
        if deterministic:
            log_prob = torch.zeros(1).to(self.device)
            entropy = torch.zeros(1).to(self.device)
        else:
            dist = Normal(mu, sigma)
            log_prob = dist.log_prob(action).sum(-1)
            entropy = dist.entropy().sum(-1)
        
        return action, log_prob, entropy, value
    
    def evaluate_action(self, state, action):
        """评估已经采取的动作"""
        mu, sigma, value, _ = self.forward(state)
        
        dist = Normal(mu, sigma)
        log_prob = dist.log_prob(action).sum(-1)
        entropy = dist.entropy().sum(-1)
        
        return value, log_prob, entropy
    
    def reclaim_analysis(self, state):
        """
        分析内存回收相关指标，为决策提供额外信息
        
        Args:
            state: 系统状态
            
        Returns:
            dict: 内存回收分析结果
        """
        with torch.no_grad():
            # 提取关键内存回收指标
            if isinstance(state, torch.Tensor):
                state_np = state.cpu().numpy()
            else:
                state_np = state
            
            # 计算内存压力指标
            memory_pressure = np.mean(state_np[:3])  # 示例，使用前3个值的平均值表示内存压力
            
            # 分析swap活动
            swap_activity = np.mean(state_np[3:6])  # 示例，使用索引3-5的值表示swap活动
            
            # 根据内存压力和swap活动计算最佳swappiness
            if memory_pressure > 0.7:  # 高内存压力
                if swap_activity < 0.3:  # 低swap活动
                    optimal_swappiness = 80  # 增加swap倾向
                else:
                    optimal_swappiness = 60  # 中等swap倾向
            else:  # 低内存压力
                if swap_activity > 0.5:  # 高swap活动
                    optimal_swappiness = 20  # 降低swap倾向
                else:
                    optimal_swappiness = 40  # 默认swap倾向
            
            # 计算最佳最小可用内存
            total_mem_gb = 16  # 示例，假设总内存为16GB
            optimal_min_free = (0.1 + 0.2 * memory_pressure) * total_mem_gb * 1024 * 1024  # 根据内存压力调整
            
            return {
                "memory_pressure": float(memory_pressure),
                "swap_activity": float(swap_activity),
                "optimal_swappiness": int(optimal_swappiness),
                "optimal_min_free_kb": float(optimal_min_free),
                "attention": self.attention(torch.FloatTensor(state_np).to(self.device)).cpu().numpy().tolist()
            }
