"""
多智能体近端策略优化算法(MAPPO)实现
基于中央化训练与分散执行(CTDE)范式
"""

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Normal
import os
import traceback
import sys
import time

class MAPPO:
    """
    多智能体近端策略优化(MAPPO)算法
    支持中央化训练和分散执行
    """
    
    def __init__(
        self, 
        network_manager,
        buffer,
        config=None,
        lr_actor=3e-4,
        lr_critic=1e-3,
        gamma=0.99,
        gae_lambda=0.95,
        clip_param=0.2,
        value_clip_param=0.2,
        entropy_coef=0.01,
        value_loss_coef=0.5,
        max_grad_norm=0.5,
        use_clipped_value_loss=True,
        normalize_advantages=True,
        use_centralized_critic=True,
        device=None
    ):
        """
        初始化MAPPO算法
        
        参数:
            network_manager: 网络管理器，包含所有智能体的网络
            buffer: 多智能体经验回放缓冲区
            config: 配置参数字典，优先级高于默认参数
            lr_actor: Actor学习率
            lr_critic: Critic学习率
            gamma: 折扣因子
            gae_lambda: GAE参数
            clip_param: PPO裁剪参数
            value_clip_param: 价值裁剪参数
            entropy_coef: 熵系数
            value_loss_coef: 价值损失系数
            max_grad_norm: 梯度裁剪范数
            use_clipped_value_loss: 是否使用裁剪的价值损失
            normalize_advantages: 是否归一化优势
            use_centralized_critic: 是否使用中央化Critic
            device: 计算设备
        """
        self.network_manager = network_manager
        self.buffer = buffer
        self.agent_ids = self.network_manager.agent_ids
        
        # 如果提供了配置，使用配置中的值覆盖默认值
        if config is not None:
            self.gamma = config.get("gamma", gamma)
            self.gae_lambda = config.get("gae_lambda", gae_lambda)
            self.clip_param = config.get("clip_param", clip_param)
            self.value_clip_param = config.get("value_clip_param", value_clip_param)
            self.entropy_coef = config.get("entropy_coef", entropy_coef)
            self.value_loss_coef = config.get("value_loss_coef", value_loss_coef)
            self.max_grad_norm = config.get("max_grad_norm", max_grad_norm)
            self.use_clipped_value_loss = config.get("use_clipped_value_loss", use_clipped_value_loss)
            self.normalize_advantages = config.get("normalize_advantages", normalize_advantages)
            self.use_centralized_critic = config.get("use_centralized_critic", use_centralized_critic)
            
            lr_actor = config.get("lr_actor", lr_actor)
            lr_critic = config.get("lr_critic", lr_critic)
            
            device_str = config.get("device", None)
            if device_str:
                device = torch.device(device_str)
        else:
            self.gamma = gamma
            self.gae_lambda = gae_lambda
            self.clip_param = clip_param
            self.value_clip_param = value_clip_param
            self.entropy_coef = entropy_coef
            self.value_loss_coef = value_loss_coef
            self.max_grad_norm = max_grad_norm
            self.use_clipped_value_loss = use_clipped_value_loss
            self.normalize_advantages = normalize_advantages
            self.use_centralized_critic = use_centralized_critic
            
        self.device = device or torch.device('cpu')
        
        # 打印MAPPO配置参数
        print("\n" + "-"*50)
        print("MAPPO算法配置参数:")
        print(f"  Actor学习率: {lr_actor}")
        print(f"  Critic学习率: {lr_critic}")
        print(f"  折扣因子 (gamma): {self.gamma}")
        print(f"  GAE lambda: {self.gae_lambda}")
        print(f"  裁剪参数: {self.clip_param}")
        print(f"  价值裁剪参数: {self.value_clip_param}")
        print(f"  熵系数: {self.entropy_coef}")
        print(f"  价值损失系数: {self.value_loss_coef}")
        print(f"  最大梯度范数: {self.max_grad_norm}")
        print(f"  使用裁剪价值损失: {self.use_clipped_value_loss}")
        print(f"  归一化优势: {self.normalize_advantages}")
        print(f"  使用中央化Critic: {self.use_centralized_critic}")
        print(f"  计算设备: {self.device}")
        print("-"*50 + "\n")
        
        # 创建优化器
        self.actor_optimizers = {}
        for agent_id in self.agent_ids:
            network = self.network_manager.actor_networks[agent_id]
            self.actor_optimizers[agent_id] = optim.Adam(network.parameters(), lr=lr_actor)
        
        # 如果使用中央化Critic，为中央化Critic创建优化器
        if self.use_centralized_critic:
            self.critic_optimizer = optim.Adam(self.network_manager.central_critic.parameters(), lr=lr_critic)
        
        # 跟踪训练统计数据
        self.stats = {
            'actor_losses': {agent_id: [] for agent_id in self.agent_ids},
            'critic_losses': {agent_id: [] for agent_id in self.agent_ids},
            'entropy': {agent_id: [] for agent_id in self.agent_ids},
            'kl_div': {agent_id: [] for agent_id in self.agent_ids},
            'value_losses': {agent_id: [] for agent_id in self.agent_ids},
            'policy_losses': {agent_id: [] for agent_id in self.agent_ids},
            'clip_fraction': {agent_id: [] for agent_id in self.agent_ids}
        }
        
        if self.use_centralized_critic:
            self.stats['central_critic_losses'] = []
        
        # 缓存观察和动作维度信息
        self.obs_dims = {}
        self.action_dims = {}
        
        # 从buffer获取维度信息
        if hasattr(buffer, 'obs_dims'):
            self.obs_dims = buffer.obs_dims
        
        if hasattr(buffer, 'action_dims'):
            self.action_dims = buffer.action_dims
            
        print(f"从buffer获取观察维度: {self.obs_dims}")
        print(f"从buffer获取动作维度: {self.action_dims}")
        
    def update(self, k_epochs=None, batch_size=None, config=None):
        """
        更新MAPPO策略
        
        参数:
            k_epochs: 每个批次的训练轮数，如果为None则从config中读取
            batch_size: 批次大小，如果为None则从config中读取
            config: 配置字典，优先级高于其他参数
            
        返回:
            stats: 包含训练统计数据的字典
        """
        # 从配置中读取参数
        if config is not None:
            k_epochs = config.get("k_epochs", k_epochs or 10)
            batch_size = config.get("batch_size", batch_size or 64)
        else:
            k_epochs = k_epochs or 10
            batch_size = batch_size or 64
        
        # 重置训练统计
        for key in self.stats:
            if key == 'central_critic_losses':
                self.stats[key] = []
            else:
                for agent_id in self.agent_ids:
                    self.stats[key][agent_id] = []
        
        update_success = False
        
        # 如果使用中央化Critic，先更新中央化Critic
        if self.use_centralized_critic:
            try:
                self._update_centralized_critic(k_epochs, batch_size)
                update_success = True
            except Exception as e:
                print(f"策略更新 (中央化Critic) 失败: {e}")
                traceback.print_exc()
        
        # 更新每个智能体的Actor(和Critic，如果没有使用中央化Critic)
        agent_success = 0
        for i, agent_id in enumerate(self.agent_ids, 1):
            try:
                self._update_agent(agent_id, k_epochs, batch_size)
                agent_success += 1
                update_success = True
            except Exception as e:
                print(f"策略更新 {i} 失败 (智能体 {agent_id}): {e}")
                traceback.print_exc()
        
        if not update_success:
            print("所有策略更新失败，跳过此轮更新")
        else:
            print(f"成功更新 {agent_success}/{len(self.agent_ids)} 个智能体")
            
        return self.stats
    
    def _update_centralized_critic(self, k_epochs, batch_size):
        """更新中央化Critic"""
        # 从缓冲区获取全局批次
        central_batch = self.buffer.get_batch(agent_id=None, batch_size=batch_size)
        
        if central_batch is None or 'batch' not in central_batch:
            print("警告: 无法获取有效的中央化批次")
            return
        
        central_batch = central_batch['batch']
        
        # 检查必要的键是否存在
        required_keys = ['global_states', 'global_values']
        missing_keys = [key for key in required_keys if key not in central_batch]
        if missing_keys:
            print(f"警告: 中央化批次缺少必要的键: {missing_keys}")
            return
        
        # 检查returns键，可能是不同名称
        if 'returns' not in central_batch:
            if 'global_returns' in central_batch:
                central_batch['returns'] = central_batch['global_returns']
                print("已将global_returns键重命名为returns")
            else:
                print("警告: 中央化批次缺少returns键，尝试使用回报估计")
                # 尝试使用GAE公式计算回报
                if 'rewards' in central_batch and 'dones' in central_batch:
                    rewards = central_batch['rewards']
                    dones = central_batch['dones']
                    global_values = central_batch['global_values']
                    
                    # 使用简单的折扣回报估计
                    returns = []
                    discounted_return = 0
                    for step in reversed(range(len(rewards))):
                        discounted_return = rewards[step] + self.gamma * discounted_return * (1 - dones[step])
                        returns.insert(0, discounted_return)
                        
                    central_batch['returns'] = torch.FloatTensor(returns).to(self.device)
                    print(f"已生成估计回报，形状: {central_batch['returns'].shape}")
                else:
                    print("错误: 无法生成回报估计，跳过中央化Critic更新")
                    return
        
        # 继续进行正常更新
        for epoch in range(k_epochs):
            try:
                # 计算中央化Critic的价值损失
                global_states = central_batch['global_states']
                global_values = central_batch['global_values']
                returns = central_batch['returns']
                
                # 确保维度匹配
                if returns.dim() == 1 and global_values.dim() > 1:
                    returns = returns.unsqueeze(-1)
                elif global_values.dim() == 1 and returns.dim() > 1:
                    global_values = global_values.unsqueeze(-1)
                    
                # 使用中央化Critic计算新价值
                new_values = self.network_manager.central_critic(global_states)
                if new_values.dim() > 1 and new_values.shape[1] == 1:
                    new_values = new_values.squeeze(-1)
                
                # 确保维度匹配计算
                if new_values.dim() != returns.dim():
                    if new_values.dim() > returns.dim():
                        new_values = new_values.squeeze()
                    else:
                        new_values = new_values.unsqueeze(-1)
                
                # 计算价值损失
                if self.use_clipped_value_loss:
                    # 裁剪价值，类似于PPO的裁剪
                    value_pred_clipped = global_values + torch.clamp(
                        new_values - global_values,
                        -self.value_clip_param,
                        self.value_clip_param
                    )
                    value_loss_clipped = (value_pred_clipped - returns).pow(2)
                    value_loss_unclipped = (new_values - returns).pow(2)
                    value_loss = torch.max(value_loss_clipped, value_loss_unclipped).mean()
                else:
                    # 标准MSE损失
                    value_loss = nn.MSELoss()(new_values, returns)
                
                # 更新中央化Critic
                self.critic_optimizer.zero_grad()
                value_loss.backward()
                nn.utils.clip_grad_norm_(self.network_manager.central_critic.parameters(), self.max_grad_norm)
                self.critic_optimizer.step()
                
                # 记录统计数据
                self.stats['central_critic_losses'].append(value_loss.item())
                
            except Exception as e:
                print(f"中央化Critic更新轮次 {epoch+1} 出错: {e}")
                traceback.print_exc()
                raise  # 重新抛出异常以便上层捕获
    
    def _update_agent(self, agent_id, k_epochs, batch_size):
        """更新单个智能体的策略"""
        # 获取智能体的批次
        batch_data = self.buffer.get_batch(agent_id=agent_id, batch_size=batch_size)
        
        if batch_data is None or 'batch' not in batch_data:
            print(f"警告: 无法获取智能体 {agent_id} 的有效批次")
            return
        
        batch = batch_data['batch']
        
        # 提取批次数据
        states = batch['observations'] if 'observations' in batch else batch['states']
        actions = batch['actions']
        returns = batch['returns']
        advantages = batch['advantages']
        old_log_probs = batch['old_log_probs'] if 'old_log_probs' in batch else batch['log_probs']
        old_values = batch['values']
        
        # 训练k_epochs轮
        for epoch in range(k_epochs):
            try:
                # 评估动作
                log_probs, values, entropy = self.network_manager.evaluate_action(agent_id, states, actions)
                
                # 计算比率(pi_theta / pi_theta_old)
                ratios = torch.exp(log_probs - old_log_probs)
                
                # 计算替代损失
                surr1 = ratios * advantages
                surr2 = torch.clamp(ratios, 1.0 - self.clip_param, 1.0 + self.clip_param) * advantages
                policy_loss = -torch.min(surr1, surr2).mean()
                
                # 计算价值损失
                if self.use_clipped_value_loss:
                    value_pred_clipped = old_values + torch.clamp(
                        values - old_values,
                        -self.value_clip_param,
                        self.value_clip_param
                    )
                    value_loss_clipped = (value_pred_clipped - returns).pow(2)
                    value_loss_unclipped = (values - returns).pow(2)
                    value_loss = torch.max(value_loss_clipped, value_loss_unclipped).mean()
                else:
                    value_loss = nn.MSELoss()(values, returns)
                
                # 计算总损失
                entropy_loss = -entropy.mean()
                loss = policy_loss + self.value_loss_coef * value_loss + self.entropy_coef * entropy_loss
                
                # 更新智能体网络
                self.actor_optimizers[agent_id].zero_grad()
                # 使用retain_graph=True解决图重用问题
                loss.backward(retain_graph=True)
                nn.utils.clip_grad_norm_(self.network_manager.actor_networks[agent_id].parameters(), self.max_grad_norm)
                self.actor_optimizers[agent_id].step()
                
                # 计算近似KL散度和裁剪比例
                with torch.no_grad():
                    approx_kl = 0.5 * ((old_log_probs - log_probs) ** 2).mean().item()
                    clip_fraction = ((ratios - 1.0).abs() > self.clip_param).float().mean().item()
                
                # 记录统计数据
                self.stats['actor_losses'][agent_id].append(loss.item())
                self.stats['critic_losses'][agent_id].append(value_loss.item())
                self.stats['entropy'][agent_id].append(entropy_loss.item())
                self.stats['kl_div'][agent_id].append(approx_kl)
                self.stats['value_losses'][agent_id].append(value_loss.item())
                self.stats['policy_losses'][agent_id].append(policy_loss.item())
                self.stats['clip_fraction'][agent_id].append(clip_fraction)
                
            except Exception as e:
                print(f"智能体 {agent_id} 更新轮次 {epoch+1} 出错: {e}")
                traceback.print_exc()
                raise  # 重新抛出异常以便上层捕获
    
    def _infer_network_input_dim(self, agent_id):
        """
        推断网络输入维度
        
        参数:
            agent_id: 智能体ID
            
        返回:
            推断的输入维度，如果无法推断则返回None
        """
        try:
            network = self.network_manager.actor_networks[agent_id]
            
            # 从网络结构推断输入维度
            if hasattr(network, 'base') and len(network.base) > 0:
                for layer in network.base:
                    if isinstance(layer, nn.Linear) and hasattr(layer, 'weight'):
                        return layer.weight.shape[1]
            
            if hasattr(network, 'pressure_encoder') and len(network.pressure_encoder) > 0:
                for layer in network.pressure_encoder:
                    if isinstance(layer, nn.Linear) and hasattr(layer, 'weight'):
                        return layer.weight.shape[1]
                        
            if hasattr(network, 'feature_extractor') and len(network.feature_extractor) > 0:
                for layer in network.feature_extractor:
                    if isinstance(layer, nn.Linear) and hasattr(layer, 'weight'):
                        return layer.weight.shape[1]
            
            if hasattr(network, 'lstm') and hasattr(network.lstm, 'input_size'):
                return network.lstm.input_size
                
            # 尝试从缓存的维度信息获取
            if agent_id in self.obs_dims:
                return self.obs_dims[agent_id]
                
        except Exception as e:
            print(f"推断智能体 {agent_id} 网络输入维度时出错: {e}")
            
        return None
    
    def act(self, observations, deterministic=False, verbose=False):
        """
        根据观察执行动作，增强错误处理
        
        参数:
            observations: 字典，键为智能体ID，值为观察
            deterministic: 是否使用确定性策略
            verbose: 是否打印详细信息
            
        返回:
            actions: 字典，键为智能体ID，值为动作
            log_probs: 字典，键为智能体ID，值为对数概率
            values: 字典，键为智能体ID，值为价值估计
        """
        actions = {}
        log_probs = {}
        values = {}
        
        with torch.no_grad():
            # 确保每个智能体都能获得动作，即使有些失败
            for agent_id in self.agent_ids:
                if agent_id not in observations:
                    continue
                    
                try:
                    # 转换观察为张量
                    obs = observations[agent_id]
                    if isinstance(obs, np.ndarray):
                        obs = torch.FloatTensor(obs).to(self.device)
                    elif not isinstance(obs, torch.Tensor):
                        obs = torch.FloatTensor([obs]).to(self.device)
                    
                    # 检查观察维度，根据实际情况处理
                    input_dim = self._infer_network_input_dim(agent_id)
                    
                    if obs.dim() == 1 and input_dim is not None:
                        # 如果观察是一维的，确保维度匹配
                        original_dim = obs.shape[0]
                        
                        # 只有在维度不匹配时才处理
                        if original_dim != input_dim:
                            if original_dim < input_dim:
                                # 需要填充
                                padding = torch.zeros(input_dim - original_dim, device=self.device)
                                obs = torch.cat([obs, padding])
                            else:
                                # 需要截断
                                obs = obs[:input_dim]
                        
                        # 添加批次维度
                        obs = obs.unsqueeze(0)
                    
                    # 确保LSTM状态已初始化(如果适用)
                    network = self.network_manager.actor_networks[agent_id]
                    if hasattr(network, 'reset_hidden') and hasattr(network, 'hidden') and network.hidden is None:
                        network.reset_hidden(batch_size=1)
                    
                    # 获取动作
                    action, log_prob, value = self.network_manager.get_action(
                        agent_id, 
                        obs, 
                        deterministic
                    )
                    
                    actions[agent_id] = action
                    log_probs[agent_id] = log_prob
                    values[agent_id] = value
                    
                    # 缓存动作维度以便之后使用
                    if agent_id not in self.action_dims and isinstance(action, np.ndarray):
                        self.action_dims[agent_id] = action.shape[0] if len(action.shape) > 0 else 1
                    
                except Exception as e:
                    print(f"获取智能体 {agent_id} 动作时出错: {e}")
                    traceback.print_exc()
                    
                    # 在错误情况下返回默认动作
                    # 尝试从动作空间推断维度
                    action_dim = None
                    if agent_id in self.action_dims:
                        action_dim = self.action_dims[agent_id]
                    else:
                        # 如果无法确定动作维度，使用默认值1
                        action_dim = 1
                        print(f"警告: 无法确定智能体 {agent_id} 的动作维度，使用默认值 1")
                    
                    actions[agent_id] = np.zeros(action_dim)
                    log_probs[agent_id] = 0.0
                    values[agent_id] = 0.0
        
        return actions, log_probs, values
    
    def get_central_value(self, global_state):
        """获取中央化价值估计"""
        if not self.use_centralized_critic:
            raise ValueError("Centralized critic is not enabled")
            
        try:
            # 转换状态为正确的格式
            if isinstance(global_state, np.ndarray):
                global_state = torch.FloatTensor(global_state).to(self.device)
            elif not isinstance(global_state, torch.Tensor):
                global_state = torch.FloatTensor([global_state]).to(self.device)
            
            # 添加批次维度(如果需要)
            if global_state.dim() == 1:
                global_state = global_state.unsqueeze(0)
                
            with torch.no_grad():
                value = self.network_manager.get_central_value(global_state)
                
            return value
        except Exception as e:
            print(f"获取中央化价值时出错: {e}")
            return torch.tensor(0.0, device=self.device)
    
    def save_models(self, path_prefix):
        """
        保存所有智能体的模型
        
        参数:
            path_prefix: 保存路径前缀
        """
        try:
            # 确保目录存在
            dirname = os.path.dirname(path_prefix)
            if dirname:
                os.makedirs(dirname, exist_ok=True)
            
            # 保存模型元数据
            metadata = {
                "agent_ids": self.agent_ids,
                "use_centralized_critic": self.use_centralized_critic,
                "gamma": self.gamma,
                "gae_lambda": self.gae_lambda,
                "clip_param": self.clip_param,
                "value_clip_param": self.value_clip_param,
                "entropy_coef": self.entropy_coef,
                "value_loss_coef": self.value_loss_coef,
                "normalize_advantages": self.normalize_advantages,
                "timestamp": str(time.time()),
                "action_dims": self.action_dims,
                "obs_dims": self.obs_dims
            }
            
            metadata_path = f"{path_prefix}_metadata.pth"
            torch.save(metadata, metadata_path)
            print(f"模型元数据保存至: {metadata_path}")
            
            # 逐个保存Actor网络
            for agent_id in self.agent_ids:
                try:
                    # 检查网络是否存在
                    if agent_id not in self.network_manager.actor_networks:
                        print(f"警告: 找不到智能体 {agent_id} 的网络")
                        continue
                    
                    actor_network = self.network_manager.actor_networks[agent_id]
                    actor_path = f"{path_prefix}_actor_{agent_id}.pth"
                    
                    # 获取网络类型
                    network_type = type(actor_network).__name__
                    
                    # 创建保存字典，包含网络类型信息
                    save_dict = {
                        "state_dict": actor_network.state_dict(),
                        "network_type": network_type
                    }
                    
                    # 保存额外网络信息 (针对特定网络类型)
                    if hasattr(actor_network, 'lstm_hidden'):
                        save_dict["lstm_info"] = {
                            "lstm_hidden": actor_network.lstm_hidden,
                            "lstm_layers": actor_network.lstm_layers if hasattr(actor_network, 'lstm_layers') else 1,
                            "lstm_initialized": hasattr(actor_network, 'lstm')
                        }
                    
                    torch.save(save_dict, actor_path)
                    print(f"智能体 {agent_id} 的 {network_type} 网络已保存至: {actor_path}")
                except Exception as e:
                    print(f"保存智能体 {agent_id} 网络时出错: {e}")
                    traceback.print_exc()
            
            # 如果使用中央化Critic，保存中央化Critic
            if self.use_centralized_critic and hasattr(self.network_manager, 'central_critic'):
                critic_path = f"{path_prefix}_central_critic.pth"
                try:
                    critic_state_dict = self.network_manager.central_critic.state_dict()
                    torch.save(critic_state_dict, critic_path)
                    print(f"中央化Critic已保存至: {critic_path}")
                except Exception as e:
                    print(f"保存中央化Critic时出错: {e}")
                    traceback.print_exc()
            
            # 保存优化器状态
            optim_path = f"{path_prefix}_optimizers.pth"
            try:
                optim_states = {
                    "actor": {agent_id: optim.state_dict() 
                            for agent_id, optim in self.actor_optimizers.items()}
                }
                
                if hasattr(self, 'critic_optimizer'):
                    optim_states["critic"] = self.critic_optimizer.state_dict()
                    
                torch.save(optim_states, optim_path)
                print(f"优化器状态已保存至: {optim_path}")
            except Exception as e:
                print(f"保存优化器状态时出错: {e}")
                traceback.print_exc()
            
            return True
        except Exception as e:
            print(f"保存模型时发生错误: {e}")
            traceback.print_exc()
            return False
    
    def load_models(self, path_prefix):
        """
        加载所有智能体的模型
        
        参数:
            path_prefix: 加载路径前缀
        """
        try:
            # 尝试加载元数据
            metadata_path = f"{path_prefix}_metadata.pth"
            try:
                metadata = torch.load(metadata_path, map_location=self.device)
                print(f"已加载模型元数据: {metadata_path}")
                
                # 可以选择性地更新一些配置参数
                if "gamma" in metadata:
                    self.gamma = metadata["gamma"]
                if "gae_lambda" in metadata:
                    self.gae_lambda = metadata["gae_lambda"]
                if "clip_param" in metadata:
                    self.clip_param = metadata["clip_param"]
                if "action_dims" in metadata:
                    self.action_dims = metadata["action_dims"]
                if "obs_dims" in metadata:
                    self.obs_dims = metadata["obs_dims"]
                
                print("已更新MAPPO参数配置")
            except FileNotFoundError:
                print(f"未找到元数据文件: {metadata_path}，继续尝试加载模型")
            except Exception as e:
                print(f"加载元数据时出错: {e}")
            
            # 加载每个智能体的Actor网络
            for agent_id in self.agent_ids:
                actor_path = f"{path_prefix}_actor_{agent_id}.pth"
                try:
                    # 加载保存的字典
                    checkpoint = torch.load(actor_path, map_location=self.device)
                    
                    # 检查是否是新格式（带网络类型信息）
                    if isinstance(checkpoint, dict) and "state_dict" in checkpoint:
                        network = self.network_manager.actor_networks[agent_id]
                        
                        # 处理LSTM特殊情况
                        if "lstm_info" in checkpoint and hasattr(network, 'lstm_hidden'):
                            lstm_info = checkpoint["lstm_info"]
                            if lstm_info["lstm_initialized"] and not hasattr(network, 'lstm'):
                                # 如果保存的模型已初始化LSTM但当前未初始化，先初始化
                                dummy_input = torch.zeros(1, 32).to(self.device)
                                with torch.no_grad():
                                    _ = network(dummy_input)
                        
                        # 加载状态字典
                        try:
                            network.load_state_dict(checkpoint["state_dict"])
                            print(f"成功加载智能体 {agent_id} 的模型（新格式）")
                        except Exception as e:
                            print(f"加载智能体 {agent_id} 状态字典时出错: {e}")
                            # 尝试宽松加载
                            try:
                                network.load_state_dict(checkpoint["state_dict"], strict=False)
                                print(f"使用非严格模式成功加载智能体 {agent_id} 的模型")
                            except Exception as e2:
                                print(f"非严格模式加载也失败: {e2}")
                    else:
                        # 旧格式，直接加载
                        try:
                            self.network_manager.actor_networks[agent_id].load_state_dict(checkpoint)
                            print(f"成功加载智能体 {agent_id} 的模型（旧格式）")
                        except Exception as e:
                            print(f"加载旧格式模型时出错: {e}")
                            # 尝试宽松加载
                            try:
                                self.network_manager.actor_networks[agent_id].load_state_dict(checkpoint, strict=False)
                                print(f"使用非严格模式成功加载智能体 {agent_id} 的模型（旧格式）")
                            except Exception as e2:
                                print(f"非严格模式加载旧格式也失败: {e2}")
                        
                except FileNotFoundError:
                    print(f"找不到智能体 {agent_id} 的模型文件: {actor_path}")
                except Exception as e:
                    print(f"加载智能体 {agent_id} 的模型时出错: {e}")
                    traceback.print_exc()
            
            # 如果使用中央化Critic，加载中央化Critic
            if self.use_centralized_critic and hasattr(self.network_manager, 'central_critic'):
                critic_path = f"{path_prefix}_central_critic.pth"
                try:
                    critic_state_dict = torch.load(critic_path, map_location=self.device)
                    self.network_manager.central_critic.load_state_dict(critic_state_dict)
                    print(f"成功加载中央化Critic: {critic_path}")
                except FileNotFoundError:
                    print(f"找不到中央化Critic文件: {critic_path}")
                except Exception as e:
                    print(f"加载中央化Critic时出错: {e}")
                    traceback.print_exc()
                    # 尝试宽松加载
                    try:
                        self.network_manager.central_critic.load_state_dict(critic_state_dict, strict=False)
                        print("使用非严格模式成功加载中央化Critic")
                    except Exception as e2:
                        print(f"非严格模式加载中央化Critic也失败: {e2}")
            
            # 尝试加载优化器状态
            optim_path = f"{path_prefix}_optimizers.pth"
            try:
                optim_states = torch.load(optim_path, map_location=self.device)
                
                # 加载Actor优化器
                if "actor" in optim_states:
                    for agent_id, state in optim_states["actor"].items():
                        if agent_id in self.actor_optimizers:
                            try:
                                self.actor_optimizers[agent_id].load_state_dict(state)
                            except Exception as e:
                                print(f"加载智能体 {agent_id} 的优化器状态时出错: {e}")
                
                # 加载Critic优化器
                if "critic" in optim_states and hasattr(self, 'critic_optimizer'):
                    try:
                        self.critic_optimizer.load_state_dict(optim_states["critic"])
                    except Exception as e:
                        print(f"加载Critic优化器状态时出错: {e}")
                
                print("已加载优化器状态")
            except FileNotFoundError:
                print(f"未找到优化器状态文件: {optim_path}")
            except Exception as e:
                print(f"加载优化器状态时出错: {e}")
            
            print("模型加载完成")
            return True
        except Exception as e:
            print(f"加载模型时发生错误: {e}")
            traceback.print_exc()
            return False
            
    def state_dict(self):
        """返回MAPPO的状态字典，用于保存"""
        state = {
            "config": {
                "gamma": self.gamma,
                "gae_lambda": self.gae_lambda,
                "clip_param": self.clip_param,
                "value_clip_param": self.value_clip_param,
                "entropy_coef": self.entropy_coef,
                "value_loss_coef": self.value_loss_coef,
                "max_grad_norm": self.max_grad_norm,
                "use_clipped_value_loss": self.use_clipped_value_loss,
                "normalize_advantages": self.normalize_advantages,
                "use_centralized_critic": self.use_centralized_critic,
                "action_dims": self.action_dims,
                "obs_dims": self.obs_dims
            },
            "actor_optimizers": {agent_id: optim.state_dict() for agent_id, optim in self.actor_optimizers.items()}
        }
        
        if hasattr(self, 'critic_optimizer'):
            state["critic_optimizer"] = self.critic_optimizer.state_dict()
            
        return state
    
    def load_state_dict(self, state_dict):
        """从状态字典加载MAPPO状态"""
        if "config" in state_dict:
            config = state_dict["config"]
            self.gamma = config.get("gamma", self.gamma)
            self.gae_lambda = config.get("gae_lambda", self.gae_lambda)
            self.clip_param = config.get("clip_param", self.clip_param)
            self.value_clip_param = config.get("value_clip_param", self.value_clip_param)
            self.entropy_coef = config.get("entropy_coef", self.entropy_coef)
            self.value_loss_coef = config.get("value_loss_coef", self.value_loss_coef)
            self.max_grad_norm = config.get("max_grad_norm", self.max_grad_norm)
            self.use_clipped_value_loss = config.get("use_clipped_value_loss", self.use_clipped_value_loss)
            self.normalize_advantages = config.get("normalize_advantages", self.normalize_advantages)
            if "action_dims" in config:
                self.action_dims = config["action_dims"]
            if "obs_dims" in config:
                self.obs_dims = config["obs_dims"]
        
        if "actor_optimizers" in state_dict:
            for agent_id, optim_state in state_dict["actor_optimizers"].items():
                if agent_id in self.actor_optimizers:
                    try:
                        self.actor_optimizers[agent_id].load_state_dict(optim_state)
                    except Exception as e:
                        print(f"加载优化器状态失败: {e}")
        
        if "critic_optimizer" in state_dict and hasattr(self, 'critic_optimizer'):
            try:
                self.critic_optimizer.load_state_dict(state_dict["critic_optimizer"])
            except Exception as e:
                print(f"加载Critic优化器状态失败: {e}")

class MAPPOTrainer:
    """
    MAPPO训练器 - 简化训练流程
    """
    
    def __init__(
        self, 
        env, 
        network_manager,
        config=None,  # 新增配置参数
        buffer_size=2048,
        batch_size=64,
        lr_actor=3e-4,
        lr_critic=1e-3,
        gamma=0.99,
        gae_lambda=0.95,
        clip_param=0.2,
        value_clip_param=0.2,
        entropy_coef=0.01,
        value_loss_coef=0.5,
        max_grad_norm=0.5,
        use_clipped_value_loss=True,
        normalize_advantages=True,
        use_centralized_critic=True,
        device=None
    ):
        """
        初始化MAPPO训练器
        
        参数:
            env: 多智能体环境
            network_manager: 网络管理器
            config: 配置字典
            buffer_size: 经验回放缓冲区大小
            batch_size: 训练批次大小
            其他参数与MAPPO相同
        """
        self.env = env
        self.network_manager = network_manager
        self.agent_ids = network_manager.agent_ids
        
        # 从配置中读取参数
        if config is not None:
            buffer_size = config.get("buffer_size", buffer_size)
            batch_size = config.get("batch_size", batch_size)
            lr_actor = config.get("lr_actor", lr_actor)
            lr_critic = config.get("lr_critic", lr_critic)
            gamma = config.get("gamma", gamma)
            gae_lambda = config.get("gae_lambda", gae_lambda)
            clip_param = config.get("clip_param", clip_param)
            value_clip_param = config.get("value_clip_param", value_clip_param)
            entropy_coef = config.get("entropy_coef", entropy_coef)
            value_loss_coef = config.get("value_loss_coef", value_loss_coef)
            max_grad_norm = config.get("max_grad_norm", max_grad_norm)
            use_clipped_value_loss = config.get("use_clipped_value_loss", use_clipped_value_loss)
            normalize_advantages = config.get("normalize_advantages", normalize_advantages)
            use_centralized_critic = config.get("use_centralized_critic", use_centralized_critic)
            
            device_str = config.get("device", None)
            if device_str:
                device = torch.device(device_str)
                
        self.device = device or torch.device('cpu')
        self.batch_size = batch_size
        
        # 打印训练器配置
        print("\n" + "-"*50)
        print("MAPPO训练器配置参数:")
        print(f"  批次大小: {batch_size}")
        print(f"  缓冲区大小: {buffer_size}")
        print(f"  计算设备: {self.device}")
        print("-"*50 + "\n")
        
        # 获取环境信息 - 动态获取观察和动作空间维度
        self.obs_dims = {}
        self.action_dims = {}
        
        try:
            # 直接从环境获取观察空间和动作空间维度
            if hasattr(env, 'observation_space'):
                for agent_id in self.agent_ids:
                    if agent_id in env.observation_space:
                        if hasattr(env.observation_space[agent_id], 'shape'):
                            self.obs_dims[agent_id] = env.observation_space[agent_id].shape[0]
                            print(f"从环境获取智能体 {agent_id} 的观察维度: {self.obs_dims[agent_id]}")
            
            if hasattr(env, 'action_space'):
                for agent_id in self.agent_ids:
                    if agent_id in env.action_space:
                        if hasattr(env.action_space[agent_id], 'shape'):
                            self.action_dims[agent_id] = env.action_space[agent_id].shape[0]
                            print(f"从环境获取智能体 {agent_id} 的动作维度: {self.action_dims[agent_id]}")
        except Exception as e:
            print(f"从环境获取维度信息时出错: {e}")
            traceback.print_exc()
        
        # 如果没有从环境获取到维度信息，尝试从网络管理器获取
        self._infer_dimensions_from_network()
        
        # 如果配置中提供了维度信息，使用配置中的值
        if config is not None and "agent_dims" in config:
            for agent_id, dims in config["agent_dims"].items():
                if agent_id in self.agent_ids:
                    if "obs_dim" in dims and (agent_id not in self.obs_dims or self.obs_dims[agent_id] is None):
                        self.obs_dims[agent_id] = dims["obs_dim"]
                        print(f"从配置获取智能体 {agent_id} 的观察维度: {dims['obs_dim']}")
                    if "action_dim" in dims and (agent_id not in self.action_dims or self.action_dims[agent_id] is None):
                        self.action_dims[agent_id] = dims["action_dim"]
                        print(f"从配置获取智能体 {agent_id} 的动作维度: {dims['action_dim']}")
        
        # 确认所有维度都已获取，如果没有则使用默认值1
        for agent_id in self.agent_ids:
            if agent_id not in self.obs_dims or self.obs_dims[agent_id] is None:
                self.obs_dims[agent_id] = 1  # 使用默认值1
                print(f"无法确定智能体 {agent_id} 的观察维度，使用默认值: 1")
                
            if agent_id not in self.action_dims or self.action_dims[agent_id] is None:
                self.action_dims[agent_id] = 1  # 使用默认值1
                print(f"无法确定智能体 {agent_id} 的动作维度，使用默认值: 1")
        
        # 创建经验回放缓冲区
        from .buffer import MultiAgentRolloutBuffer
        
        # 确定全局状态维度
        global_state_dim = None
        if hasattr(env, 'global_state_dim'):
            global_state_dim = env.global_state_dim
        else:
            # 尝试从观察维度推断
            global_state_dim = sum(self.obs_dims.values())
            print(f"从智能体观察维度推断全局状态维度: {global_state_dim}")
        
        # 从配置中获取缓冲区详细输出设置
        buffer_verbose = False
        if config is not None:
            # 优先检查专门的缓冲区配置
            if "buffer_config" in config:
                buffer_verbose = config["buffer_config"].get("verbose", False)
            # 否则使用通用调试标志
            elif "debug" in config:
                buffer_verbose = config.get("debug", False)
        
        # 创建缓冲区并控制输出
        self.buffer = MultiAgentRolloutBuffer(
            buffer_size=buffer_size,
            obs_dims=self.obs_dims,
            action_dims=self.action_dims,
            gamma=gamma,
            gae_lambda=gae_lambda,
            use_centralized_critic=use_centralized_critic,
            global_state_dim=global_state_dim,
            device=self.device,
            verbose=buffer_verbose  # 新增参数控制输出
        )
        
        # 创建MAPPO算法
        self.mappo = MAPPO(
            network_manager=network_manager,
            buffer=self.buffer,
            config=config,  # 传递配置字典
            lr_actor=lr_actor,
            lr_critic=lr_critic,
            gamma=gamma,
            gae_lambda=gae_lambda,
            clip_param=clip_param,
            value_clip_param=value_clip_param,
            entropy_coef=entropy_coef,
            value_loss_coef=value_loss_coef,
            max_grad_norm=max_grad_norm,
            use_clipped_value_loss=use_clipped_value_loss,
            normalize_advantages=normalize_advantages,
            use_centralized_critic=use_centralized_critic,
            device=self.device
        )
        
        # 训练统计
        self.episode_rewards = {agent_id: [] for agent_id in self.agent_ids}
        self.episode_lengths = []
        self.total_updates = 0
        
        # 添加回合计数追踪
        self.total_episodes = 0
        self.current_episode_steps = 0
        self.current_episode_rewards = {agent_id: 0 for agent_id in self.agent_ids}
        
        # 调试信息
        print(f"训练器初始化完成。总回合数: {self.total_episodes}")
    
    def _infer_dimensions_from_network(self):
        """从网络结构推断观察和动作维度"""
        for agent_id, network in self.network_manager.actor_networks.items():
            # 推断观察维度
            if agent_id not in self.obs_dims or self.obs_dims[agent_id] is None:
                input_dim = None
                
                # 检查不同类型的网络结构
                if hasattr(network, 'base') and len(network.base) > 0:
                    for layer in network.base:
                        if isinstance(layer, nn.Linear) and hasattr(layer, 'weight'):
                            input_dim = layer.weight.shape[1]
                            break
                
                if input_dim is None and hasattr(network, 'feature_extractor') and len(network.feature_extractor) > 0:
                    for layer in network.feature_extractor:
                        if isinstance(layer, nn.Linear) and hasattr(layer, 'weight'):
                            input_dim = layer.weight.shape[1]
                            break
                
                if input_dim is None and hasattr(network, 'pressure_encoder') and len(network.pressure_encoder) > 0:
                    for layer in network.pressure_encoder:
                        if isinstance(layer, nn.Linear) and hasattr(layer, 'weight'):
                            input_dim = layer.weight.shape[1]
                            break
                
                if input_dim is None and hasattr(network, 'lstm') and hasattr(network.lstm, 'input_size'):
                    input_dim = network.lstm.input_size
                
                if input_dim is not None:
                    self.obs_dims[agent_id] = input_dim
                    print(f"从网络结构推断智能体 {agent_id} 的观察维度: {input_dim}")
            
            # 推断动作维度
            if agent_id not in self.action_dims or self.action_dims[agent_id] is None:
                output_dim = None
                
                # 检查不同类型的网络输出层
                if hasattr(network, 'action_head') and hasattr(network.action_head, 'weight'):
                    output_dim = network.action_head.weight.shape[0]
                
                elif hasattr(network, 'mu_head') and hasattr(network.mu_head, 'weight'):
                    output_dim = network.mu_head.weight.shape[0]
                    
                elif hasattr(network, 'actor_mean') and hasattr(network.actor_mean, 'weight'):
                    output_dim = network.actor_mean.weight.shape[0]
                
                if output_dim is not None:
                    self.action_dims[agent_id] = output_dim
                    print(f"从网络结构推断智能体 {agent_id} 的动作维度: {output_dim}")
                
    def initialize_networks(self):
        """确保所有网络层都已初始化"""
        print("\n初始化网络层...")
        
        # 从网络管理器获取正确的输入维度并初始化网络
        for agent_id, network in self.network_manager.actor_networks.items():
            try:
                # 获取观察维度
                input_dim = self.obs_dims.get(agent_id)
                if input_dim is None:
                    print(f"警告: 无法确定智能体 {agent_id} 的观察维度，跳过初始化")
                    continue
                
                # 生成正确维度的随机输入
                dummy_input = torch.zeros(1, input_dim).to(self.device)
                
                print(f"初始化智能体 {agent_id} 网络，输入维度: {input_dim}")
                
                with torch.no_grad():
                    if hasattr(network, 'reset_hidden'):
                        # 重置LSTM状态
                        network.reset_hidden(batch_size=1)
                    
                    # 检查网络的前向传播方法
                    if hasattr(network, 'forward'):
                        _ = network.forward(dummy_input)
                    else:
                        # 尝试直接调用网络
                        _ = network(dummy_input)
                        
                print(f"智能体 {agent_id} 网络已成功初始化")
            except Exception as e:
                print(f"初始化智能体 {agent_id} 网络时出错: {e}")
                traceback.print_exc()
                print(f"跳过智能体 {agent_id} 初始化")
                
        # 如果使用中央化Critic，也要初始化它
        if self.mappo.use_centralized_critic and hasattr(self.network_manager, 'central_critic'):
            try:
                # 获取全局状态维度
                global_state_dim = None
                
                # 尝试从buffer获取
                if hasattr(self.buffer, 'global_state_dim'):
                    global_state_dim = self.buffer.global_state_dim
                
                # 如果无法从buffer获取，尝试从环境获取
                if global_state_dim is None and hasattr(self.env, 'global_state_dim'):
                    global_state_dim = self.env.global_state_dim
                
                # 如果仍然无法获取，尝试从观察维度总和推断
                if global_state_dim is None:
                    global_state_dim = sum(self.obs_dims.values())
                    
                print(f"初始化中央化Critic，输入维度: {global_state_dim}")
                dummy_global_input = torch.zeros(1, global_state_dim).to(self.device)
                
                with torch.no_grad():
                    _ = self.network_manager.central_critic(dummy_global_input)
                    
                print("中央化Critic已成功初始化")
            except Exception as e:
                print(f"初始化中央化Critic时出错: {e}")
                traceback.print_exc()
                print("跳过中央化Critic初始化")
        
        print("网络初始化完成\n")
    
    def collect_trajectories(self, num_steps=None, config=None):
        """
        收集经验轨迹并准确跟踪回合完成情况
        
        参数:
            num_steps: 收集的步骤数，如果为None则从config中读取
            config: 配置字典
            
        返回:
            episode_rewards: 每个智能体在完成回合中的奖励
            episode_lengths: 完成回合的长度
            completed_episodes: 本次收集完成的回合数
        """
        # 从配置中读取参数
        if config is not None:
            num_steps = config.get("steps_per_update", num_steps or 2048)
            max_episode_steps = config.get("max_steps", 50)  # 添加回合最大步数限制
        else:
            num_steps = num_steps or 2048
            max_episode_steps = 50
            
        # 准备记录本次收集的数据
        collected_rewards = {agent_id: [] for agent_id in self.agent_ids}
        collected_lengths = []
        completed_episodes = 0  # 本次完成的回合数
        steps_collected = 0
        
        # 确保环境已初始化
        if not hasattr(self, '_env_initialized') or not self._env_initialized:
            observations = self.env.reset()
            self.current_episode_steps = 0
            self.current_episode_rewards = {agent_id: 0 for agent_id in self.agent_ids}
            self._env_initialized = True
            
            global_state = None
            if hasattr(self.env, 'get_global_state'):
                global_state = self.env.get_global_state()
        else:
            # 使用上次收集结束后的状态继续
            observations = getattr(self, '_last_observations', None)
            if observations is None:
                observations = self.env.reset()
                self.current_episode_steps = 0
                self.current_episode_rewards = {agent_id: 0 for agent_id in self.agent_ids}
            
            global_state = getattr(self, '_last_global_state', None)
            if global_state is None and hasattr(self.env, 'get_global_state'):
                global_state = self.env.get_global_state()
        
        # 收集轨迹
        print(f"开始收集轨迹，目标步数: {num_steps}, 当前回合步数: {self.current_episode_steps}")
        
        try:
            while steps_collected < num_steps:
                # 获取动作和价值
                actions, log_probs, values = self.mappo.act(observations)
                
                # 如果使用中央化Critic，获取全局价值
                global_value = None
                if self.mappo.use_centralized_critic and global_state is not None:
                    global_value = self.mappo.get_central_value(global_state)
                
                # 执行动作
                next_observations, rewards, dones, infos = self.env.step(actions)
                
                # 增加当前回合步数
                self.current_episode_steps += 1
                
                # 获取下一个全局状态
                next_global_state = None
                if hasattr(self.env, 'get_global_state'):
                    next_global_state = self.env.get_global_state()
                
                # 存储经验
                self.buffer.store(
                    observations=observations,
                    actions=actions,
                    rewards=rewards,
                    dones=dones,
                    next_observations=next_observations,
                    values=values,
                    log_probs=log_probs,
                    global_state=global_state,
                    next_global_state=next_global_state,
                    global_value=global_value
                )
                
                # 更新观察和全局状态
                observations = next_observations
                global_state = next_global_state
                
                # 累积回合奖励
                for agent_id in self.agent_ids:
                    if agent_id in rewards:
                        self.current_episode_rewards[agent_id] += rewards[agent_id]
                
                # 增加收集的步数
                steps_collected += 1
                
                # 检查回合是否结束 - 三种可能情况：
                # 1. dones中的__all__标记为True
                # 2. 所有智能体的done都为True
                # 3. 达到最大回合步数
                
                # 检查是否有全局完成信号
                global_done = False
                if isinstance(dones, dict):
                    global_done = dones.get("__all__", False)
                    if not global_done:
                        # 如果没有全局信号，检查是否所有智能体都完成
                        agent_dones = [dones.get(agent_id, False) for agent_id in self.agent_ids]
                        global_done = all(agent_dones)
                else:
                    # 如果dones是单个布尔值
                    global_done = bool(dones)
                
                # 检查是否达到最大步数
                max_steps_reached = self.current_episode_steps >= max_episode_steps
                
                # 回合结束处理
                if global_done or max_steps_reached:
                    # 增加完成的回合数
                    completed_episodes += 1
                    self.total_episodes += 1
                    
                    # 记录回合统计
                    collected_lengths.append(self.current_episode_steps)
                    for agent_id in self.agent_ids:
                        collected_rewards[agent_id].append(self.current_episode_rewards[agent_id])
                    
                    # 添加到历史记录
                    self.episode_lengths.append(self.current_episode_steps)
                    for agent_id in self.agent_ids:
                        if agent_id in self.current_episode_rewards:
                            self.episode_rewards[agent_id].append(self.current_episode_rewards[agent_id])
                    
                    # 打印回合完成信息
                    end_reason = "达到步数限制" if max_steps_reached else "环境结束信号"
                    print(f"回合 {self.total_episodes} 完成 ({end_reason})，长度: {self.current_episode_steps}，奖励: {dict(self.current_episode_rewards)}")
                    
                    # 重置环境和回合状态
                    observations = self.env.reset()
                    if hasattr(self.env, 'get_global_state'):
                        global_state = self.env.get_global_state()
                    
                    # 重置当前回合状态
                    self.current_episode_steps = 0
                    self.current_episode_rewards = {agent_id: 0 for agent_id in self.agent_ids}
                    
                    # 重置LSTM隐藏状态
                    self.network_manager.reset_lstm_states()
                
                # 检查是否已收集足够步数
                if steps_collected >= num_steps:
                    break
                    
        except Exception as e:
            print(f"收集轨迹时出错: {e}")
            traceback.print_exc()
            
            # 尝试恢复状态
            try:
                observations = self.env.reset()
                if hasattr(self.env, 'get_global_state'):
                    global_state = self.env.get_global_state()
                
                self.current_episode_steps = 0
                self.current_episode_rewards = {agent_id: 0 for agent_id in self.agent_ids}
                self.network_manager.reset_lstm_states()
                print("已恢复环境状态")
            except Exception as recovery_err:
                print(f"恢复环境状态失败: {recovery_err}")
        
        # 保存最后的观察和状态以供下次继续
        self._last_observations = observations
        self._last_global_state = global_state
        
        print(f"轨迹收集完成，收集了 {steps_collected} 步，完成了 {completed_episodes} 个回合")
        print(f"当前总回合数: {self.total_episodes}")
        
        # 返回本次收集的回合奖励、长度以及完成的回合数
        return collected_rewards, collected_lengths, completed_episodes
    
    def train(self, num_episodes=None, steps_per_update=None, num_updates=None, k_epochs=None, config=None):
        """
        训练MAPPO算法
        
        参数:
            num_episodes: 训练的episode数量，如果为None则从config中读取
            steps_per_update: 每次更新前收集的步骤数，如果为None则从config中读取
            num_updates: 每次收集后进行的更新次数，如果为None则从config中读取
            k_epochs: 每个批次的训练轮数，如果为None则从config中读取
            config: 训练配置字典，优先级高于其他参数
            
        返回:
            训练统计信息
        """
        # 初始化网络（但允许在错误的情况下继续训练）
        try:
            self.initialize_networks()
        except Exception as e:
            print(f"网络初始化出错，但继续训练: {e}")
        
        # 从配置中读取参数
        if config is not None:
            num_episodes = config.get("num_episodes", num_episodes or 1000)
            steps_per_update = config.get("steps_per_update", steps_per_update or 2048)
            num_updates = config.get("num_updates", num_updates or 4)
            k_epochs = config.get("k_epochs", k_epochs or 10)
            max_steps = config.get("max_steps", 50)  # 每回合最大步数
        else:
            # 使用默认值或传入的参数
            num_episodes = num_episodes or 1000
            steps_per_update = steps_per_update or 2048
            num_updates = num_updates or 4
            k_epochs = k_epochs or 10
            max_steps = 50
        
        # 打印训练参数
        print("\n" + "-"*50)
        print("训练参数:")
        print(f"  总回合数: {num_episodes}")
        print(f"  每次更新步数: {steps_per_update}")
        print(f"  每次采集后更新次数: {num_updates}")
        print(f"  每次更新的K轮次: {k_epochs}")
        print(f"  每回合最大步数: {max_steps}")
        print("-"*50 + "\n")
        
        total_steps = 0
        start_time = time.time()
        
        try:
            while self.total_episodes < num_episodes:
                # 收集轨迹
                collection_config = {
                    "steps_per_update": steps_per_update,
                    "max_steps": max_steps
                }
                _, _, completed = self.collect_trajectories(config=collection_config)
                total_steps += steps_per_update
                
                # 执行多次策略更新
                update_success = False
                for update_idx in range(num_updates):
                    try:
                        update_config = {
                            "k_epochs": k_epochs,
                            "batch_size": self.batch_size
                        }
                        update_result = self.mappo.update(config=update_config)
                        if update_result:
                            self.total_updates += 1
                            update_success = True
                    except Exception as e:
                        print(f"策略更新 {update_idx+1} 失败: {e}")
                        traceback.print_exc()
                
                if not update_success:
                    print("所有策略更新失败，跳过此轮更新")
                
                # 打印统计信息
                if self.total_episodes % 10 == 0 or self.total_episodes >= num_episodes:
                    # 计算每个智能体的平均奖励
                    avg_rewards = {}
                    for agent_id in self.agent_ids:
                        rewards = self.episode_rewards.get(agent_id, [])
                        if rewards:
                            last_rewards = rewards[-10:] if len(rewards) >= 10 else rewards
                            avg_rewards[agent_id] = np.mean(last_rewards)
                        else:
                            avg_rewards[agent_id] = float('nan')  # 使用NaN代替0
                    
                    # 计算平均回合长度
                    avg_length = 0
                    if self.episode_lengths:
                        last_lengths = self.episode_lengths[-10:] if len(self.episode_lengths) >= 10 else self.episode_lengths
                        avg_length = np.mean(last_lengths)
                    
                    # 计算进度和时间
                    elapsed = time.time() - start_time
                    progress = self.total_episodes / num_episodes * 100
                    est_total = elapsed / max(0.001, self.total_episodes) * num_episodes
                    remaining = est_total - elapsed
                    
                    # 格式化时间
                    def format_time(seconds):
                        hours = int(seconds // 3600)
                        minutes = int((seconds % 3600) // 60)
                        secs = int(seconds % 60)
                        return f"{hours}时{minutes}分{secs}秒"
                    
                    print(f"\n回合: {self.total_episodes}/{num_episodes} ({progress:.1f}%), 总步数: {total_steps}")
                    print(f"更新次数: {self.total_updates}, 平均回合长度: {avg_length:.1f}")
                    print(f"已用时间: {format_time(elapsed)}, 预计剩余: {format_time(remaining)}")
                    
                    for agent_id, avg_reward in avg_rewards.items():
                        if not np.isnan(avg_reward):
                            print(f"智能体 {agent_id} 平均奖励: {avg_reward:.2f}")
                        else:
                            print(f"智能体 {agent_id} 平均奖励: N/A")
                    print("-" * 50)
                    
        except KeyboardInterrupt:
            print("\n训练被用户中断")
        except Exception as e:
            print(f"\n训练过程中发生错误: {e}")
            traceback.print_exc()
        
        return {
            'episode_rewards': self.episode_rewards,
            'episode_lengths': self.episode_lengths,
            'total_updates': self.total_updates,
            'total_episodes': self.total_episodes
        }
    
    def get_action(self, agent_id, observation):
        """获取单个智能体的动作"""
        return self.mappo.get_action(agent_id, observation)
    
    def save(self, path):
        """
        保存模型和训练状态
        
        参数:
            path: 保存路径
        """
        try:
            # 确保目录存在
            dirname = os.path.dirname(path)
            if dirname:
                os.makedirs(dirname, exist_ok=True)
            
            print(f"\n正在保存模型到: {path}")
            
            # 保存MAPPO模型
            success = self.mappo.save_models(path)
            
            if success:
                # 保存训练器状态
                trainer_state = {
                    "episode_rewards": self.episode_rewards,
                    "episode_lengths": self.episode_lengths,
                    "total_updates": self.total_updates,
                    "total_episodes": self.total_episodes,
                    "current_episode_steps": self.current_episode_steps,
                    "current_episode_rewards": self.current_episode_rewards,
                    "batch_size": self.batch_size,
                    "device": str(self.device),
                    "timestamp": str(time.time()),
                    "obs_dims": self.obs_dims,
                    "action_dims": self.action_dims
                }
                
                trainer_path = f"{path}_trainer_state.pth"
                torch.save(trainer_state, trainer_path)
                print(f"训练器状态已保存至: {trainer_path}")
                print(f"当前总回合数: {self.total_episodes}")
                
                return True
            else:
                print("由于MAPPO模型保存失败，训练器状态未保存")
                return False
        except Exception as e:
            print(f"保存失败: {e}")
            traceback.print_exc()
            return False
    
    def load(self, path):
        """
        加载模型和训练状态
        
        参数:
            path: 加载路径
        """
        try:
            print(f"\n正在加载模型: {path}")
            
            # 加载MAPPO模型
            success = self.mappo.load_models(path)
            
            # 尝试加载训练器状态
            try:
                trainer_path = f"{path}_trainer_state.pth"
                trainer_state = torch.load(trainer_path, map_location=self.device)
                
                # 恢复训练统计
                if "episode_rewards" in trainer_state:
                    self.episode_rewards = trainer_state["episode_rewards"]
                if "episode_lengths" in trainer_state:
                    self.episode_lengths = trainer_state["episode_lengths"]
                if "total_updates" in trainer_state:
                    self.total_updates = trainer_state["total_updates"]
                if "total_episodes" in trainer_state:
                    self.total_episodes = trainer_state["total_episodes"]
                if "current_episode_steps" in trainer_state:
                    self.current_episode_steps = trainer_state["current_episode_steps"]
                if "current_episode_rewards" in trainer_state:
                    self.current_episode_rewards = trainer_state["current_episode_rewards"]
                if "batch_size" in trainer_state:
                    self.batch_size = trainer_state["batch_size"]
                if "obs_dims" in trainer_state:
                    self.obs_dims = trainer_state["obs_dims"]
                if "action_dims" in trainer_state:
                    self.action_dims = trainer_state["action_dims"]
                
                print(f"已加载训练器状态: {self.total_episodes} 回合, {self.total_updates} 次更新")
                return True
            except FileNotFoundError:
                print(f"未找到训练器状态文件: {trainer_path}")
                return success
            except Exception as e:
                print(f"加载训练器状态时出错: {e}")
                traceback.print_exc()
                return success
        except Exception as e:
            print(f"加载模型时出错: {e}")
            traceback.print_exc()
            return False
