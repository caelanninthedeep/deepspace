# ==== robust_addons.py（可直接粘贴到现有脚本后面）====
import numpy as np, pandas as pd
from scipy.optimize import linear_sum_assignment

# 配置
CSV_PATH = r"saved_models/memory_management_20250808_121204/models/test_results/episodes_summary.csv"
N_BOOT = 5000

diff_cols = ['difficulty:easy','difficulty:medium','difficulty:hard','difficulty:extreme','difficulty:unknown']
wl_cols   = ['workload:file_cache_intensive','workload:io_intensive','workload:memory_intensive','workload:mixed_workload','workload:unknown']
comp_cols = diff_cols + wl_cols

def _read_and_prepare(csv_path):
    df = pd.read_csv(csv_path)
    df['phase'] = df['phase'].astype(str).str.lower().str.strip()
    for c in comp_cols + ['steps','total_reward','final_runtime_sec']:
        if c not in df.columns: df[c] = 0
        df[c] = pd.to_numeric(df[c], errors='coerce').fillna(0)
    base  = df[df['phase']=='baseline'].copy().reset_index(drop=True)
    mappo = df[df['phase']=='mappo'].copy().reset_index(drop=True)
    def as_prop(row):
        s = row['steps'] if row['steps']>0 else 1.0
        return row[comp_cols].to_numpy(dtype=float)/float(s)
    base['comp']  = base.apply(as_prop, axis=1)
    mappo['comp'] = mappo.apply(as_prop, axis=1)
    return base, mappo

def _l1(a,b): return float(np.abs(a-b).sum())
def _l2(a,b): return float(np.sqrt(((a-b)**2).sum()))
def _cos(a,b):
    na, nb = np.linalg.norm(a)+1e-12, np.linalg.norm(b)+1e-12
    return float(1.0 - (a@b)/(na*nb))  # 余弦距离=1-相似度

def _bootstrap_ci(x, n_boot=5000, seed=42):
    if len(x)<2: return (np.nan, np.nan, np.nan)
    rng = np.random.default_rng(seed)
    means = []
    n = len(x)
    for _ in range(n_boot):
        idx = rng.integers(0, n, n)
        means.append(np.mean(np.asarray(x)[idx]))
    means = np.sort(means)
    return (float(np.mean(x)), float(means[int(0.025*n_boot)]), float(means[int(0.975*n_boot)]))

def _report_deltas(pairs, mappo, base, tag=""):
    d_rt, d_rw, gaps = [], [], []
    for i,j,dist in pairs:
        rA, rB = mappo.loc[i], base.loc[j]
        d_rt.append(float(rB['final_runtime_sec']) - float(rA['final_runtime_sec']))  # 越大越好
        d_rw.append(float(rA['total_reward']) - float(rB['total_reward']))           # 越大越好
        gaps.append(float(dist))
    mR, loR, hiR = _bootstrap_ci(d_rt, N_BOOT)
    mW, loW, hiW = _bootstrap_ci(d_rw, N_BOOT)
    gaps = np.asarray(gaps) if gaps else np.array([np.nan])
    print(f"\n=== {tag} ===")
    print(f"配对数: {len(d_rt)}")
    print(f"匹配距离: mean={np.nanmean(gaps):.4f}, median={np.nanmedian(gaps):.4f}, p90={np.nanpercentile(gaps,90):.4f}, max={np.nanmax(gaps):.4f}")
    print(f"→ 运行时间（基线 - MAPPO），秒：mean={mR:.4f}  95%CI[{loR:.4f},{hiR:.4f}]  {'非显著' if loR<=0<=hiR else '显著'}")
    print(f"→ 奖励（MAPPO - 基线）：      mean={mW:.2f}   95%CI[{loW:.2f},{hiW:.2f}]  {'非显著' if loW<=0<=hiW else '显著'}")
    return np.array(d_rt), np.array(d_rw), gaps

def _greedy_match(base, mappo, dist_fn=_l1, caliper=None, no_replacement=True):
    used = set()
    pairs = []
    for i, ri in mappo.iterrows():
        best_j, best_d = None, 1e9
        for j, rj in base.iterrows():
            if no_replacement and j in used: 
                continue
            d = dist_fn(ri['comp'], rj['comp'])
            if caliper is not None and d>caliper: 
                continue
            if d < best_d:
                best_d, best_j = d, j
        if best_j is not None:
            pairs.append((i, best_j, best_d))
            used.add(best_j)
    return pairs

def _hungarian_match(base, mappo, dist_fn=_l1, caliper=None):
    # 构造代价矩阵（mappo 行，base 列）
    A = np.vstack(mappo['comp'].values)
    B = np.vstack(base['comp'].values)
    cost = np.zeros((A.shape[0], B.shape[0]), dtype=float)
    for i in range(A.shape[0]):
        for j in range(B.shape[0]):
            cost[i,j] = dist_fn(A[i], B[j])
    if caliper is not None:
        cost[np.where(cost>caliper)] = 1e9  # 超卡尺的禁用
    r_ind, c_ind = linear_sum_assignment(cost)  # 支持非方阵，返回 min(nA,nB) 对
    pairs = []
    for i,j in zip(r_ind, c_ind):
        d = cost[i,j]
        if d>=1e9: 
            continue
        # 取回原 DataFrame 的行号
        pairs.append((mappo.index[i], base.index[j], d))
    return pairs

def _smd(X_treat, X_ctrl, names):
    # 标准化差异： (mean_t - mean_c) / pooled_sd
    mt, mc = X_treat.mean(axis=0), X_ctrl.mean(axis=0)
    st, sc = X_treat.std(axis=0, ddof=1), X_ctrl.std(axis=0, ddof=1)
    pooled = np.sqrt((st**2 + sc**2)/2.0) + 1e-12
    smd = (mt - mc) / pooled
    out = pd.DataFrame({'feature': names, 'mean_treat': mt, 'mean_ctrl': mc, 'SMD': smd})
    out['|SMD|'] = out['SMD'].abs()
    return out.sort_values('|SMD|', ascending=False)

def run_quick_robust_checks():
    base, mappo = _read_and_prepare(CSV_PATH)

    # 1) 放宽卡尺到 0.5（L1，贪心，不放回）
    pairs_greedy_c05 = _greedy_match(base, mappo, dist_fn=_l1, caliper=0.5, no_replacement=True)
    _report_deltas(pairs_greedy_c05, mappo, base, tag="主分析变体：L1 贪心, 不放回, 卡尺=0.5")

    # 2) 匈牙利全局最优（L1），给一个中等卡尺（0.5），也顺便跑一个无限制
    pairs_hung_c05 = _hungarian_match(base, mappo, dist_fn=_l1, caliper=0.5)
    _report_deltas(pairs_hung_c05, mappo, base, tag="匈牙利（全局最优）: L1, 卡尺=0.5")

    pairs_hung_free = _hungarian_match(base, mappo, dist_fn=_l1, caliper=None)
    d_rt, d_rw, gaps = _report_deltas(pairs_hung_free, mappo, base, tag="匈牙利（全局最优）: L1, 无卡尺")

    # 3) 平衡诊断（SMD）：匹配前 vs 后（用“匈牙利无卡尺”做演示）
    X_treat_all = np.vstack(mappo['comp'].values)
    X_ctrl_all  = np.vstack(base['comp'].values)
    smd_before  = _smd(X_treat_all, X_ctrl_all, comp_cols)

    if len(pairs_hung_free)>0:
        idx_m = [i for i,_,_ in pairs_hung_free]
        idx_b = [j for _,j,_ in pairs_hung_free]
        X_treat_matched = np.vstack(mappo.loc[idx_m, 'comp'].values)
        X_ctrl_matched  = np.vstack(base.loc[idx_b, 'comp'].values)
        smd_after = _smd(X_treat_matched, X_ctrl_matched, comp_cols)
        print("\n=== 平衡诊断（SMD） ===")
        print(f"匹配前最大 |SMD|: {smd_before['|SMD|'].max():.3f}")
        print(f"匹配后最大 |SMD|: {smd_after['|SMD|'].max():.3f}")
        print("匹配后 |SMD| 前5项：")
        print(smd_after.head(5).to_string(index=False))
    else:
        print("\nSMD 无法计算：匈牙利匹配为空。")

if __name__ == "__main__":
    run_quick_robust_checks()

