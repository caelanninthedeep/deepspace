import random
import numpy as np
from collections import deque

class HybridBalancedStrategy:
    """
    混合均衡策略：结合课程学习和随机探索，
    用于在强化学习训练中动态调整工作负载难度分布
    """
    def __init__(self, config=None):
        """初始化混合均衡策略"""
        
        # 默认配置
        self.config = {
            "warmup_episodes": 1000,      # 预热阶段的回合数
            "mid_phase_episodes": 3000,   # 中期阶段的回合数
            "performance_window": 100,    # 性能追踪窗口大小
            "success_threshold": 0.6,     # 进阶难度的成功率阈值
            "exploration_factor": 0.3,    # 初始探索因子
            "difficulty_levels": ["easy", "medium", "hard", "extreme"],
            "balancing_interval": 50      # 重新平衡难度分布的间隔
        }
        
        # 更新配置
        if config:
            self.config.update(config)
            
        # 初始化性能跟踪
        self.performance_history = {
            "easy": deque(maxlen=self.config["performance_window"]),
            "medium": deque(maxlen=self.config["performance_window"]),
            "hard": deque(maxlen=self.config["performance_window"]),
            "extreme": deque(maxlen=self.config["performance_window"])
        }
        
        # 当前回合计数
        self.episode_count = 0
        
        # 难度分布
        self.difficulty_distribution = self._initialize_distribution()
        
        # 分布历史记录（用于可视化）
        self.distribution_history = []
    
    def _initialize_distribution(self):
        """初始化难度分布"""
        return {
            "easy": 0.7,
            "medium": 0.2,
            "hard": 0.08,
            "extreme": 0.02
        }
    
    def select_difficulty(self):
        """选择当前训练回合的难度级别"""
        # 每隔一定回合，更新难度分布
        if self.episode_count % self.config["balancing_interval"] == 0:
            self._update_difficulty_distribution()
        
        # 增加回合计数
        self.episode_count += 1
        
        # 根据当前分布选择难度
        return random.choices(
            self.config["difficulty_levels"], 
            weights=[self.difficulty_distribution[d] for d in self.config["difficulty_levels"]]
        )[0]
    
    def _update_difficulty_distribution(self):
        """更新难度分布"""
        # 1. 基于训练阶段的课程学习分量
        curriculum_distribution = self._get_curriculum_distribution()
        
        # 2. 基于性能的反馈分量
        performance_distribution = self._get_performance_based_distribution()
        
        # 3. 探索分量（随机）
        exploration_rate = self._get_exploration_rate()
        exploration_distribution = {d: 1/len(self.config["difficulty_levels"]) for d in self.config["difficulty_levels"]}
        
        # 4. 综合三种分量
        self.difficulty_distribution = {}
        for difficulty in self.config["difficulty_levels"]:
            self.difficulty_distribution[difficulty] = (
                (1 - exploration_rate) * (
                    0.6 * curriculum_distribution[difficulty] + 
                    0.4 * performance_distribution[difficulty]
                ) +
                exploration_rate * exploration_distribution[difficulty]
            )
        
        # 归一化
        total = sum(self.difficulty_distribution.values())
        for difficulty in self.difficulty_distribution:
            self.difficulty_distribution[difficulty] /= total
            
        # 记录分布历史
        self.distribution_history.append(self.difficulty_distribution.copy())
            
        self._log_distribution_update()
    
    def _get_curriculum_distribution(self):
        """获取基于课程学习的难度分布"""
        # 根据训练进度调整
        if self.episode_count < self.config["warmup_episodes"]:
            # 预热阶段：主要是简单难度
            return {
                "easy": 0.7,
                "medium": 0.2,
                "hard": 0.08,
                "extreme": 0.02
            }
        elif self.episode_count < self.config["mid_phase_episodes"]:
            # 中期阶段：增加中等难度
            return {
                "easy": 0.3,
                "medium": 0.5,
                "hard": 0.15,
                "extreme": 0.05
            }
        elif self.episode_count < 2 * self.config["mid_phase_episodes"]:
            # 后期阶段：增加困难级别
            return {
                "easy": 0.1,
                "medium": 0.3,
                "hard": 0.4,
                "extreme": 0.2
            }
        else:
            # 最终阶段：注重高难度
            return {
                "easy": 0.05,
                "medium": 0.25,
                "hard": 0.4,
                "extreme": 0.3
            }
    
    def _get_performance_based_distribution(self):
        """获取基于性能反馈的难度分布"""
        # 计算各难度的成功率
        success_rates = {}
        for difficulty in self.config["difficulty_levels"]:
            if len(self.performance_history[difficulty]) > 0:
                success_rates[difficulty] = sum(self.performance_history[difficulty]) / len(self.performance_history[difficulty])
            else:
                # 没有历史数据时假设较低成功率
                if difficulty == "easy":
                    success_rates[difficulty] = 0.5
                elif difficulty == "medium":
                    success_rates[difficulty] = 0.3
                elif difficulty == "hard":
                    success_rates[difficulty] = 0.2
                else:  # extreme
                    success_rates[difficulty] = 0.1
        
        # 计算反向权重：对表现差的难度给予更多关注
        inverse_weights = {d: max(0.1, 1 - rate) for d, rate in success_rates.items()}
        
        # 调整权重以平衡难度进阶
        adjusted_weights = self._adjust_weights_for_progression(inverse_weights, success_rates)
        
        # 归一化
        total = sum(adjusted_weights.values())
        return {d: w/total for d, w in adjusted_weights.items()}
    
    def _adjust_weights_for_progression(self, weights, success_rates):
        """调整权重以促进难度进阶"""
        adjusted = weights.copy()
        
        # 确保有前置难度数据
        if len(self.performance_history["easy"]) > self.config["performance_window"] * 0.5:
            # 如果简单难度成功率高，增加中等难度的权重
            if success_rates["easy"] > self.config["success_threshold"]:
                adjusted["medium"] *= 1.5
        
        if len(self.performance_history["medium"]) > self.config["performance_window"] * 0.5:
            # 如果中等难度成功率高，增加困难难度的权重
            if success_rates["medium"] > self.config["success_threshold"]:
                adjusted["hard"] *= 1.5
        
        if len(self.performance_history["hard"]) > self.config["performance_window"] * 0.5:
            # 如果困难难度成功率高，增加极端难度的权重
            if success_rates["hard"] > self.config["success_threshold"]:
                adjusted["extreme"] *= 1.5
        
        return adjusted
    
    def _get_exploration_rate(self):
        """获取当前的探索率"""
        # 随着训练进行，探索率逐渐降低
        base_rate = self.config["exploration_factor"]
        decay_factor = min(1.0, self.episode_count / (3 * self.config["mid_phase_episodes"]))
        return base_rate * (1 - decay_factor)
    
    def update_performance(self, difficulty, success):
        """
        更新特定难度的性能历史
        
        参数:
            difficulty: 难度级别
            success: 布尔值，表示是否成功
        """
        self.performance_history[difficulty].append(1 if success else 0)
    
    def _log_distribution_update(self):
        """记录难度分布更新"""
        dist_str = ", ".join([f"{d}: {self.difficulty_distribution[d]:.2f}" for d in self.config["difficulty_levels"]])
        print(f"Episode {self.episode_count}: Updated difficulty distribution - {dist_str}")
    
    def get_performance_stats(self):
        """获取各难度的性能统计"""
        stats = {}
        for difficulty in self.config["difficulty_levels"]:
            if len(self.performance_history[difficulty]) > 0:
                success_rate = sum(self.performance_history[difficulty]) / len(self.performance_history[difficulty])
                stats[difficulty] = {
                    "success_rate": success_rate,
                    "sample_count": len(self.performance_history[difficulty])
                }
            else:
                stats[difficulty] = {
                    "success_rate": 0.0,
                    "sample_count": 0
                }
        return stats
        
    def get_distribution(self):
        """返回当前难度分布"""
        return self.difficulty_distribution
