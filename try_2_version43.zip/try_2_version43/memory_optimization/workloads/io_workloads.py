"""
I/O相关工作负载模块 - 针对页面缓存和内存回收优化
"""

import os
import random
import time
import mmap
import subprocess
import psutil

class IOWorkload:
    # 定义难度等级
    DIFFICULTY_LEVELS = ["easy", "medium", "hard", "extreme"]
    
    def __init__(self):
        self.temp_root = "/tmp/rl_mem_test"
        os.makedirs(self.temp_root, exist_ok=True)
        # 获取系统内存信息
        self.update_memory_info()
    
    def update_memory_info(self):
        """更新当前内存信息"""
        memory = psutil.virtual_memory()
        self.total_memory = memory.total / (1024 * 1024)  # 总内存(MB)
        self.available_memory = memory.available / (1024 * 1024)  # 可用内存(MB)
        self.used_percent = memory.percent
        self.buffer_cache = (psutil.virtual_memory().buffers + 
                            psutil.virtual_memory().cached) / (1024 * 1024)  # 缓冲与缓存(MB)
        
        print(f"[IO] 系统总内存: {self.total_memory:.0f}MB")
        print(f"[IO] 当前可用内存: {self.available_memory:.0f}MB")
        print(f"[IO] 当前缓冲/缓存: {self.buffer_cache:.0f}MB")
    
    def run_io_intensive(self, difficulty=None):
        """
        I/O密集型工作负载
        
        参数:
            difficulty: 难度级别，可选值为 "easy", "medium", "hard", "extreme"。
                        如果不指定，则随机选择一个难度级别。
        返回:
            工作负载难度级别、文件数量和每个文件的大小
        """
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 更新内存信息
        self.update_memory_info()
        
        # 根据难度级别和可用内存确定文件数量和大小
        # 文件大小基于可用内存计算，以便更有效地填充页面缓存
        if difficulty == "easy":
            num_files = random.randint(5, 10)
            file_size_percent = 10  # 每个文件使用可用内存的10%
            read_operations = 50    # 增加读取次数
        elif difficulty == "medium":
            num_files = random.randint(8, 15)
            file_size_percent = 15  # 每个文件使用可用内存的15%
            read_operations = 100
        elif difficulty == "hard":
            num_files = random.randint(12, 18)
            file_size_percent = 20  # 每个文件使用可用内存的20%
            read_operations = 200
        elif difficulty == "extreme":
            num_files = random.randint(15, 20)
            file_size_percent = 25  # 每个文件使用可用内存的25%
            read_operations = 300
        
        # 计算文件大小，但设置上限以避免过大
        file_size_mb = int(self.available_memory * file_size_percent / 100)
        max_size = 500  # 最大文件大小500MB
        file_size_mb = min(file_size_mb, max_size)
        
        # 计算总IO操作量
        total_io_mb = file_size_mb * num_files
        
        # 创建临时文件夹
        temp_dir = os.path.join(self.temp_root, f"io_test_{difficulty}")
        os.makedirs(temp_dir, exist_ok=True)
        
        print(f"[IO Workload] 难度: {difficulty}, 创建 {num_files} 个文件，每个 {file_size_mb}MB")
        print(f"[IO Workload] 总IO量: {total_io_mb}MB, 读操作: {read_operations}")
        
        # 创建文件
        files = []
        try:
            for i in range(num_files):
                filename = f"{temp_dir}/test_file_{i}.dat"
                print(f"[IO] 创建文件 {i+1}/{num_files} ({file_size_mb}MB)...")
                
                # 分块写入大文件，以减轻内存压力
                with open(filename, 'wb') as f:
                    chunk_size = 10 * 1024 * 1024  # 10MB块
                    remaining = file_size_mb * 1024 * 1024
                    while remaining > 0:
                        write_size = min(chunk_size, remaining)
                        f.write(os.urandom(write_size))
                        remaining -= write_size
                
                files.append(filename)
                
                # 每创建3个文件检查一次内存状态
                if (i + 1) % 3 == 0:
                    self.update_memory_info()
                    if self.available_memory < 1000:  # 少于1GB可用内存时减少文件数量
                        print("[IO] 可用内存不足，减少文件数量")
                        num_files = i + 1
                        break
            
            print(f"[IO] 所有 {len(files)} 个文件创建完成")
            
            # 随机读取文件，增加页面缓存压力
            print(f"[IO] 开始执行 {read_operations} 次随机读取...")
            for i in range(read_operations):
                if i > 0 and i % 50 == 0:
                    print(f"[IO] 已完成 {i}/{read_operations} 次读取")
                
                filename = random.choice(files)
                filesize = os.path.getsize(filename)
                
                with open(filename, 'rb') as f:
                    # 随机读取多个位置，增加缓存压力
                    for _ in range(3):  # 每次操作读取3个位置
                        pos = random.randint(0, filesize - 102400)  # 确保可以读取100KB
                        f.seek(pos)
                        _ = f.read(102400)  # 读取100KB
            
            # 在清理文件前更新并显示内存信息
            self.update_memory_info()
            
        except Exception as e:
            print(f"[IO] 错误: {e}")
        finally:
            # 清理文件
            print("[IO] 清理文件...")
            for filename in files:
                try:
                    os.remove(filename)
                except Exception as e:
                    print(f"[IO] 删除文件时出错: {e}")
            
            try:
                os.rmdir(temp_dir)
            except Exception as e:
                print(f"[IO] 删除目录时出错: {e}")
        
        return difficulty, len(files), file_size_mb
    
    def run_file_cache_intensive(self, difficulty=None):
        """
        文件缓存密集型工作负载 - 创建大量小文件填充文件缓存
        
        参数:
            difficulty: 难度级别，可选值为 "easy", "medium", "hard", "extreme"
        返回:
            工作负载难度级别和文件数量
        """
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 更新内存信息
        self.update_memory_info()
        
        # 根据难度级别确定文件数量和内容大小
        if difficulty == "easy":
            num_files = random.randint(500, 1000)  # 增加文件数量
            content_size = 4096  # 每个文件4KB
            access_percent = 60   # 访问60%的文件
            reaccess_percent = 30  # 再次访问30%
        elif difficulty == "medium":
            num_files = random.randint(1000, 2000)
            content_size = 8192  # 每个文件8KB
            access_percent = 70
            reaccess_percent = 40
        elif difficulty == "hard":
            num_files = random.randint(2000, 3000)
            content_size = 16384  # 每个文件16KB
            access_percent = 80
            reaccess_percent = 50
        elif difficulty == "extreme":
            num_files = random.randint(3000, 5000)
            content_size = 32768  # 每个文件32KB
            access_percent = 90
            reaccess_percent = 60
        
        # 计算总文件大小
        total_size_mb = num_files * content_size / (1024 * 1024)
        
        # 确保总文件大小不超过可用内存的80%
        max_size_mb = self.available_memory * 0.8
        if total_size_mb > max_size_mb:
            # 如果超过，减少文件数量
            num_files = int(max_size_mb * 1024 * 1024 / content_size)
            total_size_mb = num_files * content_size / (1024 * 1024)
            print(f"[Cache] 调整文件数量以适应可用内存: {num_files} 文件")
        
        # 计算实际要访问的文件数
        access_ops = int(num_files * access_percent / 100)
        reaccess_ops = int(num_files * reaccess_percent / 100)
        
        temp_dir = os.path.join(self.temp_root, f"cache_test_{difficulty}")
        os.makedirs(temp_dir, exist_ok=True)
        
        print(f"[Cache Workload] 难度: {difficulty}, 创建 {num_files} 个小文件")
        print(f"[Cache Workload] 总文件大小: {total_size_mb:.2f}MB")
        print(f"[Cache Workload] 将访问 {access_ops} 个文件，再次访问 {reaccess_ops} 个文件")
        
        # 生成随机内容
        contents = []
        for _ in range(10):  # 创建10种不同内容
            contents.append(os.urandom(content_size))
        
        try:
            # 创建文件
            filenames = []
            for i in range(num_files):
                if i > 0 and i % 1000 == 0:
                    print(f"[Cache] 已创建 {i}/{num_files} 个文件")
                
                filename = f"{temp_dir}/small_file_{i}.dat"
                with open(filename, 'wb') as f:
                    f.write(random.choice(contents))
                filenames.append(filename)
            
            print(f"[Cache] 所有文件创建完成，开始随机访问...")
            
            # 随机访问文件
            accessed = set()
            for i in range(access_ops):
                if i > 0 and i % 1000 == 0:
                    print(f"[Cache] 已访问 {i}/{access_ops} 个文件")
                
                filename = random.choice(filenames)
                with open(filename, 'rb') as f:
                    _ = f.read()
                accessed.add(filename)
            
            # 清理一半的文件
            to_remove = num_files // 2
            print(f"[Cache] 清理 {to_remove} 个文件...")
            
            for filename in random.sample(filenames, to_remove):
                try:
                    os.remove(filename)
                    filenames.remove(filename)
                except Exception as e:
                    print(f"[Cache] 清理文件时出错: {e}")
            
            print(f"[Cache] 清理完成，开始再次访问剩余文件...")
            
            # 再次随机访问剩余文件
            for i in range(reaccess_ops):
                if i > 0 and i % 500 == 0:
                    print(f"[Cache] 再次访问 {i}/{reaccess_ops} 个文件")
                
                if filenames:  # 确保还有文件可访问
                    filename = random.choice(filenames)
                    with open(filename, 'rb') as f:
                        _ = f.read()
            
            # 更新内存信息，显示缓存变化
            self.update_memory_info()
            
        except Exception as e:
            print(f"[Cache] 错误: {e}")
        finally:
            # 清理所有文件
            print("[Cache] 清理所有文件...")
            for filename in filenames:
                try:
                    os.remove(filename)
                except Exception as e:
                    print(f"[Cache] 删除文件时出错: {e}")
            
            try:
                os.rmdir(temp_dir)
            except Exception as e:
                print(f"[Cache] 删除目录时出错: {e}")
        
        return difficulty, num_files
    
    def mmap_test(self, difficulty=None):
        """
        mmap文件模拟测试 - 使用内存映射文件增加页面缓存压力
        
        参数:
            difficulty: 难度级别，可选值为 "easy", "medium", "hard", "extreme"
        返回:
            工作负载难度级别和文件大小(MB)
        """
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 更新内存信息
        self.update_memory_info()
        
        # 根据难度级别和可用内存确定mmap文件大小和操作次数
        if difficulty == "easy":
            file_size_percent = 25  # 文件大小为可用内存的25%
            operations_factor = 10000
        elif difficulty == "medium":
            file_size_percent = 40  # 文件大小为可用内存的40%
            operations_factor = 15000
        elif difficulty == "hard":
            file_size_percent = 60  # 文件大小为可用内存的60%
            operations_factor = 20000
        elif difficulty == "extreme":
            file_size_percent = 80  # 文件大小为可用内存的80%
            operations_factor = 30000
        
        # 计算文件大小，但设置上限和下限
        file_size_mb = int(self.available_memory * file_size_percent / 100)
        file_size_mb = max(50, min(file_size_mb, 2000))  # 最小50MB，最大2GB
        
        # 操作次数基于文件大小
        operations = file_size_mb * operations_factor // 1000
        
        print(f"[mmap] 难度: {difficulty}, 通过mmap访问 {file_size_mb}MB 文件")
        print(f"[mmap] 将执行 {operations} 次随机访问操作")
        
        mmap_file = os.path.join(self.temp_root, f"mmap_test_{difficulty}")
        
        try:
            # 分块创建大文件
            print(f"[mmap] 创建 {file_size_mb}MB 文件...")
            with open(mmap_file, "wb") as f:
                chunk_size = 50 * 1024 * 1024  # 50MB块
                remaining = file_size_mb * 1024 * 1024
                while remaining > 0:
                    write_size = min(chunk_size, remaining)
                    f.write(b'\x00' * write_size)
                    remaining -= write_size
                    print(f"[mmap] 已写入 {file_size_mb - remaining/(1024*1024):.1f}/{file_size_mb}MB")
            
            print(f"[mmap] 文件创建完成，开始通过mmap访问...")
            
            # 使用内存映射访问文件
            with open(mmap_file, "r+b") as f:
                # 获取文件大小
                file_size = os.path.getsize(mmap_file)
                
                # 映射整个文件
                mm = mmap.mmap(f.fileno(), 0)
                
                # 随机访问文件的不同位置
                page_size = 4096  # 假设页面大小为4KB
                pages = file_size // page_size
                
                # 访问操作进度报告
                report_interval = operations // 10
                if report_interval == 0:
                    report_interval = 1
                
                for i in range(operations):
                    if i > 0 and i % report_interval == 0:
                        print(f"[mmap] 已完成 {i}/{operations} 次操作")
                        self.update_memory_info()
                    
                    # 随机选择一个页面并修改其中一个字节
                    page = random.randint(0, pages - 1)
                    offset = page * page_size + random.randint(0, page_size - 1)
                    if offset < file_size:
                        mm[offset] = b'\x01'[0]
                
                # 确保修改被写回文件系统
                mm.flush()
                mm.close()
            
            # 更新内存状态，显示缓存变化
            self.update_memory_info()
            
        except Exception as e:
            print(f"[mmap] 错误: {e}")
        finally:
            # 清理文件
            try:
                os.remove(mmap_file)
                print(f"[mmap] 文件已删除")
            except Exception as e:
                print(f"[mmap] 删除文件时出错: {e}")
        
        return difficulty, file_size_mb
    
    def drop_caches(self):
        """清除文件系统缓存"""
        print("[Sys] 正在清除文件系统缓存...")
        try:
            # 先同步，确保所有待写数据都写入磁盘
            subprocess.run(['sudo', 'sync'], check=True)
            print("[Sys] 同步完成，开始清除缓存...")
            
            # 清除页面缓存、dentries和inodes
            subprocess.run(['sudo', 'bash', '-c', 'echo 3 > /proc/sys/vm/drop_caches'], 
                           check=True)
            
            # 更新并显示内存状态变化
            before = self.buffer_cache
            self.update_memory_info()
            after = self.buffer_cache
            
            print(f"[Sys] 缓存清除完成")
            print(f"[Sys] 缓存变化: {before:.0f}MB -> {after:.0f}MB (减少 {before-after:.0f}MB)")
            return True
            
        except subprocess.CalledProcessError as e:
            print(f"[Sys] 清除缓存出错: {e}")
            return False
    
    def run_sequential_io(self, difficulty=None):
        """
        顺序I/O测试 - 创建大文件并顺序读取
        
        参数:
            difficulty: 难度级别
        返回:
            工作负载难度级别和文件大小
        """
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 更新内存信息
        self.update_memory_info()
        
        # 根据难度级别和可用内存确定文件大小
        if difficulty == "easy":
            file_size_percent = 30
            read_passes = 2
        elif difficulty == "medium":
            file_size_percent = 45
            read_passes = 3
        elif difficulty == "hard":
            file_size_percent = 60
            read_passes = 4
        elif difficulty == "extreme":
            file_size_percent = 75
            read_passes = 5
        
        # 计算文件大小，但设置上限
        file_size_mb = int(self.available_memory * file_size_percent / 100)
        max_size = 1500  # 最大1.5GB
        file_size_mb = min(file_size_mb, max_size)
        
        print(f"[Seq IO] 难度: {difficulty}, 创建 {file_size_mb}MB 大文件")
        print(f"[Seq IO] 将顺序读取 {read_passes} 次")
        
        seq_file = os.path.join(self.temp_root, f"seq_io_test_{difficulty}")
        
        try:
            # 创建大文件
            print(f"[Seq IO] 创建 {file_size_mb}MB 文件...")
            with open(seq_file, "wb") as f:
                chunk_size = 50 * 1024 * 1024  # 50MB块
                remaining = file_size_mb * 1024 * 1024
                while remaining > 0:
                    write_size = min(chunk_size, remaining)
                    f.write(os.urandom(write_size))
                    remaining -= write_size
                    print(f"[Seq IO] 已写入 {file_size_mb - remaining/(1024*1024):.1f}/{file_size_mb}MB")
            
            # 顺序读取文件多次
            print(f"[Seq IO] 开始顺序读取文件...")
            
            for pass_num in range(read_passes):
                print(f"[Seq IO] 读取通道 {pass_num+1}/{read_passes}...")
                
                with open(seq_file, "rb") as f:
                    chunk_size = 10 * 1024 * 1024  # 10MB块
                    bytes_read = 0
                    total_size = file_size_mb * 1024 * 1024
                    
                    while bytes_read < total_size:
                        data = f.read(chunk_size)
                        if not data:
                            break
                        bytes_read += len(data)
                        
                        if bytes_read % (100 * 1024 * 1024) == 0:  # 每100MB报告一次
                            print(f"[Seq IO] 已读取 {bytes_read/(1024*1024):.0f}/{file_size_mb}MB")
                
                # 每次读取后检查一次内存状态
                self.update_memory_info()
            
        except Exception as e:
            print(f"[Seq IO] 错误: {e}")
        finally:
            # 清理文件
            try:
                os.remove(seq_file)
                print(f"[Seq IO] 文件已删除")
            except Exception as e:
                print(f"[Seq IO] 删除文件时出错: {e}")
        
        return difficulty, file_size_mb
    
    def run_mixed_io_pattern(self, duration_seconds=60, difficulty=None):
        """
        混合IO模式 - 模拟真实工作负载
        
        参数:
            duration_seconds: 运行时间(秒)
            difficulty: 难度级别
        返回:
            工作负载难度级别
        """
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 更新内存信息
        self.update_memory_info()
        
        # 根据难度确定参数
        if difficulty == "easy":
            num_small_files = 200
            num_medium_files = 10
            large_file_size_mb = int(self.available_memory * 0.2)
            small_file_size_kb = 8
            medium_file_size_mb = 5
        elif difficulty == "medium":
            num_small_files = 500
            num_medium_files = 20
            large_file_size_mb = int(self.available_memory * 0.3)
            small_file_size_kb = 16
            medium_file_size_mb = 10
        elif difficulty == "hard":
            num_small_files = 1000
            num_medium_files = 30
            large_file_size_mb = int(self.available_memory * 0.4)
            small_file_size_kb = 32
            medium_file_size_mb = 20
        elif difficulty == "extreme":
            num_small_files = 2000
            num_medium_files = 40
            large_file_size_mb = int(self.available_memory * 0.5)
            small_file_size_kb = 64
            medium_file_size_mb = 30
        
        # 限制大文件大小
        large_file_size_mb = min(large_file_size_mb, 1000)  # 最大1GB
        
        print(f"[Mixed IO] 难度: {difficulty}, 运行 {duration_seconds} 秒")
        print(f"[Mixed IO] 将创建: {num_small_files} 个小文件({small_file_size_kb}KB), " 
              f"{num_medium_files} 个中型文件({medium_file_size_mb}MB), "
              f"1个大文件({large_file_size_mb}MB)")
        
        # 创建临时目录
        mixed_dir = os.path.join(self.temp_root, f"mixed_io_{difficulty}")
        os.makedirs(mixed_dir, exist_ok=True)
        
        files = []  # 跟踪所有创建的文件
        
        try:
            # 创建大文件
            large_file = f"{mixed_dir}/large_file.dat"
            print(f"[Mixed IO] 创建大文件 ({large_file_size_mb}MB)...")
            
            with open(large_file, "wb") as f:
                chunk_size = 50 * 1024 * 1024  # 50MB块
                remaining = large_file_size_mb * 1024 * 1024
                while remaining > 0:
                    write_size = min(chunk_size, remaining)
                    f.write(b'\x00' * write_size)
                    remaining -= write_size
            
            files.append(large_file)
            
            # 创建中型文件
            print(f"[Mixed IO] 创建 {num_medium_files} 个中型文件 (每个 {medium_file_size_mb}MB)...")
            for i in range(num_medium_files):
                filename = f"{mixed_dir}/medium_file_{i}.dat"
                with open(filename, "wb") as f:
                    f.write(os.urandom(medium_file_size_mb * 1024 * 1024))
                files.append(filename)
            
            # 创建小文件
            print(f"[Mixed IO] 创建 {num_small_files} 个小文件 (每个 {small_file_size_kb}KB)...")
            for i in range(num_small_files):
                filename = f"{mixed_dir}/small_file_{i}.dat"
                with open(filename, "wb") as f:
                    f.write(os.urandom(small_file_size_kb * 1024))
                files.append(filename)
                
                # 每创建200个小文件检查一次内存状态
                if (i + 1) % 200 == 0:
                    print(f"[Mixed IO] 已创建 {i+1}/{num_small_files} 个小文件")
                    self.update_memory_info()
            
            # 执行混合IO操作直到达到指定时间
            print(f"[Mixed IO] 开始混合IO操作, 持续 {duration_seconds} 秒...")
            start_time = time.time()
            operations_done = 0
            
            while time.time() - start_time < duration_seconds:
                # 随机选择操作类型
                op_type = random.choice(["read_small", "read_medium", "read_large", 
                                       "write_small", "write_medium"])
                
                if op_type == "read_small" and num_small_files > 0:
                    # 读取一个随机小文件
                    file_idx = random.randint(num_medium_files + 1, len(files) - 1)
                    with open(files[file_idx], "rb") as f:
                        _ = f.read()
                
                elif op_type == "read_medium" and num_medium_files > 0:
                    # 读取一个随机中型文件的部分内容
                    file_idx = random.randint(1, num_medium_files)
                    with open(files[file_idx], "rb") as f:
                        f.seek(random.randint(0, medium_file_size_mb * 1024 * 1024 - 102400))
                        _ = f.read(102400)  # 读取100KB
                
                elif op_type == "read_large":
                    # 读取大文件的一部分
                    with open(large_file, "rb") as f:
                        f.seek(random.randint(0, large_file_size_mb * 1024 * 1024 - 1024*1024))
                        _ = f.read(1024*1024)  # 读取1MB
                
                elif op_type == "write_small":
                    # 更新一个随机小文件
                    file_idx = random.randint(num_medium_files + 1, len(files) - 1)
                    with open(files[file_idx], "r+b") as f:
                        f.write(os.urandom(small_file_size_kb * 1024))
                
                elif op_type == "write_medium":
                    # 更新一个随机中型文件的部分内容
                    file_idx = random.randint(1, num_medium_files)
                    with open(files[file_idx], "r+b") as f:
                        f.seek(random.randint(0, medium_file_size_mb * 1024 * 1024 - 102400))
                        f.write(os.urandom(102400))  # 写入100KB
                
                operations_done += 1
                
                # 每100次操作报告一次状态
                if operations_done % 100 == 0:
                    elapsed = time.time() - start_time
                    print(f"[Mixed IO] 已执行 {operations_done} 次IO操作, 经过 {elapsed:.1f}/{duration_seconds} 秒")
                    # 每200次操作更新一次内存状态
                    if operations_done % 200 == 0:
                        self.update_memory_info()
            
            total_time = time.time() - start_time
            print(f"[Mixed IO] 完成 {operations_done} 次混合IO操作, 用时 {total_time:.1f} 秒")
            
            # 最终内存状态更新
            self.update_memory_info()
            
        except Exception as e:
            print(f"[Mixed IO] 错误: {e}")
        finally:
            # 清理所有文件
            print("[Mixed IO] 清理所有文件...")
            for filename in files:
                try:
                    os.remove(filename)
                except Exception as e:
                    print(f"[Mixed IO] 删除文件时出错: {e}")
            
            try:
                os.rmdir(mixed_dir)
            except Exception as e:
                print(f"[Mixed IO] 删除目录时出错: {e}")
        
        return difficulty
