"""
多智能体近端策略优化算法(MAPPO)实现
基于中央化训练与分散执行(CTDE)范式
"""

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Normal
import os
import traceback
import sys
import time

class MAPPO:
    """
    多智能体近端策略优化(MAPPO)算法
    支持中央化训练和分散执行
    """
    
    def __init__(
        self, 
        network_manager,
        buffer,
        config=None,  # 新增配置参数
        lr_actor=3e-4,
        lr_critic=1e-3,
        gamma=0.99,
        gae_lambda=0.95,
        clip_param=0.2,
        value_clip_param=0.2,
        entropy_coef=0.01,
        value_loss_coef=0.5,
        max_grad_norm=0.5,
        use_clipped_value_loss=True,
        normalize_advantages=True,
        use_centralized_critic=True,
        device=None
    ):
        """
        初始化MAPPO算法
        
        参数:
            network_manager: 网络管理器，包含所有智能体的网络
            buffer: 多智能体经验回放缓冲区
            config: 配置参数字典，优先级高于默认参数
            lr_actor: Actor学习率
            lr_critic: Critic学习率
            gamma: 折扣因子
            gae_lambda: GAE参数
            clip_param: PPO裁剪参数
            value_clip_param: 价值裁剪参数
            entropy_coef: 熵系数
            value_loss_coef: 价值损失系数
            max_grad_norm: 梯度裁剪范数
            use_clipped_value_loss: 是否使用裁剪的价值损失
            normalize_advantages: 是否归一化优势
            use_centralized_critic: 是否使用中央化Critic
            device: 计算设备
        """
        self.network_manager = network_manager
        self.buffer = buffer
        self.agent_ids = self.network_manager.agent_ids
        
        # 如果提供了配置，使用配置中的值覆盖默认值
        if config is not None:
            self.gamma = config.get("gamma", gamma)
            self.gae_lambda = config.get("gae_lambda", gae_lambda)
            self.clip_param = config.get("clip_param", clip_param)
            self.value_clip_param = config.get("value_clip_param", value_clip_param)
            self.entropy_coef = config.get("entropy_coef", entropy_coef)
            self.value_loss_coef = config.get("value_loss_coef", value_loss_coef)
            self.max_grad_norm = config.get("max_grad_norm", max_grad_norm)
            self.use_clipped_value_loss = config.get("use_clipped_value_loss", use_clipped_value_loss)
            self.normalize_advantages = config.get("normalize_advantages", normalize_advantages)
            self.use_centralized_critic = config.get("use_centralized_critic", use_centralized_critic)
            
            lr_actor = config.get("lr_actor", lr_actor)
            lr_critic = config.get("lr_critic", lr_critic)
            
            device_str = config.get("device", None)
            if device_str:
                device = torch.device(device_str)
        else:
            self.gamma = gamma
            self.gae_lambda = gae_lambda
            self.clip_param = clip_param
            self.value_clip_param = value_clip_param
            self.entropy_coef = entropy_coef
            self.value_loss_coef = value_loss_coef
            self.max_grad_norm = max_grad_norm
            self.use_clipped_value_loss = use_clipped_value_loss
            self.normalize_advantages = normalize_advantages
            self.use_centralized_critic = use_centralized_critic
            
        self.device = device or torch.device('cpu')
        
        # 打印MAPPO配置参数
        print("\n" + "-"*50)
        print("MAPPO算法配置参数:")
        print(f"  Actor学习率: {lr_actor}")
        print(f"  Critic学习率: {lr_critic}")
        print(f"  折扣因子 (gamma): {self.gamma}")
        print(f"  GAE lambda: {self.gae_lambda}")
        print(f"  裁剪参数: {self.clip_param}")
        print(f"  价值裁剪参数: {self.value_clip_param}")
        print(f"  熵系数: {self.entropy_coef}")
        print(f"  价值损失系数: {self.value_loss_coef}")
        print(f"  最大梯度范数: {self.max_grad_norm}")
        print(f"  使用裁剪价值损失: {self.use_clipped_value_loss}")
        print(f"  归一化优势: {self.normalize_advantages}")
        print(f"  使用中央化Critic: {self.use_centralized_critic}")
        print(f"  计算设备: {self.device}")
        print("-"*50 + "\n")
        
        # 创建优化器
        self.actor_optimizers = {}
        for agent_id in self.agent_ids:
            network = self.network_manager.actor_networks[agent_id]
            self.actor_optimizers[agent_id] = optim.Adam(network.parameters(), lr=lr_actor)
        
        # 如果使用中央化Critic，为中央化Critic创建优化器
        if self.use_centralized_critic:
            self.critic_optimizer = optim.Adam(self.network_manager.central_critic.parameters(), lr=lr_critic)
        
        # 跟踪训练统计数据
        self.stats = {
            'actor_losses': {agent_id: [] for agent_id in self.agent_ids},
            'critic_losses': {agent_id: [] for agent_id in self.agent_ids},
            'entropy': {agent_id: [] for agent_id in self.agent_ids},
            'kl_div': {agent_id: [] for agent_id in self.agent_ids},
            'value_losses': {agent_id: [] for agent_id in self.agent_ids},
            'policy_losses': {agent_id: [] for agent_id in self.agent_ids},
            'clip_fraction': {agent_id: [] for agent_id in self.agent_ids}
        }
        
        if self.use_centralized_critic:
            self.stats['central_critic_losses'] = []
        
    def update(self, k_epochs=None, batch_size=None, config=None):
        """
        更新MAPPO策略
        
        参数:
            k_epochs: 每个批次的训练轮数，如果为None则从config中读取
            batch_size: 批次大小，如果为None则从config中读取
            config: 配置字典，优先级高于其他参数
            
        返回:
            stats: 包含训练统计数据的字典
        """
        # 从配置中读取参数
        if config is not None:
            k_epochs = config.get("k_epochs", k_epochs or 10)
            batch_size = config.get("batch_size", batch_size or 64)
        else:
            k_epochs = k_epochs or 10
            batch_size = batch_size or 64
        
        # 重置训练统计
        for key in self.stats:
            if key == 'central_critic_losses':
                self.stats[key] = []
            else:
                for agent_id in self.agent_ids:
                    self.stats[key][agent_id] = []
        
        update_success = False
        
        # 如果使用中央化Critic，先更新中央化Critic
        if self.use_centralized_critic:
            try:
                self._update_centralized_critic(k_epochs, batch_size)
                update_success = True
            except Exception as e:
                print(f"策略更新 (中央化Critic) 失败: {e}")
                traceback.print_exc()
        
        # 更新每个智能体的Actor(和Critic，如果没有使用中央化Critic)
        agent_success = 0
        for i, agent_id in enumerate(self.agent_ids, 1):
            try:
                self._update_agent(agent_id, k_epochs, batch_size)
                agent_success += 1
                update_success = True
            except Exception as e:
                print(f"策略更新 {i} 失败: {e}")
                traceback.print_exc()
        
        if not update_success:
            print("所有策略更新失败，跳过此轮更新")
        else:
            print(f"成功更新 {agent_success}/{len(self.agent_ids)} 个智能体")
            
        return self.stats
    
    def _update_centralized_critic(self, k_epochs, batch_size):
        """更新中央化Critic"""
        # 从缓冲区获取全局批次
        central_batch = self.buffer.get_batch(agent_id=None, batch_size=batch_size)
        
        if central_batch is None or 'batch' not in central_batch:
            print("警告: 无法获取有效的中央化批次")
            return
        
        central_batch = central_batch['batch']
        
        # 检查必要的键是否存在
        required_keys = ['global_states', 'global_values']
        missing_keys = [key for key in required_keys if key not in central_batch]
        if missing_keys:
            print(f"警告: 中央化批次缺少必要的键: {missing_keys}")
            return
        
        # 检查returns键，可能是不同名称
        if 'returns' not in central_batch:
            if 'global_returns' in central_batch:
                central_batch['returns'] = central_batch['global_returns']
                print("已将global_returns键重命名为returns")
            else:
                print("警告: 中央化批次缺少returns键，尝试使用回报估计")
                # 尝试使用GAE公式计算回报
                if 'rewards' in central_batch and 'dones' in central_batch:
                    rewards = central_batch['rewards']
                    dones = central_batch['dones']
                    global_values = central_batch['global_values']
                    
                    # 使用简单的折扣回报估计
                    returns = []
                    discounted_return = 0
                    for step in reversed(range(len(rewards))):
                        discounted_return = rewards[step] + self.gamma * discounted_return * (1 - dones[step])
                        returns.insert(0, discounted_return)
                        
                    central_batch['returns'] = torch.FloatTensor(returns).to(self.device)
                    print(f"已生成估计回报，形状: {central_batch['returns'].shape}")
                else:
                    print("错误: 无法生成回报估计，跳过中央化Critic更新")
                    return
        
        # 继续进行正常更新
        for epoch in range(k_epochs):
            try:
                # 计算中央化Critic的价值损失
                global_states = central_batch['global_states']
                global_values = central_batch['global_values']
                returns = central_batch['returns']
                
                # 确保维度匹配
                if returns.dim() == 1 and global_values.dim() > 1:
                    returns = returns.unsqueeze(-1)
                elif global_values.dim() == 1 and returns.dim() > 1:
                    global_values = global_values.unsqueeze(-1)
                    
                # 使用中央化Critic计算新价值
                new_values = self.network_manager.central_critic(global_states)
                if new_values.dim() > 1:
                    new_values = new_values.squeeze(-1)
                
                # 确保维度匹配计算
                if new_values.dim() != returns.dim():
                    if new_values.dim() > returns.dim():
                        new_values = new_values.squeeze()
                    else:
                        new_values = new_values.unsqueeze(-1)
                
                # 计算价值损失
                if self.use_clipped_value_loss:
                    # 裁剪价值，类似于PPO的裁剪
                    value_pred_clipped = global_values + torch.clamp(
                        new_values - global_values,
                        -self.value_clip_param,
                        self.value_clip_param
                    )
                    value_loss_clipped = (value_pred_clipped - returns).pow(2)
                    value_loss_unclipped = (new_values - returns).pow(2)
                    value_loss = torch.max(value_loss_clipped, value_loss_unclipped).mean()
                else:
                    # 标准MSE损失
                    value_loss = nn.MSELoss()(new_values, returns)
                
                # 更新中央化Critic
                self.critic_optimizer.zero_grad()
                value_loss.backward()
                nn.utils.clip_grad_norm_(self.network_manager.central_critic.parameters(), self.max_grad_norm)
                self.critic_optimizer.step()
                
                # 记录统计数据
                self.stats['central_critic_losses'].append(value_loss.item())
                
            except Exception as e:
                print(f"中央化Critic更新轮次 {epoch+1} 出错: {e}")
                traceback.print_exc()
                raise  # 重新抛出异常以便上层捕获
    
    def _update_agent(self, agent_id, k_epochs, batch_size):
        """更新单个智能体的策略"""
        # 获取智能体的批次
        batch_data = self.buffer.get_batch(agent_id=agent_id, batch_size=batch_size)
        
        if batch_data is None or 'batch' not in batch_data:
            return
        
        batch = batch_data['batch']
        
        # 提取批次数据
        states = batch['observations'] if 'observations' in batch else batch['states']
        actions = batch['actions']
        returns = batch['returns']
        advantages = batch['advantages']
        old_log_probs = batch['old_log_probs'] if 'old_log_probs' in batch else batch['log_probs']
        old_values = batch['values']
        
        # 训练k_epochs轮
        for epoch in range(k_epochs):
            try:
                # 评估动作
                log_probs, values, entropy = self.network_manager.evaluate_action(agent_id, states, actions)
                
                # 计算比率(pi_theta / pi_theta_old)
                ratios = torch.exp(log_probs - old_log_probs)
                
                # 计算替代损失
                surr1 = ratios * advantages
                surr2 = torch.clamp(ratios, 1.0 - self.clip_param, 1.0 + self.clip_param) * advantages
                policy_loss = -torch.min(surr1, surr2).mean()
                
                # 计算价值损失
                if self.use_clipped_value_loss:
                    value_pred_clipped = old_values + torch.clamp(
                        values - old_values,
                        -self.value_clip_param,
                        self.value_clip_param
                    )
                    value_loss_clipped = (value_pred_clipped - returns).pow(2)
                    value_loss_unclipped = (values - returns).pow(2)
                    value_loss = torch.max(value_loss_clipped, value_loss_unclipped).mean()
                else:
                    value_loss = nn.MSELoss()(values, returns)
                
                # 计算总损失
                entropy_loss = -entropy.mean()
                loss = policy_loss + self.value_loss_coef * value_loss + self.entropy_coef * entropy_loss
                
                # 更新智能体网络
                self.actor_optimizers[agent_id].zero_grad()
                # 使用retain_graph=True解决图重用问题
                loss.backward(retain_graph=True)
                nn.utils.clip_grad_norm_(self.network_manager.actor_networks[agent_id].parameters(), self.max_grad_norm)
                self.actor_optimizers[agent_id].step()
                
                # 计算近似KL散度和裁剪比例
                with torch.no_grad():
                    approx_kl = 0.5 * ((old_log_probs - log_probs) ** 2).mean().item()
                    clip_fraction = ((ratios - 1.0).abs() > self.clip_param).float().mean().item()
                
                # 记录统计数据
                self.stats['actor_losses'][agent_id].append(loss.item())
                self.stats['critic_losses'][agent_id].append(value_loss.item())
                self.stats['entropy'][agent_id].append(entropy_loss.item())
                self.stats['kl_div'][agent_id].append(approx_kl)
                self.stats['value_losses'][agent_id].append(value_loss.item())
                self.stats['policy_losses'][agent_id].append(policy_loss.item())
                self.stats['clip_fraction'][agent_id].append(clip_fraction)
                
            except Exception as e:
                print(f"智能体 {agent_id} 更新轮次 {epoch+1} 出错: {e}")
                traceback.print_exc()
                raise  # 重新抛出异常以便上层捕获
    
    def act(self, observations, deterministic=False):
        """
        根据观察执行动作
        
        参数:
            observations: 字典，键为智能体ID，值为观察
            deterministic: 是否使用确定性策略
            
        返回:
            actions: 字典，键为智能体ID，值为动作
            log_probs: 字典，键为智能体ID，值为对数概率
            values: 字典，键为智能体ID，值为价值估计
        """
        actions = {}
        log_probs = {}
        values = {}
        
        with torch.no_grad():
            for agent_id in self.agent_ids:
                if agent_id in observations:
                    action, log_prob, value = self.network_manager.get_action(
                        agent_id, 
                        observations[agent_id], 
                        deterministic
                    )
                    actions[agent_id] = action
                    log_probs[agent_id] = log_prob
                    values[agent_id] = value
        
        return actions, log_probs, values
    
    def get_central_value(self, global_state):
        """获取中央化价值估计"""
        if not self.use_centralized_critic:
            raise ValueError("Centralized critic is not enabled")
            
        with torch.no_grad():
            value = self.network_manager.get_central_value(global_state)
            
        return value
    
    def save_models(self, path_prefix):
        """
        保存所有智能体的模型
        
        参数:
            path_prefix: 保存路径前缀
        """
        try:
            # 确保目录存在
            dirname = os.path.dirname(path_prefix)
            if dirname:
                os.makedirs(dirname, exist_ok=True)
            
            # 保存模型元数据
            metadata = {
                "agent_ids": self.agent_ids,
                "use_centralized_critic": self.use_centralized_critic,
                "gamma": self.gamma,
                "gae_lambda": self.gae_lambda,
                "clip_param": self.clip_param,
                "value_clip_param": self.value_clip_param,
                "entropy_coef": self.entropy_coef,
                "value_loss_coef": self.value_loss_coef,
                "normalize_advantages": self.normalize_advantages,
                "timestamp": str(time.time())
            }
            
            metadata_path = f"{path_prefix}_metadata.pth"
            torch.save(metadata, metadata_path)
            print(f"模型元数据保存至: {metadata_path}")
            
            # 逐个保存Actor网络
            for agent_id in self.agent_ids:
                try:
                    # 检查网络是否存在
                    if agent_id not in self.network_manager.actor_networks:
                        print(f"警告: 找不到智能体 {agent_id} 的网络")
                        continue
                    
                    actor_network = self.network_manager.actor_networks[agent_id]
                    actor_path = f"{path_prefix}_actor_{agent_id}.pth"
                    
                    # 获取网络类型
                    network_type = type(actor_network).__name__
                    
                    # 创建保存字典，包含网络类型信息
                    save_dict = {
                        "state_dict": actor_network.state_dict(),
                        "network_type": network_type
                    }
                    
                    # 保存额外网络信息 (针对特定网络类型)
                    if hasattr(actor_network, 'lstm_hidden'):
                        save_dict["lstm_info"] = {
                            "lstm_hidden": actor_network.lstm_hidden,
                            "lstm_layers": actor_network.lstm_layers if hasattr(actor_network, 'lstm_layers') else 1,
                            "lstm_initialized": hasattr(actor_network, 'lstm')
                        }
                    
                    torch.save(save_dict, actor_path)
                    print(f"智能体 {agent_id} 的 {network_type} 网络已保存至: {actor_path}")
                except Exception as e:
                    print(f"保存智能体 {agent_id} 网络时出错: {e}")
                    traceback.print_exc()
            
            # 如果使用中央化Critic，保存中央化Critic
            if self.use_centralized_critic and hasattr(self.network_manager, 'central_critic'):
                critic_path = f"{path_prefix}_central_critic.pth"
                try:
                    critic_state_dict = self.network_manager.central_critic.state_dict()
                    torch.save(critic_state_dict, critic_path)
                    print(f"中央化Critic已保存至: {critic_path}")
                except Exception as e:
                    print(f"保存中央化Critic时出错: {e}")
                    traceback.print_exc()
            
            # 保存优化器状态
            optim_path = f"{path_prefix}_optimizers.pth"
            try:
                optim_states = {
                    "actor": {agent_id: optim.state_dict() 
                            for agent_id, optim in self.actor_optimizers.items()}
                }
                
                if hasattr(self, 'critic_optimizer'):
                    optim_states["critic"] = self.critic_optimizer.state_dict()
                    
                torch.save(optim_states, optim_path)
                print(f"优化器状态已保存至: {optim_path}")
            except Exception as e:
                print(f"保存优化器状态时出错: {e}")
                traceback.print_exc()
            
            return True
        except Exception as e:
            print(f"保存模型时发生错误: {e}")
            traceback.print_exc()
            return False
    
    def load_models(self, path_prefix):
        """
        加载所有智能体的模型
        
        参数:
            path_prefix: 加载路径前缀
        """
        try:
            # 尝试加载元数据
            metadata_path = f"{path_prefix}_metadata.pth"
            try:
                metadata = torch.load(metadata_path, map_location=self.device)
                print(f"已加载模型元数据: {metadata_path}")
                
                # 可以选择性地更新一些配置参数
                if "gamma" in metadata:
                    self.gamma = metadata["gamma"]
                if "gae_lambda" in metadata:
                    self.gae_lambda = metadata["gae_lambda"]
                if "clip_param" in metadata:
                    self.clip_param = metadata["clip_param"]
                
                print("已更新MAPPO参数配置")
            except FileNotFoundError:
                print(f"未找到元数据文件: {metadata_path}，继续尝试加载模型")
            except Exception as e:
                print(f"加载元数据时出错: {e}")
            
            # 加载每个智能体的Actor网络
            for agent_id in self.agent_ids:
                actor_path = f"{path_prefix}_actor_{agent_id}.pth"
                try:
                    # 加载保存的字典
                    checkpoint = torch.load(actor_path, map_location=self.device)
                    
                    # 检查是否是新格式（带网络类型信息）
                    if isinstance(checkpoint, dict) and "state_dict" in checkpoint:
                        network = self.network_manager.actor_networks[agent_id]
                        
                        # 处理LSTM特殊情况
                        if "lstm_info" in checkpoint and hasattr(network, 'lstm_hidden'):
                            lstm_info = checkpoint["lstm_info"]
                            if lstm_info["lstm_initialized"] and not hasattr(network, 'lstm'):
                                # 如果保存的模型已初始化LSTM但当前未初始化，先初始化
                                dummy_input = torch.zeros(1, 32).to(self.device)
                                with torch.no_grad():
                                    _ = network(dummy_input)
                        
                        # 加载状态字典
                        try:
                            network.load_state_dict(checkpoint["state_dict"])
                            print(f"成功加载智能体 {agent_id} 的模型（新格式）")
                        except Exception as e:
                            print(f"加载智能体 {agent_id} 状态字典时出错: {e}")
                            # 尝试宽松加载
                            try:
                                network.load_state_dict(checkpoint["state_dict"], strict=False)
                                print(f"使用非严格模式成功加载智能体 {agent_id} 的模型")
                            except Exception as e2:
                                print(f"非严格模式加载也失败: {e2}")
                    else:
                        # 旧格式，直接加载
                        try:
                            self.network_manager.actor_networks[agent_id].load_state_dict(checkpoint)
                            print(f"成功加载智能体 {agent_id} 的模型（旧格式）")
                        except Exception as e:
                            print(f"加载旧格式模型时出错: {e}")
                            # 尝试宽松加载
                            try:
                                self.network_manager.actor_networks[agent_id].load_state_dict(checkpoint, strict=False)
                                print(f"使用非严格模式成功加载智能体 {agent_id} 的模型（旧格式）")
                            except Exception as e2:
                                print(f"非严格模式加载旧格式也失败: {e2}")
                        
                except FileNotFoundError:
                    print(f"找不到智能体 {agent_id} 的模型文件: {actor_path}")
                except Exception as e:
                    print(f"加载智能体 {agent_id} 的模型时出错: {e}")
                    traceback.print_exc()
            
            # 如果使用中央化Critic，加载中央化Critic
            if self.use_centralized_critic and hasattr(self.network_manager, 'central_critic'):
                critic_path = f"{path_prefix}_central_critic.pth"
                try:
                    critic_state_dict = torch.load(critic_path, map_location=self.device)
                    self.network_manager.central_critic.load_state_dict(critic_state_dict)
                    print(f"成功加载中央化Critic: {critic_path}")
                except FileNotFoundError:
                    print(f"找不到中央化Critic文件: {critic_path}")
                except Exception as e:
                    print(f"加载中央化Critic时出错: {e}")
                    traceback.print_exc()
                    # 尝试宽松加载
                    try:
                        self.network_manager.central_critic.load_state_dict(critic_state_dict, strict=False)
                        print("使用非严格模式成功加载中央化Critic")
                    except Exception as e2:
                        print(f"非严格模式加载中央化Critic也失败: {e2}")
            
            # 尝试加载优化器状态
            optim_path = f"{path_prefix}_optimizers.pth"
            try:
                optim_states = torch.load(optim_path, map_location=self.device)
                
                # 加载Actor优化器
                if "actor" in optim_states:
                    for agent_id, state in optim_states["actor"].items():
                        if agent_id in self.actor_optimizers:
                            try:
                                self.actor_optimizers[agent_id].load_state_dict(state)
                            except Exception as e:
                                print(f"加载智能体 {agent_id} 的优化器状态时出错: {e}")
                
                # 加载Critic优化器
                if "critic" in optim_states and hasattr(self, 'critic_optimizer'):
                    try:
                        self.critic_optimizer.load_state_dict(optim_states["critic"])
                    except Exception as e:
                        print(f"加载Critic优化器状态时出错: {e}")
                
                print("已加载优化器状态")
            except FileNotFoundError:
                print(f"未找到优化器状态文件: {optim_path}")
            except Exception as e:
                print(f"加载优化器状态时出错: {e}")
            
            print("模型加载完成")
            return True
        except Exception as e:
            print(f"加载模型时发生错误: {e}")
            traceback.print_exc()
            return False

    def state_dict(self):
        """返回MAPPO的状态字典，用于保存"""
        state = {
            "config": {
                "gamma": self.gamma,
                "gae_lambda": self.gae_lambda,
                "clip_param": self.clip_param,
                "value_clip_param": self.value_clip_param,
                "entropy_coef": self.entropy_coef,
                "value_loss_coef": self.value_loss_coef,
                "max_grad_norm": self.max_grad_norm,
                "use_clipped_value_loss": self.use_clipped_value_loss,
                "normalize_advantages": self.normalize_advantages,
                "use_centralized_critic": self.use_centralized_critic
            },
            "actor_optimizers": {agent_id: optim.state_dict() for agent_id, optim in self.actor_optimizers.items()}
        }
        
        if hasattr(self, 'critic_optimizer'):
            state["critic_optimizer"] = self.critic_optimizer.state_dict()
            
        return state
    
    def load_state_dict(self, state_dict):
        """从状态字典加载MAPPO状态"""
        if "config" in state_dict:
            config = state_dict["config"]
            self.gamma = config.get("gamma", self.gamma)
            self.gae_lambda = config.get("gae_lambda", self.gae_lambda)
            self.clip_param = config.get("clip_param", self.clip_param)
            self.value_clip_param = config.get("value_clip_param", self.value_clip_param)
            self.entropy_coef = config.get("entropy_coef", self.entropy_coef)
            self.value_loss_coef = config.get("value_loss_coef", self.value_loss_coef)
            self.max_grad_norm = config.get("max_grad_norm", self.max_grad_norm)
            self.use_clipped_value_loss = config.get("use_clipped_value_loss", self.use_clipped_value_loss)
            self.normalize_advantages = config.get("normalize_advantages", self.normalize_advantages)
        
        if "actor_optimizers" in state_dict:
            for agent_id, optim_state in state_dict["actor_optimizers"].items():
                if agent_id in self.actor_optimizers:
                    try:
                        self.actor_optimizers[agent_id].load_state_dict(optim_state)
                    except Exception as e:
                        print(f"加载优化器状态失败: {e}")
        
        if "critic_optimizer" in state_dict and hasattr(self, 'critic_optimizer'):
            try:
                self.critic_optimizer.load_state_dict(state_dict["critic_optimizer"])
            except Exception as e:
                print(f"加载Critic优化器状态失败: {e}")

class MAPPOTrainer:
    """
    MAPPO训练器 - 简化训练流程
    """
    
    def __init__(
        self, 
        env, 
        network_manager,
        config=None,  # 新增配置参数
        buffer_size=2048,
        batch_size=64,
        lr_actor=3e-4,
        lr_critic=1e-3,
        gamma=0.99,
        gae_lambda=0.95,
        clip_param=0.2,
        value_clip_param=0.2,
        entropy_coef=0.01,
        value_loss_coef=0.5,
        max_grad_norm=0.5,
        use_clipped_value_loss=True,
        normalize_advantages=True,
        use_centralized_critic=True,
        device=None
    ):
        """
        初始化MAPPO训练器
        
        参数:
            env: 多智能体环境
            network_manager: 网络管理器
            config: 配置字典
            buffer_size: 经验回放缓冲区大小
            batch_size: 训练批次大小
            其他参数与MAPPO相同
        """
        self.env = env
        self.network_manager = network_manager
        self.agent_ids = network_manager.agent_ids
        
        # 从配置中读取参数
        if config is not None:
            buffer_size = config.get("buffer_size", buffer_size)
            batch_size = config.get("batch_size", batch_size)
            lr_actor = config.get("lr_actor", lr_actor)
            lr_critic = config.get("lr_critic", lr_critic)
            gamma = config.get("gamma", gamma)
            gae_lambda = config.get("gae_lambda", gae_lambda)
            clip_param = config.get("clip_param", clip_param)
            value_clip_param = config.get("value_clip_param", value_clip_param)
            entropy_coef = config.get("entropy_coef", entropy_coef)
            value_loss_coef = config.get("value_loss_coef", value_loss_coef)
            max_grad_norm = config.get("max_grad_norm", max_grad_norm)
            use_clipped_value_loss = config.get("use_clipped_value_loss", use_clipped_value_loss)
            normalize_advantages = config.get("normalize_advantages", normalize_advantages)
            use_centralized_critic = config.get("use_centralized_critic", use_centralized_critic)
            
            device_str = config.get("device", None)
            if device_str:
                device = torch.device(device_str)
                
        self.device = device or torch.device('cpu')
        self.batch_size = batch_size
        self.buffer_size = buffer_size
        
        # 打印训练器配置
        print("\n" + "-"*50)
        print("MAPPO训练器配置参数:")
        print(f"  批次大小: {batch_size}")
        print(f"  缓冲区大小: {buffer_size}")
        print(f"  计算设备: {self.device}")
        print("-"*50 + "\n")
        
        # 获取环境信息
        self.obs_dims = {}
        self.action_dims = {}
        
        # 定义特定智能体的默认维度值
        agent_specific_defaults = {
            'page_cache': {'obs': 13, 'action': 3},
            'memory_reclaim': {'obs': 14, 'action': 2},
            'memory_scheduler': {'obs': 12, 'action': 2}
        }
        
        # 1. 优先从网络管理器获取维度信息
        if hasattr(network_manager, 'obs_dims') and network_manager.obs_dims:
            print("从网络管理器获取观察维度")
            self.obs_dims = network_manager.obs_dims.copy()
        if hasattr(network_manager, 'action_dims') and network_manager.action_dims:
            print("从网络管理器获取动作维度")
            self.action_dims = network_manager.action_dims.copy()
        
        # 2. 从配置中获取维度信息
        if config is not None and "agent_dims" in config:
            print("从配置中获取维度信息")
            for agent_id in self.agent_ids:
                if agent_id in config["agent_dims"]:
                    if "obs_dim" in config["agent_dims"][agent_id]:
                        self.obs_dims[agent_id] = config["agent_dims"][agent_id]["obs_dim"]
                        print(f"  从配置获取 {agent_id} 的观察维度: {self.obs_dims[agent_id]}")
                    if "action_dim" in config["agent_dims"][agent_id]:
                        self.action_dims[agent_id] = config["agent_dims"][agent_id]["action_dim"]
                        print(f"  从配置获取 {agent_id} 的动作维度: {self.action_dims[agent_id]}")
        
        # 3. 尝试从环境获取维度信息
        if not all(agent_id in self.obs_dims for agent_id in self.agent_ids) or not all(agent_id in self.action_dims for agent_id in self.agent_ids):
            print("尝试从环境获取维度信息")
            try:
                # 3.1 从observation_space和action_space获取
                if hasattr(env, 'observation_space'):
                    for agent_id in self.agent_ids:
                        if agent_id not in self.obs_dims and agent_id in env.observation_space:
                            if hasattr(env.observation_space[agent_id], 'shape'):
                                self.obs_dims[agent_id] = env.observation_space[agent_id].shape[0]
                                print(f"  从observation_space获取智能体 {agent_id} 的观察维度: {self.obs_dims[agent_id]}")
                
                if hasattr(env, 'action_space'):
                    for agent_id in self.agent_ids:
                        if agent_id not in self.action_dims and agent_id in env.action_space:
                            if hasattr(env.action_space[agent_id], 'shape'):
                                self.action_dims[agent_id] = env.action_space[agent_id].shape[0]
                                print(f"  从action_space获取智能体 {agent_id} 的动作维度: {self.action_dims[agent_id]}")
                            elif hasattr(env.action_space[agent_id], 'n'):
                                self.action_dims[agent_id] = env.action_space[agent_id].n
                                print(f"  从action_space.n获取智能体 {agent_id} 的动作维度: {self.action_dims[agent_id]}")
                
                # 3.2 从state_collector获取更准确的维度
                if hasattr(env, 'state_collector'):
                    print("  环境具有state_collector属性")
                    for agent_id in self.agent_ids:
                        if agent_id not in self.obs_dims:
                            try:
                                # 先尝试获取维度函数
                                if hasattr(env.state_collector, 'get_agent_state_dimension'):
                                    dim = env.state_collector.get_agent_state_dimension(agent_id)
                                    self.obs_dims[agent_id] = dim
                                    print(f"  从state_collector.get_agent_state_dimension获取智能体 {agent_id} 的观察维度: {dim}")
                                # 如果没有维度函数，直接获取向量并计算长度
                                elif hasattr(env.state_collector, 'get_agent_optimized_vector'):
                                    state_vector = env.state_collector.get_agent_optimized_vector(agent_id)
                                    real_obs_dim = len(state_vector)
                                    self.obs_dims[agent_id] = real_obs_dim
                                    print(f"  从state_collector.get_agent_optimized_vector计算智能体 {agent_id} 的观察维度: {real_obs_dim}")
                            except Exception as e:
                                print(f"  获取智能体 {agent_id} 的观察维度时出错: {e}")
                
                # 3.3 尝试获取动作维度的其他方法
                if not all(agent_id in self.action_dims for agent_id in self.agent_ids) and hasattr(env, 'get_action_dimensions'):
                    try:
                        action_dims = env.get_action_dimensions()
                        if isinstance(action_dims, dict):
                            for agent_id, dim in action_dims.items():
                                if agent_id not in self.action_dims:
                                    self.action_dims[agent_id] = dim
                                    print(f"  从get_action_dimensions获取智能体 {agent_id} 的动作维度: {dim}")
                    except Exception as e:
                        print(f"  调用env.get_action_dimensions时出错: {e}")
                
            except Exception as e:
                print(f"获取环境维度信息时出错: {e}")
                import traceback
                traceback.print_exc()
        
        # 4. 尝试从网络管理器的agent_configs获取
        if not all(agent_id in self.obs_dims for agent_id in self.agent_ids) or not all(agent_id in self.action_dims for agent_id in self.agent_ids):
            print("尝试从网络管理器配置获取维度信息")
            if hasattr(network_manager, 'agent_configs'):
                for agent_id in self.agent_ids:
                    if agent_id not in self.obs_dims and agent_id in network_manager.agent_configs:
                        if 'state_dim' in network_manager.agent_configs[agent_id]:
                            self.obs_dims[agent_id] = network_manager.agent_configs[agent_id]['state_dim']
                            print(f"  从agent_configs获取智能体 {agent_id} 的观察维度: {self.obs_dims[agent_id]}")
                    
                    if agent_id not in self.action_dims and agent_id in network_manager.agent_configs:
                        if 'action_dim' in network_manager.agent_configs[agent_id]:
                            self.action_dims[agent_id] = network_manager.agent_configs[agent_id]['action_dim']
                            print(f"  从agent_configs获取智能体 {agent_id} 的动作维度: {self.action_dims[agent_id]}")
        
        # 5. 为剩余的智能体设置特定默认值
        for agent_id in self.agent_ids:
            if agent_id not in self.obs_dims or self.obs_dims[agent_id] is None:
                default_dim = agent_specific_defaults.get(agent_id, {}).get('obs', 13)
                print(f"  警告: 无法确定智能体 {agent_id} 的观察维度，使用特定默认值 {default_dim}")
                self.obs_dims[agent_id] = default_dim
                
            if agent_id not in self.action_dims or self.action_dims[agent_id] is None:
                default_dim = agent_specific_defaults.get(agent_id, {}).get('action', 3)
                print(f"  警告: 无法确定智能体 {agent_id} 的动作维度，使用特定默认值 {default_dim}")
                self.action_dims[agent_id] = default_dim
        
        # 打印最终确定的维度
        print("\n最终确定的维度信息:")
        for agent_id in self.agent_ids:
            print(f"  智能体 {agent_id}: 观察维度={self.obs_dims[agent_id]}, 动作维度={self.action_dims[agent_id]}")
        
        # 确定全局状态维度
        global_state_dim = None
        if hasattr(env, 'global_state_dim'):
            global_state_dim = env.global_state_dim
        else:
            # 尝试从观察维度推断
            global_state_dim = sum(self.obs_dims.values())
            print(f"计算的全局状态维度: {global_state_dim}")
        
        # 创建经验回放缓冲区
        try:
            from .buffer import MultiAgentRolloutBuffer
            
            print("\n创建经验回放缓冲区...")
            print(f"MultiAgentRolloutBuffer - 初始化，buffer_size={buffer_size}")
            print(f"MultiAgentRolloutBuffer - 观察维度(obs_dims)：{self.obs_dims}")
            print(f"MultiAgentRolloutBuffer - 动作维度(action_dims)：{self.action_dims}")
            print(f"智能体IDs：{self.agent_ids}")
            print(f"全局状态维度(指定)：{global_state_dim}")
            
            self.buffer = MultiAgentRolloutBuffer(
                buffer_size=buffer_size,
                obs_dims=self.obs_dims,
                action_dims=self.action_dims,
                gamma=gamma,
                gae_lambda=gae_lambda,
                use_centralized_critic=use_centralized_critic,
                global_state_dim=global_state_dim,
                device=self.device
            )
            
            print("重置缓冲区...")
            self.buffer.reset()
            print("缓冲区重置完成")
            
        except Exception as e:
            print(f"创建经验回放缓冲区失败: {e}")
            import traceback
            traceback.print_exc()
            raise
        
        # 创建MAPPO算法
        try:
            self.mappo = MAPPO(
                network_manager=network_manager,
                buffer=self.buffer,
                agent_ids=self.agent_ids,
                config=config,  # 传递配置字典
                lr_actor=lr_actor,
                lr_critic=lr_critic,
                gamma=gamma,
                gae_lambda=gae_lambda,
                clip_param=clip_param,
                value_clip_param=value_clip_param,
                entropy_coef=entropy_coef,
                value_loss_coef=value_loss_coef,
                max_grad_norm=max_grad_norm,
                use_clipped_value_loss=use_clipped_value_loss,
                normalize_advantages=normalize_advantages,
                use_centralized_critic=use_centralized_critic,
                device=self.device
            )
        except Exception as e:
            print(f"创建MAPPO算法失败: {e}")
            import traceback
            traceback.print_exc()
            raise
        
        # 训练统计
        self.episode_rewards = {agent_id: [] for agent_id in self.agent_ids}
        self.episode_lengths = []
        self.total_updates = 0
        
        # 确保网络已正确初始化
        self.initialize_networks()

    def initialize_networks(self):
        """确保所有LazyLinear层都已初始化"""
        import traceback
        import torch.nn as nn
        
        print("\n初始化网络层...")
        
        # 从网络管理器获取正确的输入维度
        for agent_id, network in self.network_manager.actor_networks.items():
            try:
                # 获取正确的输入维度
                input_dim = None
                if agent_id in self.obs_dims and self.obs_dims[agent_id] is not None:
                    input_dim = self.obs_dims[agent_id]
                else:
                    # 尝试从环境获取
                    if hasattr(self.env, 'observation_space') and agent_id in self.env.observation_space:
                        input_dim = self.env.observation_space[agent_id].shape[0]
                    else:
                        # 尝试从缓冲区最近的观察中获取维度
                        if hasattr(self.buffer, 'get_recent_observation'):
                            recent_obs = self.buffer.get_recent_observation(agent_id)
                            if recent_obs is not None:
                                input_dim = recent_obs.shape[-1]
                        
                        # 尝试从网络配置中获取
                        if input_dim is None and hasattr(self.network_manager, 'agent_configs') and agent_id in self.network_manager.agent_configs:
                            input_dim = self.network_manager.agent_configs[agent_id].get('state_dim')
                
                if input_dim is None:
                    print(f"警告: 无法确定智能体 {agent_id} 的输入维度，尝试推断...")
                    # 尝试获取网络特有的输入维度信息
                    if hasattr(network, 'base') and hasattr(network.base[0], 'weight') and hasattr(network.base[0].weight, 'shape'):
                        input_dim = network.base[0].weight.shape[1]
                        print(f"从网络权重推断输入维度: {input_dim}")
                    elif hasattr(network, 'pressure_encoder') and hasattr(network.pressure_encoder[0], 'weight'):
                        input_dim = network.pressure_encoder[0].weight.shape[1]
                        print(f"从pressure_encoder权重推断输入维度: {input_dim}")
                    elif hasattr(network, 'feature_extractor') and hasattr(network.feature_extractor[0], 'weight'):
                        input_dim = network.feature_extractor[0].weight.shape[1]
                        print(f"从feature_extractor权重推断输入维度: {input_dim}")
                    else:
                        # 检查LSTM配置
                        if hasattr(network, 'lstm') and hasattr(network.lstm, 'input_size'):
                            input_dim = network.lstm.input_size
                            print(f"从LSTM配置推断输入维度: {input_dim}")
                
                # 如果仍然无法确定，使用保守值
                if input_dim is None:
                    # 检查网络的类型，尝试特定的默认值
                    if type(network).__name__ == 'PageCacheNetwork':
                        input_dim = 13  # 假设的PageCacheNetwork默认输入维度
                    elif type(network).__name__ == 'MemoryReclaimNetwork':
                        input_dim = 14  # 假设的MemoryReclaimNetwork默认输入维度
                    elif type(network).__name__ == 'MemorySchedulerNetwork':
                        input_dim = 12  # 假设的MemorySchedulerNetwork默认输入维度
                    else:
                        input_dim = 13  # 通用默认值
                    print(f"使用默认输入维度: {input_dim}")
                
                # 生成正确维度的随机输入
                dummy_input = torch.zeros(1, input_dim).to(self.device)
                
                print(f"初始化智能体 {agent_id} 网络，输入维度: {input_dim}")
                
                with torch.no_grad():
                    if hasattr(network, 'reset_hidden'):
                        # 重置LSTM状态
                        network.reset_hidden(batch_size=1)
                    
                    # 检查网络的前向传播方法
                    if hasattr(network, 'forward'):
                        _ = network.forward(dummy_input)
                    else:
                        # 尝试直接调用网络
                        _ = network(dummy_input)
                    
                print(f"智能体 {agent_id} 网络已成功初始化")
            except Exception as e:
                print(f"初始化智能体 {agent_id} 网络时出错: {e}")
                traceback.print_exc()
                print(f"尝试继续执行其他初始化操作...")
                
        # 如果使用中央化Critic，也要初始化它
        if self.mappo.use_centralized_critic and hasattr(self.network_manager, 'central_critic'):
            try:
                # 获取全局状态维度
                global_state_dim = None
                if hasattr(self.env, 'global_state_dim'):
                    global_state_dim = self.env.global_state_dim
                elif hasattr(self.buffer, 'global_state_dim'):
                    global_state_dim = self.buffer.global_state_dim
                else:
                    # 尝试拼接所有观察空间
                    global_state_dim = sum(self.obs_dims.values())
                
                if global_state_dim is None or global_state_dim == 0:
                    # 尝试从中央化Critic权重推断
                    if hasattr(self.network_manager.central_critic[0], 'weight'):
                        global_state_dim = self.network_manager.central_critic[0].weight.shape[1]
                    else:
                        global_state_dim = 39  # 从日志中看到的全局状态维度
                
                print(f"初始化中央化Critic，输入维度: {global_state_dim}")
                dummy_global_input = torch.zeros(1, global_state_dim).to(self.device)
                
                with torch.no_grad():
                    _ = self.network_manager.central_critic(dummy_global_input)
                    
                print("中央化Critic已成功初始化")
            except Exception as e:
                print(f"初始化中央化Critic时出错: {e}")
                traceback.print_exc()
                print("继续执行其他操作...")
        
        print("网络初始化完成\n")

    def collect_trajectories(self, num_steps=None, config=None):
        """
        收集经验轨迹
        
        参数:
            num_steps: 收集的步骤数，如果为None则从config中读取
            config: 配置字典
            
        返回:
            episode_rewards: 每个智能体的累积奖励
            episode_lengths: 每个episode的长度
        """
        import numpy as np
        import torch
        import traceback
        
        # 从配置中读取参数
        if config is not None:
            num_steps = config.get("steps_per_update", num_steps or 2048)
            max_episode_steps = config.get("max_steps", 1000)  # 避免episode过长
        else:
            num_steps = num_steps or 2048
            max_episode_steps = 1000
            
        # 重置环境和统计
        try:
            observations = self.env.reset()
            global_state = None
            if hasattr(self.env, 'get_global_state'):
                global_state = self.env.get_global_state()
            
            episode_rewards = {agent_id: 0 for agent_id in self.agent_ids}
            episode_lengths = 0
            current_episode_steps = 0
            
            episode_rewards_history = []
            episode_lengths_history = []
            
            # 收集轨迹
            for step in range(num_steps):
                # 获取动作和价值
                actions, log_probs, values = self.mappo.act(observations)
                
                # 如果使用中央化Critic，获取全局价值
                global_value = None
                if self.mappo.use_centralized_critic and global_state is not None:
                    global_value = self.mappo.get_central_value(global_state)
                
                # 执行动作
                next_observations, rewards, dones, infos = self.env.step(actions)
                next_global_state = None
                if hasattr(self.env, 'get_global_state'):
                    next_global_state = self.env.get_global_state()
                
                # 存储经验
                self.buffer.store(
                    observations=observations,
                    actions=actions,
                    rewards=rewards,
                    dones=dones,
                    next_observations=next_observations,
                    values=values,
                    log_probs=log_probs,
                    global_state=global_state,
                    next_global_state=next_global_state,
                    global_value=global_value
                )
                
                # 更新观察和全局状态
                observations = next_observations
                global_state = next_global_state
                
                # 累积奖励
                for agent_id in self.agent_ids:
                    if agent_id in rewards:
                        episode_rewards[agent_id] += rewards[agent_id]
                
                # 更新episode长度
                episode_lengths += 1
                current_episode_steps += 1
                
                # 检查是否所有智能体都结束或达到最大步数
                all_done = False
                if isinstance(dones, dict):
                    # 如果dones是字典，检查所有智能体是否完成
                    all_done = all(dones.values())
                else:
                    # 如果dones是单个值，直接使用
                    all_done = dones
                
                # 如果episode结束或达到最大步数，重置环境
                if all_done or current_episode_steps >= max_episode_steps:
                    # 记录统计
                    for agent_id in self.agent_ids:
                        self.episode_rewards[agent_id].append(episode_rewards[agent_id])
                    self.episode_lengths.append(current_episode_steps)
                    
                    # 保存当前episode的信息
                    episode_rewards_history.append(episode_rewards.copy())
                    episode_lengths_history.append(current_episode_steps)
                    
                    # 重置环境
                    observations = self.env.reset()
                    if hasattr(self.env, 'get_global_state'):
                        global_state = self.env.get_global_state()
                    
                    # 重置累积奖励和episode长度
                    episode_rewards = {agent_id: 0 for agent_id in self.agent_ids}
                    current_episode_steps = 0
                    
                    # 重置LSTM隐藏状态
                    if hasattr(self.network_manager, 'reset_lstm_states'):
                        self.network_manager.reset_lstm_states()
            
            return self.episode_rewards, self.episode_lengths
            
        except Exception as e:
            print(f"收集轨迹时出错: {e}")
            traceback.print_exc()
            return self.episode_rewards, self.episode_lengths

    def train(self, num_episodes=None, steps_per_update=None, num_updates=None, k_epochs=None, config=None):
        """
        训练MAPPO算法
        
        参数:
            num_episodes: 训练的episode数量，如果为None则从config中读取
            steps_per_update: 每次更新前收集的步骤数，如果为None则从config中读取
            num_updates: 每次收集后进行的更新次数，如果为None则从config中读取
            k_epochs: 每个批次的训练轮数，如果为None则从config中读取
            config: 训练配置字典，优先级高于其他参数
            
        返回:
            训练统计信息
        """
        import numpy as np
        import torch
        import traceback
        
        # 确保网络已初始化
        self.initialize_networks()
        
        # 从配置中读取参数
        if config is not None:
            num_episodes = config.get("num_episodes", num_episodes or 1000)
            steps_per_update = config.get("steps_per_update", steps_per_update or 2048)
            num_updates = config.get("num_updates", num_updates or 4)
            k_epochs = config.get("k_epochs", k_epochs or 10)
        else:
            # 使用默认值或传入的参数
            num_episodes = num_episodes or 1000
            steps_per_update = steps_per_update or 2048
            num_updates = num_updates or 4
            k_epochs = k_epochs or 10
        
        # 打印训练参数
        print("\n" + "-"*50)
        print("训练参数:")
        print(f"  总回合数: {num_episodes}")
        print(f"  每次更新步数: {steps_per_update}")
        print(f"  每次采集后更新次数: {num_updates}")
        print(f"  每次更新的K轮次: {k_epochs}")
        print("-"*50 + "\n")
        
        total_steps = 0
        episode_count = 0
        
        while episode_count < num_episodes:
            # 收集轨迹
            _, _ = self.collect_trajectories(num_steps=steps_per_update, config={'max_steps': 1000})
            total_steps += steps_per_update
            
            # 计算现有的episode数
            episode_count = len(self.episode_lengths)
            
            # 执行多次策略更新
            update_success = False
            for update_idx in range(num_updates):
                try:
                    update_config = {
                        'k_epochs': k_epochs,
                        'batch_size': self.batch_size
                    }
                    self.mappo.update(config=update_config)
                    self.total_updates += 1
                    update_success = True
                except Exception as e:
                    print(f"策略更新 {update_idx+1} 失败: {e}")
                    traceback.print_exc()
            
            if not update_success:
                print("所有策略更新失败，跳过此轮更新")
            
            # 打印统计信息
            if episode_count % 10 == 0:
                avg_rewards = {}
                for agent_id in self.agent_ids:
                    if len(self.episode_rewards[agent_id]) > 0:
                        last_rewards = self.episode_rewards[agent_id][-10:] if len(self.episode_rewards[agent_id]) >= 10 else self.episode_rewards[agent_id]
                        avg_rewards[agent_id] = np.mean(last_rewards)
                    else:
                        avg_rewards[agent_id] = 0
                
                avg_length = np.mean(self.episode_lengths[-10:]) if len(self.episode_lengths) >= 10 else np.mean(self.episode_lengths) if len(self.episode_lengths) > 0 else 0
                
                print(f"Episode: {episode_count}/{num_episodes}, Total Steps: {total_steps}")
                print(f"Updates: {self.total_updates}, Avg Episode Length: {avg_length:.2f}")
                for agent_id, avg_reward in avg_rewards.items():
                    print(f"Agent {agent_id} Avg Reward: {avg_reward:.2f}")
                print("-" * 50)
        
        return {
            'episode_rewards': self.episode_rewards,
            'episode_lengths': self.episode_lengths,
            'total_updates': self.total_updates
        }

    def eval(self, num_episodes=None, deterministic=None, config=None):
        """
        评估MAPPO算法
        
        参数:
            num_episodes: 评估的episode数量，如果为None则从config中读取
            deterministic: 是否使用确定性策略，如果为None则从config中读取
            config: 评估配置字典，优先级高于其他参数
            
        返回:
            评估统计信息
        """
        import numpy as np
        import torch
        import traceback
        
        # 确保网络已初始化
        self.initialize_networks()
        
        # 从配置中读取参数
        if config is not None:
            num_episodes = config.get("eval_episodes", num_episodes or 10)
            deterministic = config.get("deterministic", deterministic if deterministic is not None else True)
        else:
            # 使用默认值或传入的参数
            num_episodes = num_episodes or 10
            deterministic = deterministic if deterministic is not None else True
        
        # 打印评估参数
        print("\n" + "="*50)
        print(f"评估MAPPO智能体")
        print("="*50)
        
        eval_rewards = {agent_id: [] for agent_id in self.agent_ids}
        eval_lengths = []
        
        for ep in range(num_episodes):
            try:
                observations = self.env.reset()
                episode_rewards = {agent_id: 0 for agent_id in self.agent_ids}
                episode_length = 0
                done = False
                
                # 重置LSTM隐藏状态
                if hasattr(self.network_manager, 'reset_lstm_states'):
                    self.network_manager.reset_lstm_states()
                
                while not done:
                    # 获取动作
                    actions, _, _ = self.mappo.act(observations, deterministic=deterministic)
                    
                    # 执行动作
                    observations, rewards, dones, _ = self.env.step(actions)
                    
                    # 累积奖励
                    for agent_id in self.agent_ids:
                        if agent_id in rewards:
                            episode_rewards[agent_id] += rewards[agent_id]
                    
                    # 更新episode长度
                    episode_length += 1
                    
                    # 检查是否所有智能体都结束
                    if isinstance(dones, dict):
                        done = all(dones.values())
                    else:
                        done = dones
                
                # 记录统计
                for agent_id in self.agent_ids:
                    eval_rewards[agent_id].append(episode_rewards[agent_id])
                eval_lengths.append(episode_length)
                
                # 打印每个回合的结果
                print(f"回合 {ep+1}/{num_episodes} - 长度: {episode_length}", end="")
                for agent_id, reward in episode_rewards.items():
                    print(f", {agent_id}: {reward:.2f}", end="")
                print()
            
            except Exception as e:
                print(f"评估回合 {ep+1} 时出错: {e}")
                traceback.print_exc()
        
        # 计算平均统计
        avg_rewards = {}
        for agent_id, rewards in eval_rewards.items():
            if len(rewards) > 0:
                avg_rewards[agent_id] = np.mean(rewards)
                all_rewards = rewards
                print(f"智能体 {agent_id}: 平均奖励 {avg_rewards[agent_id]:.2f} [最小: {min(all_rewards):.2f}, 最大: {max(all_rewards):.2f}]")
            else:
                avg_rewards[agent_id] = 0
                print(f"智能体 {agent_id}: 无有效奖励数据")
                
        avg_length = np.mean(eval_lengths) if len(eval_lengths) > 0 else 0
        print(f"平均回合长度: {avg_length:.2f}")
        print("=" * 70)
        
        return {
            'eval_rewards': eval_rewards,
            'eval_lengths': eval_lengths,
            'avg_rewards': avg_rewards,
            'avg_length': avg_length
        }

    def save(self, path):
        """
        保存模型和训练状态
        
        参数:
            path: 保存路径
        """
        import os
        import time
        import torch
        import torch.nn as nn
        import traceback
        
        try:
            # 确保目录存在
            dirname = os.path.dirname(path)
            if dirname:
                os.makedirs(dirname, exist_ok=True)
            
            # 确保网络模型已初始化
            self.initialize_networks()
            
            print(f"\n正在保存模型到: {path}")
            
            # 保存MAPPO模型
            success = self.mappo.save_models(path)
            
            if success:
                # 保存训练器状态
                trainer_state = {
                    "episode_rewards": self.episode_rewards,
                    "episode_lengths": self.episode_lengths,
                    "total_updates": self.total_updates,
                    "batch_size": self.batch_size,
                    "device": str(self.device),
                    "timestamp": str(time.time()),
                    "obs_dims": self.obs_dims,
                    "action_dims": self.action_dims
                }
                
                trainer_path = f"{path}_trainer_state.pth"
                torch.save(trainer_state, trainer_path)
                print(f"训练器状态已保存至: {trainer_path}")
                
                return True
            else:
                print("由于MAPPO模型保存失败，训练器状态未保存")
                self.diagnose_save_issues(path)
                return False
        except Exception as e:
            print(f"保存失败: {e}")
            traceback.print_exc()
            self.diagnose_save_issues(path)
            return False

    def load(self, path):
        """
        加载模型和训练状态
        
        参数:
            path: 加载路径
        """
        import os
        import torch
        import traceback
        
        try:
            print(f"\n正在加载模型: {path}")
            
            # 加载MAPPO模型
            success = self.mappo.load_models(path)
            
            # 尝试加载训练器状态
            try:
                trainer_path = f"{path}_trainer_state.pth"
                if os.path.exists(trainer_path):
                    trainer_state = torch.load(trainer_path, map_location=self.device)
                    
                    # 恢复训练统计
                    if "episode_rewards" in trainer_state:
                        self.episode_rewards = trainer_state["episode_rewards"]
                    if "episode_lengths" in trainer_state:
                        self.episode_lengths = trainer_state["episode_lengths"]
                    if "total_updates" in trainer_state:
                        self.total_updates = trainer_state["total_updates"]
                    if "batch_size" in trainer_state:
                        self.batch_size = trainer_state["batch_size"]
                    if "obs_dims" in trainer_state:
                        self.obs_dims = trainer_state["obs_dims"]
                    if "action_dims" in trainer_state:
                        self.action_dims = trainer_state["action_dims"]
                    
                    print(f"已加载训练器状态: {len(self.episode_lengths)} 回合, {self.total_updates} 次更新")
                else:
                    print(f"未找到训练器状态文件: {trainer_path}，只加载模型权重")
            except Exception as e:
                print(f"加载训练器状态时出错: {e}")
                traceback.print_exc()
            
            return success
        except Exception as e:
            print(f"加载失败: {e}")
            traceback.print_exc()
            return False

    def diagnose_save_issues(self, path):
        """诊断模型保存问题"""
        import os
        import torch
        import torch.nn as nn
        import traceback
        import shutil
        
        print("\n" + "="*50)
        print("开始诊断模型保存问题")
        print("="*50)
        
        # 检查路径
        print(f"保存路径: {path}")
        parent_dir = os.path.dirname(path) if os.path.dirname(path) else '.'
        print(f"父目录: {parent_dir}")
        print(f"父目录存在: {os.path.exists(parent_dir)}")
        
        # 尝试创建目录
        try:
            os.makedirs(parent_dir, exist_ok=True)
            print(f"目录创建/确认成功: {parent_dir}")
        except Exception as e:
            print(f"创建目录失败: {e}")
        
        # 检查写入权限
        try:
            test_file = os.path.join(parent_dir, "test_write.tmp")
            with open(test_file, 'w') as f:
                f.write("test")
            os.remove(test_file)
            print(f"写入权限检查: 通过")
        except Exception as e:
            print(f"写入权限检查: 失败 - {e}")
        
        # 检查磁盘空间
        try:
            total, used, free = shutil.disk_usage(parent_dir)
            print(f"磁盘空间 - 总计: {total//(1024**3)}GB, 已用: {used//(1024**3)}GB, 可用: {free//(1024**3)}GB")
        except Exception as e:
            print(f"无法检查磁盘空间: {e}")
        
        # 检查网络模型
        print("\n检查网络模型:")
        for agent_id, network in self.network_manager.actor_networks.items():
            print(f"\n智能体 {agent_id}:")
            print(f"  网络类型: {type(network).__name__}")
            
            # 检查网络参数
            total_params = sum(p.numel() for p in network.parameters())
            print(f"  参数总数: {total_params}")
            
            # 检查是否有LazyLinear层
            has_lazy = False
            for name, module in network.named_modules():
                if isinstance(module, nn.LazyLinear):
                    has_lazy = True
                    print(f"  发现LazyLinear层: {name}, 已初始化: {hasattr(module, 'weight')}")
            
            if has_lazy:
                print("  警告: 存在LazyLinear层，保存前需要确保已初始化")
                
            # 尝试获取state_dict
            try:
                state_dict = network.state_dict()
                print(f"  state_dict项数: {len(state_dict)}")
                
                # 检查state_dict大小
                total_size = sum(p.numel() * p.element_size() for p in state_dict.values() if torch.is_tensor(p))
                print(f"  state_dict大小: {total_size/(1024*1024):.2f} MB")
                
                # 尝试小型保存测试
                test_path = os.path.join(parent_dir, f"test_{agent_id}.pt")
                torch.save({"test": torch.randn(10, 10)}, test_path)
                os.remove(test_path)
                print(f"  小型保存测试: 成功")
                
                # 尝试保存单个网络
                try:
                    single_path = os.path.join(parent_dir, f"single_{agent_id}.pt")
                    torch.save(state_dict, single_path)
                    print(f"  单网络保存测试: 成功 - {single_path}")
                    # 保留此文件以供检查
                except Exception as e:
                    print(f"  单网络保存失败: {e}")
            except Exception as e:
                print(f"  获取state_dict失败: {e}")
        
        # 检查中央化Critic
        if self.mappo.use_centralized_critic:
            print("\n检查中央化Critic:")
            if hasattr(self.network_manager, 'central_critic'):
                critic = self.network_manager.central_critic
                print(f"  类型: {type(critic).__name__}")
                
                # 尝试获取state_dict
                try:
                    state_dict = critic.state_dict()
                    print(f"  state_dict项数: {len(state_dict)}")
                    
                    # 检查state_dict大小
                    total_size = sum(p.numel() * p.element_size() for p in state_dict.values() if torch.is_tensor(p))
                    print(f"  state_dict大小: {total_size/(1024*1024):.2f} MB")
                    
                    # 尝试保存
                    critic_path = os.path.join(parent_dir, "test_critic.pt")
                    torch.save(state_dict, critic_path)
                    print(f"  保存测试: 成功 - {critic_path}")
                    # 保留此文件以供检查
                except Exception as e:
                    print(f"  获取state_dict或保存失败: {e}")
            else:
                print("  警告: use_centralized_critic=True但network_manager中没有central_critic")
        
        # 检查缓冲区状态
        print("\n检查缓冲区状态:")
        try:
            buffer = self.buffer
            print(f"缓冲区大小: {buffer.buffer_size}")
            print(f"当前指针: {buffer.ptr}")
            print(f"是否已满: {buffer.full}")
            
            # 检查观察和动作维度
            if hasattr(buffer, 'obs_dims'):
                print(f"观察维度配置: {buffer.obs_dims}")
            if hasattr(buffer, 'action_dims'):
                print(f"动作维度配置: {buffer.action_dims}")
            
            # 尝试获取一个小批次，检查结构
            try:
                print("\n获取测试批次进行分析:")
                if hasattr(buffer, 'get_batch'):
                    test_batch = buffer.get_batch(agent_id=None, batch_size=2)
                    if test_batch is not None and isinstance(test_batch, dict) and 'batch' in test_batch:
                        batch = test_batch['batch']
                        print(f"批次键: {list(batch.keys())}")
                        for key, value in batch.items():
                            if isinstance(value, torch.Tensor):
                                print(f"  {key}: 类型={type(value).__name__}, 形状={value.shape}, 设备={value.device}")
                            else:
                                print(f"  {key}: 类型={type(value).__name__}")
                    else:
                        print("无法获取有效批次进行分析")
                else:
                    print("缓冲区没有get_batch方法")
            except Exception as e:
                print(f"获取测试批次失败: {e}")
        except Exception as e:
            print(f"检查缓冲区状态失败: {e}")
        
        print("\n测试torch.save基本功能:")
        try:
            test_dict = {"test": torch.randn(100, 100)}
            test_path = os.path.join(parent_dir, "torch_save_test.pt")
            torch.save(test_dict, test_path)
            print(f"基础torch.save测试: 成功 - {test_path}")
            os.remove(test_path)
        except Exception as e:
            print(f"基础torch.save测试失败: {e}")
        
        # 检查Python版本和PyTorch版本
        print(f"\nPython版本: {sys.version}")
        print(f"PyTorch版本: {torch.__version__}")
        print(f"CUDA是否可用: {torch.cuda.is_available()}")
        if torch.cuda.is_available():
            print(f"CUDA版本: {torch.version.cuda}")
        
        print("="*50)
        print("诊断完成")
        print("="*50)

    def get_recent_observation(self, agent_id):
        """获取最近一个有效的观察"""
        if hasattr(self.buffer, 'get_recent_observation'):
            return self.buffer.get_recent_observation(agent_id)
        
        # 如果缓冲区没有该方法，尝试自己实现
        if not hasattr(self.buffer, 'observations') or agent_id not in self.buffer.observations:
            return None
        
        observations = self.buffer.observations[agent_id]
        
        if self.buffer.full:
            # 缓冲区已满，返回当前指针前一个位置的观察
            idx = (self.buffer.ptr - 1) % self.buffer.buffer_size
            return observations[idx]
        elif self.buffer.ptr > 0:
            # 缓冲区未满，但有数据，返回最后一个存储的观察
            return observations[self.buffer.ptr - 1]
        else:
            # 缓冲区为空
            return None
