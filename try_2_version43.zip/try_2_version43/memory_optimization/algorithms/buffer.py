"""
经验回放缓冲区 - 支持单智能体和多智能体环境
"""

import numpy as np
import torch

class RolloutBuffer:
    """单智能体经验回放缓冲区"""
    
    def __init__(self, buffer_size, state_dim, action_dim, gamma=0.99, 
                 gae_lambda=0.95, device=None):
        """
        初始化经验回放缓冲区
        
        参数:
            buffer_size: 缓冲区大小
            state_dim: 状态维度
            action_dim: 动作维度
            gamma: 折扣因子
            gae_lambda: GAE参数
            device: 计算设备
        """
        self.buffer_size = buffer_size
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.gae_lambda = gae_lambda
        self.device = device or torch.device('cpu')
        
        # 初始化缓冲区
        self.reset()
    
    def reset(self):
        """重置缓冲区"""
        self.states = np.zeros((self.buffer_size, self.state_dim), dtype=np.float32)
        self.actions = np.zeros((self.buffer_size, self.action_dim), dtype=np.float32)
        self.rewards = np.zeros(self.buffer_size, dtype=np.float32)
        self.dones = np.zeros(self.buffer_size, dtype=np.bool_)
        self.next_states = np.zeros((self.buffer_size, self.state_dim), dtype=np.float32)
        self.values = np.zeros(self.buffer_size, dtype=np.float32)
        self.log_probs = np.zeros(self.buffer_size, dtype=np.float32)
        
        self.size = 0
        self.pointer = 0
    
    def store(self, state, action, reward, done, next_state, value, log_prob):
        """存储经验"""
        # 如果缓冲区已满，覆盖最早的经验
        idx = self.pointer % self.buffer_size
        
        self.states[idx] = state
        self.actions[idx] = action
        self.rewards[idx] = reward
        self.dones[idx] = done
        self.next_states[idx] = next_state
        self.values[idx] = value
        self.log_probs[idx] = log_prob
        
        self.pointer += 1
        self.size = min(self.size + 1, self.buffer_size)
    
    def compute_advantages(self, last_value=0):
        """计算广义优势估计和回报"""
        advantages = np.zeros(self.size, dtype=np.float32)
        returns = np.zeros(self.size, dtype=np.float32)
        
        # 使用GAE计算优势
        last_gae_lambda = 0
        
        for t in reversed(range(self.size)):
            # 如果是最后一步或者该步是终止状态，使用奖励作为下一个价值
            if t == self.size - 1:
                next_value = last_value
                next_non_terminal = 1.0 - self.dones[t]
            else:
                next_value = self.values[t + 1]
                next_non_terminal = 1.0 - self.dones[t]
            
            # 计算TD误差
            delta = self.rewards[t] + self.gamma * next_value * next_non_terminal - self.values[t]
            
            # 计算GAE
            last_gae_lambda = delta + self.gamma * self.gae_lambda * next_non_terminal * last_gae_lambda
            advantages[t] = last_gae_lambda
            
            # 计算回报(值函数目标)
            returns[t] = advantages[t] + self.values[t]
        
        # 归一化优势
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)
        
        return advantages, returns
    
    def get_batch(self, batch_size=64):
        """获取随机批次"""
        # 确保批次大小不超过缓冲区大小
        batch_size = min(batch_size, self.size)
        
        # 随机选择索引
        idx = np.random.choice(self.size, batch_size, replace=False)
        
        # 获取批次数据
        batch = {
            'batch': {
                'states': torch.FloatTensor(self.states[idx]).to(self.device),
                'actions': torch.FloatTensor(self.actions[idx]).to(self.device),
                'rewards': torch.FloatTensor(self.rewards[idx]).to(self.device),
                'dones': torch.FloatTensor(self.dones[idx]).to(self.device),
                'next_states': torch.FloatTensor(self.next_states[idx]).to(self.device),
                'values': torch.FloatTensor(self.values[idx]).to(self.device),
                'old_log_probs': torch.FloatTensor(self.log_probs[idx]).to(self.device),
                'advantages': torch.FloatTensor(self.compute_advantages()[0][idx]).to(self.device),
                'returns': torch.FloatTensor(self.compute_advantages()[1][idx]).to(self.device)
            }
        }
        
        return batch

class MultiAgentRolloutBuffer:
    """多智能体经验回放缓冲区 - 适用于MAPPO"""
    
    def __init__(self, buffer_size, obs_dims, action_dims, gamma=0.99, 
                 gae_lambda=0.95, use_centralized_critic=True,
                 global_state_dim=None, device=None):
        """
        初始化多智能体经验回放缓冲区
        
        参数:
            buffer_size: 缓冲区大小
            obs_dims: 字典，键为智能体ID，值为观察维度
            action_dims: 字典，键为智能体ID，值为动作维度
            gamma: 折扣因子
            gae_lambda: GAE参数
            use_centralized_critic: 是否使用中央化Critic
            global_state_dim: 全局状态维度（用于中央化Critic）
            device: 计算设备
        """
        # 添加调试信息
        print(f"MultiAgentRolloutBuffer - 初始化，buffer_size={buffer_size}")
        print(f"MultiAgentRolloutBuffer - 观察维度(obs_dims)：{obs_dims}")
        print(f"MultiAgentRolloutBuffer - 动作维度(action_dims)：{action_dims}")
        
        self.buffer_size = buffer_size
        self.gamma = gamma
        self.gae_lambda = gae_lambda
        self.use_centralized_critic = use_centralized_critic
        self.device = device or torch.device('cpu')
        
        # 检查并清理 obs_dims
        if not obs_dims:
            raise ValueError("必须提供非空的 obs_dims 字典")
            
        # 清理和验证输入数据
        self.obs_dims = {}
        self.action_dims = {}
        self.agent_ids = list(obs_dims.keys())  # 直接使用obs_dims的键作为智能体ID
        
        print(f"智能体IDs：{self.agent_ids}")
        
        # 处理 obs_dims
        for agent_id in self.agent_ids:
            if obs_dims[agent_id] is None:
                print(f"警告：智能体 {agent_id} 的观察维度为 None，使用动态维度")
                self.obs_dims[agent_id] = None
            else:
                self.obs_dims[agent_id] = obs_dims[agent_id]
        
        # 处理 action_dims
        if not action_dims:
            print("警告：未提供 action_dims，使用动态维度")
            self.action_dims = {agent_id: None for agent_id in self.agent_ids}
        else:
            for agent_id in self.agent_ids:
                if agent_id not in action_dims:
                    print(f"警告：智能体 {agent_id} 在 action_dims 中缺失，使用动态维度")
                    self.action_dims[agent_id] = None
                else:
                    self.action_dims[agent_id] = action_dims[agent_id]
        
        # 如果使用中央化Critic但未指定全局状态维度，则将所有观察组合作为全局状态
        if use_centralized_critic:
            if global_state_dim is None:
                # 使用动态全局状态维度
                self.global_state_dim = None
                print(f"全局状态维度：动态计算")
            else:
                self.global_state_dim = global_state_dim
                print(f"全局状态维度(指定)：{self.global_state_dim}")
        else:
            self.global_state_dim = None
            print("未使用中央化Critic，不需要全局状态")
        
        # 初始化缓冲区 - 只初始化基本结构，数组将在第一次存储时创建
        self.reset()
    
    def reset(self):
        """重置缓冲区"""
        # 为每个智能体创建单独的缓冲区结构，但不预先分配数组
        self.agent_buffers = {}
        
        print("重置缓冲区...")
        for agent_id in self.agent_ids:
            self.agent_buffers[agent_id] = {
                'observations': None,  # 在第一次存储时创建
                'actions': None,       # 在第一次存储时创建
                'rewards': np.zeros(self.buffer_size, dtype=np.float32),
                'dones': np.zeros(self.buffer_size, dtype=np.bool_),
                'next_observations': None,  # 在第一次存储时创建
                'values': np.zeros(self.buffer_size, dtype=np.float32),
                'log_probs': np.zeros(self.buffer_size, dtype=np.float32),
                'ptr': 0,
                'size': 0
            }
        
        # 如果使用中央化Critic，创建全局状态缓冲区结构
        if self.use_centralized_critic:
            self.global_states = None       # 在第一次存储时创建
            self.next_global_states = None  # 在第一次存储时创建
            self.global_values = np.zeros(self.buffer_size, dtype=np.float32)
        
        # 公共计数器
        self.ptr = 0
        self.size = 0
        print("缓冲区重置完成")
    
    def store(self, observations, actions, rewards, dones, next_observations, values, log_probs, global_state=None, next_global_state=None, global_value=None):
        """
        存储多智能体经验
        
        参数:
            observations: 字典，键为智能体ID，值为观察
            actions: 字典，键为智能体ID，值为动作
            rewards: 字典，键为智能体ID，值为奖励
            dones: 字典，键为智能体ID，值为终止标志
            next_observations: 字典，键为智能体ID，值为下一个观察
            values: 字典，键为智能体ID，值为观察的价值估计
            log_probs: 字典，键为智能体ID，值为动作的对数概率
            global_state: 全局状态（用于中央化Critic）
            next_global_state: 下一个全局状态
            global_value: 全局状态的价值估计
        """
        # 确保索引在范围内
        idx = self.ptr % self.buffer_size
        
        # 存储每个智能体的数据
        for agent_id in self.agent_ids:
            if agent_id in observations:
                agent_buffer = self.agent_buffers[agent_id]
                
                # 动态创建或调整观察空间
                if agent_buffer['observations'] is None:
                    # 首次存储，创建观察空间数组
                    obs_shape = observations[agent_id].shape
                    print(f"智能体 {agent_id} - 创建观察空间数组，形状：{obs_shape}")
                    agent_buffer['observations'] = np.zeros((self.buffer_size,) + obs_shape, dtype=np.float32)
                    agent_buffer['next_observations'] = np.zeros((self.buffer_size,) + obs_shape, dtype=np.float32)
                elif agent_buffer['observations'].shape[1:] != observations[agent_id].shape:
                    # 观察空间维度变化，重新创建数组
                    old_shape = agent_buffer['observations'].shape[1:]
                    new_shape = observations[agent_id].shape
                    print(f"警告：智能体 {agent_id} 的观察维度变化 - 从 {old_shape} 到 {new_shape}，重新创建数组")
                    agent_buffer['observations'] = np.zeros((self.buffer_size,) + new_shape, dtype=np.float32)
                    agent_buffer['next_observations'] = np.zeros((self.buffer_size,) + new_shape, dtype=np.float32)
                
                # 动态创建或调整动作空间
                if agent_buffer['actions'] is None:
                    # 首次存储，创建动作空间数组
                    act_shape = actions[agent_id].shape
                    print(f"智能体 {agent_id} - 创建动作空间数组，形状：{act_shape}")
                    agent_buffer['actions'] = np.zeros((self.buffer_size,) + act_shape, dtype=np.float32)
                elif agent_buffer['actions'].shape[1:] != actions[agent_id].shape:
                    # 动作空间维度变化，重新创建数组
                    old_shape = agent_buffer['actions'].shape[1:]
                    new_shape = actions[agent_id].shape
                    print(f"警告：智能体 {agent_id} 的动作维度变化 - 从 {old_shape} 到 {new_shape}，重新创建数组")
                    agent_buffer['actions'] = np.zeros((self.buffer_size,) + new_shape, dtype=np.float32)
                
                # 存储数据
                try:
                    agent_buffer['observations'][idx] = observations[agent_id]
                    agent_buffer['actions'][idx] = actions[agent_id]
                    agent_buffer['rewards'][idx] = rewards[agent_id]
                    agent_buffer['dones'][idx] = dones[agent_id]
                    agent_buffer['next_observations'][idx] = next_observations[agent_id]
                    agent_buffer['values'][idx] = values[agent_id]
                    agent_buffer['log_probs'][idx] = log_probs[agent_id]
                except Exception as e:
                    print(f"存储数据时出错 - 智能体 {agent_id}：{e}")
                    print(f"观察形状：{observations[agent_id].shape}, 缓冲区形状：{agent_buffer['observations'].shape}")
                    print(f"动作形状：{actions[agent_id].shape}, 缓冲区形状：{agent_buffer['actions'].shape}")
                    raise
                
                agent_buffer['ptr'] = (agent_buffer['ptr'] + 1) % self.buffer_size
                agent_buffer['size'] = min(agent_buffer['size'] + 1, self.buffer_size)
        
        # 存储全局状态（如果使用中央化Critic）
        if self.use_centralized_critic and global_state is not None:
            # 动态创建全局状态数组
            if self.global_states is None:
                # 首次存储，创建全局状态数组
                global_shape = global_state.shape
                print(f"创建全局状态数组，形状：{global_shape}")
                self.global_states = np.zeros((self.buffer_size,) + global_shape, dtype=np.float32)
                if next_global_state is not None:
                    self.next_global_states = np.zeros((self.buffer_size,) + global_shape, dtype=np.float32)
            elif self.global_states.shape[1:] != global_state.shape:
                # 全局状态维度变化，重新创建数组
                old_shape = self.global_states.shape[1:]
                new_shape = global_state.shape
                print(f"警告：全局状态维度变化 - 从 {old_shape} 到 {new_shape}，重新创建数组")
                self.global_states = np.zeros((self.buffer_size,) + new_shape, dtype=np.float32)
                if next_global_state is not None:
                    self.next_global_states = np.zeros((self.buffer_size,) + new_shape, dtype=np.float32)
            
            try:
                self.global_states[idx] = global_state
                if next_global_state is not None and self.next_global_states is not None:
                    self.next_global_states[idx] = next_global_state
                if global_value is not None:
                    self.global_values[idx] = global_value
            except Exception as e:
                print(f"存储全局状态时出错：{e}")
                print(f"全局状态形状：{global_state.shape}, 缓冲区形状：{self.global_states.shape}")
                if next_global_state is not None:
                    print(f"下一个全局状态形状：{next_global_state.shape}")
                raise
        
        # 更新公共计数器
        self.ptr = (self.ptr + 1) % self.buffer_size
        self.size = min(self.size + 1, self.buffer_size)
    
    def compute_advantages_and_returns(self, agent_id, last_value=0):
        """
        计算特定智能体的广义优势估计和回报
        
        参数:
            agent_id: 智能体ID
            last_value: 最后状态的估计值
            
        返回:
            advantages: 优势估计
            returns: 估计回报
        """
        agent_buffer = self.agent_buffers[agent_id]
        size = agent_buffer['size']
        
        # 初始化优势和回报
        advantages = np.zeros(size, dtype=np.float32)
        returns = np.zeros(size, dtype=np.float32)
        
        # 使用GAE计算优势
        last_gae_lambda = 0
        ptr = agent_buffer['ptr'] # 指向缓冲区中最旧数据的下一个位置
        
        # 循环计算优势，从最近的经验开始
        for i in range(size):
            # 转换为实际索引
            t = (ptr - i - 1) % self.buffer_size
            t_next = (t + 1) % self.buffer_size
            
            # 确定下一个值和终止标志
            if i == 0:
                next_value = last_value
                next_non_terminal = 1.0 - agent_buffer['dones'][t]
            else:
                next_value = agent_buffer['values'][t_next]
                next_non_terminal = 1.0 - agent_buffer['dones'][t]
            
            # 计算TD误差
            delta = agent_buffer['rewards'][t] + self.gamma * next_value * next_non_terminal - agent_buffer['values'][t]
            
            # 计算GAE
            last_gae_lambda = delta + self.gamma * self.gae_lambda * next_non_terminal * last_gae_lambda
            
            # 存储到正确的位置
            idx = (size - 1 - i)
            advantages[idx] = last_gae_lambda
            returns[idx] = last_gae_lambda + agent_buffer['values'][t]
        
        # 归一化优势
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)
        
        return advantages, returns
    
    def get_batch(self, agent_id=None, batch_size=None):
        """
        获取批次数据
        
        参数:
            agent_id: 智能体ID，如果为None则返回中央化批次
            batch_size: 批次大小，如果为None则使用全部数据
        
        返回:
            batch: 包含经验的批次
        """
        print(f"获取批次 - agent_id: {agent_id}, batch_size: {batch_size}")
        
        # 如果agent_id为None且使用中央化Critic，返回全局批次
        if agent_id is None and self.use_centralized_critic:
            return self._get_centralized_batch(batch_size)
        
        # 确保agent_id有效
        if agent_id not in self.agent_ids:
            raise ValueError(f"无效的智能体ID: {agent_id}")
        
        agent_buffer = self.agent_buffers[agent_id]
        buffer_size = agent_buffer['size']
        
        print(f"智能体 {agent_id} 缓冲区大小: {buffer_size}")
        
        # 如果缓冲区为空，返回None
        if buffer_size == 0:
            print("缓冲区为空，返回None")
            return None
        
        # 如果未指定批次大小或批次大小大于缓冲区，使用全部数据
        if batch_size is None or batch_size >= buffer_size:
            indices = np.arange(buffer_size)
            print(f"使用全部数据，样本数: {len(indices)}")
        else:
            # 随机选择索引
            indices = np.random.choice(buffer_size, batch_size, replace=False)
            print(f"随机采样，样本数: {len(indices)}")
        
        # 计算优势和回报
        advantages, returns = self.compute_advantages_and_returns(agent_id)
        
        print(f"计算的优势均值: {advantages.mean():.4f}, 标准差: {advantages.std():.4f}")
        print(f"计算的回报均值: {returns.mean():.4f}, 标准差: {returns.std():.4f}")
        
        # 收集实际数据
        actual_indices = []
        ptr = agent_buffer['ptr']
        for i in indices:
            # 计算在循环缓冲区中的实际索引
            actual_idx = (ptr - buffer_size + i) % self.buffer_size
            actual_indices.append(actual_idx)
        
        # 获取批次数据
        batch = {
            'batch': {
                'observations': torch.FloatTensor(agent_buffer['observations'][actual_indices]).to(self.device),
                'actions': torch.FloatTensor(agent_buffer['actions'][actual_indices]).to(self.device),
                'rewards': torch.FloatTensor(agent_buffer['rewards'][actual_indices]).to(self.device),
                'dones': torch.FloatTensor(agent_buffer['dones'][actual_indices]).to(self.device),
                'next_observations': torch.FloatTensor(agent_buffer['next_observations'][actual_indices]).to(self.device),
                'values': torch.FloatTensor(agent_buffer['values'][actual_indices]).to(self.device),
                'old_log_probs': torch.FloatTensor(agent_buffer['log_probs'][actual_indices]).to(self.device),
                'advantages': torch.FloatTensor(advantages[indices]).to(self.device),
                'returns': torch.FloatTensor(returns[indices]).to(self.device)
            }
        }
        
        return batch
    
    def _get_centralized_batch(self, batch_size=None):
        """
        获取中央化批次数据
        
        参数:
            batch_size: 批次大小，如果为None则使用全部数据
        
        返回:
            batch: 包含中央化经验的批次
        """
        print(f"获取中央化批次，batch_size: {batch_size}")
        
        # 如果缓冲区为空，返回None
        if self.size == 0:
            print("中央化缓冲区为空，返回None")
            return None
        
        # 如果未指定批次大小或批次大小大于缓冲区，使用全部数据
        if batch_size is None or batch_size >= self.size:
            indices = np.arange(self.size)
            print(f"使用全部中央化数据，样本数: {len(indices)}")
        else:
            # 随机选择索引
            indices = np.random.choice(self.size, batch_size, replace=False)
            print(f"随机采样中央化数据，样本数: {len(indices)}")
        
        # 收集实际数据
        actual_indices = []
        for i in indices:
            # 计算在循环缓冲区中的实际索引
            actual_idx = (self.ptr - self.size + i) % self.buffer_size
            actual_indices.append(actual_idx)
        
        # 创建包含所有智能体观察和动作的批次
        batch = {'batch': {}}
        
        # 添加全局状态
        if self.global_states is not None:
            batch['batch']['global_states'] = torch.FloatTensor(self.global_states[actual_indices]).to(self.device)
            if self.next_global_states is not None:
                batch['batch']['next_global_states'] = torch.FloatTensor(self.next_global_states[actual_indices]).to(self.device)
        else:
            # 如果没有全局状态，尝试拼接所有智能体的观察作为全局状态
            print("没有预存的全局状态，尝试拼接智能体观察")
            all_observations = []
            for agent_id in self.agent_ids:
                agent_buffer = self.agent_buffers[agent_id]
                if agent_buffer['observations'] is not None:
                    all_observations.append(agent_buffer['observations'][actual_indices].reshape(len(actual_indices), -1))
            
            if all_observations:
                # 拼接所有观察
                concatenated_obs = np.concatenate(all_observations, axis=1)
                batch['batch']['global_states'] = torch.FloatTensor(concatenated_obs).to(self.device)
                print(f"拼接的全局状态形状: {concatenated_obs.shape}")
        
        # 添加全局值
        batch['batch']['global_values'] = torch.FloatTensor(self.global_values[actual_indices]).to(self.device)
        
        # 添加每个智能体的观察和动作
        for agent_id in self.agent_ids:
            agent_buffer = self.agent_buffers[agent_id]
            batch['batch'][f'{agent_id}_observations'] = torch.FloatTensor(agent_buffer['observations'][actual_indices]).to(self.device)
            batch['batch'][f'{agent_id}_actions'] = torch.FloatTensor(agent_buffer['actions'][actual_indices]).to(self.device)
            batch['batch'][f'{agent_id}_rewards'] = torch.FloatTensor(agent_buffer['rewards'][actual_indices]).to(self.device)
            batch['batch'][f'{agent_id}_log_probs'] = torch.FloatTensor(agent_buffer['log_probs'][actual_indices]).to(self.device)
        
        # 计算全局优势和回报
        # 使用所有智能体奖励的平均值
        rewards_sum = np.zeros(len(actual_indices))
        for agent_id in self.agent_ids:
            rewards_sum += self.agent_buffers[agent_id]['rewards'][actual_indices]
        
        rewards_avg = rewards_sum / len(self.agent_ids)
        
        # 简化的回报计算 - 在实际应用中，应该使用折扣累积奖励
        returns = np.zeros_like(rewards_avg)
        advantages = np.zeros_like(rewards_avg)
        
        # 使用第一个智能体的done值来计算回报
        first_agent_id = self.agent_ids[0]
        dones = self.agent_buffers[first_agent_id]['dones'][actual_indices]
        
        # 简单计算回报，没有使用GAE
        discounted_reward = 0
        for i in reversed(range(len(rewards_avg))):
            discounted_reward = rewards_avg[i] + (self.gamma * discounted_reward * (1 - dones[i]))
            returns[i] = discounted_reward
        
        # 计算优势 = 回报 - 值
        for i in range(len(advantages)):
            advantages[i] = returns[i] - self.global_values[actual_indices][i]
        
        # 归一化优势
        if len(advantages) > 1:  # 防止只有一个样本时的除零错误
            advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)
        
        batch['batch']['global_returns'] = torch.FloatTensor(returns).to(self.device)
        batch['batch']['global_advantages'] = torch.FloatTensor(advantages).to(self.device)
        
        print(f"全局回报均值: {returns.mean():.4f}, 标准差: {returns.std():.4f}")
        print(f"全局优势均值: {advantages.mean():.4f}, 标准差: {advantages.std():.4f}")
        
        return batch
    
    def __len__(self):
        """返回缓冲区中样本的数量"""
        return self.size

class MultiAgentReplayBuffer:
    """多智能体经验回放缓冲区 - 旧版兼容接口"""
    
    def __init__(self, capacity=10000, num_agents=3, device=None):
        """
        初始化多智能体经验回放缓冲区
        
        参数:
            capacity: 每个智能体的缓冲区容量
            num_agents: 智能体数量
            device: 计算设备
        """
        self.capacity = capacity
        self.num_agents = num_agents
        self.buffers = {}  # 每个智能体的缓冲区
        self.global_buffer = []  # 全局经验缓冲区
        self.position = 0
        self.device = device or torch.device('cpu')
    
    def add(self, agent_id, state, action, reward, next_state, log_prob, value, done, global_state=None):
        """
        添加经验到缓冲区
        
        参数:
            agent_id: 智能体ID
            state: 状态
            action: 动作
            reward: 奖励
            next_state: 下一个状态
            log_prob: 动作对数概率
            value: 状态价值
            done: 是否终止
            global_state: 全局状态(可选)
        """
        # 如果这个智能体的缓冲区不存在，则创建
        if agent_id not in self.buffers:
            self.buffers[agent_id] = {
                'states': [],
                'actions': [],
                'rewards': [],
                'next_states': [],
                'log_probs': [],
                'values': [],
                'dones': []
            }
        
        # 添加经验到智能体的缓冲区
        self.buffers[agent_id]['states'].append(state)
        self.buffers[agent_id]['actions'].append(action)
        self.buffers[agent_id]['rewards'].append(reward)
        self.buffers[agent_id]['next_states'].append(next_state)
        self.buffers[agent_id]['log_probs'].append(log_prob)
        self.buffers[agent_id]['values'].append(value)
        self.buffers[agent_id]['dones'].append(done)
        
        # 如果缓冲区超过容量，移除最早的经验
        if len(self.buffers[agent_id]['states']) > self.capacity:
            for key in self.buffers[agent_id]:
                self.buffers[agent_id][key].pop(0)
        
        # 如果提供了全局状态，添加到全局缓冲区
        if global_state is not None:
            self.global_buffer.append({
                'global_state': global_state,
                'reward': reward,
                'done': done,
                'agent_id': agent_id
            })
            
            # 如果全局缓冲区超过容量，移除最早的经验
            if len(self.global_buffer) > self.capacity:
                self.global_buffer.pop(0)
    
    def sample(self, agent_id, batch_size):
        """
        从特定智能体的缓冲区采样批次
        
        参数:
            agent_id: 智能体ID
            batch_size: 批次大小
            
        返回:
            batch: 包含经验的批次
        """
        if agent_id not in self.buffers or len(self.buffers[agent_id]['states']) == 0:
            return None
        
        # 确保批次大小不超过缓冲区大小
        buffer_size = len(self.buffers[agent_id]['states'])
        batch_size = min(batch_size, buffer_size)
        
        # 随机选择索引
        indices = np.random.choice(buffer_size, batch_size, replace=False)
        
        # 获取批次数据
        batch = {
            'states': np.array([self.buffers[agent_id]['states'][i] for i in indices]),
            'actions': np.array([self.buffers[agent_id]['actions'][i] for i in indices]),
            'rewards': np.array([self.buffers[agent_id]['rewards'][i] for i in indices]),
            'next_states': np.array([self.buffers[agent_id]['next_states'][i] for i in indices]),
            'log_probs': np.array([self.buffers[agent_id]['log_probs'][i] for i in indices]),
            'values': np.array([self.buffers[agent_id]['values'][i] for i in indices]),
            'dones': np.array([self.buffers[agent_id]['dones'][i] for i in indices])
        }
        
        return batch
    
    def sample_global(self, batch_size):
        """
        从全局缓冲区采样批次
        
        参数:
            batch_size: 批次大小
            
        返回:
            batch: 包含全局经验的批次
        """
        if len(self.global_buffer) == 0:
            return None
        
        # 确保批次大小不超过缓冲区大小
        batch_size = min(batch_size, len(self.global_buffer))
        
        # 随机选择索引
        indices = np.random.choice(len(self.global_buffer), batch_size, replace=False)
        
        # 获取批次数据
        batch = {
            'global_states': np.array([self.global_buffer[i]['global_state'] for i in indices]),
            'rewards': np.array([self.global_buffer[i]['reward'] for i in indices]),
            'dones': np.array([self.global_buffer[i]['done'] for i in indices]),
            'agent_ids': [self.global_buffer[i]['agent_id'] for i in indices]
        }
        
        return batch
    
    def compute_returns(self, rewards, gamma=0.99, last_value=0):
        """
        计算折扣回报
        
        参数:
            rewards: 奖励序列
            gamma: 折扣因子
            last_value: 最后一个状态的价值估计
            
        返回:
            returns: 折扣回报序列
        """
        returns = np.zeros_like(rewards)
        R = last_value
        
        for t in reversed(range(len(rewards))):
            R = rewards[t] + gamma * R
            returns[t] = R
            
        return returns
    
    def compute_advantages(self, agent_id, gamma=0.99, gae_lambda=0.95, last_value=0):
        """
        计算广义优势估计和回报
        
        参数:
            agent_id: 智能体ID
            gamma: 折扣因子
            gae_lambda: GAE参数
            last_value: 最后一个状态的价值估计
            
        返回:
            advantages: 优势估计
            returns: 折扣回报
        """
        if agent_id not in self.buffers or len(self.buffers[agent_id]['states']) == 0:
            return None, None
        
        buffer = self.buffers[agent_id]
        rewards = np.array(buffer['rewards'])
        values = np.array(buffer['values'])
        dones = np.array(buffer['dones'])
        
        # 初始化优势和回报
        advantages = np.zeros_like(rewards)
        returns = np.zeros_like(rewards)
        
        # 计算GAE
        last_gae_lam = 0
        
        for t in reversed(range(len(rewards))):
            # 如果是最后一步或者该步是终止状态，使用提供的last_value
            if t == len(rewards) - 1:
                next_value = last_value
                next_non_terminal = 1.0 - dones[t]
            else:
                next_value = values[t + 1]
                next_non_terminal = 1.0 - dones[t]
            
            # 计算TD误差
            delta = rewards[t] + gamma * next_value * next_non_terminal - values[t]
            
            # 计算GAE
            last_gae_lam = delta + gamma * gae_lambda * next_non_terminal * last_gae_lam
            advantages[t] = last_gae_lam
            
            # 计算回报
            returns[t] = advantages[t] + values[t]
        
        # 归一化优势
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)
        
        return advantages, returns
    
    def clear(self):
        """清空所有缓冲区"""
        self.buffers.clear()
        self.global_buffer.clear()
    
    def __len__(self):
        """返回缓冲区中样本的数量"""
        if not self.buffers:
            return 0
        return min(len(buffer['states']) for buffer in self.buffers.values())
