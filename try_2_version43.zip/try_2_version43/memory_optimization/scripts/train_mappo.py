#!/usr/bin/env python3

"""
训练专门化内存管理智能体脚本

这个脚本用于训练专门化的内存管理智能体，包括：
1. 页面缓存智能体（Page Cache Agent）
2. 内存回收智能体（Memory Reclaim Agent）
3. 内存调度智能体（Memory Scheduler Agent）

支持使用 MAPPO 进行联合训练或使用 PPO 分别训练每个智能体
"""

import os
import sys
import time
import argparse
import yaml
import numpy as np
import torch
from datetime import datetime
from collections import defaultdict
from .reward_tracker import RewardTracker

# train.py - 在训练开始前初始化
reward_tracker = RewardTracker(save_dir='./memory_rl_logs')

# 导入项目组件
from ..algorithms.network import create_memory_management_networks
from ..algorithms.buffer import MultiAgentRolloutBuffer
from ..algorithms.mappo import MAPPO, MAPPOTrainer
from ..algorithms.ppo import PPO

def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description="Train specialized memory management agents")
    parser.add_argument("--config", type=str, required=True, help="Path to config file")
    parser.add_argument("--checkpoint", type=str, default=None, help="Path to checkpoint to resume training")
    parser.add_argument("--mode", type=str, default="joint", choices=["joint", "separate"], 
                       help="Training mode: joint (MAPPO) or separate (individual PPO)")
    parser.add_argument("--seed", type=int, default=None, help="Random seed")
    parser.add_argument("--eval", action="store_true", help="Evaluate instead of train")
    parser.add_argument("--debug", action="store_true", help="启用详细调试输出")
    return parser.parse_args()

def load_config(config_path):
    """加载配置文件"""
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    return config

def set_seed(seed):
    """设置随机种子"""
    if seed is None:
        return
        
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    # 设置确定性
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def create_save_dir(config):
    """创建保存目录"""
    # 创建基础目录
    base_dir = config.get("save_dir", "saved_models")
    os.makedirs(base_dir, exist_ok=True)
    
    # 创建特定实验目录
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    exp_name = config.get("exp_name", "memory_management")
    save_dir = os.path.join(base_dir, f"{exp_name}_{timestamp}")
    os.makedirs(save_dir, exist_ok=True)
    
    # 创建模型和日志子目录
    models_dir = os.path.join(save_dir, "models")
    logs_dir = os.path.join(save_dir, "logs")
    os.makedirs(models_dir, exist_ok=True)
    os.makedirs(logs_dir, exist_ok=True)
    
    return save_dir, models_dir, logs_dir

def create_environment(env_config):
    """创建环境实例"""
    try:
        # 尝试导入环境
        from ..environment.mem_env import MultiAgentMemoryEnv
        # 创建环境实例
        env = MultiAgentMemoryEnv(params=env_config)
        return env
    except ImportError as e:
        print(f"Error importing environment: {e}")
        print("Please make sure the environment module is available in your PYTHONPATH")
        sys.exit(1)

def train_with_mappo(config, save_dir, models_dir, logs_dir, debug_mode=False):
    """使用MAPPO联合训练所有智能体"""
    print("\n" + "="*60)
    print("         开始使用 MAPPO 联合训练所有智能体")
    print("="*60)
    
    # 设置调试日志
    debug_log_file = None
    if debug_mode:
        debug_log_file = os.path.join(logs_dir, "debug.log")
        
    def debug_print(message):
        if debug_mode:
            timestamp = datetime.now().strftime("%H:%M:%S")
            full_message = f"[{timestamp}] [DEBUG] {message}"
            print(full_message)
            if debug_log_file:
                with open(debug_log_file, "a") as f:
                    f.write(f"{full_message}\n")
    
    # 设置设备
    device = torch.device("cuda" if torch.cuda.is_available() and config.get("use_cuda", True) else "cpu")
    print(f"使用设备: {device}")
    debug_print(f"CUDA是否可用: {torch.cuda.is_available()}")
    
    # 创建环境
    env_config = config.get("env_config", {})
    debug_print(f"环境配置: {env_config}")
    
    try:
        env = create_environment(env_config)
        debug_print("环境创建成功")
        
        # 打印环境信息
        if hasattr(env, 'agent_ids'):
            debug_print(f"智能体IDs: {env.agent_ids}")
        if hasattr(env, 'observation_space'):
            debug_print(f"观察空间: {env.observation_space}")
        if hasattr(env, 'action_space'):
            debug_print(f"动作空间: {env.action_space}")
    except Exception as e:
        print(f"环境创建失败: {e}")
        import traceback
        traceback.print_exc()
        return None
    
    # 创建网络管理器
    try:
        network_manager = create_memory_management_networks(device=device)
        debug_print("网络管理器创建成功")
    except Exception as e:
        print(f"网络管理器创建失败: {e}")
        import traceback
        traceback.print_exc()
        return None
    
    # 获取MAPPO配置
    mappo_config = config.get("mappo_config", {})
    debug_print(f"MAPPO配置: {mappo_config}")
    
    # 设置设备到MAPPO配置中，确保设备信息传递
    if "device" not in mappo_config:
        mappo_config["device"] = str(device)
    
    # 创建MAPPO训练器 - 直接传递整个配置字典
    try:
        trainer = MAPPOTrainer(
            env=env,
            network_manager=network_manager,
            config=mappo_config,  # 直接传递整个配置字典
            device=device
        )
        debug_print("MAPPO训练器创建成功")
    except Exception as e:
        print(f"MAPPO训练器创建失败: {e}")
        import traceback
        traceback.print_exc()
        return None
    
    # 加载检查点（如果有）
    checkpoint_path = config.get("checkpoint", None)
    if checkpoint_path is not None and os.path.exists(checkpoint_path):
        try:
            trainer.load(checkpoint_path)
            print(f"加载检查点成功: {checkpoint_path}")
            debug_print(f"加载检查点: {checkpoint_path}")
        except Exception as e:
            print(f"加载检查点失败: {e}")
            debug_print(f"加载检查点失败: {e}")
    
    # 获取训练配置
    training_config = config.get("training", {})
    
    # 打印训练配置
    print("\n" + "-"*40)
    print("训练配置:")
    print(f"总回合数: {training_config.get('num_episodes')}")
    print(f"更新间隔步数: {training_config.get('steps_per_update')}")
    print(f"每次采集后更新次数: {training_config.get('num_updates')}")
    print(f"K epochs: {training_config.get('k_epochs')}")
    print(f"批次大小: {mappo_config.get('batch_size')}")
    print(f"评估间隔: {training_config.get('eval_interval')} 回合")
    print(f"保存间隔: {training_config.get('save_interval')} 回合")
    print(f"日志间隔: {training_config.get('log_interval')} 回合")
    print("-"*40 + "\n")
    
    # 训练循环
    total_start_time = time.time()
    episode_count = 0
    update_count = 0
    
    # 保存训练统计
    training_stats = {
        "episode_rewards": defaultdict(list),
        "episode_lengths": [],
        "eval_rewards": defaultdict(list),
        "eval_lengths": [],
        "actor_losses": defaultdict(list),
        "critic_losses": defaultdict(list),
        "timestamps": []
    }
    
    print(f"开始训练 {training_config.get('num_episodes')} 回合...")
    print(f"每次更新步数: {training_config.get('steps_per_update')}, 每次采集后更新次数: {training_config.get('num_updates')}")
    print("-" * 60)
    
    try:
        while episode_count < training_config.get("num_episodes"):
            # 收集轨迹配置
            collect_config = {
                "steps_per_update": training_config.get("steps_per_update")
            }
            
            # 收集轨迹
            collect_start_time = time.time()
            debug_print(f"开始采集轨迹, 目标步数: {training_config.get('steps_per_update')}")
            
            try:
                # 使用配置参数收集轨迹
                episode_rewards, episode_lengths = trainer.collect_trajectories(config=collect_config)
                collect_time = time.time() - collect_start_time
                debug_print(f"轨迹采集完成, 用时: {collect_time:.2f}秒, 回合数: {len(episode_lengths)}")
            except Exception as e:
                print(f"轨迹采集失败: {e}")
                debug_print(f"轨迹采集失败: {e}")
                import traceback
                debug_print(traceback.format_exc())
                continue
            
            # 执行多次策略更新
            update_start_time = time.time()
            debug_print(f"开始执行 {training_config.get('num_updates')} 次策略更新")
            
            update_errors = 0
            for update_idx in range(training_config.get("num_updates")):
                try:
                    # 创建更新配置
                    update_config = {
                        "k_epochs": training_config.get("k_epochs"),
                        "batch_size": mappo_config.get("batch_size")
                    }
                    
                    update_stats = trainer.mappo.update(config=update_config)
                    update_count += 1
                    
                    # 记录训练统计
                    for agent_id in trainer.agent_ids:
                        if agent_id in update_stats["actor_losses"]:
                            training_stats["actor_losses"][agent_id].extend(update_stats["actor_losses"][agent_id])
                        if agent_id in update_stats["critic_losses"]:
                            training_stats["critic_losses"][agent_id].extend(update_stats["critic_losses"][agent_id])
                    
                    debug_print(f"更新 {update_idx+1}/{training_config.get('num_updates')} 完成")
                except Exception as e:
                    print(f"策略更新 {update_idx+1} 失败: {e}")
                    debug_print(f"策略更新失败: {e}")
                    import traceback
                    debug_print(traceback.format_exc())
                    update_errors += 1
            
            if update_errors == training_config.get("num_updates"):
                print("所有策略更新失败，跳过此轮更新")
                continue
                
            update_time = time.time() - update_start_time
            
            # 更新episode计数
            episode_count = len(trainer.episode_lengths)
            
            # 记录训练统计
            for agent_id in trainer.agent_ids:
                training_stats["episode_rewards"][agent_id].extend(trainer.episode_rewards[agent_id][-len(episode_lengths):])
            training_stats["episode_lengths"].extend(episode_lengths)
            training_stats["timestamps"].append(time.time() - total_start_time)
            
            # 添加奖励追踪记录
            debug_print("记录奖励追踪数据")
            for i, length in enumerate(episode_lengths):
                # 获取最近一次episode的相关信息
                last_episode_idx = len(training_stats["episode_lengths"]) - i - 1
                
                # 获取每个智能体的奖励
                rewards_dict = {agent_id: training_stats["episode_rewards"][agent_id][last_episode_idx]
                                for agent_id in trainer.agent_ids}
                
                # 计算全局奖励（所有智能体奖励总和）
                global_reward = sum(rewards_dict.values())
                
                # 获取环境信息（如果可用）
                workload_type = getattr(env, 'current_workload_type', 'unknown')
                difficulty = getattr(env, 'current_difficulty', 'unknown')
                runtime = getattr(env, 'last_workload_runtime', 0.0)
                prev_runtime = getattr(env, 'previous_workload_runtime', None)
                
                # 记录到奖励追踪器
                reward_tracker.add_record(
                    episode=last_episode_idx + 1,  # episode从1开始
                    rewards_dict=rewards_dict,
                    global_reward=global_reward,
                    runtime=runtime,
                    prev_runtime=prev_runtime,
                    workload_type=workload_type,
                    difficulty=difficulty
                )
            
            # 定期打印摘要
            if episode_count % training_config.get("summary_interval", 50) == 0:
                reward_tracker.print_summary(episode_count)
                debug_print("打印奖励追踪摘要")
            
            # 检查是否收敛
            if episode_count % training_config.get("convergence_check_interval", 200) == 0 and episode_count >= training_config.get("convergence_min_episodes", 400):
                converged, change = reward_tracker.check_convergence()
                if converged:
                    print(f"\n模型似乎已经收敛于回合 {episode_count}!")
                    print(f"奖励相对变化: {change:.6f}")
                    print("考虑停止训练或降低学习率。")
                    debug_print(f"检测到收敛, 相对变化: {change:.6f}")
            
            # 打印训练信息
            if episode_count % training_config.get("log_interval") == 0:
                # 计算最近10回合的平均奖励和长度
                recent_episodes = training_config.get("recent_episodes_stats", 10)
                recent_rewards = {agent_id: trainer.episode_rewards[agent_id][-min(recent_episodes, len(trainer.episode_rewards[agent_id])):] 
                                 for agent_id in trainer.agent_ids}
                avg_rewards = {agent_id: np.mean(rewards) if len(rewards) > 0 else 0.0
                              for agent_id, rewards in recent_rewards.items()}
                
                recent_lengths = trainer.episode_lengths[-min(recent_episodes, len(trainer.episode_lengths)):]
                avg_length = np.mean(recent_lengths) if recent_lengths else 0.0
                
                # 计算智能体奖励统计
                agent_reward_stats = {}
                for agent_id in trainer.agent_ids:
                    if agent_id in recent_rewards and len(recent_rewards[agent_id]) > 0:
                        rewards = recent_rewards[agent_id]
                        agent_reward_stats[agent_id] = {
                            "min": np.min(rewards),
                            "max": np.max(rewards),
                            "std": np.std(rewards)
                        }
                
                # 打印详细信息
                print("\n" + "-"*60)
                print(f"回合: {episode_count}/{training_config.get('num_episodes')} | 更新次数: {update_count}")
                print(f"采集用时: {collect_time:.2f}秒 | 更新用时: {update_time:.2f}秒")
                print(f"平均回合长度: {avg_length:.1f} 步")
                
                # 打印每个智能体的奖励详情
                print(f"\n智能体奖励统计 (最近{recent_episodes}回合):")
                for agent_id, avg_reward in avg_rewards.items():
                    stats = agent_reward_stats.get(agent_id, {})
                    stats_str = ""
                    if stats:
                        stats_str = f" [最小: {stats.get('min', 0):.2f}, 最大: {stats.get('max', 0):.2f}, 标准差: {stats.get('std', 0):.2f}]"
                    print(f"  智能体 {agent_id}: {avg_reward:.2f}{stats_str}")
                
                # 计算总体奖励
                total_avg_reward = sum(avg_rewards.values())
                print(f"\n总体平均奖励: {total_avg_reward:.2f}")
                
                # 打印训练进度
                elapsed_time = time.time() - total_start_time
                remaining_episodes = training_config.get("num_episodes") - episode_count
                estimated_time_remaining = (elapsed_time / max(1, episode_count)) * remaining_episodes
                
                time_format = lambda seconds: f"{int(seconds//3600)}时{int((seconds%3600)//60)}分{int(seconds%60)}秒"
                
                print(f"\n训练进度: {episode_count/training_config.get('num_episodes')*100:.1f}% 完成")
                print(f"已用时间: {time_format(elapsed_time)}")
                print(f"预计剩余: {time_format(estimated_time_remaining)}")
                print("-"*60)
            
            # 定期评估
            if episode_count % training_config.get("eval_interval") == 0:
                print("\n" + "*"*40)
                print("评估当前策略...")
                debug_print(f"开始第 {episode_count} 回合的评估")
                
                try:
                    # 创建评估配置
                    eval_config = {
                        "eval_episodes": training_config.get("eval_episodes"),
                        "deterministic": training_config.get("deterministic_eval")
                    }
                    
                    eval_stats = trainer.eval(config=eval_config)
                    
                    # 记录评估统计
                    for agent_id in trainer.agent_ids:
                        if agent_id in eval_stats["eval_rewards"]:
                            training_stats["eval_rewards"][agent_id].extend(eval_stats["eval_rewards"][agent_id])
                    training_stats["eval_lengths"].extend(eval_stats["eval_lengths"])
                    
                    # 打印评估结果
                    eval_rewards = {agent_id: np.mean(eval_stats["eval_rewards"][agent_id]) 
                                  for agent_id in trainer.agent_ids 
                                  if agent_id in eval_stats["eval_rewards"]}
                    eval_length = np.mean(eval_stats["eval_lengths"]) if eval_stats["eval_lengths"] else 0
                    
                    print("评估结果:")
                    print(f"平均回合长度: {eval_length:.1f} 步")
                    for agent_id, reward in eval_rewards.items():
                        print(f"智能体 {agent_id} 平均奖励: {reward:.2f}")
                    print(f"总体平均奖励: {sum(eval_rewards.values()):.2f}")
                    
                    # 保存评估结果
                    eval_results_path = os.path.join(logs_dir, f"eval_results_ep{episode_count}.yaml")
                    with open(eval_results_path, 'w') as f:
                        yaml.dump(eval_stats, f)
                    print(f"评估结果已保存至: {eval_results_path}")
                    debug_print(f"评估完成并保存结果")
                except Exception as e:
                    print(f"评估失败: {e}")
                    debug_print(f"评估失败: {e}")
                    import traceback
                    debug_print(traceback.format_exc())
                
                print("*"*40)
            
            # 定期保存模型
            if episode_count % training_config.get("save_interval") == 0:
                checkpoint_path = os.path.join(models_dir, f"checkpoint_ep{episode_count}")
                try:
                    trainer.save(checkpoint_path)
                    print(f"\n检查点已保存: {checkpoint_path}")
                    debug_print(f"保存检查点: {checkpoint_path}")
                    
                    # 保存训练统计
                    stats_path = os.path.join(logs_dir, f"training_stats_ep{episode_count}.yaml")
                    with open(stats_path, 'w') as f:
                        yaml.dump(training_stats, f)
                    debug_print(f"保存训练统计: {stats_path}")
                except Exception as e:
                    print(f"保存模型失败: {e}")
                    debug_print(f"保存模型失败: {e}")
                    import traceback
                    debug_print(traceback.format_exc())
    
    except KeyboardInterrupt:
        print("\n\n训练被用户中断")
        debug_print("训练被用户中断")
    
    except Exception as e:
        print(f"\n\n训练过程中出现错误: {e}")
        debug_print(f"训练错误: {e}")
        import traceback
        traceback.print_exc()
        debug_print(traceback.format_exc())
    
    # 训练结束，保存最终模型和统计
    try:
        final_checkpoint_path = os.path.join(models_dir, "final_checkpoint")
        trainer.save(final_checkpoint_path)
        
        final_stats_path = os.path.join(logs_dir, "final_training_stats.yaml")
        with open(final_stats_path, 'w') as f:
            yaml.dump(training_stats, f)
        
        total_time = time.time() - total_start_time
        print(f"\n\n训练完成，总用时: {total_time:.2f} 秒")
        print(f"总回合数: {episode_count}, 总更新次数: {update_count}")
        print(f"最终模型已保存至: {final_checkpoint_path}")
        print(f"训练统计已保存至: {final_stats_path}")
        debug_print("训练完成并保存最终结果")
    except Exception as e:
        print(f"保存最终模型和统计失败: {e}")
        debug_print(f"保存最终结果失败: {e}")
    
    return trainer

def evaluate_mappo(trainer, config, save_dir=None, debug_mode=False):
    """评估MAPPO训练的智能体"""
    print("\n" + "="*60)
    print("         评估MAPPO智能体")
    print("="*60)
    
    # 设置调试日志
    debug_log_file = None
    if debug_mode and save_dir:
        debug_log_file = os.path.join(save_dir, "eval_debug.log")
        
    def debug_print(message):
        if debug_mode:
            timestamp = datetime.now().strftime("%H:%M:%S")
            full_message = f"[{timestamp}] [EVAL] {message}"
            print(full_message)
            if debug_log_file:
                with open(debug_log_file, "a") as f:
                    f.write(f"{full_message}\n")
    
    # 评估参数
    eval_config = config.get("eval_config", {})
    num_episodes = eval_config.get("num_episodes", 20)
    deterministic = eval_config.get("deterministic", True)
    render = eval_config.get("render", False)
    
    debug_print(f"开始评估, 回合数: {num_episodes}, 确定性: {deterministic}")
    
    # 执行评估
    try:
        eval_stats = trainer.eval(num_episodes=num_episodes, deterministic=deterministic)
        
        # 打印评估结果
        print("\n评估结果:")
        
        # 计算每个智能体的平均、最小、最大奖励
        agent_stats = {}
        for agent_id in trainer.agent_ids:
            if agent_id in eval_stats["eval_rewards"]:
                rewards = eval_stats["eval_rewards"][agent_id]
                agent_stats[agent_id] = {
                    "mean": np.mean(rewards),
                    "min": np.min(rewards),
                    "max": np.max(rewards),
                    "std": np.std(rewards),
                    "count": len(rewards)
                }
        
        # 打印统计信息
        print("\n每个智能体的奖励统计:")
        for agent_id, stats in agent_stats.items():
            print(f"智能体 {agent_id}:")
            print(f"  平均奖励: {stats['mean']:.2f}")
            print(f"  最小奖励: {stats['min']:.2f}")
            print(f"  最大奖励: {stats['max']:.2f}")
            print(f"  标准差: {stats['std']:.2f}")
        
        # 计算总体平均奖励
        global_mean_reward = sum(stats["mean"] for stats in agent_stats.values())
        print(f"\n总体平均奖励: {global_mean_reward:.2f}")
        
        # 打印回合长度统计
        lengths = eval_stats["eval_lengths"]
        if lengths:
            print(f"回合长度 - 平均: {np.mean(lengths):.1f}, 最小: {np.min(lengths)}, 最大: {np.max(lengths)}")
        
        # 保存评估结果
        if save_dir:
            eval_results_path = os.path.join(save_dir, "mappo_eval_results.yaml")
            with open(eval_results_path, 'w') as f:
                yaml.dump(eval_stats, f)
            print(f"评估结果已保存至: {eval_results_path}")
            debug_print(f"评估完成并保存结果: {eval_results_path}")
    except Exception as e:
        print(f"评估过程中出现错误: {e}")
        debug_print(f"评估错误: {e}")
        import traceback
        traceback.print_exc()
        debug_print(traceback.format_exc())
        return None
    
    return eval_stats

def evaluate_separate_agents(agents, env, config, save_dir=None, debug_mode=False):
    """评估单独训练的智能体"""
    print("\n" + "="*60)
    print("         评估单独训练的智能体")
    print("="*60)
    
    # 设置调试日志
    debug_log_file = None
    if debug_mode and save_dir:
        debug_log_file = os.path.join(save_dir, "separate_eval_debug.log")
        
    def debug_print(message):
        if debug_mode:
            timestamp = datetime.now().strftime("%H:%M:%S")
            full_message = f"[{timestamp}] [EVAL] {message}"
            print(full_message)
            if debug_log_file:
                with open(debug_log_file, "a") as f:
                    f.write(f"{full_message}\n")
    
    # 评估参数
    eval_config = config.get("eval_config", {})
    num_episodes = eval_config.get("num_episodes", 20)
    deterministic = eval_config.get("deterministic", True)
    steps_per_episode = eval_config.get("steps_per_episode", 1000)
    
    debug_print(f"开始评估, 回合数: {num_episodes}, 确定性: {deterministic}")
    
    # 评估结果
    eval_stats = {
        "eval_rewards": {},
        "eval_lengths": [],
    }
    
    for agent_id, agent in agents.items():
        print(f"\n评估智能体: {agent_id}")
        debug_print(f"开始评估智能体: {agent_id}")
        
        agent_rewards = []
        episode_lengths = []
        
        try:
            for ep in range(num_episodes):
                debug_print(f"开始评估回合 {ep+1}/{num_episodes}")
                
                # 重置LSTM状态（如果有）
                if agent_id == "memory_scheduler" and hasattr(agent, 'is_lstm_network') and agent.is_lstm_network:
                    agent.reset_lstm_state()
                    debug_print("重置LSTM状态")
                
                # 重置环境
                try:
                    state = env.reset(agent_type=agent_id)
                    debug_print("环境重置成功")
                except Exception as e:
                    print(f"环境重置失败: {e}")
                    debug_print(f"环境重置失败: {e}")
                    continue
                
                episode_reward = 0
                episode_length = 0
                done = False
                
                while not done and episode_length < steps_per_episode:
                    # 选择动作（确定性或随机）
                    try:
                        if deterministic:
                            with torch.no_grad():
                                state_tensor = torch.FloatTensor(state).unsqueeze(0).to(agent.device)
                                action_mean, _, _ = agent.model(state_tensor)
                                action = action_mean.cpu().numpy().flatten()
                        else:
                            action, _, _ = agent.select_action(state)
                        
                        # 执行动作
                        next_state, reward, done, info = env.step(action, agent_type=agent_id)
                        
                        # 更新状态
                        state = next_state
                        
                        # 更新统计
                        episode_reward += reward
                        episode_length += 1
                        
                        # 定期打印状态
                        if episode_length % 100 == 0:
                            debug_print(f"步数: {episode_length}, 当前奖励: {episode_reward:.2f}")
                    
                    except Exception as e:
                        print(f"评估步骤执行失败: {e}")
                        debug_print(f"评估步骤错误: {e}")
                        break
                
                # 记录统计
                agent_rewards.append(episode_reward)
                episode_lengths.append(episode_length)
                
                print(f"回合 {ep+1}/{num_episodes} - 奖励: {episode_reward:.2f}, 长度: {episode_length}")
                debug_print(f"回合 {ep+1} 完成, 奖励: {episode_reward:.2f}, 长度: {episode_length}")
            
            # 计算平均值
            if agent_rewards:
                avg_reward = np.mean(agent_rewards)
                min_reward = np.min(agent_rewards)
                max_reward = np.max(agent_rewards)
                std_reward = np.std(agent_rewards)
                
                avg_length = np.mean(episode_lengths) if episode_lengths else 0
                
                print(f"\n智能体 {agent_id} 评估统计:")
                print(f"  平均奖励: {avg_reward:.2f} [最小: {min_reward:.2f}, 最大: {max_reward:.2f}, 标准差: {std_reward:.2f}]")
                print(f"  平均长度: {avg_length:.1f}")
            
            # 记录结果
            eval_stats["eval_rewards"][agent_id] = agent_rewards
            eval_stats["eval_lengths"].extend(episode_lengths)
            
            debug_print(f"智能体 {agent_id} 评估完成")
        
        except Exception as e:
            print(f"评估智能体 {agent_id} 时出错: {e}")
            debug_print(f"评估智能体错误: {e}")
            import traceback
            debug_print(traceback.format_exc())
    
    # 保存评估结果
    if save_dir:
        try:
            eval_results_path = os.path.join(save_dir, "separate_agents_eval_results.yaml")
            with open(eval_results_path, 'w') as f:
                yaml.dump(eval_stats, f)
            print(f"\n评估结果已保存至: {eval_results_path}")
            debug_print(f"保存评估结果: {eval_results_path}")
        except Exception as e:
            print(f"保存评估结果失败: {e}")
            debug_print(f"保存评估结果失败: {e}")
    
    return eval_stats

def main():
    """主函数"""
    # 解析命令行参数
    args = parse_args()
    
    # 加载配置文件
    config = load_config(args.config)
    
    # 设置随机种子
    set_seed(args.seed or config.get("seed", 1))
    
    # 如果指定了检查点，更新配置
    if args.checkpoint:
        config["checkpoint"] = args.checkpoint
    
    # 创建保存目录
    save_dir, models_dir, logs_dir = create_save_dir(config)
    
    # 保存配置副本
    config_copy_path = os.path.join(save_dir, "config.yaml")
    with open(config_copy_path, 'w') as f:
        yaml.dump(config, f)
    
    # 更新配置中的评估和保存频率
    if "training" not in config:
        config["training"] = {}
    
    # 如果指定了命令行参数，更新配置
    if hasattr(args, "eval_freq") and args.eval_freq is not None:
        config["training"]["eval_interval"] = args.eval_freq
    if hasattr(args, "save_freq") and args.save_freq is not None:
        config["training"]["save_interval"] = args.save_freq
    
    # 打印配置信息
    print("\n" + "="*60)
    print("           内存管理智能体训练系统")
    print("="*60)
    print(f"配置文件: {args.config}")
    print(f"训练模式: {'联合训练 (MAPPO)' if args.mode == 'joint' else '单独训练 (PPO)'}")
    print(f"随机种子: {args.seed if args.seed else config.get('seed', '未设置')}")
    print(f"调试模式: {'启用' if args.debug else '禁用'}")
    
    if "training" in config:
        training_config = config["training"]
        print("\n训练配置:")
        print(f"  评估频率: 每 {training_config.get('eval_interval')} 回合")
        print(f"  保存频率: 每 {training_config.get('save_interval')} 回合")
    
    print(f"\n保存目录: {save_dir}")
    print("="*60 + "\n")
    
    # 根据模式选择训练或评估方法
    if args.eval:
        # 评估模式
        print("启动评估模式...")
        
        env_config = config.get("env_config", {})
        env = create_environment(env_config)
        
        if args.mode == "joint" or config.get("mode", "joint") == "joint":
            # 为MAPPO评估创建网络管理器和训练器
            device = torch.device("cuda" if torch.cuda.is_available() and config.get("use_cuda", True) else "cpu")
            network_manager = create_memory_management_networks(device=device)
            
            trainer_config = config.get("mappo_config", {})
            trainer = MAPPOTrainer(
                env=env,
                network_manager=network_manager,
                buffer_size=trainer_config.get("buffer_size", 2048),
                batch_size=trainer_config.get("batch_size", 64),
                use_centralized_critic=trainer_config.get("use_centralized_critic", True),
                device=device
            )
            
            # 加载检查点
            checkpoint_path = config.get("checkpoint")
            if checkpoint_path is not None:
                trainer.load(checkpoint_path)
                print(f"加载检查点: {checkpoint_path}")
                
                # 评估
                evaluate_mappo(trainer, config, save_dir, debug_mode=args.debug)
            else:
                print("错误: 未指定评估用检查点")
                sys.exit(1)
        else:
            # 为单独智能体评估创建智能体
            agent_configs = config.get("agent_configs", {})
            ppo_config = config.get("ppo_config", {})
            
            agents = {}
            for agent_id, agent_config in agent_configs.items():
                # 合并配置
                full_config = {**ppo_config}
                full_config.update(agent_config)
                
                # 创建智能体
                agent = PPO(
                    state_dim=full_config["state_dim"],
                    action_dim=full_config["action_dim"],
                    config=full_config
                )
                
                # 加载检查点
                checkpoint_path = config.get("checkpoint")
                if checkpoint_path is not None:
                    agent_checkpoint = f"{checkpoint_path}_{agent_id}.pt"
                    if os.path.exists(agent_checkpoint):
                        agent.load(agent_checkpoint)
                        print(f"加载智能体 {agent_id} 的检查点: {agent_checkpoint}")
                        agents[agent_id] = agent
                    else:
                        print(f"警告: 未找到智能体 {agent_id} 的检查点: {agent_checkpoint}")
            
            if agents:
                # 评估
                evaluate_separate_agents(agents, env, config, save_dir, debug_mode=args.debug)
            else:
                print("错误: 未加载有效的检查点进行评估")
                sys.exit(1)
    else:
        # 训练模式
        if args.mode == "joint" or config.get("mode", "joint") == "joint":
            # 联合训练所有智能体
            trainer = train_with_mappo(config, save_dir, models_dir, logs_dir, debug_mode=args.debug)
            
            # 训练结束后评估
            if trainer is not None:
                evaluate_mappo(trainer, config, save_dir, debug_mode=args.debug)
            else:
                print("训练失败，跳过评估")
        else:
            # 分别训练每个智能体
            agents = train_separate_agents(config, save_dir, models_dir, logs_dir, debug_mode=args.debug)
            
            # 如果有成功训练的智能体，进行评估
            if agents:
                # 创建环境
                env_config = config.get("env_config", {})
                env = create_environment(env_config)
                
                # 训练结束后评估
                evaluate_separate_agents(agents, env, config, save_dir, debug_mode=args.debug)
            else:
                print("所有智能体训练失败，跳过评估")

if __name__ == "__main__":
    main()
