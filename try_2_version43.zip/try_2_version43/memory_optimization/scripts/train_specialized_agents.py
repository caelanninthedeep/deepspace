#!/usr/bin/env python3

"""
训练专门化内存管理智能体脚本

这个脚本用于训练专门化的内存管理智能体，包括：
1. 页面缓存智能体（Page Cache Agent）
2. 内存回收智能体（Memory Reclaim Agent）
3. 内存调度智能体（Memory Scheduler Agent）

支持使用 MAPPO 进行联合训练或使用 PPO 分别训练每个智能体
"""

import os
import sys
import time
import argparse
import yaml
import numpy as np
import torch
from datetime import datetime
from collections import defaultdict
from .reward_tracker import RewardTracker

# train.py - 在训练开始前初始化
reward_tracker = RewardTracker(save_dir='./memory_rl_logs')

# 导入项目组件
from ..algorithms.network import create_memory_management_networks
from ..algorithms.buffer import MultiAgentRolloutBuffer
from ..algorithms.mappo import MAPPO, MAPPOTrainer
from ..algorithms.ppo import PPO

def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description="Train specialized memory management agents")
    parser.add_argument("--config", type=str, required=True, help="Path to config file")
    parser.add_argument("--checkpoint", type=str, default=None, help="Path to checkpoint to resume training")
    parser.add_argument("--mode", type=str, default="joint", choices=["joint", "separate"], 
                       help="Training mode: joint (MAPPO) or separate (individual PPO)")
    parser.add_argument("--seed", type=int, default=None, help="Random seed")
    parser.add_argument("--eval", action="store_true", help="Evaluate instead of train")
    return parser.parse_args()

def load_config(config_path):
    """加载配置文件"""
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    return config

def set_seed(seed):
    """设置随机种子"""
    if seed is None:
        return
        
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    # 设置确定性
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def create_save_dir(config):
    """创建保存目录"""
    # 创建基础目录
    base_dir = config.get("save_dir", "saved_models")
    os.makedirs(base_dir, exist_ok=True)
    
    # 创建特定实验目录
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    exp_name = config.get("exp_name", "memory_management")
    save_dir = os.path.join(base_dir, f"{exp_name}_{timestamp}")
    os.makedirs(save_dir, exist_ok=True)
    
    # 创建模型和日志子目录
    models_dir = os.path.join(save_dir, "models")
    logs_dir = os.path.join(save_dir, "logs")
    os.makedirs(models_dir, exist_ok=True)
    os.makedirs(logs_dir, exist_ok=True)
    
    return save_dir, models_dir, logs_dir

def create_environment(env_config):
    """创建环境实例"""
    try:
        # 尝试导入环境
        from ..environment.mem_env import MultiAgentMemoryEnv
        
        # 创建环境实例
        env = MultiAgentMemoryEnv(**env_config)
        return env
    except ImportError as e:
        print(f"Error importing environment: {e}")
        print("Please make sure the environment module is available in your PYTHONPATH")
        sys.exit(1)

def train_with_mappo(config, save_dir, models_dir, logs_dir):
    """使用MAPPO联合训练所有智能体"""
    print("Starting joint training with MAPPO...")
    
    # 设置设备
    device = torch.device("cuda" if torch.cuda.is_available() and config.get("use_cuda", True) else "cpu")
    print(f"Using device: {device}")
    
    # 创建环境
    env_config = config.get("env_config", {})
    env = create_environment(env_config)
    
    # 创建网络管理器
    network_manager = create_memory_management_networks(device=device)
    
    # 创建MAPPO训练器
    trainer_config = config.get("mappo_config", {})
    trainer = MAPPOTrainer(
        env=env,
        network_manager=network_manager,
        buffer_size=trainer_config.get("buffer_size", 2048),
        batch_size=trainer_config.get("batch_size", 64),
        lr_actor=trainer_config.get("lr_actor", 3e-4),
        lr_critic=trainer_config.get("lr_critic", 1e-3),
        gamma=trainer_config.get("gamma", 0.99),
        gae_lambda=trainer_config.get("gae_lambda", 0.95),
        clip_param=trainer_config.get("clip_param", 0.2),
        value_clip_param=trainer_config.get("value_clip_param", 0.2),
        entropy_coef=trainer_config.get("entropy_coef", 0.01),
        value_loss_coef=trainer_config.get("value_loss_coef", 0.5),
        max_grad_norm=trainer_config.get("max_grad_norm", 0.5),
        use_clipped_value_loss=trainer_config.get("use_clipped_value_loss", True),
        use_centralized_critic=trainer_config.get("use_centralized_critic", True),
        device=device
    )
    
    # 加载检查点（如果有）
    checkpoint_path = config.get("checkpoint", None)
    if checkpoint_path is not None and os.path.exists(checkpoint_path):
        trainer.load(checkpoint_path)
        print(f"Loaded checkpoint from {checkpoint_path}")
    
    # 训练参数
    training_config = config.get("training", {})
    num_episodes = training_config.get("num_episodes", 1000)
    steps_per_update = training_config.get("steps_per_update", 2048)
    num_updates = training_config.get("num_updates", 4)
    k_epochs = training_config.get("k_epochs", 10)
    eval_interval = training_config.get("eval_interval", 100)
    save_interval = training_config.get("save_interval", 100)
    log_interval = training_config.get("log_interval", 10)
    
    # 训练循环
    total_start_time = time.time()
    episode_count = 0
    update_count = 0
    
    # 保存训练统计
    training_stats = {
        "episode_rewards": defaultdict(list),
        "episode_lengths": [],
        "eval_rewards": defaultdict(list),
        "eval_lengths": [],
        "actor_losses": defaultdict(list),
        "critic_losses": defaultdict(list),
        "timestamps": []
    }
    
    print(f"Starting training for {num_episodes} episodes...")
    print(f"Steps per update: {steps_per_update}, Updates per collection: {num_updates}")
    print(f"K epochs: {k_epochs}, Batch size: {trainer_config.get('batch_size', 64)}")
    print("-" * 60)
    
    while episode_count < num_episodes:
        # 收集轨迹
        collect_start_time = time.time()
        episode_rewards, episode_lengths = trainer.collect_trajectories(num_steps=steps_per_update)
        collect_time = time.time() - collect_start_time
        
        # 执行多次策略更新
        update_start_time = time.time()
        for _ in range(num_updates):
            update_stats = trainer.mappo.update(k_epochs=k_epochs, batch_size=trainer_config.get("batch_size", 64))
            update_count += 1
            
            # 记录训练统计
            for agent_id in trainer.agent_ids:
                if agent_id in update_stats["actor_losses"]:
                    training_stats["actor_losses"][agent_id].extend(update_stats["actor_losses"][agent_id])
                if agent_id in update_stats["critic_losses"]:
                    training_stats["critic_losses"][agent_id].extend(update_stats["critic_losses"][agent_id])
        update_time = time.time() - update_start_time
        
        # 更新episode计数
        episode_count = len(trainer.episode_lengths)
        
        # 记录训练统计
        for agent_id in trainer.agent_ids:
            training_stats["episode_rewards"][agent_id].extend(trainer.episode_rewards[agent_id][-len(episode_lengths):])
        training_stats["episode_lengths"].extend(episode_lengths)
        training_stats["timestamps"].append(time.time() - total_start_time)
        
        # 添加奖励追踪记录
        for i, length in enumerate(episode_lengths):
            # 获取最近一次episode的相关信息
            last_episode_idx = len(training_stats["episode_lengths"]) - i - 1
            
            # 获取每个智能体的奖励
            rewards_dict = {agent_id: training_stats["episode_rewards"][agent_id][last_episode_idx]
                            for agent_id in trainer.agent_ids}
            
            # 计算全局奖励（所有智能体奖励总和）
            global_reward = sum(rewards_dict.values())
            
            # 获取环境信息（如果可用）
            workload_type = getattr(env, 'current_workload_type', 'unknown')
            difficulty = getattr(env, 'current_difficulty', 'unknown')
            runtime = getattr(env, 'last_workload_runtime', 0.0)
            prev_runtime = getattr(env, 'previous_workload_runtime', None)
            
            # 记录到奖励追踪器
            reward_tracker.add_record(
                episode=last_episode_idx + 1,  # episode从1开始
                rewards_dict=rewards_dict,
                global_reward=global_reward,
                runtime=runtime,
                prev_runtime=prev_runtime,
                workload_type=workload_type,
                difficulty=difficulty
            )
        
        # 定期打印摘要
        if episode_count % 50 == 0:
            reward_tracker.print_summary(episode_count)
        
        # 检查是否收敛
        if episode_count % 200 == 0 and episode_count >= 400:
            converged, change = reward_tracker.check_convergence()
            if converged:
                print(f"\nModel appears to have converged at episode {episode_count}!")
                print(f"Relative change in rewards: {change:.6f}")
                print("Consider stopping training or reducing learning rate.")
        
        # 打印训练信息
        if episode_count % log_interval == 0:
            avg_rewards = {agent_id: np.mean(trainer.episode_rewards[agent_id][-10:]) 
                          for agent_id in trainer.agent_ids}
            avg_length = np.mean(trainer.episode_lengths[-10:])
            
            print(f"Episode: {episode_count}/{num_episodes} | Updates: {update_count}")
            print(f"Collect time: {collect_time:.2f}s | Update time: {update_time:.2f}s")
            print(f"Avg episode length: {avg_length:.1f} steps")
            for agent_id, avg_reward in avg_rewards.items():
                print(f"Agent {agent_id} avg reward: {avg_reward:.2f}")
            print("-" * 40)
        
        # 定期评估
        if episode_count % eval_interval == 0:
            print("Evaluating current policy...")
            eval_stats = trainer.eval(num_episodes=10)
            
            # 记录评估统计
            for agent_id in trainer.agent_ids:
                if agent_id in eval_stats["eval_rewards"]:
                    training_stats["eval_rewards"][agent_id].extend(eval_stats["eval_rewards"][agent_id])
            training_stats["eval_lengths"].extend(eval_stats["eval_lengths"])
            
            # 保存评估结果
            eval_results_path = os.path.join(logs_dir, f"eval_results_ep{episode_count}.yaml")
            with open(eval_results_path, 'w') as f:
                yaml.dump(eval_stats, f)
        
        # 定期保存模型
        if episode_count % save_interval == 0:
            checkpoint_path = os.path.join(models_dir, f"checkpoint_ep{episode_count}")
            trainer.save(checkpoint_path)
            print(f"Saved checkpoint to {checkpoint_path}")
            
            # 保存训练统计
            stats_path = os.path.join(logs_dir, "training_stats.yaml")
            with open(stats_path, 'w') as f:
                yaml.dump(training_stats, f)
    
    # 训练结束，保存最终模型和统计
    final_checkpoint_path = os.path.join(models_dir, "final_checkpoint")
    trainer.save(final_checkpoint_path)
    
    final_stats_path = os.path.join(logs_dir, "final_training_stats.yaml")
    with open(final_stats_path, 'w') as f:
        yaml.dump(training_stats, f)
    
    total_time = time.time() - total_start_time
    print(f"Training completed in {total_time:.2f} seconds")
    print(f"Total episodes: {episode_count}, Total updates: {update_count}")
    print(f"Final models saved to {final_checkpoint_path}")
    print(f"Training statistics saved to {final_stats_path}")
    
    return trainer

def train_separate_agents(config, save_dir, models_dir, logs_dir):
    """分别训练每个智能体"""
    print("Starting separate training for each agent...")
    
    # 设置设备
    device = torch.device("cuda" if torch.cuda.is_available() and config.get("use_cuda", True) else "cpu")
    print(f"Using device: {device}")
    
    # 获取智能体配置
    agent_configs = config.get("agent_configs", {
        "page_cache": {
            "network_type": "page_cache",
            "state_dim": 32,
            "action_dim": 3
        },
        "memory_reclaim": {
            "network_type": "memory_reclaim",
            "state_dim": 32,
            "action_dim": 2
        },
        "memory_scheduler": {
            "network_type": "memory_scheduler",
            "state_dim": 32,
            "action_dim": 2,
            "use_lstm": True
        }
    })
    
    # PPO通用配置
    ppo_config = config.get("ppo_config", {})
    
    # 训练参数
    training_config = config.get("training", {})
    num_episodes_per_agent = training_config.get("num_episodes_per_agent", 500)
    steps_per_episode = training_config.get("steps_per_episode", 1000)
    
    # 创建环境
    env_config = config.get("env_config", {})
    env = create_environment(env_config)
    
    # 为每个智能体分别训练
    agents = {}
    for agent_id, agent_config in agent_configs.items():
        print(f"\n{'='*40}")
        print(f"Training agent: {agent_id}")
        print(f"{'='*40}\n")
        
        # 合并配置
        full_config = {**ppo_config}
        full_config.update(agent_config)
        full_config["save_dir"] = os.path.join(models_dir, agent_id)
        full_config["log_dir"] = os.path.join(logs_dir, agent_id)
        
        # 确保目录存在
        os.makedirs(full_config["save_dir"], exist_ok=True)
        os.makedirs(full_config["log_dir"], exist_ok=True)
        
        # 创建PPO智能体
        agent = PPO(
            state_dim=full_config["state_dim"],
            action_dim=full_config["action_dim"],
            config=full_config
        )
        
        # 加载检查点（如果有）
        checkpoint_path = config.get("checkpoint", None)
        if checkpoint_path is not None:
            agent_checkpoint = f"{checkpoint_path}_{agent_id}.pt"
            if os.path.exists(agent_checkpoint):
                agent.load(agent_checkpoint)
                print(f"Loaded checkpoint for {agent_id} from {agent_checkpoint}")
        
        # 训练智能体
        print(f"Training {agent_id} for {num_episodes_per_agent} episodes...")
        
        # 训练循环
        total_steps = 0
        total_episodes = 0
        episode_rewards = []
        episode_lengths = []
        start_time = time.time()
        
        while total_episodes < num_episodes_per_agent:
            # 重置环境和状态
            if agent_id == "memory_scheduler" and agent.is_lstm_network:
                agent.reset_lstm_state()
            
            state = env.reset(agent_type=agent_id)  # 假设环境支持指定智能体类型
            
            # 一个episode的轨迹
            episode_reward = 0
            episode_length = 0
            done = False
            
            while not done and episode_length < steps_per_episode:
                # 选择动作
                action, log_prob, value = agent.select_action(state)
                
                # 执行动作
                next_state, reward, done, info = env.step(action, agent_type=agent_id)
                
                # 存储经验
                agent.store(state, action, reward, done, next_state, value, log_prob)
                
                # 更新状态
                state = next_state
                
                # 更新统计
                episode_reward += reward
                episode_length += 1
                total_steps += 1
                
                # 如果缓冲区满，则更新策略
                if agent.buffer.size >= agent.config["buffer_size"]:
                    update_info = agent.update()
                    
                    # 可能的动作标准差衰减
                    if total_episodes > 0 and total_episodes % 20 == 0:
                        agent.decay_action_std(decay_rate=0.05)
            
            # 记录统计
            episode_rewards.append(episode_reward)
            episode_lengths.append(episode_length)
            total_episodes += 1
            
            # 添加奖励追踪记录
            rewards_dict = {agent_id: episode_reward}  # 只有一个智能体
            
            # 获取环境信息（如果可用）
            workload_type = getattr(env, 'current_workload_type', 'unknown')
            difficulty = getattr(env, 'current_difficulty', 'unknown')
            runtime = getattr(env, 'last_workload_runtime', 0.0)
            prev_runtime = getattr(env, 'previous_workload_runtime', None)
            
            # 记录到奖励追踪器
            reward_tracker.add_record(
                episode=total_episodes,
                rewards_dict=rewards_dict,
                global_reward=episode_reward,  # 单智能体情况下，全局奖励就是智能体奖励
                runtime=runtime,
                prev_runtime=prev_runtime,
                workload_type=workload_type,
                difficulty=difficulty
            )
            
            # 定期打印摘要
            if total_episodes % 50 == 0:
                reward_tracker.print_summary(total_episodes)
            
            # 检查是否收敛
            if total_episodes % 200 == 0 and total_episodes >= 400:
                converged, change = reward_tracker.check_convergence()
                if converged:
                    print(f"\nModel appears to have converged at episode {total_episodes}!")
                    print(f"Relative change in rewards: {change:.6f}")
                    print("Consider stopping training or reducing learning rate.")
            
            # 打印进度
            if total_episodes % 10 == 0:
                elapsed_time = time.time() - start_time
                avg_reward = np.mean(episode_rewards[-10:])
                avg_length = np.mean(episode_lengths[-10:])
                
                print(f"Episode: {total_episodes}/{num_episodes_per_agent} | Steps: {total_steps}")
                print(f"Average reward (last 10): {avg_reward:.2f}")
                print(f"Average length (last 10): {avg_length:.1f}")
                print(f"Elapsed time: {elapsed_time:.2f}s")
                print("-" * 40)
            
            # 定期保存模型
            if total_episodes % 50 == 0:
                save_path = os.path.join(full_config["save_dir"], f"checkpoint_ep{total_episodes}")
                agent.save(save_path)
                print(f"Saved checkpoint to {save_path}.pt")
        
        # 保存最终模型
        final_path = os.path.join(full_config["save_dir"], "final_model")
        agent.save(final_path)
        
        # 保存训练统计
        agent_stats = {
            "episode_rewards": episode_rewards,
            "episode_lengths": episode_lengths,
            "total_steps": total_steps,
            "training_time": time.time() - start_time
        }
        
        stats_path = os.path.join(full_config["log_dir"], "training_stats.yaml")
        with open(stats_path, 'w') as f:
            yaml.dump(agent_stats, f)
        
        print(f"\nFinished training agent {agent_id}")
        print(f"Final model saved to {final_path}.pt")
        print(f"Training statistics saved to {stats_path}")
        
        # 保存智能体
        agents[agent_id] = agent
    
    print("\nSeparate training completed for all agents")
    
    return agents

def evaluate_mappo(trainer, config, save_dir=None):
    """评估MAPPO训练的智能体"""
    print("\nEvaluating MAPPO agents...")
    
    # 评估参数
    eval_config = config.get("eval_config", {})
    num_episodes = eval_config.get("num_episodes", 20)
    deterministic = eval_config.get("deterministic", True)
    render = eval_config.get("render", False)
    
    # 执行评估
    eval_stats = trainer.eval(num_episodes=num_episodes, deterministic=deterministic)
    
    # 保存评估结果
    if save_dir:
        eval_results_path = os.path.join(save_dir, "mappo_eval_results.yaml")
        with open(eval_results_path, 'w') as f:
            yaml.dump(eval_stats, f)
        print(f"Evaluation results saved to {eval_results_path}")
    
    return eval_stats

def evaluate_separate_agents(agents, env, config, save_dir=None):
    """评估单独训练的智能体"""
    print("\nEvaluating separately trained agents...")
    
    # 评估参数
    eval_config = config.get("eval_config", {})
    num_episodes = eval_config.get("num_episodes", 20)
    deterministic = eval_config.get("deterministic", True)
    steps_per_episode = eval_config.get("steps_per_episode", 1000)
    
    # 评估结果
    eval_stats = {
        "eval_rewards": {},
        "eval_lengths": [],
    }
    
    for agent_id, agent in agents.items():
        print(f"Evaluating agent: {agent_id}")
        
        agent_rewards = []
        episode_lengths = []
        
        for ep in range(num_episodes):
            # 重置LSTM状态（如果有）
            if agent_id == "memory_scheduler" and agent.is_lstm_network:
                agent.reset_lstm_state()
            
            # 重置环境
            state = env.reset(agent_type=agent_id)
            
            episode_reward = 0
            episode_length = 0
            done = False
            
            while not done and episode_length < steps_per_episode:
                # 选择动作（确定性或随机）
                if deterministic:
                    with torch.no_grad():
                        state_tensor = torch.FloatTensor(state).unsqueeze(0).to(agent.device)
                        action_mean, _, _ = agent.model(state_tensor)
                        action = action_mean.cpu().numpy().flatten()
                else:
                    action, _, _ = agent.select_action(state)
                
                # 执行动作
                next_state, reward, done, info = env.step(action, agent_type=agent_id)
                
                # 更新状态
                state = next_state
                
                # 更新统计
                episode_reward += reward
                episode_length += 1
            
            # 记录统计
            agent_rewards.append(episode_reward)
            episode_lengths.append(episode_length)
            
            print(f"Episode {ep+1}/{num_episodes} - Reward: {episode_reward:.2f}, Length: {episode_length}")
        
        # 计算平均值
        avg_reward = np.mean(agent_rewards)
        avg_length = np.mean(episode_lengths)
        
        print(f"Agent {agent_id} - Avg Reward: {avg_reward:.2f}, Avg Length: {avg_length:.1f}")
        
        # 记录结果
        eval_stats["eval_rewards"][agent_id] = agent_rewards
        eval_stats["eval_lengths"].extend(episode_lengths)
    
    # 保存评估结果
    if save_dir:
        eval_results_path = os.path.join(save_dir, "separate_agents_eval_results.yaml")
        with open(eval_results_path, 'w') as f:
            yaml.dump(eval_stats, f)
        print(f"Evaluation results saved to {eval_results_path}")
    
    return eval_stats

def main():
    """主函数"""
    # 解析命令行参数
    args = parse_args()
    
    # 加载配置文件
    config = load_config(args.config)
    
    # 设置随机种子
    set_seed(args.seed or config.get("seed", 1))
    
    # 如果指定了检查点，更新配置
    if args.checkpoint:
        config["checkpoint"] = args.checkpoint
    
    # 创建保存目录
    save_dir, models_dir, logs_dir = create_save_dir(config)
    
    # 保存配置副本
    config_copy_path = os.path.join(save_dir, "config.yaml")
    with open(config_copy_path, 'w') as f:
        yaml.dump(config, f)
    
    # 根据模式选择训练或评估方法
    if args.eval:
        # 评估模式
        env_config = config.get("env_config", {})
        env = create_environment(env_config)
        
        if args.mode == "joint" or config.get("mode", "joint") == "joint":
            # 为MAPPO评估创建网络管理器和训练器
            device = torch.device("cuda" if torch.cuda.is_available() and config.get("use_cuda", True) else "cpu")
            network_manager = create_memory_management_networks(device=device)
            
            trainer_config = config.get("mappo_config", {})
            trainer = MAPPOTrainer(
                env=env,
                network_manager=network_manager,
                buffer_size=trainer_config.get("buffer_size", 2048),
                batch_size=trainer_config.get("batch_size", 64),
                use_centralized_critic=trainer_config.get("use_centralized_critic", True),
                device=device
            )
            
            # 加载检查点
            checkpoint_path = config.get("checkpoint")
            if checkpoint_path is not None:
                trainer.load(checkpoint_path)
                print(f"Loaded checkpoint from {checkpoint_path}")
                
                # 评估
                evaluate_mappo(trainer, config, save_dir)
            else:
                print("Error: No checkpoint specified for evaluation")
                sys.exit(1)
        else:
            # 为单独智能体评估创建智能体
            agent_configs = config.get("agent_configs", {})
            ppo_config = config.get("ppo_config", {})
            
            agents = {}
            for agent_id, agent_config in agent_configs.items():
                # 合并配置
                full_config = {**ppo_config}
                full_config.update(agent_config)
                
                # 创建智能体
                agent = PPO(
                    state_dim=full_config["state_dim"],
                    action_dim=full_config["action_dim"],
                    config=full_config
                )
                
                # 加载检查点
                checkpoint_path = config.get("checkpoint")
                if checkpoint_path is not None:
                    agent_checkpoint = f"{checkpoint_path}_{agent_id}.pt"
                    if os.path.exists(agent_checkpoint):
                        agent.load(agent_checkpoint)
                        print(f"Loaded checkpoint for {agent_id} from {agent_checkpoint}")
                        agents[agent_id] = agent
                    else:
                        print(f"Warning: Checkpoint for {agent_id} not found at {agent_checkpoint}")
            
            if agents:
                # 评估
                evaluate_separate_agents(agents, env, config, save_dir)
            else:
                print("Error: No valid checkpoints loaded for evaluation")
                sys.exit(1)
    else:
        # 训练模式
        if args.mode == "joint" or config.get("mode", "joint") == "joint":
            # 联合训练所有智能体
            trainer = train_with_mappo(config, save_dir, models_dir, logs_dir)
            
            # 训练结束后评估
            evaluate_mappo(trainer, config, save_dir)
        else:
            # 分别训练每个智能体
            agents = train_separate_agents(config, save_dir, models_dir, logs_dir)
            
            # 创建环境
            env_config = config.get("env_config", {})
            env = create_environment(env_config)
            
            # 训练结束后评估
            evaluate_separate_agents(agents, env, config, save_dir)

if __name__ == "__main__":
    main()
