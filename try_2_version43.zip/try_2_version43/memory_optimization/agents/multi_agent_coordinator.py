"""
多智能体协调器 - 协调三个专门化内存智能体
"""

import torch
import torch.nn as nn
import numpy as np
from typing import Dict, List, Any, Tuple

class MemoryAgentCoordinator:
    """
    多智能体协调器 - 协调页面缓存、内存回收和内存调度智能体
    """
    def __init__(self, page_cache_agent, memory_reclaim_agent, memory_scheduler_agent, device=None):
        """
        初始化多智能体协调器
        
        Args:
            page_cache_agent: 页面缓存智能体
            memory_reclaim_agent: 内存回收智能体
            memory_scheduler_agent: 内存调度智能体
            device: 计算设备
        """
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # 保存各个智能体
        self.page_cache_agent = page_cache_agent
        self.memory_reclaim_agent = memory_reclaim_agent
        self.memory_scheduler_agent = memory_scheduler_agent
        
        # 智能体映射
        self.agents = {
            "page_cache": page_cache_agent,
            "memory_reclaim": memory_reclaim_agent,
            "memory_scheduler": memory_scheduler_agent
        }
        
        # 参数映射
        self.agent_params = {
            "page_cache": ["vfs_cache_pressure", "dirty_ratio", "dirty_background_ratio"],
            "memory_reclaim": ["swappiness", "min_free_kbytes"],
            "memory_scheduler": ["watermark_scale_factor", "compaction_proactiveness"]
        }
        
        # 冲突检测矩阵 - 记录哪些参数间可能冲突
        self.conflict_matrix = {
            # 缓存压力和swap倾向度可能存在冲突
            ("vfs_cache_pressure", "swappiness"): self._resolve_cache_swap_conflict,
            
            # 脏页比例和最小可用内存可能存在冲突
            ("dirty_ratio", "min_free_kbytes"): self._resolve_dirty_minfree_conflict,
            
            # 水位线因子和最小可用内存可能存在冲突
            ("watermark_scale_factor", "min_free_kbytes"): self._resolve_watermark_minfree_conflict,
            
            # 脏页比例和水位线因子可能存在冲突
            ("dirty_background_ratio", "watermark_scale_factor"): self._resolve_dirty_bg_watermark_conflict
        }
        
        # 最近的系统状态
        self.last_system_state = None
    
    def get_agent_actions(self, observations: Dict[str, np.ndarray], deterministic=False) -> Tuple[Dict[str, np.ndarray], Dict[str, float], Dict[str, Dict[str, Any]]]:
        """
        获取所有智能体的动作
        
        Args:
            observations: 字典，键为智能体ID，值为观察向量
            deterministic: 是否使用确定性策略
            
        Returns:
            actions_dict: 智能体动作字典
            values_dict: 智能体价值估计字典
            analysis_dict: 智能体分析结果字典
        """
        actions_dict = {}
        log_probs_dict = {}
        entropies_dict = {}
        values_dict = {}
        analysis_dict = {}
        
        # 保存系统状态用于冲突检测
        if "page_cache" in observations:
            self.last_system_state = observations["page_cache"]
        
        # 获取每个智能体的动作
        for agent_id, agent in self.agents.items():
            if agent_id in observations:
                observation = observations[agent_id]
                
                # 重置内存调度智能体的隐藏状态（如果是新的episode）
                if agent_id == "memory_scheduler" and hasattr(agent, 'reset_hidden'):
                    agent.reset_hidden()
                
                # 获取动作
                if agent_id == "page_cache":
                    action, log_prob, entropy, value = agent.get_action(observation, deterministic)
                    analysis = agent.cache_analysis(observation)
                elif agent_id == "memory_reclaim":
                    action, log_prob, entropy, value = agent.get_action(observation, deterministic)
                    analysis = agent.reclaim_analysis(observation)
                elif agent_id == "memory_scheduler":
                    action, log_prob, entropy, value = agent.get_action(observation, deterministic)
                    analysis = agent.scheduler_analysis(observation)
                else:
                    continue
                
                actions_dict[agent_id] = action.cpu().numpy()
                log_probs_dict[agent_id] = log_prob.cpu().item() if isinstance(log_prob, torch.Tensor) else log_prob
                entropies_dict[agent_id] = entropy.cpu().item() if isinstance(entropy, torch.Tensor) else entropy
                values_dict[agent_id] = value.cpu().item() if isinstance(value, torch.Tensor) else value
                analysis_dict[agent_id] = analysis
        
        # 检查并解决参数冲突
        actions_dict = self._resolve_conflicts(actions_dict, analysis_dict)
        
        return actions_dict, values_dict, analysis_dict
    
    def _resolve_conflicts(self, actions_dict: Dict[str, np.ndarray], analysis_dict: Dict[str, Dict[str, Any]]) -> Dict[str, np.ndarray]:
        """
        检查并解决智能体间的参数冲突
        
        Args:
            actions_dict: 智能体动作字典
            analysis_dict: 智能体分析结果字典
            
        Returns:
            Dict[str, np.ndarray]: 解决冲突后的动作字典
        """
        # 将动作转换为参数空间
        param_actions = self._actions_to_params(actions_dict)
        
        # 检查冲突并解决
        for (param1, param2), resolver in self.conflict_matrix.items():
            # 确保两个参数都在当前动作中
            if param1 in param_actions and param2 in param_actions:
                # 应用冲突解决器
                param_actions = resolver(param_actions, analysis_dict, self.last_system_state)
        
        # 将解决冲突后的参数转换回智能体动作空间
        resolved_actions = self._params_to_actions(param_actions, actions_dict)
        
        return resolved_actions
    
    def _actions_to_params(self, actions_dict: Dict[str, np.ndarray]) -> Dict[str, float]:
        """
        将智能体动作转换为参数值
        
        Args:
            actions_dict: 智能体动作字典
            
        Returns:
            Dict[str, float]: 参数值字典
        """
        param_actions = {}
        
        for agent_id, action in actions_dict.items():
            if agent_id in self.agent_params:
                params = self.agent_params[agent_id]
                for i, param in enumerate(params):
                    if i < len(action):
                        # 将[-1, 1]范围的动作转换为实际参数值
                        # 这里只是一个示例，实际转换需要根据参数的真实范围调整
                        if param == "vfs_cache_pressure":
                            # 0-500范围
                            param_actions[param] = int((action[i] + 1) / 2 * 500)
                        elif param == "dirty_ratio":
                            # 1-60范围
                            param_actions[param] = int((action[i] + 1) / 2 * 59 + 1)
                        elif param == "dirty_background_ratio":
                            # 1-50范围
                            param_actions[param] = int((action[i] + 1) / 2 * 49 + 1)
                        elif param == "swappiness":
                            # 0-100范围
                            param_actions[param] = int((action[i] + 1) / 2 * 100)
                        elif param == "min_free_kbytes":
                            # 1024-1048576范围 (1MB-1GB)
                            param_actions[param] = int((action[i] + 1) / 2 * (1048576 - 1024) + 1024)
                        elif param == "watermark_scale_factor":
                            # 10-1000范围
                            param_actions[param] = int((action[i] + 1) / 2 * 990 + 10)
                        elif param == "compaction_proactiveness":
                            # 0-100范围
                            param_actions[param] = int((action[i] + 1) / 2 * 100)
        
        return param_actions
    
    def _params_to_actions(self, param_actions: Dict[str, float], original_actions: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
        """
        将参数值转换回智能体动作
        
        Args:
            param_actions: 参数值字典
            original_actions: 原始智能体动作字典
            
        Returns:
            Dict[str, np.ndarray]: 更新后的智能体动作字典
        """
        new_actions = {}
        
        for agent_id, params in self.agent_params.items():
            if agent_id in original_actions:
                # 复制原始动作
                action = original_actions[agent_id].copy()
                
                # 更新动作
                for i, param in enumerate(params):
                    if i < len(action) and param in param_actions:
                        # 将参数值转换回[-1, 1]范围的动作
                        if param == "vfs_cache_pressure":
                            # 0-500范围
                            action[i] = param_actions[param] / 500 * 2 - 1
                        elif param == "dirty_ratio":
                            # 1-60范围
                            action[i] = (param_actions[param] - 1) / 59 * 2 - 1
                        elif param == "dirty_background_ratio":
                            # 1-50范围
                            action[i] = (param_actions[param] - 1) / 49 * 2 - 1
                        elif param == "swappiness":
                            # 0-100范围
                            action[i] = param_actions[param] / 100 * 2 - 1
                        elif param == "min_free_kbytes":
                            # 1024-1048576范围 (1MB-1GB)
                            action[i] = (param_actions[param] - 1024) / (1048576 - 1024) * 2 - 1
                        elif param == "watermark_scale_factor":
                            # 10-1000范围
                            action[i] = (param_actions[param] - 10) / 990 * 2 - 1
                        elif param == "compaction_proactiveness":
                            # 0-100范围
                            action[i] = param_actions[param] / 100 * 2 - 1
                
                new_actions[agent_id] = action
        
        return new_actions
    
    def _resolve_cache_swap_conflict(self, param_actions, analysis_dict, system_state):
        """解决缓存压力和swap倾向度之间的冲突"""
        if "vfs_cache_pressure" in param_actions and "swappiness" in param_actions:
            # 获取分析结果
            cache_analysis = analysis_dict.get("page_cache", {})
            reclaim_analysis = analysis_dict.get("memory_reclaim", {})
            
            cache_pressure = param_actions["vfs_cache_pressure"]
            swappiness = param_actions["swappiness"]
            
            # 检查是否存在冲突情况
            # 例如：高缓存压力和高swap倾向可能导致过度回收
            if cache_pressure > 300 and swappiness > 80:
                # 降低swap倾向以避免过度回收
                param_actions["swappiness"] = 60
            
            # 低缓存压力和低swap倾向可能导致缓存增长过快
            elif cache_pressure < 50 and swappiness < 20:
                # 增加缓存压力以防止缓存过度增长
                param_actions["vfs_cache_pressure"] = 100
        
        return param_actions
    
    def _resolve_dirty_minfree_conflict(self, param_actions, analysis_dict, system_state):
        """解决脏页比例和最小可用内存之间的冲突"""
        if "dirty_ratio" in param_actions and "min_free_kbytes" in param_actions:
            dirty_ratio = param_actions["dirty_ratio"]
            min_free_kbytes = param_actions["min_free_kbytes"]
            
            # 高脏页比例和低最小可用内存可能导致内存不足
            if dirty_ratio > 40 and min_free_kbytes < 8192:  # 8MB
                # 增加最小可用内存
                param_actions["min_free_kbytes"] = 32768  # 32MB
        
        return param_actions
    
    def _resolve_watermark_minfree_conflict(self, param_actions, analysis_dict, system_state):
        """解决水位线因子和最小可用内存之间的冲突"""
        if "watermark_scale_factor" in param_actions and "min_free_kbytes" in param_actions:
            watermark_factor = param_actions["watermark_scale_factor"]
            min_free_kbytes = param_actions["min_free_kbytes"]
            
            # 高水位线因子和低最小可用内存会导致回收不及时
            if watermark_factor > 500 and min_free_kbytes < 8192:  # 8MB
                # 降低水位线因子以便更及时回收
                param_actions["watermark_scale_factor"] = 200
        
        return param_actions
    
    def _resolve_dirty_bg_watermark_conflict(self, param_actions, analysis_dict, system_state):
        """解决脏页后台比例和水位线因子之间的冲突"""
        if "dirty_background_ratio" in param_actions and "watermark_scale_factor" in param_actions:
            dirty_bg_ratio = param_actions["dirty_background_ratio"]
            watermark_factor = param_actions["watermark_scale_factor"]
            
            # 低脏页后台比例和高水位线因子会延迟脏页回写
            if dirty_bg_ratio < 5 and watermark_factor > 800:
                # 增加脏页后台比例
                param_actions["dirty_background_ratio"] = 10
        
        return param_actions
    
    def save_models(self, path):
        """保存所有智能体模型"""
        for agent_id, agent in self.agents.items():
            torch.save(agent.state_dict(), f"{path}/{agent_id}.pt")
    
    def load_models(self, path):
        """加载所有智能体模型"""
        for agent_id, agent in self.agents.items():
            try:
                agent.load_state_dict(torch.load(f"{path}/{agent_id}.pt", map_location=self.device))
                print(f"Loaded model for {agent_id}")
            except:
                print(f"Failed to load model for {agent_id}")
