import torch
import numpy as np
from abc import ABC, abstractmethod

class BaseAgent(ABC):
    """所有内存优化智能体的基类，提供通用接口和功能"""
    
    def __init__(self, agent_id, obs_dim, act_dim, hidden_dim=64, lr=3e-4, gamma=0.99, 
                 use_shared_network=False, shared_network=None):
        self.agent_id = agent_id
        self.obs_dim = obs_dim
        self.act_dim = act_dim
        
        # 如果使用共享网络，则直接引用传入的网络
        if use_shared_network and shared_network is not None:
            self.policy_network = shared_network
        else:
            # 否则创建自己的网络（将在子类中实现）
            self._create_networks(hidden_dim)
            
        self.lr = lr
        self.gamma = gamma
        
        # 智能体间通信缓存
        self.comm_buffer = {}
        
        # 智能体特定的统计信息
        self.stats = {
            "rewards": [],
            "losses": [],
            "entropies": []
        }
    
    @abstractmethod
    def _create_networks(self, hidden_dim):
        """创建智能体特定的网络，由子类实现"""
        pass
    
    @abstractmethod
    def select_action(self, obs, deterministic=False):
        """根据观察选择动作，由子类实现"""
        pass
    
    @abstractmethod
    def update(self, batch):
        """更新智能体策略，由子类实现"""
        pass
    
    def send_message(self, target_agent_id, message):
        """向其他智能体发送消息"""
        return {
            "sender": self.agent_id,
            "content": message,
            "timestamp": np.datetime64('now')
        }
    
    def receive_message(self, message):
        """接收其他智能体发送的消息"""
        sender = message["sender"]
        if sender not in self.comm_buffer:
            self.comm_buffer[sender] = []
        self.comm_buffer[sender].append(message)
    
    def get_messages(self, sender_id=None):
        """获取指定发送者的消息或所有消息"""
        if sender_id is not None:
            return self.comm_buffer.get(sender_id, [])
        return self.comm_buffer
    
    def clear_messages(self, sender_id=None):
        """清除指定发送者的消息或所有消息"""
        if sender_id is not None and sender_id in self.comm_buffer:
            self.comm_buffer[sender_id] = []
        else:
            self.comm_buffer = {}
    
    def get_stats(self):
        """返回智能体的统计信息"""
        return self.stats
    
    def save(self, path):
        """保存智能体模型"""
        torch.save({
            'agent_id': self.agent_id,
            'policy_state_dict': self.policy_network.state_dict(),
            'stats': self.stats
        }, path)
    
    def load(self, path):
        """加载智能体模型"""
        checkpoint = torch.load(path)
        self.policy_network.load_state_dict(checkpoint['policy_state_dict'])
        self.stats = checkpoint['stats']
