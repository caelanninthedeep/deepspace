# state_normalizer.py
import numpy as np
import os
from environment.state_collector import StateCollector

class StateNormalizer:
    def __init__(self):
        self.state_collector = StateCollector()
        # 关键指标的最小/最大值（基于经验值）
        self.feature_ranges = {
            'free_memory_ratio': (0.01, 0.5),
            'swap_used_ratio': (0.0, 0.8),
            'major_page_faults': (0, 200),
            'minor_page_faults': (0, 10000),
            'swap_io_rate': (0, 100),
            'cached_ratio': (0.1, 0.7),
            'slab_ratio': (0.01, 0.2),
            'active_ratio': (0.3, 0.8),
            'inactive_ratio': (0.1, 0.4),
            'load_ratio': (0.1, 5.0),
            'iowait_ratio': (0.0, 0.3),
            'workload_runtime': (5.0, 120.0)
        }
    
    def get_normalized_state(self):
        """获取归一化后的状态向量"""
        raw_state = self.state_collector.get_state()
        normalized = self._normalize(raw_state)
        return self._to_feature_vector(normalized)
    
    def _normalize(self, state):
        """应用Min-Max归一化"""
        normalized = {}
        mem_total = state['memory_total_MB']
        swap_total = max(state['swap_total_MB'], 1)  # 避免除零
        
        # 关键指标计算和归一化
        normalized['free_memory_ratio'] = self._minmax_norm(
            state['free_memory_MB'] / mem_total,
            self.feature_ranges['free_memory_ratio']
        )
        
        normalized['swap_used_ratio'] = self._minmax_norm(
            state['swap_used_MB'] / swap_total,
            self.feature_ranges['swap_used_ratio']
        )
        
        normalized['major_page_faults'] = self._minmax_norm(
            state['major_page_faults_per_sec'],
            self.feature_ranges['major_page_faults']
        )
        
        normalized['minor_page_faults'] = self._minmax_norm(
            state['minor_page_faults_per_sec'],
            self.feature_ranges['minor_page_faults']
        )
        
        swap_io = state['swap_in_per_sec'] + state['swap_out_per_sec']
        normalized['swap_io_rate'] = self._minmax_norm(
            min(swap_io, 100),  # 上限100
            self.feature_ranges['swap_io_rate']
        )
        
        normalized['cached_ratio'] = self._minmax_norm(
            state['cached_memory_MB'] / mem_total,
            self.feature_ranges['cached_ratio']
        )
        
        normalized['slab_ratio'] = self._minmax_norm(
            state['slab_memory_MB'] / mem_total,
            self.feature_ranges['slab_ratio']
        )
        
        normalized['active_ratio'] = self._minmax_norm(
            state['active_memory_MB'] / mem_total,
            self.feature_ranges['active_ratio']
        )
        
        normalized['inactive_ratio'] = self._minmax_norm(
            state['inactive_memory_MB'] / mem_total,
            self.feature_ranges['inactive_ratio']
        )
        
        cpu_count = state.get('cpu_count', os.cpu_count() or 1)
        load_ratio = state['system_loadavg_1min'] / cpu_count
        normalized['load_ratio'] = self._minmax_norm(
            min(load_ratio, 5.0),  # 上限5.0
            self.feature_ranges['load_ratio']
        )
        
        normalized['iowait_ratio'] = self._minmax_norm(
            state.get('cpu_iowait_percent', 0) / 100,
            self.feature_ranges['iowait_ratio']
        )
        
        # 添加工作负载运行时间（如果有）
        if 'last_workload_runtime' in state:
            normalized['workload_runtime'] = self._minmax_norm(
                state['last_workload_runtime'],
                self.feature_ranges['workload_runtime']
            )
        
        return normalized
    
    def _minmax_norm(self, value, range_tuple):
        """应用Min-Max归一化"""
        min_val, max_val = range_tuple
        return (value - min_val) / (max_val - min_val)
    
    def _to_feature_vector(self, normalized_state):
        """转换为固定顺序的特征向量"""
        return np.array([
            normalized_state['free_memory_ratio'],
            normalized_state['swap_used_ratio'],
            normalized_state['major_page_faults'],
            normalized_state['minor_page_faults'],
            normalized_state['swap_io_rate'],
            normalized_state['cached_ratio'],
            normalized_state['slab_ratio'],
            normalized_state['active_ratio'],
            normalized_state['inactive_ratio'],
            normalized_state['load_ratio'],
            normalized_state['iowait_ratio'],
            normalized_state.get('workload_runtime', 0.5)  # 默认值
        ], dtype=np.float32)
