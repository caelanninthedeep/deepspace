"""
使用PPO算法训练内存优化代理 - 支持连续动作空间
增强版：扩大训练规模与更强大的调试功能
"""

import os
import time
import numpy as np
import torch
from collections import deque
import argparse
import json
from datetime import datetime
import matplotlib.pyplot as plt
from memory_optimization.environment.mem_env import MemoryOptimizationEnv
from memory_optimization.algorithms.ppo import PPO

def train(
    max_episodes=50,           # 增加到50轮
    max_steps=100,             # 增加到100步
    buffer_size=1000,          # 增加到1000
    batch_size=64,             # 增加到64
    epochs=10,
    update_interval=200,       # 更新间隔增加到200步
    save_interval=5,           # 每5轮保存一次
    log_interval=1, 
    lr=0.0003,
    gamma=0.99,
    gae_lambda=0.95,
    clip_ratio=0.2,
    entropy_coef=0.01,
    value_coef=0.5,
    action_std=0.6,
    action_std_decay_rate=0.05,
    min_action_std=0.1,
    action_std_decay_freq=5,   # 每5轮降低一次探索
    resume_from=None,
    config=None,
    debug_mode=True            # 添加调试模式
):
    """
    训练内存优化代理 - 增强版
    """
    # 创建日志目录
    os.makedirs("models", exist_ok=True)
    os.makedirs("logs", exist_ok=True)
    
    # 时间戳
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # 设置调试日志
    debug_log_file = None
    if debug_mode:
        debug_log_file = f"logs/debug_{timestamp}.log"
        
    def debug_print(message):
        if debug_mode:
            print(f"[DEBUG] {message}")
            if debug_log_file:
                with open(debug_log_file, "a") as f:
                    f.write(f"{datetime.now().strftime('%H:%M:%S')} - {message}\n")

    debug_print(f"开始初始化训练...\n配置参数: max_episodes={max_episodes}, buffer_size={buffer_size}")
    
    # 创建环境
    try:
        env = MemoryOptimizationEnv()
        debug_print("环境创建成功")
    except Exception as e:
        print(f"环境创建失败: {e}")
        return None, [], {}
    
    # 获取状态和动作维度
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]  # 连续动作空间
    
    debug_print(f"状态维度: {state_dim}, 动作维度: {action_dim}")
    
    # 创建配置字典
    ppo_config = {
        'lr': lr,
        'gamma': gamma,
        'gae_lambda': gae_lambda,
        'clip_ratio': clip_ratio,
        'batch_size': batch_size,
        'epochs': epochs,
        'buffer_size': buffer_size,
        'action_std_init': action_std,
        'entropy_coef': entropy_coef,
        'value_coef': value_coef,
        'save_dir': 'models',
        'log_dir': f'logs/ppo_{timestamp}'
    }
    
    # 更新配置（如果提供）
    if config:
        ppo_config.update(config)
    
    # 初始化PPO算法
    try:
        agent = PPO(state_dim, action_dim, ppo_config)
        debug_print("PPO代理初始化成功")
    except Exception as e:
        print(f"代理初始化失败: {e}")
        import traceback
        traceback.print_exc()
        return None, [], {}
    
    # 如果需要，从现有模型继续训练
    if resume_from:
        try:
            agent.load(resume_from)
            print(f"继续训练模型: {resume_from}")
            debug_print(f"成功加载模型: {resume_from}")
        except Exception as e:
            print(f"模型加载失败: {e}")
            debug_print(f"模型加载失败: {e}")
    
    # 记录训练数据
    episode_rewards = []
    avg_rewards = deque(maxlen=10)  # 固定为10以计算滚动平均
    episode_lengths = []
    best_avg_reward = -float('inf')
    
    # 定义一个更全面的奖励记录器
    class RewardTracker:
        def __init__(self):
            self.episode_rewards = []
            self.raw_env_rewards = []  # 环境原始奖励
            self.clipped_rewards = []  # 剪裁后奖励
            self.step_rewards = []     # 单步奖励列表
            
        def record_episode(self, episode_reward, step_rewards):
            self.episode_rewards.append(episode_reward)
            self.step_rewards.append(step_rewards)
            
        def record_raw_reward(self, raw_reward):
            self.raw_env_rewards.append(raw_reward)
            
        def record_clipped_reward(self, clipped_reward):
            self.clipped_rewards.append(clipped_reward)
            
        def get_stats(self):
            if not self.episode_rewards:
                return {"mean": 0, "max": 0, "min": 0, "std": 0}
            
            return {
                "mean": np.mean(self.episode_rewards),
                "max": np.max(self.episode_rewards),
                "min": np.min(self.episode_rewards),
                "std": np.std(self.episode_rewards),
                "count": len(self.episode_rewards)
            }
            
    reward_tracker = RewardTracker()
    
    # 日志记录
    log_file = f"logs/training_log_{timestamp}.csv"
    with open(log_file, 'w') as f:
        f.write("episode,steps,reward,avg_reward_10,max_step_reward,min_step_reward,value_loss,policy_loss,entropy,approx_kl,runtime_avg\n")
    
    # 训练循环
    start_time = time.time()
    total_steps = 0
    training_updates = 0
    episodes_completed = 0
    
    print(f"=========== 开始训练 ===========")
    print(f"最大回合数: {max_episodes}, 每回合最大步数: {max_steps}")
    print(f"缓冲区大小: {buffer_size}, 批次大小: {batch_size}")
    print(f"更新间隔: {update_interval}步\n")
    
    try:
        for episode in range(1, max_episodes + 1):
            episode_start_time = time.time()
            debug_print(f"\n======== 开始第 {episode}/{max_episodes} 轮训练 ========")
            
            try:
                # 重置环境
                state = env.reset()
                debug_print(f"环境已重置，初始状态维度: {len(state)}")
                
                episode_reward = 0
                episode_length = 0
                step_rewards = []  # 记录本回合每一步的奖励
                
                # 回合循环
                for step in range(1, max_steps + 1):
                    try:
                        # 选择动作
                        action, log_prob, value = agent.select_action(state)
                        debug_print(f"Step {step}: 选择动作 {action}")
                        
                        # 执行动作
                        next_state, reward, done, info = env.step(action)
                        
                        # 环境奖励可能非常大，但PPO内部会剪裁
                        debug_print(f"Step {step}: 环境奖励={reward:.2f}, done={done}")
                        
                        # 记录原始奖励
                        reward_tracker.record_raw_reward(reward)
                        
                        # 存储经验前记录原始奖励
                        original_reward = reward
                        
                        # 添加奖励缩放代码 - 使用对数缩放而非简单裁剪
                        if abs(reward) > 100:
                            reward = 10.0 * np.sign(reward) * np.log(1 + abs(reward/100))
                            debug_print(f"奖励缩放: {original_reward} -> {reward}")
                        
                        # 记录剪裁后奖励
                        reward_tracker.record_clipped_reward(reward)
                        
                        # 存储经验
                        agent.store(state, action, reward, done, next_state, value, log_prob)
                        
                        # 更新状态和计数器
                        state = next_state
                        episode_reward += reward
                        episode_length += 1
                        total_steps += 1
                        step_rewards.append(reward)
                        
                        # 打印详细步骤信息
                        if step % 10 == 0 or step == 1:
                            debug_print(f"  步骤 {step}/{max_steps}: 奖励={reward:.4f}, 累计奖励={episode_reward:.4f}")
                        
                        # 判断是否结束回合
                        if done:
                            debug_print(f"  Episode在第{step}步提前结束，原因: {info}")
                            break
                            
                        # 定期更新
                        if total_steps % update_interval == 0:
                            debug_print(f"达到更新间隔 {update_interval}，执行网络更新...")
                            
                            train_info = agent.update()
                            if train_info:
                                training_updates += 1
                                
                                # 打印更新信息
                                print(f"\n更新 #{training_updates} | 步数: {total_steps}")
                                print(f"价值损失: {train_info['value_loss']:.4f}, 策略损失: {train_info['policy_loss']:.4f}")
                                print(f"熵: {train_info['entropy']:.4f}, KL散度: {train_info['approx_kl']:.4f}")
                            else:
                                debug_print("更新返回None，可能缓冲区样本不足")
                    except Exception as step_err:
                        print(f"步骤 {step} 执行错误: {step_err}")
                        debug_print(f"步骤错误: {step_err}")
                        import traceback
                        debug_print(traceback.format_exc())
                        # 继续下一个步骤
                        continue
                
                # 回合结束处理
                episode_duration = time.time() - episode_start_time
                debug_print(f"第 {episode} 轮训练完成: 步数={episode_length}, 总奖励={episode_reward:.2f}, 用时: {episode_duration:.2f}秒")
                
                # 记录奖励和步数
                episode_rewards.append(episode_reward)
                avg_rewards.append(episode_reward)
                episode_lengths.append(episode_length)
                reward_tracker.record_episode(episode_reward, step_rewards)
                episodes_completed += 1
                
                # 计算平均奖励
                avg_reward_10 = np.mean(list(avg_rewards)) if avg_rewards else 0
                
                # 保存最佳模型
                if avg_reward_10 > best_avg_reward:
                    best_avg_reward = avg_reward_10
                    agent.save(f"models/ppo_memory_opt_best_{timestamp}.pt")
                    print(f"发现最佳模型! 平均奖励: {best_avg_reward:.2f}")
                
                # 打印日志
                if episode % log_interval == 0 or episode == 1:
                    elapsed_time = time.time() - start_time
                    
                    # 更安全地计算统计数据
                    avg_reward = np.mean(list(avg_rewards)) if avg_rewards else 0.0
                    avg_length = np.mean(episode_lengths[-log_interval:]) if episode_lengths else 0.0
                    
                    # 获取工作负载运行时间
                    runtime_avg = 0
                    if hasattr(env, 'runtime_history') and env.runtime_history:
                        if isinstance(env.runtime_history, list):
                            if len(env.runtime_history) > 0:
                                if isinstance(env.runtime_history[0], dict):
                                    runtime_avg = np.mean([info.get('runtime', 0) for info in env.runtime_history])
                                else:
                                    runtime_avg = np.mean([r for r in env.runtime_history if isinstance(r, (int, float))])
                    
                    # 步骤奖励统计
                    if step_rewards:
                        max_step_reward = max(step_rewards)
                        min_step_reward = min(step_rewards)
                    else:
                        max_step_reward = 0
                        min_step_reward = 0
                    
                    print(f"\n回合: {episode}/{max_episodes} | "
                          f"总步数: {total_steps} | "
                          f"奖励: {episode_reward:.2f} | "
                          f"平均奖励(10回合): {avg_reward:.2f} | "
                          f"步数: {episode_length} | "
                          f"更新次数: {training_updates} | "
                          f"用时: {elapsed_time:.2f}s")
                    print(f"步奖励范围: {min_step_reward:.2f} 到 {max_step_reward:.2f} | "
                          f"平均运行时间: {runtime_avg:.2f}s")
                          
                    # 如果有难度信息，打印难度分布
                    if hasattr(env, 'difficulty_strategy'):
                        difficulty_dist = env.difficulty_strategy.get_distribution()
                        print(f"难度分布: {difficulty_dist}")
                
                # 记录训练日志
                train_info_latest = {}
                
                if hasattr(agent, 'writer') and hasattr(agent.writer, 'scalar_dict'):
                    train_info_latest = agent.writer.scalar_dict
                
                with open(log_file, 'a') as f:
                    # 获取最新的训练信息
                    value_loss = train_info_latest.get('training/value_loss', 0)
                    policy_loss = train_info_latest.get('training/policy_loss', 0)
                    entropy = train_info_latest.get('training/entropy', 0)
                    approx_kl = train_info_latest.get('training/approx_kl', 0)
                    
                    # 记录步骤奖励统计
                    max_step_reward = max(step_rewards) if step_rewards else 0
                    min_step_reward = min(step_rewards) if step_rewards else 0
                    
                    # 记录日志
                    runtime_avg = 0
                    if hasattr(env, 'runtime_history') and env.runtime_history:
                        if isinstance(env.runtime_history, list):
                            if len(env.runtime_history) > 0:
                                if all(isinstance(item, dict) for item in env.runtime_history):
                                    runtime_avg = np.mean([info.get('runtime', 0) for info in env.runtime_history])
                                else:
                                    runtime_avg = np.mean([r for r in env.runtime_history if isinstance(r, (int, float))])
                    
                    f.write(f"{episode},{episode_length},{episode_reward:.4f},{avg_reward_10:.4f},"
                            f"{max_step_reward:.4f},{min_step_reward:.4f},{value_loss:.6f},{policy_loss:.6f},"
                            f"{entropy:.6f},{approx_kl:.6f},{runtime_avg:.4f}\n")
                
                # 保存模型
                if episode % save_interval == 0:
                    save_path = f"models/ppo_memory_opt_episode_{episode}_{timestamp}.pt"
                    agent.save(save_path)
                    debug_print(f"模型已保存: {save_path}")
                
                # 动态调整动作标准差
                if episode % action_std_decay_freq == 0 and action_std > min_action_std:
                    agent.decay_action_std(action_std_decay_rate)
                    print(f"动作标准差调整为: {agent.action_std:.2f}")
                
                # 中间绘图，每10个episode或训练结束前
                if episode % 10 == 0 or episode == max_episodes:
                    try:
                        plot_training_results(episode_rewards, episode_lengths, f"{timestamp}_ep{episode}")
                        debug_print(f"中间绘图已保存: episode {episode}")
                    except Exception as plot_err:
                        debug_print(f"中间绘图错误: {plot_err}")
                
            except Exception as episode_err:
                print(f"第 {episode} 轮训练出错: {episode_err}")
                debug_print(f"Episode错误: {episode_err}")
                import traceback
                traceback_str = traceback.format_exc()
                debug_print(traceback_str)
                
                # 继续下一个回合而不是完全中断
                continue
            
            # 如果训练时间过长，提前终止
            if time.time() - start_time > 12 * 3600:  # 12小时
                print("训练时间超过12小时，提前终止")
                debug_print("训练时间超过限制，提前终止")
                break
    
    except KeyboardInterrupt:
        print("\n训练被用户中断")
        debug_print("训练被用户中断")
    
    except Exception as e:
        print(f"训练主循环发生错误: {e}")
        debug_print(f"训练主循环错误: {e}")
        import traceback
        traceback.print_exc()
        debug_print(traceback.format_exc())
    
    # 保存最终模型
    try:
        final_model_path = f"models/ppo_memory_opt_final_{timestamp}.pt"
        agent.save(final_model_path)
        print(f"最终模型已保存: {final_model_path}")
    except Exception as save_err:
        print(f"保存最终模型失败: {save_err}")
    
    total_training_time = time.time() - start_time
    print(f"\n训练完成! 总共耗时: {total_training_time:.2f}s")
    print(f"完成的episodes: {episodes_completed}/{max_episodes}")
    
    # 保存训练配置和结果
    training_results = {
        'config': ppo_config,
        'episodes_completed': episodes_completed,
        'total_episodes_attempted': episode,
        'total_steps': total_steps, 
        'training_updates': training_updates,
        'training_time': total_training_time,
        'final_avg_reward': np.mean(episode_rewards[-10:]) if len(episode_rewards) >= 10 else np.mean(episode_rewards),
        'best_avg_reward': best_avg_reward,
        'timestamp': timestamp,
        'reward_stats': reward_tracker.get_stats()
    }
    
    # 保存训练结果
    result_file = f"logs/training_results_{timestamp}.json"
    with open(result_file, 'w') as f:
        json.dump(training_results, f, indent=2)
    print(f"训练结果已保存: {result_file}")
    
    # 绘制最终奖励曲线
    try:
        final_plot_file = f"logs/final_training_plot_{timestamp}.png"
        plot_training_results(episode_rewards, episode_lengths, timestamp)
        print(f"训练图表已保存: {final_plot_file}")
    except Exception as plot_err:
        print(f"最终绘图错误: {plot_err}")
    
    return agent, episode_rewards, training_results

def plot_training_results(rewards, lengths, timestamp):
    """
    增强版绘制训练结果图表，更好地处理少量数据点的情况
    """
    try:
        plt.figure(figsize=(12, 10))
        
        # 检查数据点数量
        n_points = len(rewards)
        
        # 奖励曲线
        plt.subplot(2, 1, 1)
        
        # 处理少量数据点的情况
        if n_points <= 1:
            # 单点情况使用柱状图
            plt.bar([1], rewards, width=0.4, color='blue', alpha=0.7, label='Reward')
            plt.xlim(0.5, 1.5)
            plt.xticks([1], ['Episode 1'])
        else:
            # 多点情况使用线图
            plt.plot(range(1, n_points+1), rewards, 'b-o', alpha=0.7, label='Raw')
            # 只在有足够数据点时应用平滑
            if n_points > 5:
                # 使用移动平均来平滑
                window_size = min(5, n_points // 2)
                if window_size > 0:
                    # 使用卷积来创建移动平均
                    smooth_rewards = np.convolve(rewards, np.ones(window_size)/window_size, mode='valid')
                    # 对齐x轴
                    smooth_x = range(window_size//2 + 1, n_points + 1 - window_size//2)
                    plt.plot(smooth_x, smooth_rewards, 'r-', linewidth=2, label='Smoothed')
        
        # 添加均值线
        if n_points > 0:
            mean_reward = np.mean(rewards)
            plt.axhline(y=mean_reward, color='g', linestyle='--', label=f'Mean: {mean_reward:.2f}')
        
        plt.title('Training Rewards')
        plt.xlabel('Episode')
        plt.ylabel('Reward')
        plt.grid(True, linestyle='--', alpha=0.7)
        plt.legend()
        
        # 回合长度曲线
        plt.subplot(2, 1, 2)
        
        # 处理少量数据点的情况
        if n_points <= 1:
            # 单点情况使用柱状图
            plt.bar([1], lengths, width=0.4, color='green', alpha=0.7, label='Steps')
            plt.xlim(0.5, 1.5)
            plt.xticks([1], ['Episode 1'])
        else:
            # 多点情况使用线图
            plt.plot(range(1, n_points+1), lengths, 'g-o', alpha=0.7, label='Raw')
            # 只在有足够数据点时应用平滑
            if n_points > 5:
                # 使用移动平均来平滑
                window_size = min(5, n_points // 2)
                if window_size > 0:
                    # 使用卷积来创建移动平均
                    smooth_lengths = np.convolve(lengths, np.ones(window_size)/window_size, mode='valid')
                    # 对齐x轴
                    smooth_x = range(window_size//2 + 1, n_points + 1 - window_size//2)
                    plt.plot(smooth_x, smooth_lengths, 'r-', linewidth=2, label='Smoothed')
        
        # 添加均值线
        if n_points > 0:
            mean_length = np.mean(lengths)
            plt.axhline(y=mean_length, color='g', linestyle='--', label=f'Mean: {mean_length:.2f}')
        
        plt.title('Episode Lengths')
        plt.xlabel('Episode')
        plt.ylabel('Steps')
        plt.grid(True, linestyle='--', alpha=0.7)
        plt.legend()
        
        plt.tight_layout()
        plt.savefig(f'logs/training_plot_{timestamp}.png')
        plt.close()
        
        # 如果有足够的数据点，创建额外的诊断图
        if n_points > 5:
            plt.figure(figsize=(12, 8))
            
            # 奖励分布直方图
            plt.subplot(1, 2, 1)
            plt.hist(rewards, bins=min(20, n_points//2), alpha=0.7, color='blue')
            plt.axvline(x=np.mean(rewards), color='r', linestyle='--', label=f'Mean: {np.mean(rewards):.2f}')
            plt.title('Reward Distribution')
            plt.xlabel('Reward')
            plt.ylabel('Frequency')
            plt.legend()
            
            # 回合长度分布直方图
            plt.subplot(1, 2, 2)
            plt.hist(lengths, bins=min(20, n_points//2), alpha=0.7, color='green')
            plt.axvline(x=np.mean(lengths), color='r', linestyle='--', label=f'Mean: {np.mean(lengths):.2f}')
            plt.title('Episode Length Distribution')
            plt.xlabel('Steps')
            plt.ylabel('Frequency')
            plt.legend()
            
            plt.tight_layout()
            plt.savefig(f'logs/training_diagnostics_{timestamp}.png')
            plt.close()
        
        print(f"训练结果图表已保存至: logs/training_plot_{timestamp}.png")
        
    except Exception as e:
        print(f"绘图错误: {e}")
        import traceback
        traceback.print_exc()

def custom_reward_scaler(reward):
    """
    对奖励进行更合理的缩放，保留相对大小关系
    """
    if abs(reward) < 1.0:
        return reward  # 小奖励保持不变
    elif abs(reward) < 100.0:
        return np.sign(reward) * (5.0 * np.log10(1 + abs(reward)/10.0))
    else:
        return np.sign(reward) * (10.0 * np.log10(1 + abs(reward)/100.0))

if __name__ == "__main__":
    # 解析命令行参数
    parser = argparse.ArgumentParser(description="使用PPO训练内存优化代理")
    parser.add_argument("--episodes", type=int, default=50, help="最大训练回合数")
    parser.add_argument("--steps", type=int, default=100, help="每个回合的最大步数")
    parser.add_argument("--buffer", type=int, default=1000, help="缓冲区大小")
    parser.add_argument("--batch", type=int, default=64, help="批量大小")
    parser.add_argument("--lr", type=float, default=0.0003, help="学习率")
    parser.add_argument("--gamma", type=float, default=0.99, help="折扣因子")
    parser.add_argument("--action-std", type=float, default=0.6, help="初始动作标准差")
    parser.add_argument("--update-interval", type=int, default=200, help="更新间隔（步数）")
    parser.add_argument("--resume", type=str, help="从现有模型继续训练")
    parser.add_argument("--save-interval", type=int, default=5, help="保存模型间隔（回合数）")
    parser.add_argument("--log-interval", type=int, default=1, help="日志记录间隔（回合数）")
    parser.add_argument("--debug", action="store_true", help="启用调试模式")
    
    args = parser.parse_args()
    
    # 执行训练
    agent, rewards, results = train(
        max_episodes=args.episodes,
        max_steps=args.steps,
        buffer_size=args.buffer,
        batch_size=args.batch,
        lr=args.lr,
        gamma=args.gamma,
        action_std=args.action_std,
        update_interval=args.update_interval,
        save_interval=args.save_interval,
        log_interval=args.log_interval,
        resume_from=args.resume,
        debug_mode=args.debug
    )
    
    print("\n训练结果摘要:")
    print(f"完成的Episodes: {results['episodes_completed']}/{args.episodes}")
    print(f"总步数: {results['total_steps']}")
    print(f"总更新次数: {results['training_updates']}")
    print(f"最终平均奖励: {results['final_avg_reward']:.2f}")
    print(f"最佳平均奖励: {results['best_avg_reward']:.2f}")
    print(f"总训练时间: {results['training_time']:.2f}秒")
