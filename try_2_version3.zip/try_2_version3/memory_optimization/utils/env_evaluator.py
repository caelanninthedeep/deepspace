import numpy as np
from collections import defaultdict

class EnvironmentEvaluator:
    def __init__(self, env):
        self.env = env
        
    def evaluate_randomness(self, num_episodes=100):
        """评估环境的随机性"""
        same_state_rewards = defaultdict(list)
        
        for _ in range(num_episodes):
            state = self.env.reset()
            done = False
            
            while not done:
                action = self.env.action_space.sample()
                next_state, reward, done, _ = self.env.step(action)
                
                # 记录相同状态下的奖励
                state_key = tuple(state)
                same_state_rewards[state_key].append(reward)
                
                state = next_state
        
        # 计算随机性指标
        randomness_scores = []
        for rewards in same_state_rewards.values():
            if len(rewards) > 1:
                randomness_scores.append(np.std(rewards))
        
        return {
            'randomness_score': np.mean(randomness_scores) if randomness_scores else 0,
            'state_visit_counts': len(same_state_rewards)
        }
    
    def evaluate_difficulty(self, num_episodes=100):
        """评估环境难度"""
        success_rates = []
        episode_lengths = []
        reward_means = []
        
        for _ in range(num_episodes):
            state = self.env.reset()
            done = False
            episode_rewards = []
            steps = 0
            
            while not done:
                action = self.env.action_space.sample()
                _, reward, done, _ = self.env.step(action)
                episode_rewards.append(reward)
                steps += 1
            
            success_rates.append(1 if sum(episode_rewards) > 0 else 0)
            episode_lengths.append(steps)
            reward_means.append(np.mean(episode_rewards))
        
        return {
            'success_rate': np.mean(success_rates),
            'avg_episode_length': np.mean(episode_lengths),
            'avg_reward': np.mean(reward_means)
        } 