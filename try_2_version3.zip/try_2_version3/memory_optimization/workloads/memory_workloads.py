"""
内存相关工作负载模块
"""

import random
import time
import psutil

class MemoryWorkload:
    # 定义难度等级
    DIFFICULTY_LEVELS = ["easy", "medium", "hard", "extreme"]
    
    def __init__(self):
        self.system_memory = psutil.virtual_memory().total / (1024 * 1024)  # 转换为MB
    
    def run_memory_intensive(self, difficulty=None):
        """
        内存密集型工作负载
        
        参数:
            difficulty: 难度级别，可选值为 "easy", "medium", "hard", "extreme"。
                      如果不指定，则随机选择一个难度级别。
        返回:
            工作负载难度级别和执行的规模
        """
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 根据难度级别确定内存大小范围
        if difficulty == "easy":
            size_mb = random.randint(100, 200)
        elif difficulty == "medium":
            size_mb = random.randint(300, 500)
        elif difficulty == "hard":
            size_mb = random.randint(600, 800)
        elif difficulty == "extreme":
            # 确保不超过系统内存的1/4
            max_size = min(1200, int(self.system_memory / 4))
            size_mb = random.randint(900, max_size)
        
        print(f"[Memory Workload] Difficulty: {difficulty}, Creating and accessing {size_mb}MB array...")
        
        # 创建大数组并访问它
        data = bytearray(size_mb * 1024 * 1024)
        
        # 根据难度调整随机读写操作次数
        operations = {
            "easy": 5000,
            "medium": 10000,
            "hard": 20000,
            "extreme": 30000
        }
        
        # 随机读写操作
        for _ in range(operations[difficulty]):
            index = random.randint(0, len(data) - 1)
            data[index] = 1
        
        # 释放内存
        del data
        
        return difficulty, size_mb
    
    def parallel_memory_allocations(self, difficulty=None):
        """
        并发内存分配测试
        
        参数:
            difficulty: 难度级别，可选值为 "easy", "medium", "hard", "extreme"
        返回:
            工作负载难度级别和进程数量
        """
        import multiprocessing
        
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 根据难度确定进程数和每个进程的内存分配
        if difficulty == "easy":
            num_processes = 2
            min_size, max_size = 50, 150
        elif difficulty == "medium":
            num_processes = 3
            min_size, max_size = 100, 300
        elif difficulty == "hard":
            num_processes = 4
            min_size, max_size = 200, 400
        elif difficulty == "extreme":
            num_processes = 5
            min_size, max_size = 300, 500
        
        print(f"[Parallel Load] Difficulty: {difficulty}, Spawning {num_processes} memory-heavy processes...")
        
        def worker():
            """工作进程函数：分配并操作内存块"""
            size_mb = random.randint(min_size, max_size)
            data = bytearray(size_mb * 1024 * 1024)
            # 根据难度调整随机访问次数
            ops = {
                "easy": 500,
                "medium": 1000,
                "hard": 2000,
                "extreme": 3000
            }
            # 随机访问
            for _ in range(ops[difficulty]):
                index = random.randint(0, len(data) - 1)
                data[index] = 1
            time.sleep(1 if difficulty == "easy" else 2)
        
        # 创建多个工作进程
        procs = [multiprocessing.Process(target=worker) for _ in range(num_processes)]
        for p in procs:
            p.start()
        
        # 等待所有进程完成
        for p in procs:
            p.join()
        
        return difficulty, num_processes
    
    def memory_fragmentation_test(self, difficulty=None):
        """
        内存碎片测试
        
        参数:
            difficulty: 难度级别，可选值为 "easy", "medium", "hard", "extreme"
        返回:
            工作负载难度级别和块数量
        """
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 根据难度级别确定内存块数量和大小范围
        if difficulty == "easy":
            num_blocks = 50
            min_size, max_size = 1, 20
        elif difficulty == "medium":
            num_blocks = 100
            min_size, max_size = 1, 30
        elif difficulty == "hard":
            num_blocks = 150
            min_size, max_size = 10, 40
        elif difficulty == "extreme":
            num_blocks = 200
            min_size, max_size = 20, 50
        
        print(f"[Memory] Difficulty: {difficulty}, Running fragmentation test with {num_blocks} blocks...")
        
        # 创建多个不同大小的内存块
        blocks = []
        for _ in range(num_blocks):
            size = random.randint(min_size, max_size) * 1024 * 1024  # 1MB到50MB
            blocks.append(bytearray(size))
        
        # 释放一半的块
        for i in range(0, len(blocks), 2):
            blocks[i] = None
        
        # 重新分配一些块
        realloc_blocks = {
            "easy": 10,
            "medium": 25,
            "hard": 40,
            "extreme": 60
        }
        
        for _ in range(realloc_blocks[difficulty]):
            size = random.randint(min_size, max_size) * 1024 * 1024
            blocks.append(bytearray(size))
        
        # 最后释放所有块
        blocks.clear()
        
        return difficulty, num_blocks
