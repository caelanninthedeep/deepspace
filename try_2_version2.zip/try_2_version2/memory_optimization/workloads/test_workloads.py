"""
测试不同难度级别下的工作负载性能
"""

from memory_optimization.workloads.memory_workloads import MemoryWorkload
from memory_optimization.workloads.io_workloads import IOWorkload
from memory_optimization.workloads.mixed_workloads import MixedWorkload

def test_workload_difficulties():
    """测试不同难度下的工作负载表现"""
    # 初始化工作负载
    memory_workload = MemoryWorkload()
    io_workload = IOWorkload()
    mixed_workload = MixedWorkload()
    
    # 测试不同难度下的工作负载
    for difficulty in ['easy', 'medium', 'hard', 'extreme']:
        print(f"\n--- 测试 {difficulty} 难度工作负载 ---")
        
        # 内存工作负载
        runtime, memory = memory_workload.run_memory_intensive(difficulty)
        print(f"内存工作负载: {runtime:.2f}秒, 使用内存: {memory}MB")
        
        # IO工作负载
        runtime, read_mb, write_mb = io_workload.run_io_intensive(difficulty)
        print(f"IO工作负载: {runtime:.2f}秒, 读取: {read_mb}MB, 写入: {write_mb}MB")
        
        # 文件缓存工作负载
        runtime, cache_mb, files = io_workload.run_file_cache_intensive(difficulty)
        print(f"文件缓存工作负载: {runtime:.2f}秒, 缓存: {cache_mb}MB, 文件数: {files}")
        
        # 混合工作负载
        runtime, memory, io_ops, cpu_load = mixed_workload.run_mixed_workload(difficulty)
        print(f"混合工作负载: {runtime:.2f}秒, 内存: {memory}MB, IO操作: {io_ops}, CPU负载: {cpu_load}%")

if __name__ == "__main__":
    test_workload_difficulties()
