import unittest
import numpy as np
from memory_optimization.environment import MemoryOptimizationEnv

class TestMemoryGymEnv(unittest.TestCase):
    def setUp(self):
        self.env = MemoryOptimizationEnv()
    
    def test_reset(self):
        """测试环境重置"""
        state = self.env.reset()
        self.assertIsNotNone(state)
        self.assertTrue(isinstance(state, np.ndarray))
    
    def test_step(self):
        """测试环境步进"""
        self.env.reset()
        action = self.env.action_space.sample()
        next_state, reward, done, info = self.env.step(action)
        
        self.assertIsNotNone(next_state)
        self.assertTrue(isinstance(reward, (int, float)))
        self.assertTrue(isinstance(done, bool))
        self.assertTrue(isinstance(info, dict))
    
    def test_action_space(self):
        """测试动作空间"""
        self.assertTrue(hasattr(self.env, 'action_space'))
        self.assertTrue(hasattr(self.env.action_space, 'sample'))
    
    def test_observation_space(self):
        """测试观察空间"""
        self.assertTrue(hasattr(self.env, 'observation_space'))
        self.assertTrue(hasattr(self.env.observation_space, 'sample'))

if __name__ == '__main__':
    unittest.main() 