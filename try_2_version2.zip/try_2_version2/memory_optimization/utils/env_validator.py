import numpy as np
from collections import defaultdict

class EnvironmentValidator:
    def __init__(self, env):
        self.env = env
        
    def test_reset_consistency(self, num_tests=100):
        """测试环境重置的一致性"""
        initial_states = []
        for _ in range(num_tests):
            state = self.env.reset()
            initial_states.append(state)
        
        # 计算初始状态的统计信息
        initial_states = np.array(initial_states)
        stats = {
            'mean': np.mean(initial_states, axis=0),
            'std': np.std(initial_states, axis=0),
            'min': np.min(initial_states, axis=0),
            'max': np.max(initial_states, axis=0)
        }
        
        # 检查状态是否在合理范围内
        is_consistent = np.all(stats['std'] < 1e-6)  # 标准差应该很小
        return {
            'is_consistent': is_consistent,
            'stats': stats
        }
    
    def test_action_consistency(self, num_tests=100):
        """测试动作效果的一致性"""
        action_results = defaultdict(list)
        
        for _ in range(num_tests):
            state = self.env.reset()
            for action in range(self.env.action_space.n):
                # 执行相同动作多次
                next_states = []
                rewards = []
                for _ in range(5):  # 每个动作执行5次
                    next_state, reward, _, _ = self.env.step(action)
                    next_states.append(next_state)
                    rewards.append(reward)
                    self.env.reset()  # 重置环境
                
                # 记录结果
                action_results[action].append({
                    'next_states': np.array(next_states),
                    'rewards': np.array(rewards)
                })
        
        # 分析结果
        consistency_analysis = {}
        for action, results in action_results.items():
            # 计算状态转移的一致性
            state_std = np.mean([np.std(r['next_states'], axis=0) for r in results])
            reward_std = np.mean([np.std(r['rewards']) for r in results])
            
            consistency_analysis[action] = {
                'state_consistency': state_std < 1e-6,  # 状态转移应该一致
                'reward_consistency': reward_std < 1e-6,  # 奖励应该一致
                'state_std': state_std,
                'reward_std': reward_std
            }
        
        return consistency_analysis
    
    def evaluate_reward_function(self, num_episodes=1000):
        """评估奖励函数的稳定性和区分能力"""
        reward_distributions = defaultdict(list)
        state_reward_pairs = []
        
        for _ in range(num_episodes):
            state = self.env.reset()
            done = False
            episode_rewards = []
            
            while not done:
                action = self.env.action_space.sample()
                next_state, reward, done, _ = self.env.step(action)
                
                # 记录状态-奖励对
                state_reward_pairs.append((state, reward))
                episode_rewards.append(reward)
                state = next_state
            
            # 记录每个动作的奖励分布
            for action in range(self.env.action_space.n):
                action_rewards = [r for s, r in state_reward_pairs if s[action] == 1]
                if action_rewards:
                    reward_distributions[action].extend(action_rewards)
        
        # 分析奖励函数
        analysis = {
            'reward_stats': {},
            'discrimination_power': 0,
            'stability_score': 0
        }
        
        # 计算每个动作的奖励统计信息
        for action, rewards in reward_distributions.items():
            if rewards:
                analysis['reward_stats'][action] = {
                    'mean': np.mean(rewards),
                    'std': np.std(rewards),
                    'min': np.min(rewards),
                    'max': np.max(rewards)
                }
        
        # 计算奖励函数的区分能力
        reward_means = [stats['mean'] for stats in analysis['reward_stats'].values()]
        if reward_means:
            analysis['discrimination_power'] = np.std(reward_means) / (np.mean(reward_means) + 1e-6)
        
        # 计算奖励函数的稳定性
        reward_stds = [stats['std'] for stats in analysis['reward_stats'].values()]
        if reward_stds:
            analysis['stability_score'] = 1.0 / (np.mean(reward_stds) + 1e-6)
        
        return analysis
    
    def run_full_validation(self):
        """运行完整的环境验证"""
        results = {
            'reset_consistency': self.test_reset_consistency(),
            'action_consistency': self.test_action_consistency(),
            'reward_function': self.evaluate_reward_function()
        }
        
        # 生成验证报告
        report = {
            'is_environment_stable': all([
                results['reset_consistency']['is_consistent'],
                all(ac['state_consistency'] and ac['reward_consistency'] 
                    for ac in results['action_consistency'].values()),
                results['reward_function']['stability_score'] > 0.5
            ]),
            'details': results
        }
        
        return report 