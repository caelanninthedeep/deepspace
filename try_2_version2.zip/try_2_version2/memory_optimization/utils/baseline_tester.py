import os
import json
import numpy as np
from typing import Dict, List, Any, Optional
from .config import ConfigManager
from .experiment_logger import ExperimentLogger

class BaselineTester:
    """基线性能测试器"""
    def __init__(self, env, config_manager: ConfigManager, log_dir: str = "baselines"):
        self.env = env
        self.config_manager = config_manager
        self.log_dir = log_dir
        self.logger = ExperimentLogger(log_dir)
        
        # 创建基线目录
        os.makedirs(log_dir, exist_ok=True)
    
    def test_default_config(self, num_episodes: int = 100):
        """测试默认配置性能"""
        print("测试默认配置性能...")
        
        # 记录配置
        self.logger.log_config(self.config_manager)
        
        # 运行测试
        metrics = self._run_test(num_episodes)
        
        # 记录结果
        self.logger.log_metrics(metrics)
        self.logger.save_metrics()
        self.logger.plot_metrics()
        
        return self.logger.generate_report()
    
    def test_parameter_combinations(self, param_grid: Dict[str, List[Any]], num_episodes: int = 100):
        """测试参数组合性能"""
        print("测试参数组合性能...")
        
        # 生成参数组合
        combinations = self._generate_combinations(param_grid)
        
        results = []
        for i, params in enumerate(combinations):
            print(f"测试参数组合 {i+1}/{len(combinations)}")
            
            # 更新配置
            self.config_manager.update_env_config(**params.get("environment", {}))
            self.config_manager.update_train_config(**params.get("training", {}))
            
            # 记录配置
            self.logger.log_config(self.config_manager)
            
            # 运行测试
            metrics = self._run_test(num_episodes)
            
            # 记录结果
            self.logger.log_metrics(metrics)
            self.logger.save_metrics()
            self.logger.plot_metrics()
            
            # 保存结果
            results.append({
                "params": params,
                "metrics": metrics
            })
        
        # 保存所有结果
        with open(os.path.join(self.log_dir, "parameter_test_results.json"), "w") as f:
            json.dump(results, f, indent=4)
        
        return results
    
    def _run_test(self, num_episodes: int) -> Dict[str, List[float]]:
        """运行测试并收集指标"""
        metrics = {
            "episode_rewards": [],
            "episode_lengths": [],
            "hit_rates": [],
            "memory_usage": [],
            "fragmentation": []
        }
        
        for episode in range(num_episodes):
            state = self.env.reset()
            done = False
            episode_reward = 0
            episode_length = 0
            
            while not done:
                # 使用随机策略
                action = self.env.action_space.sample()
                next_state, reward, done, info = self.env.step(action)
                
                episode_reward += reward
                episode_length += 1
                state = next_state
            
            # 记录指标
            metrics["episode_rewards"].append(episode_reward)
            metrics["episode_lengths"].append(episode_length)
            metrics["hit_rates"].append(info.get("hit_rate", 0))
            metrics["memory_usage"].append(info.get("memory_usage", 0))
            metrics["fragmentation"].append(info.get("fragmentation", 0))
        
        return metrics
    
    def _generate_combinations(self, param_grid: Dict[str, List[Any]]) -> List[Dict[str, Any]]:
        """生成参数组合"""
        import itertools
        
        # 分离环境和训练参数
        env_params = param_grid.get("environment", {})
        train_params = param_grid.get("training", {})
        
        # 生成环境和训练参数的组合
        env_combinations = [dict(zip(env_params.keys(), values))
                          for values in itertools.product(*env_params.values())]
        train_combinations = [dict(zip(train_params.keys(), values))
                            for values in itertools.product(*train_params.values())]
        
        # 组合所有参数
        combinations = []
        for env_params in env_combinations:
            for train_params in train_combinations:
                combinations.append({
                    "environment": env_params,
                    "training": train_params
                })
        
        return combinations
    
    def analyze_results(self, results: List[Dict[str, Any]]):
        """分析测试结果"""
        # 计算每个参数组合的平均性能
        performance_metrics = []
        for result in results:
            metrics = result["metrics"]
            performance_metrics.append({
                "params": result["params"],
                "avg_reward": np.mean(metrics["episode_rewards"]),
                "avg_hit_rate": np.mean(metrics["hit_rates"]),
                "avg_memory_usage": np.mean(metrics["memory_usage"]),
                "avg_fragmentation": np.mean(metrics["fragmentation"])
            })
        
        # 找出最佳参数组合
        best_reward = max(performance_metrics, key=lambda x: x["avg_reward"])
        best_hit_rate = max(performance_metrics, key=lambda x: x["avg_hit_rate"])
        
        # 生成分析报告
        report = {
            "best_reward_params": best_reward["params"],
            "best_hit_rate_params": best_hit_rate["params"],
            "performance_summary": performance_metrics
        }
        
        # 保存分析报告
        with open(os.path.join(self.log_dir, "analysis_report.json"), "w") as f:
            json.dump(report, f, indent=4)
        
        return report 