"""
PPO经验回放缓冲区 - 支持连续动作空间
"""

import numpy as np
import torch

class RolloutBuffer:
    """
    经验回放缓冲区，用于存储和采样PPO训练数据
    """
    
    def __init__(self, buffer_size, state_dim, action_dim, gamma=0.99, gae_lambda=0.95, device='cpu'):
        """
        初始化缓冲区
        
        参数:
            buffer_size: 缓冲区大小
            state_dim: 状态维度
            action_dim: 动作维度
            gamma: 折扣因子
            gae_lambda: GAE(广义优势估计)参数
            device: 训练设备
        """
        self.buffer_size = buffer_size
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.gae_lambda = gae_lambda
        self.device = device
        
        # 重置缓冲区
        self.reset()
    
    def reset(self):
        """重置缓冲区"""
        # 初始化数组
        self.states = np.zeros((self.buffer_size, self.state_dim), dtype=np.float32)
        self.actions = np.zeros((self.buffer_size, self.action_dim), dtype=np.float32)
        self.rewards = np.zeros((self.buffer_size, 1), dtype=np.float32)
        self.dones = np.zeros((self.buffer_size, 1), dtype=np.float32)
        self.next_states = np.zeros((self.buffer_size, self.state_dim), dtype=np.float32)
        self.values = np.zeros((self.buffer_size, 1), dtype=np.float32)
        self.log_probs = np.zeros((self.buffer_size, 1), dtype=np.float32)
        
        # 计数器
        self.ptr = 0
        self.size = 0
    
    def store(self, state, action, reward, done, next_state, value, log_prob):
        """
        存储经验
        
        参数:
            state: 状态
            action: 动作
            reward: 奖励
            done: 终止标志
            next_state: 下一状态
            value: 状态价值估计
            log_prob: 动作对数概率
        """
        # 确保索引在范围内
        idx = self.ptr % self.buffer_size
        
        # 存储数据
        self.states[idx] = state
        self.actions[idx] = action
        self.rewards[idx] = reward
        self.dones[idx] = done
        self.next_states[idx] = next_state
        self.values[idx] = value
        self.log_probs[idx] = log_prob
        
        # 更新计数器
        self.ptr += 1
        self.size = min(self.size + 1, self.buffer_size)
    
    def compute_advantages(self, last_value, use_gae=True):
        """
        计算优势和回报
        
        参数:
            last_value: 最后一个状态的价值估计
            use_gae: 是否使用广义优势估计
            
        返回:
            advantages: 优势估计数组
            returns: 回报估计数组
        """
        # 创建副本以避免修改原始数据
        values = np.append(self.values, last_value)
        advantages = np.zeros_like(self.rewards)
        returns = np.zeros_like(self.rewards)
        
        # GAE计算
        if use_gae:
            gae = 0
            for i in reversed(range(self.size)):
                # 计算TD误差
                delta = self.rewards[i] + self.gamma * values[i+1] * (1 - self.dones[i]) - values[i]
                
                # 计算GAE
                gae = delta + self.gamma * self.gae_lambda * (1 - self.dones[i]) * gae
                advantages[i] = gae
                
                # 计算回报
                returns[i] = advantages[i] + values[i]
        else:
            # 传统方式计算回报
            returns[-1] = self.rewards[-1] + self.gamma * last_value * (1 - self.dones[-1])
            for i in reversed(range(self.size-1)):
                returns[i] = self.rewards[i] + self.gamma * returns[i+1] * (1 - self.dones[i])
            
            advantages = returns - self.values
        
        return advantages, returns
    
    def get_batch(self, batch_size=64, normalize_advantage=True):
        """
        获取随机批次数据
        
        参数:
            batch_size: 批次大小
            normalize_advantage: 是否归一化优势
            
        返回:
            batch_data: 批次数据字典，包括状态、动作、回报、优势和旧的对数概率
        """
        # 计算最后一个状态的价值估计
        advantages, returns = self.compute_advantages(0.0)  # 假设缓冲区最后状态的next_value = 0
        
        # 标准化优势
        if normalize_advantage and len(advantages) > 1:
            advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)
        
        # 随机采样索引
        indices = np.random.permutation(self.size)
        
        # 构建批次数据
        batch_data = {}
        
        for start_idx in range(0, self.size, batch_size):
            # 获取批次索引
            batch_indices = indices[start_idx:min(start_idx + batch_size, self.size)]
            
            # 获取批次数据
            states = self.states[batch_indices]
            actions = self.actions[batch_indices]
            returns_batch = returns[batch_indices]
            advantages_batch = advantages[batch_indices]
            old_log_probs = self.log_probs[batch_indices]
            
            # 转换为PyTorch张量
            states = torch.FloatTensor(states).to(self.device)
            actions = torch.FloatTensor(actions).to(self.device)
            returns_batch = torch.FloatTensor(returns_batch).to(self.device)
            advantages_batch = torch.FloatTensor(advantages_batch).to(self.device)
            old_log_probs = torch.FloatTensor(old_log_probs).to(self.device)
            
            # 将批次数据添加到字典
            batch_data[start_idx] = {
                'states': states,
                'actions': actions,
                'returns': returns_batch,
                'advantages': advantages_batch,
                'old_log_probs': old_log_probs
            }
        
        return batch_data

# 提供 ReplayBuffer 作为 RolloutBuffer 的别名，以维持向后兼容性
ReplayBuffer = RolloutBuffer
