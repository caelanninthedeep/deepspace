"""
训练过程可视化工具
"""
import os
import json
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def visualize_training(log_file, save_dir='visualizations'):
    """
    可视化训练日志数据
    
    参数:
        log_file: 训练日志CSV文件路径
        save_dir: 图表保存目录
    """
    os.makedirs(save_dir, exist_ok=True)
    
    # 读取日志数据
    df = pd.read_csv(log_file)
    
    # 设置绘图样式
    sns.set(style="darkgrid")
    
    # 图1: 奖励曲线
    plt.figure(figsize=(12, 6))
    sns.lineplot(x='episode', y='reward', data=df, label='Episode Reward')
    sns.lineplot(x='episode', y='avg_reward_10', data=df, label='10-Episode Avg')
    plt.title('Training Rewards')
    plt.xlabel('Episode')
    plt.ylabel('Reward')
    plt.legend()
    plt.savefig(f"{save_dir}/rewards.png")
    
    # 图2: 损失函数
    plt.figure(figsize=(12, 6))
    sns.lineplot(x='episode', y='value_loss', data=df, label='Value Loss')
    sns.lineplot(x='episode', y='policy_loss', data=df, label='Policy Loss')
    plt.title('Training Losses')
    plt.xlabel('Episode')
    plt.ylabel('Loss')
    plt.yscale('log')
    plt.legend()
    plt.savefig(f"{save_dir}/losses.png")
    
    # 图3: 工作负载运行时间
    plt.figure(figsize=(12, 6))
    sns.lineplot(x='episode', y='runtime_avg', data=df)
    plt.title('Workload Runtime')
    plt.xlabel('Episode')
    plt.ylabel('Runtime (seconds)')
    plt.savefig(f"{save_dir}/runtime.png")
    
    # 如果有难度分布数据，也可视化它
    if os.path.exists('logs/difficulty_distribution.json'):
        with open('logs/difficulty_distribution.json', 'r') as f:
            diff_data = json.load(f)
        
        # 转换为DataFrame
        diff_df = pd.DataFrame(diff_data)
        
        # 绘制难度分布变化
        plt.figure(figsize=(12, 6))
        for column in ['easy', 'medium', 'hard', 'extreme']:
            if column in diff_df.columns:
                sns.lineplot(data=diff_df, x='episode', y=column, label=column)
        
        plt.title('Difficulty Distribution Evolution')
        plt.xlabel('Episode')
        plt.ylabel('Probability')
        plt.legend()
        plt.savefig(f"{save_dir}/difficulty_distribution.png")

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Visualize training logs")
    parser.add_argument("--log", type=str, required=True, help="Path to training log CSV file")
    parser.add_argument("--outdir", type=str, default="visualizations", help="Output directory for visualizations")
    
    args = parser.parse_args()
    visualize_training(args.log, args.outdir)
