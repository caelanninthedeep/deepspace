"""
内存子系统优化强化学习环境的核心类 - 优化版
支持PPO连续动作空间
"""

import time
import random
import logging
from collections import deque
import numpy as np
import gym
from gym import spaces

from .state_collector import StateCollector
from .action_handler import ActionHandler
from .reward_calculator import RewardCalculator
from memory_optimization.workloads.memory_workloads import MemoryWorkload
from memory_optimization.workloads.io_workloads import IOWorkload
from memory_optimization.workloads.mixed_workloads import MixedWorkload
from memory_optimization.utils.safety_checks import SafetyChecker
from memory_optimization.strategy.hybrid_balanced_strategy import HybridBalancedStrategy

class MemoryOptimizationEnv(gym.Env):
    """Linux内存子系统优化的强化学习环境 - 支持PPO连续动作空间"""
    
    metadata = {'render.modes': ['human']}
    
    def __init__(self, params={}):
        super(MemoryOptimizationEnv, self).__init__()
        
        # 配置日志
        logging.basicConfig(level=logging.INFO, 
                           format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger('MemoryOptimizationEnv')
        
        self.params = params
        
        # 初始化组件
        self.state_collector = StateCollector(normalize=True)
        self.action_handler = ActionHandler()
        self.reward_calculator = RewardCalculator()
        self.safety_checker = SafetyChecker()
        
        # 初始化难度策略
        self.difficulty_strategy = HybridBalancedStrategy()
        
        # 工作负载实例
        self.memory_workload = MemoryWorkload()
        self.io_workload = IOWorkload()
        self.mixed_workload = MixedWorkload()
        
        # 初始化历史记录
        self.action_history = deque(maxlen=100)
        self.state_history = deque(maxlen=100)
        self.reward_history = deque(maxlen=100)
        self.runtime_history = deque(maxlen=10)
        
        # 工作负载和难度跟踪
        self.current_workload_type = None
        self.current_difficulty = None
        self.previous_workload_runtime = None
        self.last_workload_runtime = None
        
        # 记录初始参数值以便恢复
        self.initial_params = self.action_handler.get_current_parameters()
        
        # 设置连续动作空间 (对每个参数，范围为[-1,1])
        # -1表示最小值，1表示最大值，实际应用时会映射到参数的真实范围
        param_count = len(self.action_handler.param_ranges)
        self.action_space = spaces.Box(
            low=-1.0,
            high=1.0,
            shape=(param_count,),
            dtype=np.float32
        )
        
        # 设置观察空间
        # 使用PPO优化的状态向量
        sample_state = self.state_collector.get_state_vector_for_ppo()
        self.observation_space = spaces.Box(
            low=-1.0,
            high=1.0,
            shape=sample_state.shape,
            dtype=np.float32
        )
    
    def reset(self):
        """重置环境状态"""
        self.logger.info("Resetting environment...")
        
        # 恢复初始参数
        if hasattr(self, 'initial_params'):
            for param, value in self.initial_params.items():
                self.action_handler.set_parameter(param, value)
                
        # 清空历史记录
        self.action_history.clear()
        self.state_history.clear()
        self.reward_history.clear()
        self.runtime_history.clear()
        
        # 选择初始难度
        self.current_difficulty = self.difficulty_strategy.select_difficulty()
        
        # 选择工作负载类型
        self.current_workload_type = self._select_workload_type()
        
        # 运行初始工作负载以建立基准
        self.run_test_workload()
        self.previous_workload_runtime = self.last_workload_runtime
        
        # 获取最新状态
        state_vector = self.state_collector.get_state_vector_for_ppo()
        
        return state_vector
    
    def step(self, action):
        """
        执行一步动作 - 支持连续动作空间
        
        参数:
            action: numpy数组，每个参数的标准化值(-1到1)
            
        返回:
            (observation, reward, done, info)元组
        """
        # 安全检查
        if not self.safety_checker.is_safe_to_proceed(self.state_collector.get_state()):
            self.logger.warning("Unsafe system state detected. Skipping this step.")
            return self.state_collector.get_state_vector_for_ppo(), -100, False, {"skipped": True}
        
        # 记录动作
        self.action_history.append(action)
        
        # 将连续动作值转换为参数值字典
        action_values = self._convert_action_to_param_values(action)
        
        # 执行参数调整
        self.action_handler.execute_action(action_values)
        
        # 可能更改工作负载类型
        if random.random() < 0.2:  # 20%概率改变工作负载
            self.current_workload_type = self._select_workload_type()
            
        # 可能更改难度(每10步一次)
        if len(self.action_history) % 10 == 0:
            self.current_difficulty = self.difficulty_strategy.select_difficulty()
            self.logger.info(f"Changed difficulty to: {self.current_difficulty}")
        
        # 运行测试工作负载
        self.run_test_workload()
        
        # 获取新状态
        new_state = self.state_collector.get_state()
        self.state_history.append(new_state)
        
        # 确保 runtime 值为数值类型用于奖励计算
        prev_runtime = self._ensure_numeric(self.previous_workload_runtime)
        curr_runtime = self._ensure_numeric(self.last_workload_runtime)
        
        # 计算奖励
        reward = self.reward_calculator.calculate_reward(
            new_state, 
            previous_runtime=prev_runtime, 
            current_runtime=curr_runtime,
            workload_type=self.current_workload_type,
            difficulty=self.current_difficulty
        )
        self.reward_history.append(reward)
        
        # 更新难度策略
        success = reward > 0  # 简单判断：正奖励为成功
        self.difficulty_strategy.update_performance(self.current_difficulty, success)
        
        # 更新前一次工作负载运行时间
        self.previous_workload_runtime = self.last_workload_runtime
        
        # 判断是否结束
        done = False
        # 一个episode通常不会自然结束，除非到达步数限制
        
        # 计算性能改进 (确保安全计算)
        improvement = 0
        try:
            prev_rt = self._ensure_numeric(self.previous_workload_runtime)
            curr_rt = self._ensure_numeric(self.last_workload_runtime)
            if prev_rt > 0:
                improvement = (prev_rt - curr_rt) / prev_rt
        except (TypeError, ValueError, ZeroDivisionError):
            self.logger.warning("Could not calculate improvement due to invalid runtime values")
        
        info = {
            'workload_type': self.current_workload_type,
            'difficulty': self.current_difficulty,
            'runtime': self.last_workload_runtime,
            'improvement': improvement,
            'applied_params': action_values,
            'success': success
        }
        
        # 获取优化后的观察向量
        observation = self.state_collector.get_state_vector_for_ppo()
        
        return observation, reward, done, info
    
    def _ensure_numeric(self, value):
        """确保值为数值类型"""
        if value is None:
            return 0.0
            
        try:
            if isinstance(value, str):
                # 如果是难度字符串，返回一个默认值
                if value in ['easy', 'medium', 'hard', 'extreme', 'easys', 'mediums', 'hards', 'extremes']:
                    return 1.0
                return float(value)
            return float(value)
        except (ValueError, TypeError):
            self.logger.warning(f"Could not convert value to number: {value}")
            return 0.0
    
    def _convert_action_to_param_values(self, action):
        """
        将连续动作向量转换为参数值字典
        
        参数:
            action: numpy数组，每个参数的标准化值(-1到1)
            
        返回:
            dict: 参数名和值的映射
        """
        param_values = {}
        param_names = list(self.action_handler.param_ranges.keys())
        
        for i, param_name in enumerate(param_names):
            if i < len(action):
                param_range = self.action_handler.param_ranges[param_name]
                min_val = param_range['min']
                max_val = param_range['max']
                
                # 将[-1,1]映射到[min_val,max_val]
                normalized_val = (action[i] + 1) / 2.0  # 从[-1,1]映射到[0,1]
                param_val = min_val + normalized_val * (max_val - min_val)
                
                # 对于整数参数，四舍五入
                if param_range.get('type', int) == int:
                    param_val = int(round(param_val))
                
                param_values[param_name] = param_val
        
        return param_values
    
    def _select_workload_type(self):
        """随机选择一种工作负载类型"""
        workload_types = [
            'memory_intensive',
            'io_intensive',
            'mixed_workload',
            'file_cache_intensive'
        ]
        return random.choice(workload_types)
    
    def run_test_workload(self):
        """运行测试负载并测量性能"""
        # 记录开始时间
        start_time = time.time()
        
        # 根据选择的类型和难度运行对应工作负载
        try:
            if self.current_workload_type == 'memory_intensive':
                runtime, _ = self.memory_workload.run_memory_intensive(self.current_difficulty)
            elif self.current_workload_type == 'io_intensive':
                runtime, _, _ = self.io_workload.run_io_intensive(self.current_difficulty)
            elif self.current_workload_type == 'mixed_workload':
                runtime, _, _, _ = self.mixed_workload.run_mixed_workload(self.current_difficulty)
            elif self.current_workload_type == 'file_cache_intensive':
                runtime, _, _ = self.io_workload.run_file_cache_intensive(self.current_difficulty)
            else:
                # 默认运行混合工作负载
                runtime, _, _, _ = self.mixed_workload.run_mixed_workload(self.current_difficulty)
            
            # 确保 runtime 是数值类型
            runtime = self._process_runtime(runtime, start_time)
            
        except Exception as e:
            self.logger.error(f"Error running workload: {e}")
            # 发生错误时使用默认运行时间
            runtime = time.time() - start_time
        
        self.last_workload_runtime = runtime
        self.runtime_history.append(runtime)
        
        self.logger.info(f"Workload: {self.current_workload_type}, Difficulty: {self.current_difficulty}, Runtime: {runtime}s")
    
    def _process_runtime(self, runtime, start_time):
        """处理运行时间，确保返回数值类型"""
        try:
            # 先检查 runtime 是否为 None
            if runtime is None:
                return time.time() - start_time
                
            # 如果是字符串类型，尝试转换为浮点数
            if isinstance(runtime, str):
                # 检查是否等于或包含难度级别
                if runtime in [self.current_difficulty, self.current_difficulty + "s", "easy", "medium", "hard", "extreme", "easys", "mediums", "hards", "extremes"]:
                    return time.time() - start_time
                    
                # 尝试将字符串转换为浮点数
                try:
                    return float(runtime)
                except (ValueError, TypeError):
                    return time.time() - start_time
                    
            # 确保返回的是数值类型
            return float(runtime)
            
        except (ValueError, TypeError) as e:
            # 如果转换失败，记录警告并使用实际运行时间
            self.logger.warning(f"Invalid runtime value: {runtime}, using elapsed time instead. Error: {e}")
            return time.time() - start_time
    
    def render(self, mode='human'):
        """渲染环境状态（可选）"""
        if mode == 'human':
            # 获取当前状态和参数
            current_state = self.state_collector.get_state()
            current_params = self.action_handler.get_current_parameters()
            
            # 打印关键信息
            print("\n=== Current Environment State ===")
            print(f"Difficulty: {self.current_difficulty}")
            print(f"Workload Type: {self.current_workload_type}")
            
            # 打印关键指标
            key_metrics = [
                'major_page_faults_per_sec', 
                'memory_usage_percent',
                'swap_percent', 
                'swap_in_per_sec', 
                'swap_out_per_sec',
                'system_loadavg_1min'
            ]
            
            print("--- Key Metrics ---")
            for metric in key_metrics:
                if metric in current_state:
                    print(f"{metric}: {current_state[metric]}")
            
            # 打印当前参数设置
            print("--- Current Parameters ---")
            for param, value in current_params.items():
                print(f"{param}: {value}")
            
            # 打印性能信息
            if hasattr(self, 'last_workload_runtime'):
                print(f"\nLast runtime: {self._ensure_numeric(self.last_workload_runtime):.2f}s")
                if self.previous_workload_runtime:
                    try:
                        prev_rt = self._ensure_numeric(self.previous_workload_runtime)
                        curr_rt = self._ensure_numeric(self.last_workload_runtime)
                        if prev_rt > 0:
                            change = (prev_rt - curr_rt) / prev_rt * 100
                            print(f"Change from previous: {change:.1f}%")
                    except (TypeError, ValueError, ZeroDivisionError):
                        print("Could not calculate change (invalid runtime values)")
            
            # 打印奖励信息
            if len(self.reward_history) > 0:
                print(f"Last reward: {self.reward_history[-1]:.2f}")
                print(f"Average reward (last 10): {np.mean(list(self.reward_history)[-10:]):.2f}")
            
            print("===============================\n")
    
    def close(self):
        """关闭环境，恢复初始参数"""
        self.logger.info("Closing environment and restoring parameters...")
        if hasattr(self, 'initial_params'):
            for param, value in self.initial_params.items():
                self.action_handler.set_parameter(param, value)
    
    def get_diagnostic_info(self):
        """获取环境的诊断信息（用于调试和分析）"""
        # 安全地计算运行时间统计
        runtime_stats = {'mean': 0, 'std': 0, 'min': 0, 'max': 0, 'improvement': 0}
        
        try:
            if self.runtime_history:
                # 确保所有运行时间是数值类型
                numeric_runtimes = [self._ensure_numeric(rt) for rt in self.runtime_history]
                
                runtime_stats = {
                    'mean': np.mean(numeric_runtimes),
                    'std': np.std(numeric_runtimes),
                    'min': min(numeric_runtimes),
                    'max': max(numeric_runtimes)
                }
                
                # 计算改进百分比
                if len(numeric_runtimes) > 1 and numeric_runtimes[0] > 0:
                    runtime_stats['improvement'] = ((numeric_runtimes[0] - numeric_runtimes[-1]) / numeric_runtimes[0] * 100)
        except Exception as e:
            self.logger.warning(f"Error calculating runtime statistics: {e}")
        
        info = {
            'difficulty_distribution': self.difficulty_strategy.get_distribution(),
            'performance_history': self.difficulty_strategy.get_performance_history(),
            'reward_stats': {
                'mean': np.mean(self.reward_history) if self.reward_history else 0,
                'std': np.std(self.reward_history) if self.reward_history else 0,
                'min': min(self.reward_history) if self.reward_history else 0,
                'max': max(self.reward_history) if self.reward_history else 0,
            },
            'runtime_stats': runtime_stats
        }
        
        # 如果存在最近的奖励，获取详细计算过程
        if hasattr(self, 'reward_calculator') and self.state_history:
            latest_state = self.state_history[-1]
            prev_runtime = self._ensure_numeric(self.previous_workload_runtime)
            curr_runtime = self._ensure_numeric(self.last_workload_runtime)
            
            info['reward_details'] = self.reward_calculator.get_diagnostic_info(
                latest_state,
                previous_runtime=prev_runtime, 
                current_runtime=curr_runtime,
                workload_type=self.current_workload_type,
                difficulty=self.current_difficulty
            )
        
        return info
