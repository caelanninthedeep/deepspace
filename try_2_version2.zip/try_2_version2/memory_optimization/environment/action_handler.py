import subprocess
import numpy as np
import logging

class ActionHandler:
    """
    处理内存参数调整的执行
    支持PPO连续动作空间，直接接收参数的目标值
    """
    def __init__(self):
        # 定义参数范围
        self.param_ranges = {
            'swappiness': {'min': 0, 'max': 100, 'type': int},
            'vfs_cache_pressure': {'min': 0, 'max': 500, 'type': int},
            'dirty_ratio': {'min': 1, 'max': 60, 'type': int},
            'dirty_background_ratio': {'min': 1, 'max': 50, 'type': int},
            'min_free_kbytes': {'min': 1024, 'max': 1048576, 'type': int},  # 1MB ~ 1GB
            'watermark_scale_factor': {'min': 10, 'max': 1000, 'type': int}
        }
        
        # 设置日志
        logging.basicConfig(level=logging.INFO, 
                           format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger('ActionHandler')
    
    def execute_action(self, action_values):
        """
        执行参数调整动作
        
        Args:
            action_values: 字典，包含参数名和目标值的映射，例如 {'swappiness': 60, 'vfs_cache_pressure': 100}
        
        Returns:
            dict: 实际设置的参数值
        """
        # 获取当前参数
        current_params = self.get_current_parameters()
        applied_values = {}
        
        # 应用动作
        for param, target_value in action_values.items():
            if param not in self.param_ranges:
                self.logger.warning(f"Parameter {param} not in defined ranges, skipping")
                continue
                
            # 确保参数值在合法范围内
            param_range = self.param_ranges[param]
            value_type = param_range['type']
            
            # 转换为正确类型并限制在范围内
            if value_type == int:
                validated_value = int(round(target_value))
            else:
                validated_value = float(target_value)
                
            validated_value = max(param_range['min'], min(validated_value, param_range['max']))
            
            # 特殊情况：dirty_background_ratio必须小于dirty_ratio
            if param == 'dirty_background_ratio' and 'dirty_ratio' in current_params:
                if validated_value >= current_params['dirty_ratio']:
                    validated_value = current_params['dirty_ratio'] - 1
                    self.logger.info(f"Adjusted dirty_background_ratio to {validated_value} to keep it below dirty_ratio")
            
            # 反之，如果调整dirty_ratio，确保它大于dirty_background_ratio
            if param == 'dirty_ratio' and 'dirty_background_ratio' in current_params:
                if validated_value <= current_params['dirty_background_ratio']:
                    validated_value = current_params['dirty_background_ratio'] + 1
                    self.logger.info(f"Adjusted dirty_ratio to {validated_value} to keep it above dirty_background_ratio")
            
            # 设置新参数值
            if validated_value != current_params.get(param):
                success = self.set_parameter(param, validated_value)
                if success:
                    applied_values[param] = validated_value
        
        # 返回实际应用的参数值
        return applied_values
    
    def get_current_parameters(self):
        """获取当前内存子系统参数"""
        params = {}
        
        # 读取所有支持的参数
        param_paths = {
            'swappiness': '/proc/sys/vm/swappiness',
            'vfs_cache_pressure': '/proc/sys/vm/vfs_cache_pressure',
            'dirty_ratio': '/proc/sys/vm/dirty_ratio',
            'dirty_background_ratio': '/proc/sys/vm/dirty_background_ratio',
            'min_free_kbytes': '/proc/sys/vm/min_free_kbytes',
            'watermark_scale_factor': '/proc/sys/vm/watermark_scale_factor'
        }
        
        for param, path in param_paths.items():
            try:
                with open(path, 'r') as f:
                    value = f.read().strip()
                    value_type = self.param_ranges[param]['type']
                    params[param] = value_type(value)
            except Exception as e:
                self.logger.error(f"Error reading parameter {param}: {e}")
        
        return params
    
    def set_parameter(self, param, value):
        """
        设置内存子系统参数
        
        Args:
            param: 参数名称
            value: 参数值
            
        Returns:
            bool: 是否成功设置参数
        """
        try:
            # 使用sysctl命令设置
            subprocess.run(['sudo', 'sysctl', f'vm.{param}={value}'], 
                         check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
            self.logger.info(f"Set {param} to {value}")
            return True
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Error setting parameter {param}: {e}")
            return False
    
    def get_normalized_state(self):
        """
        获取当前参数的归一化状态向量
        用于观察空间
        
        Returns:
            np.array: 归一化的参数值数组
        """
        params = self.get_current_parameters()
        norm_state = []
        
        for param, config in self.param_ranges.items():
            if param in params:
                # 将参数归一化到[-1, 1]范围
                min_val = config['min']
                max_val = config['max']
                value = params[param]
                norm_value = 2 * (value - min_val) / (max_val - min_val) - 1
                norm_state.append(norm_value)
            else:
                # 如果无法获取参数，使用0（中间值）
                norm_state.append(0)
        
        return np.array(norm_state)
    
    def apply_param_values(self, param_dict):
        """
        应用一组参数值
        
        Args:
            param_dict: 字典，参数名称和值的映射
            
        Returns:
            dict: 实际应用的参数值
        """
        return self.execute_action(param_dict)
    
    def validate_parameters(self, params):
        """
        验证参数值是否合法
        
        Args:
            params: 字典，参数名称和值的映射
            
        Returns:
            dict: 经过验证和调整后的参数值
        """
        validated = {}
        for param, value in params.items():
            if param in self.param_ranges:
                param_range = self.param_ranges[param]
                if param_range['type'] == int:
                    value = int(round(value))
                value = max(param_range['min'], min(value, param_range['max']))
                validated[param] = value
        
        # 确保dirty_ratio > dirty_background_ratio
        if 'dirty_ratio' in validated and 'dirty_background_ratio' in validated:
            if validated['dirty_ratio'] <= validated['dirty_background_ratio']:
                validated['dirty_ratio'] = validated['dirty_background_ratio'] + 1
                self.logger.info(f"Adjusted dirty_ratio to {validated['dirty_ratio']} to maintain consistency")
        
        return validated
    
    def get_parameter_dimensions(self):
        """
        返回参数空间维度（用于构建观察空间）
        
        Returns:
            int: 参数数量
        """
        return len(self.param_ranges)
