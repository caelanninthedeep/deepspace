# gym_env.py
import gym
from gym import spaces
import numpy as np
from environment.mem_env import MemoryOptimizationEnv
from state_normalizer import StateNormalizer
from action_mapper import ActionMapper

class MemoryGymEnv(gym.Env):
    metadata = {'render.modes': ['human']}
    
    def __init__(self, config=None):
        super(MemoryGymEnv, self).__init__()
        
        # 初始化环境组件
        self.mem_env = MemoryOptimizationEnv(config or {})
        self.state_normalizer = StateNormalizer()
        self.action_mapper = ActionMapper()
        
        # 定义动作空间 (9个离散动作)
        self.action_space = spaces.Discrete(self.action_mapper.get_action_space_size())
        
        # 定义状态空间 (12维归一化向量)
        self.observation_space = spaces.Box(
            low=0, high=1, 
            shape=(12,), 
            dtype=np.float32
        )
        
        # 当前状态
        self.current_state = None
        
    def reset(self):
        """重置环境并返回初始状态"""
        raw_state = self.mem_env.reset()
        self.current_state = self.state_normalizer.get_normalized_state()
        return self.current_state
    
    def step(self, action):
        """执行一步动作"""
        # 映射离散动作到参数调整
        action_dict = self.action_mapper.map_action(action)
        
        # 执行动作
        _, reward, done, info = self.mem_env.step(action_dict)
        
        # 获取新状态
        self.current_state = self.state_normalizer.get_normalized_state()
        
        return self.current_state, reward, done, info
    
    def render(self, mode='human'):
        """可选：实现环境可视化"""
        if mode == 'human':
            print(f"Current State: {self.current_state}")
            print(f"Last Reward: {self.mem_env.reward_history[-1] if self.mem_env.reward_history else 0}")
            print(f"Workload Runtime: {self.mem_env.last_workload_runtime:.2f}s")
    
    def close(self):
        """关闭环境并恢复参数"""
        self.mem_env.close()
        
    def get_raw_state(self):
        """获取原始状态字典（用于调试）"""
        return self.state_normalizer.state_collector.get_state()
