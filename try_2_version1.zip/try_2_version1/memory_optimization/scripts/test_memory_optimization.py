"""
测试训练好的内存优化代理
"""
import torch
import numpy as np

from memory_optimization.environment.mem_env import MemoryOptimizationEnv
from memory_optimization.algorithms.ppo import PPO

def test_agent(model_path, episodes=10, render=True):
    """
    测试训练好的代理
    
    Args:
        model_path (str): 模型路径
        episodes (int): 测试回合数
        render (bool): 是否渲染环境
    """
    # 创建环境
    env = MemoryOptimizationEnv()
    
    # 获取状态和动作维度
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n
    
    # 初始化代理
    agent = PPO(state_dim, action_dim)
    
    # 加载模型
    agent.load(model_path)
    print(f"加载模型: {model_path}")
    
    # 测试循环
    total_rewards = []
    
    for episode in range(1, episodes + 1):
        state = env.reset()
        episode_reward = 0
        done = False
        step = 0
        
        while not done:
            # 根据策略选择动作
            action = agent.select_action(state)
            
            # 执行动作
            next_state, reward, done, _ = env.step(action)
            
            # 渲染环境
            if render:
                env.render()
                
            # 更新状态和奖励
            state = next_state
            episode_reward += reward
            step += 1
        
        # 记录总奖励
        total_rewards.append(episode_reward)
        print(f"回合 {episode}/{episodes} | 总奖励: {episode_reward:.2f} | 步数: {step}")
    
    # 打印平均奖励
    avg_reward = np.mean(total_rewards)
    print(f"\n===== 测试结果 =====")
    print(f"平均奖励: {avg_reward:.2f} ± {np.std(total_rewards):.2f}")
    
    return total_rewards

if __name__ == "__main__":
    # 测试代理
    rewards = test_agent("models/ppo_memory_opt_final.pt")
