"""
使用PPO算法训练内存优化代理
"""
import os
import time
import numpy as np
import torch
from collections import deque

from memory_optimization.environment.mem_env import MemoryOptimizationEnv
from memory_optimization.algorithms.ppo import PPO

def train(max_episodes=1000, max_steps=1000, 
          batch_size=64, update_interval=100,
          save_interval=100, log_interval=10):
    """
    训练内存优化代理
    
    Args:
        max_episodes (int): 最大训练回合数
        max_steps (int): 每个回合的最大步数
        batch_size (int): 批量大小
        update_interval (int): 更新间隔（步数）
        save_interval (int): 保存模型间隔（回合数）
        log_interval (int): 日志记录间隔（回合数）
    """
    # 创建环境
    env = MemoryOptimizationEnv()
    
    # 创建保存目录
    os.makedirs("models", exist_ok=True)
    
    # 获取状态和动作维度
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n
    
    print(f"状态维度: {state_dim}, 动作维度: {action_dim}")
    
    # 初始化PPO算法
    agent = PPO(state_dim, action_dim)
    
    # 记录训练数据
    episode_rewards = []
    avg_rewards = deque(maxlen=log_interval)
    
    # 训练循环
    start_time = time.time()
    total_steps = 0
    
    for episode in range(1, max_episodes + 1):
        state = env.reset()
        episode_reward = 0
        
        # 存储每一步的数据
        states = []
        actions = []
        rewards = []
        next_states = []
        dones = []
        
        for step in range(1, max_steps + 1):
            # 选择动作
            action = agent.select_action(state)
            
            # 执行动作
            next_state, reward, done, _ = env.step(action)
            
            # 存储数据
            states.append(state)
            actions.append(action)
            rewards.append(reward)
            next_states.append(next_state)
            dones.append(done)
            
            # 更新状态
            state = next_state
            episode_reward += reward
            total_steps += 1
            
            # 判断是否结束回合
            if done or step == max_steps:
                break
                
            # 定期更新
            if total_steps % update_interval == 0:
                agent.update(states, actions, rewards, next_states, dones)
                states, actions, rewards, next_states, dones = [], [], [], [], []
        
        # 如果还有未处理的数据
        if states:
            agent.update(states, actions, rewards, next_states, dones)
            
        # 记录奖励
        episode_rewards.append(episode_reward)
        avg_rewards.append(episode_reward)
        
        # 打印日志
        if episode % log_interval == 0:
            avg_reward = np.mean(avg_rewards)
            elapsed_time = time.time() - start_time
            print(f"回合: {episode}/{max_episodes} | "
                  f"总步数: {total_steps} | "
                  f"平均奖励: {avg_reward:.2f} | "
                  f"用时: {elapsed_time:.2f}s")
            
        # 保存模型
        if episode % save_interval == 0:
            agent.save(f"models/ppo_memory_opt_episode_{episode}.pt")
    
    # 保存最终模型
    agent.save("models/ppo_memory_opt_final.pt")
    print(f"训练完成! 总共耗时: {time.time() - start_time:.2f}s")
    
    return agent, episode_rewards

if __name__ == "__main__":
    # 执行训练
    agent, rewards = train()
    
    # 绘制奖励曲线
    try:
        import matplotlib.pyplot as plt
        plt.figure(figsize=(10, 5))
        plt.plot(rewards)
        plt.title('Training Rewards')
        plt.xlabel('Episode')
        plt.ylabel('Reward')
        plt.savefig('rewards.png')
        plt.show()
    except ImportError:
        print("matplotlib not found, skipping plot")
