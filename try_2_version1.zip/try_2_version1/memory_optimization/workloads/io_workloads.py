"""
I/O相关工作负载模块
"""

import os
import random
import time
import mmap
import subprocess

class IOWorkload:
    def __init__(self):
        self.temp_root = "/tmp/rl_mem_test"
        os.makedirs(self.temp_root, exist_ok=True)
        
    def run_io_intensive(self):
        """I/O密集型工作负载"""
        # 创建临时文件夹
        temp_dir = os.path.join(self.temp_root, "io_test")
        os.makedirs(temp_dir, exist_ok=True)
        
        # 生成多个文件并随机读写
        num_files = random.randint(5, 20)
        file_size_mb = random.randint(10, 100)
        
        print(f"[IO Workload] Creating {num_files} files of {file_size_mb}MB each...")
        
        # 创建文件
        files = []
        for i in range(num_files):
            filename = f"{temp_dir}/test_file_{i}.dat"
            with open(filename, 'wb') as f:
                f.write(os.urandom(file_size_mb * 1024 * 1024))
            files.append(filename)
        
        # 随机读取文件
        for _ in range(50):
            filename = random.choice(files)
            with open(filename, 'rb') as f:
                # 随机读取位置
                f.seek(random.randint(0, file_size_mb * 1024 * 1024 - 1024))
                _ = f.read(1024)
        
        # 清理文件
        for filename in files:
            try:
                os.remove(filename)
            except:
                pass
                
        try:
            os.rmdir(temp_dir)
        except:
            pass
            
    def run_file_cache_intensive(self):
        """文件缓存密集型工作负载"""
        temp_dir = os.path.join(self.temp_root, "cache_test")
        os.makedirs(temp_dir, exist_ok=True)
        
        # 创建很多小文件，测试dentry和inode缓存
        num_files = random.randint(500, 3000)
        print(f"[Cache Workload] Creating and accessing {num_files} small files...")
        
        # 创建文件
        filenames = []
        for i in range(num_files):
            filename = f"{temp_dir}/small_file_{i}.txt"
            with open(filename, 'w') as f:
                f.write(f"test content {i}")
            filenames.append(filename)
        
        # 随机访问文件
        for _ in range(min(1000, num_files)):
            filename = random.choice(filenames)
            with open(filename, 'r') as f:
                _ = f.read()
        
        # 清理一半的文件
        for filename in random.sample(filenames, num_files // 2):
            try:
                os.remove(filename)
                filenames.remove(filename)
            except:
                pass
        
        # 再次随机访问剩余文件
        for _ in range(min(500, len(filenames))):
            filename = random.choice(filenames)
            with open(filename, 'r') as f:
                _ = f.read()
        
        # 清理所有文件
        for filename in filenames:
            try:
                os.remove(filename)
            except:
                pass
                
        try:
            os.rmdir(temp_dir)
        except:
            pass
            
    def mmap_test(self):
        """mmap文件模拟测试"""
        print("[mmap] Accessing via mmap...")
        mmap_file = os.path.join(self.temp_root, "mmap_test")
        
        with open(mmap_file, "wb") as f:
            f.write(b'\x00' * 1024 * 1024)
        
        with open(mmap_file, "r+b") as f:
            mm = mmap.mmap(f.fileno(), 0)
            for _ in range(100000):
                mm[random.randint(0, 1024 * 1024 - 1)] = b'\x01'[0]
            mm.close()
        
        try:
            os.remove(mmap_file)
        except:
            pass
            
    def drop_caches(self):
        """清除文件系统缓存"""
        print("[Sys] Dropping filesystem caches...")
        try:
            subprocess.run(['sudo', 'sync'], check=True)
            subprocess.run(['sudo', 'bash', '-c', 'echo 3 > /proc/sys/vm/drop_caches'], 
                          check=True)
            return True
        except subprocess.CalledProcessError as e:
            print(f"Error dropping caches: {e}")
            return False