"""
混合类工作负载模块
"""

import os
import random
import time
import subprocess

class MixedWorkload:
    def __init__(self):
        self.temp_root = "/tmp/rl_mem_test"
        os.makedirs(self.temp_root, exist_ok=True)
    
    def run_mixed_workload(self):
        """混合型工作负载，结合内存和IO操作"""
        print("[Mixed Workload] Running mixed memory+IO workload...")
        
        # 内存部分
        size_mb = random.randint(50, 500)
        memory_data = bytearray(size_mb * 1024 * 1024)
        
        # IO部分
        temp_dir = os.path.join(self.temp_root, "mixed_test")
        os.makedirs(temp_dir, exist_ok=True)
        
        num_files = random.randint(2, 10)
        file_size_mb = random.randint(5, 50)
        
        # 创建文件
        files = []
        for i in range(num_files):
            filename = f"{temp_dir}/test_file_mixed_{i}.dat"
            with open(filename, 'wb') as f:
                f.write(os.urandom(file_size_mb * 1024 * 1024))
            files.append(filename)
        
        # 交替执行内存和IO操作
        for _ in range(50):
            # 内存访问
            for _ in range(1000):
                index = random.randint(0, len(memory_data) - 1)
                memory_data[index] = random.randint(0, 255)
            
            # 文件访问
            filename = random.choice(files)
            with open(filename, 'rb') as f:
                f.seek(random.randint(0, file_size_mb * 1024 * 1024 - 1024))
                _ = f.read(1024)
        
        # 清理文件
        for filename in files:
            try:
                os.remove(filename)
            except:
                pass
                
        try:
            os.rmdir(temp_dir)
        except:
            pass
            
        # 释放内存
        del memory_data
    
    def run_network_memory_workload(self):
        """网络和内存混合负载"""
        print("[Mixed] Network + Memory workload...")
        
        # 内存部分
        size_mb = random.randint(50, 300)
        memory_data = bytearray(size_mb * 1024 * 1024)
        
        # 网络部分（模拟，实际效果可能不明显）
        ping_count = random.randint(5, 20)
        try:
            subprocess.run(['ping', '-c', str(ping_count), 'google.com'],
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:
            print(f"Network operation error: {e}")
            
        # 访问内存
        for _ in range(5000):
            index = random.randint(0, len(memory_data) - 1)
            memory_data[index] = random.randint(0, 255)
            
        # 释放内存
        del memory_data
        
    def run_cpu_memory_workload(self):
        """CPU和内存混合负载"""
        print("[Mixed] CPU + Memory workload...")
        
        # 内存部分
        size_mb = random.randint(50, 400)
        memory_data = bytearray(size_mb * 1024 * 1024)
        
        # CPU密集计算
        matrix_size = 500
        matrix_a = [[random.random() for _ in range(matrix_size)] for _ in range(matrix_size)]
        matrix_b = [[random.random() for _ in range(matrix_size)] for _ in range(matrix_size)]
        
        # 计算部分矩阵乘法
        for i in range(100):
            for j in range(100):
                result = sum(matrix_a[i][k] * matrix_b[k][j] for k in range(matrix_size))
                
                # 同时访问内存
                if i % 10 == 0:
                    for _ in range(1000):
                        index = random.randint(0, len(memory_data) - 1)
                        memory_data[index] = random.randint(0, 255)
                        
        # 释放内存
        del memory_data
        del matrix_a
        del matrix_b