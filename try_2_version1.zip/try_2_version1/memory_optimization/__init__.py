"""
内存优化强化学习项目

这个项目使用强化学习来优化内存管理策略，包括页面置换、内存分配等。
"""

from .environment import MemoryOptimizationEnv
from .algorithms import PPO
from .core import MemoryManager
from .utils import ConfigManager, ExperimentLogger

__version__ = "0.1.0"

__all__ = [
    'MemoryOptimizationEnv',
    'PPO',
    'MemoryManager',
    'ConfigManager',
    'ExperimentLogger'
] 