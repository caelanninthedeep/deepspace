"""
内存管理器类
"""

import numpy as np
import psutil

class MemoryManager:
    def __init__(self):
        self.memory = psutil.virtual_memory()
        self.swap = psutil.swap_memory()
        
    def get_memory_info(self):
        """获取内存信息"""
        return {
            'total': self.memory.total,
            'available': self.memory.available,
            'used': self.memory.used,
            'free': self.memory.free,
            'percent': self.memory.percent
        }
        
    def get_swap_info(self):
        """获取交换空间信息"""
        return {
            'total': self.swap.total,
            'used': self.swap.used,
            'free': self.swap.free,
            'percent': self.swap.percent
        }
        
    def get_memory_usage(self):
        """获取内存使用率"""
        return self.memory.percent
        
    def get_swap_usage(self):
        """获取交换空间使用率"""
        return self.swap.percent 