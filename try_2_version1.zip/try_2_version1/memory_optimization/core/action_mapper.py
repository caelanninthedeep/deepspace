# action_mapper.py
class ActionMapper:
    def __init__(self):
        # 定义参数组
        self.param_groups = {
            'swappiness': {'min': 0, 'max': 100, 'step': 10},
            'vfs_cache_pressure': {'min': 0, 'max': 500, 'step': 25},
            'dirty_ratio': {'min': 1, 'max': 60, 'step': 5},
            'dirty_background_ratio': {'min': 1, 'max': 50, 'step': 3},
        }
        
        # 压缩动作映射 (0-8)
        self.action_map = {
            0: {'swappiness': '0', 'vfs_cache_pressure': '0', 
                'dirty_ratio': '0', 'dirty_background_ratio': '0'},  # 无操作
                
            1: {'swappiness': '+', 'vfs_cache_pressure': '0', 
                'dirty_ratio': '0', 'dirty_background_ratio': '0'},  # 仅增加swappiness
                
            2: {'swappiness': '-', 'vfs_cache_pressure': '0', 
                'dirty_ratio': '0', 'dirty_background_ratio': '0'},  # 仅减少swappiness
                
            3: {'swappiness': '0', 'vfs_cache_pressure': '+', 
                'dirty_ratio': '0', 'dirty_background_ratio': '0'},  # 仅增加cache_pressure
                
            4: {'swappiness': '0', 'vfs_cache_pressure': '-', 
                'dirty_ratio': '0', 'dirty_background_ratio': '0'},  # 仅减少cache_pressure
                
            5: {'swappiness': '0', 'vfs_cache_pressure': '0', 
                'dirty_ratio': '+', 'dirty_background_ratio': '+'},  # 同时增加dirty参数
                
            6: {'swappiness': '0', 'vfs_cache_pressure': '0', 
                'dirty_ratio': '-', 'dirty_background_ratio': '-'},  # 同时减少dirty参数
                
            7: {'swappiness': '0', 'vfs_cache_pressure': '0', 
                'dirty_ratio': '0', 'dirty_background_ratio': '+'},  # 仅增加dirty_bg_ratio
                
            8: {'swappiness': '0', 'vfs_cache_pressure': '0', 
                'dirty_ratio': '0', 'dirty_background_ratio': '-'},  # 仅减少dirty_bg_ratio
        }
    
    def map_action(self, action_id):
        """将离散动作ID映射为参数调整字典"""
        return self.action_map.get(action_id, self.action_map[0])
    
    def get_action_space_size(self):
        """获取动作空间大小"""
        return len(self.action_map)
