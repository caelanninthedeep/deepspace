"""
计算奖励的模块
"""

import numpy as np

class RewardCalculator:
    def __init__(self):
        # 可以定义不同指标的权重
        self.weights = {
            'major_page_faults': -5.0,  # 每个major页面错误的惩罚
            'minor_page_faults': -0.01, # 每个minor页面错误的惩罚（权重较低）
            'memory_usage': 1.0,        # 内存使用的权重
            'swap_usage': -2.0,         # swap使用的权重
            'swap_io': -3.0,            # swap I/O的权重
            'runtime': -10.0,           # 运行时间的权重（越短越好）
        }
    
    def calculate_reward(self, state, previous_runtime=None, current_runtime=None):
        """
        根据内存子系统性能指标计算奖励
        
        Args:
            state: 当前系统状态
            previous_runtime: 上一次工作负载运行时间
            current_runtime: 当前工作负载运行时间
            
        Returns:
            float: 计算得到的奖励值
        """
        reward = 0
        
        # --- 优化目标1：减少页面错误 ---
        # 主页面错误越少越好（高权重）
        major_faults = state.get('major_page_faults_per_sec', 0)
        if major_faults == 0:
            reward += 50  # 无主页面错误，很好
        elif major_faults < 10:
            reward += 30  # 少量主页面错误，可接受
        elif major_faults < 100:
            reward += 0   # 一般水平
        else:
            reward -= 50  # 严重的主页面错误问题
        
        # 次要页面错误（低权重）
        minor_faults = state.get('minor_page_faults_per_sec', 0)
        if minor_faults < 100:
            reward += 10
        elif minor_faults < 1000:
            reward += 5
        
        # 可用内存量（中等权重）
        free_mem = state.get('free_memory_MB', 0)
        total_mem = state.get('memory_total_MB', 1)
        free_mem_percent = (free_mem / total_mem) * 100 if total_mem > 0 else 0
        
        if free_mem_percent > 30:
            reward += 20  # 内存充足
        elif free_mem_percent > 15:
            reward += 10  # 内存状态良好
        elif free_mem_percent > 5:
            reward += 0   # 一般水平
        else:
            reward -= 30  # 内存紧张
        
        # --- 优化目标2：降低Swap使用 ---
        swap_used = state.get('swap_used_MB', 0)
        total_swap = state.get('swap_total_MB', 1)
        swap_used_percent = (swap_used / total_swap) * 100 if total_swap > 0 else 0
        
        if swap_used_percent == 0:
            reward += 30  # 无swap使用
        elif swap_used_percent < 10:
            reward += 15  # 少量使用
        elif swap_used_percent < 30:
            reward += 0   # 一般水平
        else:
            reward -= 30  # 大量使用swap
        
        # swap I/O频率（高权重）
        swap_io = state.get('swap_in_per_sec', 0) + state.get('swap_out_per_sec', 0)
        if swap_io == 0:
            reward += 40  # 无swap I/O
        elif swap_io < 10:
            reward += 20  # 少量swap I/O
        elif swap_io < 50:
            reward -= 10  # 明显的swap I/O
        else:
            reward -= 50  # 频繁的swap I/O，严重影响性能
        
        # --- 优化目标3：优化内存分配/释放行为（可选，权重较低）---
        # 这里简单处理，根据项目需要可以进一步细化
        
        # --- 优化目标4：提升任务运行性能 ---
        # 系统负载（中等权重）
        load = state.get('system_loadavg_1min', 0)
        cpu_count = state.get('cpu_count', 1)  # 理想情况下应该获取CPU核心数
        load_ratio = load / cpu_count if cpu_count > 0 else load
        
        if load_ratio < 0.5:
            reward += 20  # 系统负载低
        elif load_ratio < 1:
            reward += 10  # 负载适中
        elif load_ratio < 2:
            reward -= 10  # 负载较高
        else:
            reward -= 30  # 负载过高
        
        # 工作负载运行时间（高权重）
        if previous_runtime is not None and current_runtime is not None:
            runtime_change = previous_runtime - current_runtime
            if abs(runtime_change) < 0.1:  # 变化不大
                reward += 0
            elif runtime_change > 0:  # 运行更快了
                improvement_percent = (runtime_change / previous_runtime) * 100
                reward += min(50, int(improvement_percent * 5))  # 每提升1%加5分，最高50
            else:  # 运行更慢了
                degradation_percent = (-runtime_change / previous_runtime) * 100
                reward -= min(50, int(degradation_percent * 5))  # 每下降1%减5分，最多减50
        
        return reward