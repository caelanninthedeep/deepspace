"""
PPO (Proximal Policy Optimization) 实现
"""
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from .networks import PolicyNetwork, ValueNetwork

class PPO:
    """
    PPO (Proximal Policy Optimization) 算法的实现
    
    特点:
    - 使用裁剪目标函数避免过大的策略更新
    - 分离策略网络和价值网络
    - 使用GAE (Generalized Advantage Estimation)
    """
    
    def __init__(self, state_dim, action_dim, 
                 lr=3e-4, gamma=0.99, 
                 clip_ratio=0.2, value_coef=0.5, 
                 entropy_coef=0.01, gae_lambda=0.95):
        """
        初始化PPO算法
        
        Args:
            state_dim (int): 状态空间维度
            action_dim (int): 动作空间维度
            lr (float): 学习率
            gamma (float): 折扣因子
            clip_ratio (float): PPO裁剪参数
            value_coef (float): 价值损失系数
            entropy_coef (float): 熵正则化系数
            gae_lambda (float): GAE lambda参数
        """
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.clip_ratio = clip_ratio
        self.value_coef = value_coef
        self.entropy_coef = entropy_coef
        self.gae_lambda = gae_lambda
        
        # 初始化网络
        self.policy_net = PolicyNetwork(state_dim, action_dim)
        self.value_net = ValueNetwork(state_dim)
        
        # 初始化优化器
        self.policy_optimizer = optim.Adam(self.policy_net.parameters(), lr=lr)
        self.value_optimizer = optim.Adam(self.value_net.parameters(), lr=lr)
        
        # 设置设备
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.policy_net.to(self.device)
        self.value_net.to(self.device)
        
    def select_action(self, state):
        """
        根据当前策略选择动作
        
        Args:
            state (np.ndarray): 状态
            
        Returns:
            int: 选择的动作索引
        """
        state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        with torch.no_grad():
            action_probs = self.policy_net(state_tensor)
            
        # 根据概率分布采样动作
        action = torch.multinomial(action_probs, 1).item()
        return action
    
    def compute_returns(self, rewards, dones, next_value=0.0):
        """
        计算每个时间步的折扣回报
        
        Args:
            rewards (list): 奖励序列
            dones (list): 终止标志序列
            next_value (float): 最后状态的估计价值
            
        Returns:
            torch.Tensor: 每个时间步的折扣回报
        """
        # 从后向前简单计算折扣回报
        returns = []
        R = next_value
        
        for r, done in zip(reversed(rewards), reversed(dones)):
            R = r + self.gamma * R * (1 - done)
            returns.insert(0, R)
        
        return torch.FloatTensor(returns)
    
    def update(self, states, actions, rewards, next_states, dones):
        """
        使用PPO算法更新策略和价值网络
        
        Args:
            states (list): 状态序列
            actions (list): 动作序列
            rewards (list): 奖励序列
            next_states (list): 下一状态序列
            dones (list): 终止标志序列
        """
        # 转换为张量
        states_tensor = torch.FloatTensor(np.array(states)).to(self.device)
        actions_tensor = torch.LongTensor(actions).to(self.device)
        rewards_tensor = torch.FloatTensor(rewards).to(self.device)
        dones_tensor = torch.FloatTensor(dones).to(self.device)
        
        # 计算价值
        with torch.no_grad():
            values = self.value_net(states_tensor).squeeze(-1)
            if len(next_states) > 0:
                next_state_tensor = torch.FloatTensor(next_states[-1]).unsqueeze(0).to(self.device)
                next_value = self.value_net(next_state_tensor).item()
            else:
                next_value = 0.0
        
        # 计算优势函数和回报
        returns = self.compute_returns(rewards, dones, next_value)
        returns = returns.to(self.device)
        advantages = returns - values
        
        # 保存旧策略的动作概率
        with torch.no_grad():
            old_action_probs = self.policy_net(states_tensor).gather(1, actions_tensor.unsqueeze(-1)).detach()
            
        # 多次更新策略和价值网络
        for _ in range(10):  # 执行多次更新
            # 计算当前策略的动作概率
            action_probs = self.policy_net(states_tensor)
            curr_action_probs = action_probs.gather(1, actions_tensor.unsqueeze(-1))
            
            # 计算ratio
            ratio = curr_action_probs / old_action_probs
            
            # 计算裁剪后的目标函数
            surr1 = ratio * advantages.unsqueeze(-1)
            surr2 = torch.clamp(ratio, 1 - self.clip_ratio, 1 + self.clip_ratio) * advantages.unsqueeze(-1)
            
            # 计算策略损失
            policy_loss = -torch.min(surr1, surr2).mean()
            
            # 熵正则化
            entropy = -torch.sum(action_probs * torch.log(action_probs + 1e-10), dim=-1).mean()
            
            # 更新策略网络
            self.policy_optimizer.zero_grad()
            (policy_loss - self.entropy_coef * entropy).backward()
            self.policy_optimizer.step()
            
            # 计算价值损失
            value_preds = self.value_net(states_tensor).squeeze(-1)
            value_loss = nn.MSELoss()(value_preds, returns)
            
            # 更新价值网络
            self.value_optimizer.zero_grad()
            (self.value_coef * value_loss).backward()
            self.value_optimizer.step()
    
    def save(self, path):
        """
        保存模型
        
        Args:
            path (str): 保存路径
        """
        torch.save({
            'policy_net': self.policy_net.state_dict(),
            'value_net': self.value_net.state_dict(),
            'policy_optimizer': self.policy_optimizer.state_dict(),
            'value_optimizer': self.value_optimizer.state_dict(),
        }, path)
    
    def load(self, path):
        """
        加载模型
        
        Args:
            path (str): 模型路径
        """
        checkpoint = torch.load(path)
        self.policy_net.load_state_dict(checkpoint['policy_net'])
        self.value_net.load_state_dict(checkpoint['value_net'])
        self.policy_optimizer.load_state_dict(checkpoint['policy_optimizer'])
        self.value_optimizer.load_state_dict(checkpoint['value_optimizer'])
