"""
强化学习的神经网络模型
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

class PolicyNetwork(nn.Module):
    """策略网络：将状态映射到动作概率分布"""
    
    def __init__(self, state_dim, action_dim, hidden_dim=128):
        """
        初始化策略网络
        
        Args:
            state_dim (int): 状态空间维度
            action_dim (int): 动作空间维度
            hidden_dim (int): 隐藏层维度
        """
        super(PolicyNetwork, self).__init__()
        
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, action_dim)
        
    def forward(self, state):
        """
        前向传播
        
        Args:
            state (torch.Tensor): 状态张量
            
        Returns:
            torch.Tensor: 动作概率分布
        """
        x = F.relu(self.fc1(state))
        x = F.relu(self.fc2(x))
        action_probs = F.softmax(self.fc3(x), dim=-1)
        return action_probs
    
class ValueNetwork(nn.Module):
    """价值网络：将状态映射到价值估计"""
    
    def __init__(self, state_dim, hidden_dim=128):
        """
        初始化价值网络
        
        Args:
            state_dim (int): 状态空间维度
            hidden_dim (int): 隐藏层维度
        """
        super(ValueNetwork, self).__init__()
        
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, 1)
        
    def forward(self, state):
        """
        前向传播
        
        Args:
            state (torch.Tensor): 状态张量
            
        Returns:
            torch.Tensor: 状态价值估计
        """
        x = F.relu(self.fc1(state))
        x = F.relu(self.fc2(x))
        value = self.fc3(x)
        return value
