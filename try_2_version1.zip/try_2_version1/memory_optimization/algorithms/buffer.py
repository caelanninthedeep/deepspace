"""
存储和采样训练数据的缓冲区
"""
import random
import numpy as np
from collections import deque

class ReplayBuffer:
    """经验回放缓冲区，用于存储和采样训练数据"""
    
    def __init__(self, capacity=10000):
        """
        初始化回放缓冲区
        
        Args:
            capacity (int): 缓冲区容量
        """
        self.buffer = deque(maxlen=capacity)
        self.capacity = capacity
        
    def push(self, state, action, reward, next_state, done):
        """
        将经验添加到缓冲区
        
        Args:
            state: 当前状态
            action: 执行的动作
            reward: 获得的奖励
            next_state: 下一个状态
            done: 是否为终止状态
        """
        self.buffer.append((state, action, reward, next_state, done))
        
    def sample(self, batch_size):
        """
        随机采样批量经验
        
        Args:
            batch_size (int): 批量大小
            
        Returns:
            tuple: (states, actions, rewards, next_states, dones)
        """
        batch = random.sample(self.buffer, min(len(self.buffer), batch_size))
        states, actions, rewards, next_states, dones = zip(*batch)
        
        return states, actions, rewards, next_states, dones
    
    def __len__(self):
        """返回缓冲区中的经验数量"""
        return len(self.buffer)
