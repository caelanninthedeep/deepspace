"""
混合均衡策略测试脚本
"""
import matplotlib.pyplot as plt
import numpy as np
from memory_optimization.strategy.hybrid_balanced_strategy import HybridBalancedStrategy

def test_hybrid_strategy():
    """测试混合均衡策略的适应性"""
    # 初始化策略
    strategy = HybridBalancedStrategy(adaptation_rate=0.1)
    
    # 记录数据
    difficulty_history = []
    distribution_history = []
    success_rate_history = []
    
    # 模拟200个步骤
    for i in range(200):
        # 选择难度
        difficulty = strategy.select_difficulty()
        difficulty_history.append(difficulty)
        
        # 记录当前分布
        distribution_history.append(strategy.get_distribution().copy())
        
        # 模拟成功率随难度变化
        # easy: 90% 成功, medium: 70% 成功, hard: 50% 成功, extreme: 30% 成功
        success_rates = {'easy': 0.9, 'medium': 0.7, 'hard': 0.5, 'extreme': 0.3}
        success = np.random.random() < success_rates[difficulty]
        
        # 更新性能
        strategy.update_performance(difficulty, success)
        
        # 记录成功率
        success_rate_history.append(strategy.get_success_rates().copy())
        
        # 输出每10步的状态
        if (i + 1) % 20 == 0:
            print(f"Step {i+1}:")
            print(f"  Distribution: {strategy.get_distribution()}")
            print(f"  Success Rates: {strategy.get_success_rates()}")
    
    # 可视化结果
    plot_strategy_results(difficulty_history, distribution_history, success_rate_history)

def plot_strategy_results(difficulties, distributions, success_rates):
    """绘制策略结果图表"""
    plt.figure(figsize=(15, 10))
    
    # 难度选择频率
    plt.subplot(3, 1, 1)
    difficulty_counts = {'easy': [], 'medium': [], 'hard': [], 'extreme': []}
    window_size = 20
    
    for i in range(len(difficulties)):
        if i >= window_size:
            window = difficulties[i-window_size:i]
            for diff in ['easy', 'medium', 'hard', 'extreme']:
                difficulty_counts[diff].append(window.count(diff) / window_size)
    
    x = range(window_size, len(difficulties))
    for diff, counts in difficulty_counts.items():
        plt.plot(x, counts, label=diff)
    
    plt.title('Difficulty Selection Frequency (Moving Window)')
    plt.xlabel('Steps')
    plt.ylabel('Frequency')
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.7)
    
    # 难度分布变化
    plt.subplot(3, 1, 2)
    x = range(len(distributions))
    for diff in ['easy', 'medium', 'hard', 'extreme']:
        values = [d[diff] for d in distributions]
        plt.plot(x, values, label=diff)
    
    plt.title('Difficulty Distribution Evolution')
    plt.xlabel('Steps')
    plt.ylabel('Probability')
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.7)
    
    # 成功率变化
    plt.subplot(3, 1, 3)
    x = range(len(success_rates))
    for diff in ['easy', 'medium', 'hard', 'extreme']:
        values = [d[diff] for d in success_rates]
        plt.plot(x, values, label=diff)
    
    plt.title('Success Rate Evolution')
    plt.xlabel('Steps')
    plt.ylabel('Success Rate')
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.7)
    
    plt.tight_layout()
    plt.savefig('hybrid_strategy_test.png')
    plt.show()

if __name__ == "__main__":
    test_hybrid_strategy()
