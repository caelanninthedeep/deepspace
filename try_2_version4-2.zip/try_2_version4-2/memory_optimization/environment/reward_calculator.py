import numpy as np
from collections import deque
from typing import Dict, Any, List, Optional

class MultiAgentRewardCalculator:
    def __init__(self, history_length=10):
        # 基础权重配置
        self.weights = {
            'major_page_faults': -5.0,
            'minor_page_faults': -0.01,
            'memory_usage': 1.0,
            'swap_usage': -2.0,
            'swap_io': -3.0,
            'runtime': -10.0,
        }
        
        # 保存状态历史，用于计算趋势
        self.state_history = deque(maxlen=history_length)
        
        # 工作负载适应性权重
        self.workload_weights = {
            'memory_intensive': {
                'major_page_faults': -6.0,
                'memory_usage': 1.5,
                'swap_usage': -3.0,
                'runtime': -8.0
            },
            'io_intensive': {
                'major_page_faults': -4.0,
                'swap_io': -5.0,
                'runtime': -12.0
            },
            'mixed': {}  # 使用默认权重
        }
        
        # 难度特定的权重调整
        self.difficulty_weights = {
            "easy": {
                'runtime': -15.0,  # 简单任务更注重速度
                'memory_usage': 1.5  # 简单任务更注重内存效率
            },
            "medium": {},  # 使用默认权重
            "hard": {
                'major_page_faults': -7.0,  # 困难任务更严格惩罚页面错误
                'swap_io': -4.0  # 困难任务更严格惩罚swap I/O
            },
            "extreme": {
                'major_page_faults': -8.0,  # 极端任务最严格惩罚页面错误
                'swap_io': -5.0,  # 极端任务最严格惩罚swap I/O
                'swap_usage': -3.0  # 极端任务更严格限制swap使用
            }
        }
        
        # 难度乘数
        self.difficulty_multiplier = {
            "easy": 1.0,
            "medium": 1.5,
            "hard": 2.25,
            "extreme": 3.0
        }
        
        # 根据难度调整最佳内存利用率目标
        self.optimal_memory_usage = {
            "easy": 60,    # 简单任务，预留更多内存
            "medium": 70,  # 中等任务，标准内存利用率
            "hard": 80,    # 困难任务，允许更高内存利用
            "extreme": 85  # 极端任务，允许非常高的内存利用
        }
        
        # 正规化常数，用于统一不同指标的量级
        self.normalization_constants = {
            'major_page_faults': 100,  # 假设100是一个显著的fault数量
            'minor_page_faults': 10000,
            'free_memory_percent': 100,  # 百分比
            'swap_used_percent': 100,  # 百分比
            'swap_io': 100,  # 假设每秒100次I/O是高负载
            'load_ratio': 4.0,  # 假设负载达到CPU核心数的4倍是极端情况
            'runtime_improvement': 50,  # 百分比改进
            'reclaimed_pages_per_sec': 1000,  # 每秒回收页面数
            'kswapd_cpu_usage': 100,    # kswapd CPU使用率
            'pgmajfault_to_pgfault_ratio': 0.1  # 主错误与总错误的比例
        }
        
        # 记录基准性能作为参考
        self.baseline_performance = None
        
        # 多智能体奖励配置
        self.agent_reward_weights = {
            "page_cache": {
                'memory_efficiency': 2.0,  # 更注重内存效率
                'minor_page_faults': -0.02,  # 更关注次要页面错误
                'cached_memory': 1.5,  # 缓存利用率重要性更高
                'dirty_ratio_optimization': 1.0  # 针对脏页比例优化的特殊奖励
            },
            "memory_reclaim": {
                # 保留原有严格惩罚
                'major_page_faults': -6.0,  # 严格惩罚主要页面错误
                'swap_usage': -3.0,      # 严格控制swap使用
                'swap_io': -4.0,         # 严格控制swap I/O
                'memory_pressure_reduction': 1.5,  # 原有的正向指标
                
                # 新增正向指标
                'reclaim_efficiency': 2.5,        # 新增：内存回收效率
                'thrashing_prevention': 1.5,      # 新增：防止内存颠簸
                'free_memory_balance': 2.0,       # 新增：保持合理的可用内存
                'recovery_speed': 2.0             # 新增：从内存压力中恢复速度
            },
            "memory_scheduler": {
                'load_balancing': 1.5,  # 更注重负载均衡
                'memory_fragmentation': -2.0,  # 更关注内存碎片化
                'system_load': 1.2,  # 更关注系统负载
                'allocation_efficiency': 1.3  # 内存分配效率的特殊奖励
            }
        }
        
        # 每个智能体关注的关键指标
        self.agent_key_metrics = {
            "page_cache": [
                'cached_memory_MB', 'active_file_MB', 'inactive_file_MB',
                'minor_page_faults_per_sec', 'dirty_ratio'
            ],
            "memory_reclaim": [
                'major_page_faults_per_sec', 'swap_in_per_sec', 'swap_out_per_sec',
                'swap_used_MB', 'free_memory_MB', 'memory_pressure',
                'reclaimed_pages_per_sec',     # 新增：页面回收数
                'kswapd_cpu_usage',            # 新增：kswapd CPU使用率
                'pgmajfault_to_pgfault_ratio'  # 新增：页面错误比例
            ],
            "memory_scheduler": [
                'memory_fragmentation', 'system_loadavg_1min', 'active_memory_MB',
                'inactive_memory_MB', 'slab_memory_MB'
            ]
        }
        
        # 初始化previous_states用于计算趋势
        self.previous_states = []

    def update_weights_for_workload(self, workload_type):
        """根据工作负载类型调整权重"""
        if workload_type in self.workload_weights:
            # 只更新特定工作负载定义的权重，其他保持默认
            for key, value in self.workload_weights[workload_type].items():
                self.weights[key] = value

    def update_weights_for_difficulty(self, difficulty):
        """根据难度级别调整权重"""
        if difficulty in self.difficulty_weights:
            # 应用难度特定的权重调整
            for key, value in self.difficulty_weights[difficulty].items():
                self.weights[key] = value

    def set_baseline_performance(self, state):
        """设置基准性能作为参考点"""
        self.baseline_performance = state.copy()

    def sigmoid(self, x, center=0, steepness=1):
        """S形函数，将输入平滑映射到0-1区间"""
        return 1 / (1 + np.exp(-steepness * (x - center)))

    def calculate_trend_bonus(self, current_value, metric_key):
        """计算指标趋势的奖励加成"""
        if len(self.state_history) < 2:
            return 0
        
        # 提取历史值
        historical_values = [
            state.get(metric_key, current_value) 
            for state in self.state_history if metric_key in state
        ]
        
        if not historical_values:
            return 0
        
        # 计算最近3个值的平均变化率
        recent_history = historical_values[-3:]
        if len(recent_history) < 2:
            return 0
            
        # 计算趋势方向和强度
        changes = [recent_history[i] - recent_history[i-1] for i in range(1, len(recent_history))]
        avg_change = np.mean(changes)
        
        # 根据指标类型判断趋势是好是坏
        is_negative_better = metric_key in [
            'major_page_faults_per_sec', 'minor_page_faults_per_sec', 
            'swap_used_MB', 'swap_in_per_sec', 'swap_out_per_sec',
            'system_loadavg_1min', 'memory_fragmentation'
        ]
        
        # 如果下降趋势对于该指标是好的，则奖励为正
        if (is_negative_better and avg_change < 0) or (not is_negative_better and avg_change > 0):
            return min(10, abs(avg_change) * 2)  # 最多+10的奖励
        else:
            return max(-10, -abs(avg_change) * 2)  # 最多-10的惩罚

    def calculate_memory_efficiency_reward(self, state, difficulty=None):
        """计算内存利用率奖励，可根据难度调整"""
        free_mem = state.get('free_memory_MB', 0)
        total_mem = state.get('memory_total_MB', 1)
        free_mem_percent = (free_mem / total_mem) * 100 if total_mem > 0 else 0
        mem_usage_percent = 100 - free_mem_percent
        
        # 选择目标内存利用率
        if difficulty and difficulty in self.optimal_memory_usage:
            target_usage = self.optimal_memory_usage[difficulty]
        else:
            target_usage = 70  # 默认目标
        
        # 使用钟形曲线，以目标利用率为中心
        return 20 * np.exp(-0.5 * ((mem_usage_percent - target_usage) / 20)**2)

    def calculate_reward(self, state, previous_runtime=None, current_runtime=None, workload_type=None, difficulty=None):
        """
        根据内存子系统性能指标计算奖励，现在整合了难度考量
        
        Args:
            state: 当前系统状态
            previous_runtime: 上一次工作负载运行时间
            current_runtime: 当前工作负载运行时间
            workload_type: 工作负载类型，可以是'memory_intensive', 'io_intensive', 或 'mixed'
            difficulty: 工作负载难度，可以是'easy', 'medium', 'hard', 或 'extreme'
            
        Returns:
            float: 计算得到的奖励值
        """
        # 根据工作负载类型调整权重
        if workload_type:
            self.update_weights_for_workload(workload_type)
        
        # 根据难度级别进一步调整权重
        if difficulty:
            self.update_weights_for_difficulty(difficulty)
        
        reward = 0
        
        # --- 优化目标1：减少页面错误 - 使用连续函数 ---
        # 主页面错误 (使用负指数衰减函数)
        major_faults = state.get('major_page_faults_per_sec', 0)
        major_faults_norm = major_faults / self.normalization_constants['major_page_faults']
        major_faults_reward = 50 * np.exp(-4 * major_faults_norm) - 10 * major_faults_norm
        
        # 对高难度任务适当减轻页面错误惩罚
        if difficulty in ['hard', 'extreme'] and major_faults > 0 and major_faults < 50:
            major_faults_reward += 15
            
        reward += major_faults_reward
        
        # 次要页面错误 (权重较低，使用对数衰减)
        minor_faults = state.get('minor_page_faults_per_sec', 0)
        minor_faults_norm = minor_faults / self.normalization_constants['minor_page_faults']
        minor_faults_reward = 10 * (1 - np.log1p(minor_faults_norm * 10) / np.log(11))
        reward += minor_faults_reward
        
        # --- 内存使用情况 - 连续曲线 ---
        free_mem = state.get('free_memory_MB', 0)
        total_mem = state.get('memory_total_MB', 1)
        free_mem_percent = (free_mem / total_mem) * 100 if total_mem > 0 else 0
        
        # 使用S形函数：低于5%时急剧下降，5-15%平缓增长，15%以上平稳
        memory_reward = 30 * self.sigmoid(free_mem_percent - 10, center=0, steepness=0.2) - 10
        reward += memory_reward
        
        # 内存利用率奖励，根据难度调整目标值
        memory_efficiency = self.calculate_memory_efficiency_reward(state, difficulty)
        reward += memory_efficiency
        
        # --- Swap使用情况 - 连续惩罚函数 ---
        swap_used = state.get('swap_used_MB', 0)
        total_swap = state.get('swap_total_MB', 1)
        swap_used_percent = (swap_used / total_swap) * 100 if total_swap > 0 else 0
        
        # 使用sigmoid函数让惩罚随swap使用增加而逐渐增大
        # 对极端难度任务，允许更多swap使用（移动惩罚阈值）
        swap_threshold = 20
        if difficulty == 'hard':
            swap_threshold = 30
        elif difficulty == 'extreme':
            swap_threshold = 40
            
        swap_penalty = -50 * self.sigmoid(swap_used_percent - swap_threshold, steepness=0.1)
        reward += swap_penalty
        
        # Swap I/O - 对数惩罚
        swap_in = state.get('swap_in_per_sec', 0)
        swap_out = state.get('swap_out_per_sec', 0)
        swap_io = swap_in + swap_out
        swap_io_norm = swap_io / self.normalization_constants['swap_io']
        
        if swap_io == 0:
            swap_io_reward = 40  # 无swap I/O
        else:
            swap_io_reward = -30 * np.log1p(swap_io_norm * 10) / np.log(11)
        reward += swap_io_reward
        
        # --- 系统负载 - 连续评估 ---
        load = state.get('system_loadavg_1min', 0)
        cpu_count = state.get('cpu_count', 1)
        load_ratio = load / cpu_count if cpu_count > 0 else load
        load_ratio_norm = load_ratio / self.normalization_constants['load_ratio']
        
        # 对于高难度任务，提高可接受的负载阈值
        load_threshold = 1.0  # 默认阈值
        if difficulty == 'hard':
            load_threshold = 1.5
        elif difficulty == 'extreme':
            load_threshold = 2.0
        
        # 使用S形曲线，低负载时正奖励，高负载时惩罚
        load_reward = 30 * (1 - self.sigmoid(load_ratio - load_threshold, steepness=2))
        reward += load_reward
        
        # --- 运行时间改进 - 连续比例奖励 ---
        if previous_runtime is not None and current_runtime is not None and previous_runtime > 0:
            # 计算改进百分比
            runtime_change_percent = ((previous_runtime - current_runtime) / previous_runtime) * 100
            
            # 使用arctangent函数提供平滑但有界的奖励
            runtime_reward = 80 * np.arctan(runtime_change_percent / 15) / (np.pi/2)
            reward += runtime_reward
        
        # --- 考虑指标的历史趋势 ---
        trend_metrics = [
            'major_page_faults_per_sec', 
            'free_memory_MB', 
            'swap_used_MB',
            'swap_in_per_sec', 
            'swap_out_per_sec'
        ]
        
        for metric in trend_metrics:
            if metric in state:
                trend_bonus = self.calculate_trend_bonus(state[metric], metric)
                reward += trend_bonus
        
        # 保存当前状态到历史记录
        self.state_history.append(state.copy())
        
        # 应用难度乘数调整最终奖励
        if difficulty and difficulty in self.difficulty_multiplier:
            reward *= self.difficulty_multiplier[difficulty]
        
        return reward

    def calculate_agent_specific_reward(self, agent_id, state, previous_runtime=None, current_runtime=None, workload_type=None, difficulty=None):
        """
        计算特定智能体的奖励
        
        Args:
            agent_id: 智能体ID，如"page_cache"
            state: 当前系统状态
            previous_runtime: 上一次运行时间
            current_runtime: 当前运行时间
            workload_type: 工作负载类型
            difficulty: 难度级别
            
        Returns:
            float: 智能体特定奖励
        """
        # 如果不是已知智能体，返回全局奖励
        if agent_id not in self.agent_reward_weights:
            return self.calculate_reward(state, previous_runtime, current_runtime, workload_type, difficulty)
        
        # 获取该智能体的权重配置
        agent_weights = self.agent_reward_weights[agent_id]
        
        # 基于智能体类型计算特定奖励
        if agent_id == "page_cache":
            return self._calculate_page_cache_reward(
                state, agent_weights, previous_runtime, current_runtime, workload_type, difficulty
            )
        elif agent_id == "memory_reclaim":
            return self._calculate_memory_reclaim_reward(
                state, agent_weights, previous_runtime, current_runtime, workload_type, difficulty
            )
        elif agent_id == "memory_scheduler":
            return self._calculate_memory_scheduler_reward(
                state, agent_weights, previous_runtime, current_runtime, workload_type, difficulty
            )
        else:
            # 未知智能体，返回全局奖励
            return self.calculate_reward(state, previous_runtime, current_runtime, workload_type, difficulty)

    def _calculate_page_cache_reward(self, state, weights, previous_runtime=None, current_runtime=None, workload_type=None, difficulty=None):
        """计算页面缓存智能体特定奖励"""
        reward = 0
        
        # --- 页面缓存利用效率 ---
        cached_mb = state.get('cached_memory_MB', 0)
        total_mem = state.get('memory_total_MB', 1)
        cached_ratio = cached_mb / total_mem if total_mem > 0 else 0
        
        # 为IO密集型工作负载调整目标缓存率
        if workload_type == 'io_intensive':
            target_cache_ratio = 0.4  # 更高的缓存目标
        elif workload_type == 'memory_intensive':
            target_cache_ratio = 0.2  # 更低的缓存目标
        else:
            target_cache_ratio = 0.3  # 默认缓存目标
        
        # 使用钟形曲线计算缓存效率奖励
        cache_efficiency_reward = 25 * np.exp(-0.5 * ((cached_ratio - target_cache_ratio) / 0.15)**2)
        reward += cache_efficiency_reward * weights.get('cached_memory', 1.0)
        
        # --- 次要页面错误 ---
        minor_faults = state.get('minor_page_faults_per_sec', 0)
        minor_faults_norm = minor_faults / self.normalization_constants['minor_page_faults']
        minor_faults_reward = 15 * (1 - np.log1p(minor_faults_norm * 10) / np.log(11))
        reward += minor_faults_reward * weights.get('minor_page_faults', -0.01)
        
        # --- 脏页比例优化 ---
        dirty_ratio = state.get('current_dirty_ratio', 20)
        dirty_bg_ratio = state.get('current_dirty_bg_ratio', 10)
        
        # 检查脏页比例是否合理
        if dirty_ratio > 0 and dirty_bg_ratio > 0 and dirty_ratio > dirty_bg_ratio:
            # 脏页配置合理性奖励
            ratio_diff = dirty_ratio - dirty_bg_ratio
            if 5 <= ratio_diff <= 20:
                dirty_ratio_reward = 20  # 比例差异在合理范围内
            else:
                dirty_ratio_reward = 10 * np.exp(-0.5 * ((ratio_diff - 10) / 10)**2)
            
            reward += dirty_ratio_reward * weights.get('dirty_ratio_optimization', 1.0)
        
        # --- 活跃/非活跃文件页面平衡 ---
        active_file = state.get('active_file_MB', 0)
        inactive_file = state.get('inactive_file_MB', 0)
        total_file = active_file + inactive_file
        
        if total_file > 0:
            # 理想情况下活跃文件与非活跃文件有一个平衡
            active_ratio = active_file / total_file
            balance_reward = 20 * np.exp(-0.5 * ((active_ratio - 0.6) / 0.3)**2)
            reward += balance_reward
        
        # --- 内存效率奖励 ---
        memory_efficiency = self.calculate_memory_efficiency_reward(state, difficulty)
        reward += memory_efficiency * weights.get('memory_efficiency', 2.0)
        
        # --- 运行时改进奖励 (针对IO密集型工作负载特别重要) ---
        if previous_runtime is not None and current_runtime is not None and previous_runtime > 0:
            runtime_change_percent = ((previous_runtime - current_runtime) / previous_runtime) * 100
            
            # IO密集型工作负载中的页面缓存更影响性能
            if workload_type == 'io_intensive':
                runtime_reward_multiplier = 1.5
            else:
                runtime_reward_multiplier = 1.0
                
            runtime_reward = 60 * np.arctan(runtime_change_percent / 15) / (np.pi/2) * runtime_reward_multiplier
            reward += runtime_reward
        
        # --- 趋势奖励 ---
        for metric in self.agent_key_metrics["page_cache"]:
            if metric in state:
                trend_bonus = self.calculate_trend_bonus(state[metric], metric)
                reward += trend_bonus
        
        # 应用难度乘数
        if difficulty and difficulty in self.difficulty_multiplier:
            reward *= self.difficulty_multiplier[difficulty]
            
        return reward

    def _calculate_memory_reclaim_reward(self, state, weights, previous_runtime=None, current_runtime=None, workload_type=None, difficulty=None):
        """计算内存回收智能体特定奖励 - 修改了错误版本"""
        reward = 0
        
        # --- 主页面错误 (负向指标) ---
        major_faults = state.get('major_page_faults_per_sec', 0)
        major_faults_norm = major_faults / self.normalization_constants['major_page_faults']
        
        # 错误多=值大=乘以负权重后为负奖励
        major_faults_penalty = major_faults_norm * 30
        reward += major_faults_penalty * weights.get('major_page_faults', -6.0)
        
        # --- Swap使用 (负向指标) ---
        swap_used = state.get('swap_used_MB', 0)
        total_swap = state.get('swap_total_MB', 1)
        swap_used_percent = (swap_used / total_swap) * 100 if total_swap > 0 else 0
        
        # 不同工作负载对swap使用的容忍度不同
        if workload_type == 'memory_intensive':
            swap_threshold = 15  # 内存密集型任务更严格控制swap
        else:
            swap_threshold = 20  # 默认阈值
        
        # 调整难度等级
        if difficulty == 'hard':
            swap_threshold += 10
        elif difficulty == 'extreme':
            swap_threshold += 20
        
        # Swap使用高=值大=乘以负权重后为负奖励
        swap_usage_penalty = (swap_used_percent / 100) * 20  # 基础惩罚值
        reward += swap_usage_penalty * weights.get('swap_usage', -3.0)
        
        # --- Swap I/O (负向指标) ---
        swap_in = state.get('swap_in_per_sec', 0)
        swap_out = state.get('swap_out_per_sec', 0)
        swap_io = swap_in + swap_out
        swap_io_norm = min(1, swap_io / self.normalization_constants['swap_io'])
        
        # I/O高=值大=乘以负权重后为负奖励
        swap_io_penalty = swap_io_norm * 20  # 基础惩罚值
        reward += swap_io_penalty * weights.get('swap_io', -4.0)
        
        # --- 内存压力减轻 (正向指标) ---
        memory_pressure = state.get('memory_pressure', 0)
        memory_pressure_reduction = (1 - min(1, memory_pressure)) * 30
        reward += memory_pressure_reduction * weights.get('memory_pressure_reduction', 1.5)
        
        # --- 内存回收效率 (正向指标) --- 修改后
        reclaimed_pages = state.get('reclaimed_pages_per_sec', 0)
        kswapd_cpu = state.get('kswapd_cpu_usage', 0.1)  # 防止除零
        
        # 根据内存压力调整对回收活动的期望
        if memory_pressure < 10:  # 系统内存充足，几乎没有压力
            # 在内存充足时，回收活动应该很少但不应完全消失
            if 0 < reclaimed_pages <= 5 and kswapd_cpu < 2.0:
                # 适当的低活动，但不是完全不活动
                reclaim_efficiency = 20
            elif reclaimed_pages == 0 and kswapd_cpu < 0.5:
                # 完全不活动，给予中等奖励而不是最高奖励
                reclaim_efficiency = 10
            else:
                # 在内存充足时过度回收是浪费资源
                reclaim_efficiency = 10 - min(10, reclaimed_pages / 20 + kswapd_cpu / 2)
        
        elif memory_pressure < 40:  # 轻度内存压力
            # 应该有适度的回收活动，但不要过度
            if 5 <= reclaimed_pages <= 100 and kswapd_cpu < 10:
                # 适度的回收活动
                reclaim_efficiency = 15 + (reclaimed_pages / 20)
                # 如果大部分回收是通过kswapd而不是直接回收，给予额外奖励
                kswapd_reclaim_ratio = state.get('kswapd_reclaim_ratio', 0.5)
                if kswapd_reclaim_ratio > 0.7:
                    reclaim_efficiency += 5 * (kswapd_reclaim_ratio - 0.7)
            elif reclaimed_pages < 5:
                # 回收不足以应对轻度压力
                reclaim_efficiency = max(0, 15 - (5 - reclaimed_pages) * 2)
            else:
                # 回收过多
                reclaim_efficiency = 10
        
        elif memory_pressure < 70:  # 中度内存压力
            # 应该有更积极的回收活动
            if 50 <= reclaimed_pages <= 500:
                # 回收率与CPU使用率的平衡
                cpu_efficiency = max(0, 10 - kswapd_cpu / 10)
                reclaim_efficiency = 15 + min(10, reclaimed_pages / 100) + cpu_efficiency
                
                # 奖励kswapd回收比例的提高
                kswapd_reclaim_ratio = state.get('kswapd_reclaim_ratio', 0.5)
                if kswapd_reclaim_ratio > 0.6:
                    reclaim_efficiency += 5 * (kswapd_reclaim_ratio - 0.6)
            else:
                # 回收不足
                reclaim_efficiency = max(0, 15 - (50 - min(50, reclaimed_pages)) / 10)
        
        else:  # 高内存压力
            # 需要大量回收，但也要考虑效率
            if reclaimed_pages > 300:
                # 回收量大但CPU使用合理
                if kswapd_cpu < 30:
                    efficiency_ratio = min(1.0, reclaimed_pages / (kswapd_cpu * 50 + 1))
                    reclaim_efficiency = 20 + 5 * efficiency_ratio
                else:
                    # CPU使用过高，降低评分
                    reclaim_efficiency = 20 - (kswapd_cpu - 30) / 3
            else:
                # 回收不足以应对高压力
                reclaim_efficiency = max(0, 15 - (300 - min(300, reclaimed_pages)) / 30)
        
        # 添加回收效率奖励
        reward += reclaim_efficiency * weights.get('reclaim_efficiency', 4.0)
        
        # --- 新增：防止内存颠簸 (正向指标) ---
        fault_ratio = state.get('pgmajfault_to_pgfault_ratio', 0)
        
        # 颠簸比例越低越好 (低于0.01非常好，超过0.1非常差)
        if fault_ratio < 0.01:
            thrashing_score = 15  # 最高分
        else:
            thrashing_score = max(0, 15 * (1 - fault_ratio / 0.1))
        
        reward += thrashing_score * weights.get('thrashing_prevention', 1.5)
        
        # --- 新增：可用内存平衡 (正向指标) ---
        free_mem = state.get('free_memory_MB', 0)
        total_mem = state.get('memory_total_MB', 1)
        free_mem_percent = (free_mem / total_mem) * 100 if total_mem > 0 else 0
        
        # 不同难度有不同的可用内存要求
        if difficulty == 'easy':
            target_free = 20
        elif difficulty == 'medium':
            target_free = 15
        elif difficulty == 'hard':
            target_free = 10
        else:  # extreme
            target_free = 8
            
        # 目标是保持适当的可用内存（钟形曲线）
        free_mem_score = 20 * np.exp(-0.5 * ((free_mem_percent - target_free) / 7.5)**2)
        
        reward += free_mem_score * weights.get('free_memory_balance', 3.5)
        
        # --- 新增：恢复速度 (正向指标) ---
        if len(self.previous_states) >= 3:
            # 获取过去几个状态的内存压力
            prev_pressures = [state.get('memory_pressure', 0) for state in self.previous_states[-3:]]
            current_pressure = memory_pressure
            
            # 检测从高压力恢复的趋势
            if max(prev_pressures) > 0.7 and current_pressure < max(prev_pressures):
                # 计算恢复速度
                recovery_magnitude = max(prev_pressures) - current_pressure
                recovery_score = 25 * (recovery_magnitude / max(prev_pressures))
            else:
                recovery_score = 0
        else:
            recovery_score = 0
        
        reward += recovery_score * weights.get('recovery_speed', 3.0)
        
        # --- 运行时间改进 ---
        if previous_runtime is not None and current_runtime is not None and previous_runtime > 0:
            runtime_change_percent = ((previous_runtime - current_runtime) / previous_runtime) * 100
            runtime_reward = 60 * np.arctan(runtime_change_percent / 15) / (np.pi/2)
            reward += runtime_reward
        
        # --- 趋势奖励 ---
        for metric in self.agent_key_metrics["memory_reclaim"]:
            if metric in state:
                trend_bonus = self.calculate_trend_bonus(state[metric], metric)
                reward += trend_bonus
        
        # 更新状态历史
        self.previous_states.append(state.copy())
        if len(self.previous_states) > 5:  # 保留最近5个状态
            self.previous_states.pop(0)
        
        # 应用难度乘数，但为避免极端负值，对负奖励使用较小的乘数
        if difficulty and difficulty in self.difficulty_multiplier:
            if reward < 0:
                # 对负奖励使用平方根乘数而不是线性乘数
                multiplier = np.sqrt(self.difficulty_multiplier[difficulty])
            else:
                multiplier = self.difficulty_multiplier[difficulty]
            reward *= multiplier
        
        return reward

    def _calculate_memory_scheduler_reward(self, state, weights, previous_runtime=None, current_runtime=None, workload_type=None, difficulty=None):
        """计算内存调度智能体特定奖励"""
        reward = 0
        
        # --- 内存碎片化 ---
        fragmentation = state.get('memory_fragmentation', 0)
        # 碎片化程度越低越好
        fragmentation_reward = 30 * (1 - self.sigmoid(fragmentation - 0.5, steepness=2))
        reward += fragmentation_reward * weights.get('memory_fragmentation', -2.0)
        
        # --- 系统负载平衡 ---
        load = state.get('system_loadavg_1min', 0)
        cpu_count = state.get('cpu_count', 1)
        load_ratio = load / cpu_count if cpu_count > 0 else load
        
        # 不同工作负载类型对负载的容忍度不同
        if workload_type == 'memory_intensive':
            load_threshold = 1.2
        elif workload_type == 'io_intensive':
            load_threshold = 0.8
        else:
            load_threshold = 1.0
            
        # 根据难度调整
        if difficulty == 'hard':
            load_threshold *= 1.2
        elif difficulty == 'extreme':
            load_threshold *= 1.5
        
        load_reward = 25 * (1 - self.sigmoid(load_ratio - load_threshold, steepness=2))
        reward += load_reward * weights.get('load_balancing', 1.5)
        
        # --- 活跃/非活跃内存平衡 ---
        active_mem = state.get('active_memory_MB', 0)
        inactive_mem = state.get('inactive_memory_MB', 0)
        total_mem = active_mem + inactive_mem
        
        if total_mem > 0:
            # 内存调度需要维持合理的活跃/非活跃比例
            active_ratio = active_mem / total_mem
            
            # 目标比例根据工作负载类型调整
            if workload_type == 'memory_intensive':
                target_ratio = 0.65  # 内存密集型需要更多活跃内存
            else:
                target_ratio = 0.55  # 默认目标
                
            balance_reward = 20 * np.exp(-0.5 * ((active_ratio - target_ratio) / 0.2)**2)
            reward += balance_reward
        
        # --- Slab内存管理 ---
        slab_mem = state.get('slab_memory_MB', 0)
        total_mem = state.get('memory_total_MB', 1)
        slab_ratio = slab_mem / total_mem if total_mem > 0 else 0
        
        # Slab内存占比应适中
        slab_reward = 15 * np.exp(-0.5 * ((slab_ratio - 0.05) / 0.05)**2)
        reward += slab_reward
        
        # --- 内存分配效率 ---
        # 估算内存分配效率（简化模型）
        watermark_factor = state.get('current_watermark_scale_factor', 100)
        min_free_kb = state.get('current_min_free_kbytes', 0)
        
        # 判断参数是否在合理范围
        watermark_score = 0
        if 10 <= watermark_factor <= 1000:
            # 钟形曲线，峰值在100-150之间
            watermark_score = 15 * np.exp(-0.5 * ((watermark_factor - 125) / 100)**2)
        
        min_free_score = 0
        if min_free_kb > 0:
            # 判断min_free_kbytes是否在合理范围（根据总内存大小调整）
            total_mem_kb = state.get('memory_total_MB', 8192) * 1024
            optimal_min_free = np.sqrt(total_mem_kb) * 3  # 经验公式
            
            min_free_score = 15 * np.exp(-0.5 * ((min_free_kb - optimal_min_free) / optimal_min_free)**2)
        
        allocation_reward = watermark_score + min_free_score
        reward += allocation_reward * weights.get('allocation_efficiency', 1.3)
        
        # --- 运行时间改进 ---
        if previous_runtime is not None and current_runtime is not None and previous_runtime > 0:
            runtime_change_percent = ((previous_runtime - current_runtime) / previous_runtime) * 100
            runtime_reward = 65 * np.arctan(runtime_change_percent / 15) / (np.pi/2)
            reward += runtime_reward
        
        # --- 趋势奖励 ---
        for metric in self.agent_key_metrics["memory_scheduler"]:
            if metric in state:
                trend_bonus = self.calculate_trend_bonus(state[metric], metric)
                reward += trend_bonus
        
        # 应用难度乘数
        if difficulty and difficulty in self.difficulty_multiplier:
            reward *= self.difficulty_multiplier[difficulty]
            
        return reward

    def get_diagnostic_info(self, state, previous_runtime=None, current_runtime=None, workload_type=None, difficulty=None):
        """
        返回详细的奖励计算诊断信息，用于调试和可视化，包括难度调整因素
        """
        diagnostics = {
            "raw_rewards": {},
            "trend_rewards": {},
            "difficulty_adjustments": {},
            "agent_specific_rewards": {}
        }
        
        # 保存当前权重
        original_weights = self.weights.copy()
        
        # 如果指定了工作负载类型，应用相应权重
        if workload_type:
            self.update_weights_for_workload(workload_type)
        
        # 如果指定了难度，应用相应权重
        if difficulty:
            self.update_weights_for_difficulty(difficulty)
            diagnostics["difficulty_adjustments"]["weight_changes"] = {
                k: self.weights[k] - original_weights[k]
                for k in self.weights if self.weights[k] != original_weights[k]
            }
        
        # 计算各部分的原始奖励（不含难度乘数）
        
        # 页面错误奖励
        major_faults = state.get('major_page_faults_per_sec', 0)
        major_faults_norm = major_faults / self.normalization_constants['major_page_faults']
        major_faults_reward = 50 * np.exp(-4 * major_faults_norm) - 10 * major_faults_norm
        
        # 高难度任务的页面错误宽容度调整
        major_faults_difficulty_bonus = 0
        if difficulty in ['hard', 'extreme'] and major_faults > 0 and major_faults < 50:
            major_faults_difficulty_bonus = 15
            
        diagnostics["raw_rewards"]["major_faults_reward"] = major_faults_reward
        diagnostics["difficulty_adjustments"]["major_faults_bonus"] = major_faults_difficulty_bonus
        
        # 次要页面错误
        minor_faults = state.get('minor_page_faults_per_sec', 0)
        minor_faults_norm = minor_faults / self.normalization_constants['minor_page_faults']
        diagnostics["raw_rewards"]["minor_faults_reward"] = 10 * (1 - np.log1p(minor_faults_norm * 10) / np.log(11))
        
        # 内存使用
        free_mem = state.get('free_memory_MB', 0)
        total_mem = state.get('memory_total_MB', 1)
        free_mem_percent = (free_mem / total_mem) * 100 if total_mem > 0 else 0
        diagnostics["raw_rewards"]["memory_reward"] = 30 * self.sigmoid(free_mem_percent - 10, center=0, steepness=0.2) - 10
        
        # 内存利用率 - 难度调整
        diagnostics["raw_rewards"]["memory_efficiency"] = self.calculate_memory_efficiency_reward(state, difficulty)
        if difficulty:
            diagnostics["difficulty_adjustments"]["memory_target"] = self.optimal_memory_usage.get(difficulty, 70)
        
        # Swap使用
        swap_used = state.get('swap_used_MB', 0)
        total_swap = state.get('swap_total_MB', 1)
        swap_used_percent = (swap_used / total_swap) * 100 if total_swap > 0 else 0
        
        swap_threshold = 20
        if difficulty == 'hard':
            swap_threshold = 30
        elif difficulty == 'extreme':
            swap_threshold = 40
            
        diagnostics["raw_rewards"]["swap_penalty"] = -50 * self.sigmoid(swap_used_percent - swap_threshold, steepness=0.1)
        diagnostics["difficulty_adjustments"]["swap_threshold"] = swap_threshold
        
        # Swap I/O
        swap_in = state.get('swap_in_per_sec', 0)
        swap_out = state.get('swap_out_per_sec', 0)
        swap_io = swap_in + swap_out
        swap_io_norm = swap_io / self.normalization_constants['swap_io']
        
        if swap_io == 0:
            diagnostics["raw_rewards"]["swap_io_reward"] = 40
        else:
            diagnostics["raw_rewards"]["swap_io_reward"] = -30 * np.log1p(swap_io_norm * 10) / np.log(11)
        
        # 系统负载
        load = state.get('system_loadavg_1min', 0)
        cpu_count = state.get('cpu_count', 1)
        load_ratio = load / cpu_count if cpu_count > 0 else load
        
        load_threshold = 1.0
        if difficulty == 'hard':
            load_threshold = 1.5
        elif difficulty == 'extreme':
            load_threshold = 2.0
            
        diagnostics["raw_rewards"]["load_reward"] = 30 * (1 - self.sigmoid(load_ratio - load_threshold, steepness=2))
        diagnostics["difficulty_adjustments"]["load_threshold"] = load_threshold
        
        # 运行时间
        if previous_runtime is not None and current_runtime is not None and previous_runtime > 0:
            runtime_change_percent = ((previous_runtime - current_runtime) / previous_runtime) * 100
            diagnostics["raw_rewards"]["runtime_reward"] = 80 * np.arctan(runtime_change_percent / 15) / (np.pi/2)
            diagnostics["runtime_change_percent"] = runtime_change_percent
        else:
            diagnostics["raw_rewards"]["runtime_reward"] = 0
            
        # 趋势奖励
        trend_metrics = [
            'major_page_faults_per_sec', 
            'free_memory_MB', 
            'swap_used_MB',
            'swap_in_per_sec', 
            'swap_out_per_sec'
        ]
        
        for metric in trend_metrics:
            if metric in state:
                diagnostics["trend_rewards"][metric] = self.calculate_trend_bonus(state[metric], metric)
        
        # 计算总奖励（未应用难度乘数）
        base_reward = sum([v for v in diagnostics["raw_rewards"].values()])
        base_reward += major_faults_difficulty_bonus
        base_reward += sum(diagnostics["trend_rewards"].values())
        
        # 应用难度乘数
        difficulty_multiplier = self.difficulty_multiplier.get(difficulty, 1.0)
        final_reward = base_reward * difficulty_multiplier
        
        diagnostics["base_reward"] = base_reward
        diagnostics["difficulty_multiplier"] = difficulty_multiplier
        diagnostics["final_reward"] = final_reward
        
        # 计算各智能体特定奖励
        for agent_id in self.agent_reward_weights.keys():
            agent_reward = self.calculate_agent_specific_reward(
                agent_id, state, previous_runtime, current_runtime, workload_type, difficulty
            )
            diagnostics["agent_specific_rewards"][agent_id] = agent_reward
        
        # 恢复原始权重
        self.weights = original_weights
        
        return diagnostics
