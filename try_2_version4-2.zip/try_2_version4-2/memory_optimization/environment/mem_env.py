"""
内存子系统优化强化学习环境的核心类 - 多智能体版本
支持多智能体架构，每个智能体专注于内存子系统的不同方面
"""

import time
import random
import logging
from collections import deque
from typing import Dict, List, Tuple, Any, Optional, Union
import numpy as np
import gym
from gym import spaces
from .state_collector import MultiAgentStateCollector
from .action_handler import MultiAgentActionHandler
from .reward_calculator import MultiAgentRewardCalculator
from ..workloads.memory_workloads import MemoryWorkload
from ..workloads.io_workloads import IOWorkload
from ..workloads.mixed_workloads import MixedWorkload
from ..utils.safety_checks import SafetyChecker
from ..strategy.hybrid_balanced_strategy import HybridBalancedStrategy

class MultiAgentMemoryEnv(gym.Env):
    """Linux内存子系统优化的多智能体强化学习环境 - 支持MAPPO"""
    
    metadata = {'render.modes': ['human']}
    
    def __init__(self, params=None):
        super(MultiAgentMemoryEnv, self).__init__()
    
        # 配置日志
        logging.basicConfig(level=logging.INFO, 
                          format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger('MultiAgentMemoryEnv')
    
        # 处理参数
        if params is None:
            params = {}
    
        # 如果params是列表，尝试转换为字典
        if isinstance(params, list):
            self.logger.warning(f"params是列表类型，尝试转换为字典")
            params_dict = {}
            for item in params:
                if isinstance(item, dict):
                    params_dict.update(item)
            params = params_dict
        elif not isinstance(params, dict):
            self.logger.warning(f"params不是字典类型，使用空字典替代")
            params = {}
    
        self.params = params
    
        # 从params读取环境配置
        self.normalize_observations = self.params.get("normalize_observations", True)
        self.normalize_rewards = self.params.get("normalize_rewards", False)
        self.render_mode = self.params.get("render_mode", None)
        self.env_type = self.params.get("env_type", "memory_management")
        self.scenario = self.params.get("scenario", "memory_management")

        # 初始化组件
        self.state_collector = MultiAgentStateCollector(normalize=True)
        self.action_handler = MultiAgentActionHandler()
        self.reward_calculator = MultiAgentRewardCalculator()
        self.safety_checker = SafetyChecker()
    
        # 初始化难度策略
        self.difficulty_strategy = HybridBalancedStrategy()
    
        # 工作负载实例
        self.memory_workload = MemoryWorkload()
        self.io_workload = IOWorkload()
        self.mixed_workload = MixedWorkload()
    
        # 初始化历史记录
        self.action_history = deque(maxlen=100)
        self.state_history = deque(maxlen=100)
        self.reward_history = deque(maxlen=100)
        self.runtime_history = deque(maxlen=10)
    
        # 工作负载和难度跟踪
        self.current_workload_type = None
        self.current_difficulty = None
        self.previous_workload_runtime = None
        self.last_workload_runtime = None
    
        # 记录初始参数值以便恢复
        self.initial_params = self.action_handler.get_current_parameters()
    
        # 定义智能体及其负责的参数
        self.agent_ids = ["page_cache", "memory_reclaim", "memory_scheduler"]
    
        # 每个智能体负责的参数映射
        self.agent_params = {
            "page_cache": ["vfs_cache_pressure", "dirty_ratio", "dirty_background_ratio"],
            "memory_reclaim": ["swappiness", "min_free_kbytes"],
            "memory_scheduler": ["watermark_scale_factor", "compaction_proactiveness"]
        }
    
        # 每个智能体的动作空间
        self.agent_action_spaces = {}
        for agent_id, params_list in self.agent_params.items():
            # 为每个智能体创建专用动作空间
            self.agent_action_spaces[agent_id] = spaces.Box(
                low=-1.0,
                high=1.0,
                shape=(len(params_list),),
                dtype=np.float32
            )
    
        # 每个智能体的观察空间
        self.agent_observation_spaces = {}
        for agent_id in self.agent_ids:
            # 获取每个智能体的状态维度
            state_dim = self.state_collector.get_agent_state_dimension(agent_id)
            self.agent_observation_spaces[agent_id] = spaces.Box(
                low=-1.0,
                high=1.0,
                shape=(state_dim,),
                dtype=np.float32
            )
    
        # 兼容原有单智能体接口
        # 设置动作空间 (所有参数组合)
        param_count = len(self.action_handler.param_ranges)
        self.action_space = spaces.Box(
            low=-1.0,
            high=1.0,
            shape=(param_count,),
            dtype=np.float32
        )
    
        # 设置观察空间
        sample_state = self.state_collector.get_state_vector_for_ppo()
        self.observation_space = spaces.Box(
            low=-1.0,
            high=1.0,
            shape=sample_state.shape,
            dtype=np.float32
        )
    
        # 多智能体环境属性
        self.num_agents = len(self.agent_ids)
        self.is_multiagent = True
    
        # 添加回合和步数跟踪
        self.steps_in_episode = 0
        self.total_steps = 0
        self.episode_count = 0
    
        # 使用动态可设置的最大步数
        try:
            if "max_episode_steps" in self.params:
                self._max_episode_steps = int(self.params.get("max_episode_steps", 30))
            else:
                self._max_episode_steps = 30
        except (TypeError, ValueError):
            self.logger.warning("无法读取max_episode_steps参数，使用默认值30")
            self._max_episode_steps = 30
        
        self.logger.info(f"初始化最大回合步数为: {self._max_episode_steps}")
     
    @property
    def max_episode_steps(self):
        """获取当前最大步数限制"""
        return self._max_episode_steps
    
    @max_episode_steps.setter
    def max_episode_steps(self, value):
        """动态设置最大步数限制"""
        if isinstance(value, int) and value > 0:
            old_value = self._max_episode_steps
            self._max_episode_steps = value
            self.logger.info(f"更新最大回合步数: {old_value} -> {value}")
        else:
            self.logger.warning(f"无效的最大回合步数: {value}，保持当前值: {self._max_episode_steps}")
    
    def reset(self):
        """
        重置环境状态
        
        Returns:
            Dict[str, np.ndarray]: 每个智能体的初始观察
        """
        self.logger.info("Resetting environment...")
        
        # 如果不是首次重置，增加回合计数
        if hasattr(self, 'total_steps') and self.total_steps > 0:
            self.episode_count += 1
            self.logger.info(f"Episode {self.episode_count} completed.")
        
        # 重置步数计数器
        self.steps_in_episode = 0
        
        # 恢复初始参数
        if hasattr(self, 'initial_params'):
            for param, value in self.initial_params.items():
                self.action_handler.set_parameter(param, value)
                
        # 清空历史记录
        self.action_history.clear()
        self.state_history.clear()
        self.reward_history.clear()
        self.runtime_history.clear()
        
        # 选择初始难度
        self.current_difficulty = self.difficulty_strategy.select_difficulty()
        
        # 选择工作负载类型
        self.current_workload_type = self._select_workload_type()
        
        # 运行初始工作负载以建立基准
        self.run_test_workload()
        self.previous_workload_runtime = self.last_workload_runtime
        
        # 获取每个智能体的初始观察
        observations = {}
        for agent_id in self.agent_ids:
            observations[agent_id] = self.state_collector.get_agent_optimized_vector(agent_id)
        
        # 保存初始状态
        initial_state = self.state_collector.get_state()
        self.state_history.append(initial_state)
        
        # 调试输出当前回合信息
        self.logger.info(f"开始第 {self.episode_count+1} 回合, 目前总步数: {self.total_steps}")
        
        return observations
    
    def step(self, actions_dict):
        """
        执行一步环境交互 - 多智能体版本
        
        Args:
            actions_dict: 字典，键为智能体ID，值为对应的动作数组
            
        Returns:
            (observations, rewards, dones, info): 每个值都是一个字典，键为智能体ID
        """
        # 增加步数计数
        self.steps_in_episode += 1
        self.total_steps += 1
        
        # 安全检查
        if not self.safety_checker.is_safe_to_proceed(self.state_collector.get_state()):
            self.logger.warning("Unsafe system state detected. Skipping this step.")
            
            # 为所有智能体创建跳过步骤的返回值
            observations = {}
            rewards = {}
            dones = {}
            
            for agent_id in self.agent_ids:
                observations[agent_id] = self.state_collector.get_agent_optimized_vector(agent_id)
                rewards[agent_id] = -100
                dones[agent_id] = False
                
            # 添加全局完成标志
            dones["__all__"] = False
            
            info = {
                "skipped": True,
                "steps_in_episode": self.steps_in_episode,
                "total_steps": self.total_steps,
                "episode_count": self.episode_count
            }
            return observations, rewards, dones, info
        
        # 聚合所有智能体的动作
        combined_action = self._combine_agent_actions(actions_dict)
        self.action_history.append(combined_action)
        
        # 将连续动作值转换为参数值字典
        action_values = self._convert_action_to_param_values(combined_action)
        
        # 执行参数调整
        self.action_handler.execute_action(action_values)
        
        # 可能更改工作负载类型
        if random.random() < 0.2:  # 20%概率改变工作负载
            self.current_workload_type = self._select_workload_type()
            
        # 可能更改难度(每10步一次)
        if len(self.action_history) % 10 == 0:
            self.current_difficulty = self.difficulty_strategy.select_difficulty()
            self.logger.info(f"Changed difficulty to: {self.current_difficulty}")
        
        # 运行测试工作负载
        self.run_test_workload()
        
        # 获取新状态
        new_state = self.state_collector.get_state()
        self.state_history.append(new_state)
        
        # 确保 runtime 值为数值类型用于奖励计算
        prev_runtime = self._ensure_numeric(self.previous_workload_runtime)
        curr_runtime = self._ensure_numeric(self.last_workload_runtime)
        
        # 计算全局奖励
        global_reward = self.reward_calculator.calculate_reward(
            new_state, 
            previous_runtime=prev_runtime, 
            current_runtime=curr_runtime,
            workload_type=self.current_workload_type,
            difficulty=self.current_difficulty
        )
        self.reward_history.append(global_reward)
        
        # 为每个智能体计算特定奖励
        rewards = {}
        for agent_id in self.agent_ids:
            # 计算智能体特定奖励，将全局奖励作为基础，加上特定奖励
            agent_specific_reward = self.reward_calculator.calculate_agent_specific_reward(
                agent_id, new_state, prev_runtime, curr_runtime, 
                self.current_workload_type, self.current_difficulty
            )
            
            # 合并全局和特定奖励
            # 这里可以调整权重，例如70%全局奖励，30%特定奖励
            rewards[agent_id] = 0.7 * global_reward + 0.3 * agent_specific_reward
        
        # 更新难度策略
        success = global_reward > 0  # 简单判断：正奖励为成功
        self.difficulty_strategy.update_performance(self.current_difficulty, success)
        
        # 更新前一次工作负载运行时间
        self.previous_workload_runtime = self.last_workload_runtime
        
        # 检查是否达到最大步数
        force_terminate = self.steps_in_episode >= self._max_episode_steps
        
        # 为每个智能体创建观察和完成标志
        observations = {}
        dones = {}
        
        for agent_id in self.agent_ids:
            observations[agent_id] = self.state_collector.get_agent_optimized_vector(agent_id)
            dones[agent_id] = force_terminate  # 当达到最大步数时设置为完成
        
        # 添加全局完成标志
        dones["__all__"] = force_terminate
        
        # 计算性能改进
        improvement = 0
        try:
            prev_rt = self._ensure_numeric(self.previous_workload_runtime)
            curr_rt = self._ensure_numeric(self.last_workload_runtime)
            if prev_rt > 0:
                improvement = (prev_rt - curr_rt) / prev_rt
        except (TypeError, ValueError, ZeroDivisionError):
            self.logger.warning("Could not calculate improvement due to invalid runtime values")
        
        # 包含步数和回合信息
        info = {
            'workload_type': self.current_workload_type,
            'difficulty': self.current_difficulty,
            'runtime': self.last_workload_runtime,
            'improvement': improvement,
            'applied_params': action_values,
            'success': success,
            'global_reward': global_reward,
            'agent_rewards': rewards,
            'steps_in_episode': self.steps_in_episode,
            'total_steps': self.total_steps,
            'episode_count': self.episode_count,
            'force_terminated': force_terminate
        }
        
        # 如果强制终止，打印信息
        if force_terminate:
            self.logger.info(f"回合 {self.episode_count+1} 达到最大步数 {self._max_episode_steps}，强制终止")
        
        return observations, rewards, dones, info
    
    def _combine_agent_actions(self, actions_dict):
        """
        将多个智能体的动作合并为一个完整的动作向量
        
        Args:
            actions_dict: 字典，键为智能体ID，值为对应的动作数组
            
        Returns:
            np.ndarray: 合并后的动作向量
        """
        # 创建完整参数列表
        all_params = []
        for params in self.agent_params.values():
            all_params.extend(params)
        
        # 初始化合并动作向量为零
        combined_action = np.zeros(len(all_params))
        
        # 填充每个智能体的动作
        current_idx = 0
        for agent_id, params in self.agent_params.items():
            if agent_id in actions_dict:
                agent_action = actions_dict[agent_id]
                param_count = len(params)
                
                # 确保动作维度匹配
                if len(agent_action) == param_count:
                    combined_action[current_idx:current_idx+param_count] = agent_action
                else:
                    self.logger.warning(f"Agent {agent_id} action dimension mismatch: expected {param_count}, got {len(agent_action)}")
                
                current_idx += param_count
        
        return combined_action
    
    def _ensure_numeric(self, value):
        """确保值为数值类型"""
        if value is None:
            return 0.0
            
        try:
            if isinstance(value, str):
                # 如果是难度字符串，返回一个默认值
                if value in ['easy', 'medium', 'hard', 'extreme', 'easys', 'mediums', 'hards', 'extremes']:
                    return 1.0
                return float(value)
            return float(value)
        except (ValueError, TypeError):
            self.logger.warning(f"Could not convert value to number: {value}")
            return 0.0
    
    def _convert_action_to_param_values(self, action):
        """
        将连续动作向量转换为参数值字典
        
        参数:
            action: numpy数组，每个参数的标准化值(-1到1)
            
        返回:
            dict: 参数名和值的映射
        """
        param_values = {}
        param_names = list(self.action_handler.param_ranges.keys())
        
        for i, param_name in enumerate(param_names):
            if i < len(action):
                param_range = self.action_handler.param_ranges[param_name]
                min_val = param_range['min']
                max_val = param_range['max']
                
                # 将[-1,1]映射到[min_val,max_val]
                normalized_val = (action[i] + 1) / 2.0  # 从[-1,1]映射到[0,1]
                param_val = min_val + normalized_val * (max_val - min_val)
                
                # 对于整数参数，四舍五入
                if param_range.get('type', int) == int:
                    param_val = int(round(param_val))
                
                param_values[param_name] = param_val
        
        return param_values
    
    def _select_workload_type(self):
        """随机选择一种工作负载类型"""
        workload_types = [
            'memory_intensive',
            'io_intensive',
            'mixed_workload',
            'file_cache_intensive'
        ]
        return random.choice(workload_types)
    
    def run_test_workload(self):
        """运行测试负载并测量性能"""
        # 记录开始时间
        start_time = time.time()
        
        # 根据选择的类型和难度运行对应工作负载
        try:
            if self.current_workload_type == 'memory_intensive':
                results = self.memory_workload.run_memory_intensive(self.current_difficulty)
                runtime = results[0] if isinstance(results, tuple) and len(results) > 0 else None
                
            elif self.current_workload_type == 'io_intensive':
                results = self.io_workload.run_io_intensive(self.current_difficulty)
                runtime = results[0] if isinstance(results, tuple) and len(results) > 0 else None
                
            elif self.current_workload_type == 'mixed_workload':
                results = self.mixed_workload.run_mixed_workload(self.current_difficulty)
                runtime = results[0] if isinstance(results, tuple) and len(results) > 0 else None
                
            elif self.current_workload_type == 'file_cache_intensive':
                # 问题所在：这个函数可能只返回2个值，而不是期望的3个值
                results = self.io_workload.run_file_cache_intensive(self.current_difficulty)
                runtime = results[0] if isinstance(results, tuple) and len(results) > 0 else None
                
            else:
                # 默认运行混合工作负载
                results = self.mixed_workload.run_mixed_workload(self.current_difficulty)
                runtime = results[0] if isinstance(results, tuple) and len(results) > 0 else None
            
            # 确保 runtime 是数值类型
            runtime = self._process_runtime(runtime, start_time)
            
        except Exception as e:
            self.logger.error(f"Error running workload: {e}")
            # 发生错误时使用默认运行时间
            runtime = time.time() - start_time
        
        self.last_workload_runtime = runtime
        self.runtime_history.append(runtime)
        
        self.logger.info(f"Workload: {self.current_workload_type}, Difficulty: {self.current_difficulty}, Runtime: {runtime}s")
    
    def _process_runtime(self, runtime, start_time):
        """处理运行时间，确保返回数值类型"""
        try:
            # 先检查 runtime 是否为 None
            if runtime is None:
                return time.time() - start_time
                
            # 如果是字符串类型，尝试转换为浮点数
            if isinstance(runtime, str):
                # 检查是否等于或包含难度级别
                if runtime in [self.current_difficulty, self.current_difficulty + "s", "easy", "medium", "hard", "extreme", "easys", "mediums", "hards", "extremes"]:
                    return time.time() - start_time
                    
                # 尝试将字符串转换为浮点数
                try:
                    return float(runtime)
                except (ValueError, TypeError):
                    return time.time() - start_time
                    
            # 确保返回的是数值类型
            return float(runtime)
            
        except (ValueError, TypeError) as e:
            # 如果转换失败，记录警告并使用实际运行时间
            self.logger.warning(f"Invalid runtime value: {runtime}, using elapsed time instead. Error: {e}")
            return time.time() - start_time
    
    def render(self, mode='human'):
        """渲染环境状态（可选）"""
        if mode == 'human':
            # 获取当前状态和参数
            current_state = self.state_collector.get_state()
            current_params = self.action_handler.get_current_parameters()
            
            # 打印关键信息
            print("\n=== Current Environment State ===")
            print(f"Episode: {self.episode_count+1}, Step: {self.steps_in_episode}/{self._max_episode_steps}")
            print(f"Difficulty: {self.current_difficulty}")
            print(f"Workload Type: {self.current_workload_type}")
            
            # 打印关键指标
            key_metrics = [
                'major_page_faults_per_sec', 
                'memory_usage_percent',
                'swap_percent', 
                'swap_in_per_sec', 
                'swap_out_per_sec',
                'system_loadavg_1min'
            ]
            
            print("--- Key Metrics ---")
            for metric in key_metrics:
                if metric in current_state:
                    print(f"{metric}: {current_state[metric]}")
            
            # 打印当前参数设置（按智能体分组）
            print("--- Current Parameters (By Agent) ---")
            for agent_id, params in self.agent_params.items():
                print(f"\n{agent_id}:")
                for param in params:
                    if param in current_params:
                        print(f"  {param}: {current_params[param]}")
            
            # 打印性能信息
            if hasattr(self, 'last_workload_runtime'):
                print(f"\nLast runtime: {self._ensure_numeric(self.last_workload_runtime):.2f}s")
                if self.previous_workload_runtime:
                    try:
                        prev_rt = self._ensure_numeric(self.previous_workload_runtime)
                        curr_rt = self._ensure_numeric(self.last_workload_runtime)
                        if prev_rt > 0:
                            change = (prev_rt - curr_rt) / prev_rt * 100
                            print(f"Change from previous: {change:.1f}%")
                    except (TypeError, ValueError, ZeroDivisionError):
                        print("Could not calculate change (invalid runtime values)")
            
            # 打印奖励信息
            if len(self.reward_history) > 0:
                print(f"Last global reward: {self.reward_history[-1]:.2f}")
                print(f"Average reward (last 10): {np.mean(list(self.reward_history)[-10:]):.2f}")
            
            print("===============================\n")
    
    def close(self):
        """关闭环境，恢复初始参数"""
        self.logger.info(f"Closing environment after {self.episode_count} episodes and {self.total_steps} steps.")
        if hasattr(self, 'initial_params'):
            for param, value in self.initial_params.items():
                self.action_handler.set_parameter(param, value)
    
    def get_diagnostic_info(self):
        """获取环境的诊断信息（用于调试和分析）"""
        # 安全地计算运行时间统计
        runtime_stats = {'mean': 0, 'std': 0, 'min': 0, 'max': 0, 'improvement': 0}
        
        try:
            if self.runtime_history:
                # 确保所有运行时间是数值类型
                numeric_runtimes = [self._ensure_numeric(rt) for rt in self.runtime_history]
                
                runtime_stats = {
                    'mean': np.mean(numeric_runtimes),
                    'std': np.std(numeric_runtimes),
                    'min': min(numeric_runtimes),
                    'max': max(numeric_runtimes)
                }
                
                # 计算改进百分比
                if len(numeric_runtimes) > 1 and numeric_runtimes[0] > 0:
                    runtime_stats['improvement'] = ((numeric_runtimes[0] - numeric_runtimes[-1]) / numeric_runtimes[0] * 100)
        except Exception as e:
            self.logger.warning(f"Error calculating runtime statistics: {e}")
        
        info = {
            'difficulty_distribution': self.difficulty_strategy.get_distribution(),
            'performance_history': self.difficulty_strategy.get_performance_history(),
            'reward_stats': {
                'mean': np.mean(self.reward_history) if self.reward_history else 0,
                'std': np.std(self.reward_history) if self.reward_history else 0,
                'min': min(self.reward_history) if self.reward_history else 0,
                'max': max(self.reward_history) if self.reward_history else 0,
            },
            'runtime_stats': runtime_stats,
            'agent_stats': self._get_agent_stats(),
            'episode_stats': {
                'total_episodes': self.episode_count,
                'total_steps': self.total_steps,
                'current_episode_steps': self.steps_in_episode,
                'max_episode_steps': self._max_episode_steps
            }
        }
        
        # 如果存在最近的奖励，获取详细计算过程
        if hasattr(self, 'reward_calculator') and self.state_history:
            latest_state = self.state_history[-1]
            prev_runtime = self._ensure_numeric(self.previous_workload_runtime)
            curr_runtime = self._ensure_numeric(self.last_workload_runtime)
            
            info['reward_details'] = self.reward_calculator.get_diagnostic_info(
                latest_state,
                previous_runtime=prev_runtime, 
                current_runtime=curr_runtime,
                workload_type=self.current_workload_type,
                difficulty=self.current_difficulty
            )
        
        return info
    
    def _get_agent_stats(self):
        """获取每个智能体的统计信息"""
        agent_stats = {}
        
        for agent_id in self.agent_ids:
            # 获取该智能体负责的参数
            params = self.agent_params.get(agent_id, [])
            current_params = self.action_handler.get_current_parameters()
            
            # 提取该智能体负责的当前参数值
            agent_params = {param: current_params.get(param) for param in params}
            
            agent_stats[agent_id] = {
                'parameters': agent_params,
                'state_dimension': self.state_collector.get_agent_state_dimension(agent_id),
                'action_dimension': len(params)
            }
        
        return agent_stats
    
    # 兼容单智能体接口
    def single_agent_step(self, action):
        """
        执行单智能体步骤（兼容原有接口）
        
        Args:
            action: numpy数组，标准化的参数值
            
        Returns:
            (observation, reward, done, info): 单智能体接口返回值
        """
        # 将单一动作转换为多智能体动作字典
        action_dict = {}
        current_idx = 0
        
        for agent_id, params in self.agent_params.items():
            param_count = len(params)
            if current_idx + param_count <= len(action):
                action_dict[agent_id] = action[current_idx:current_idx+param_count]
                current_idx += param_count
        
        # 执行多智能体步骤
        observations, rewards, dones, info = self.step(action_dict)
        
        # 返回第一个智能体的结果（或合并所有结果），并传递done信号
        return self.state_collector.get_state_vector_for_ppo(), rewards.get(self.agent_ids[0], 0), dones.get("__all__", False), info
    
    def single_agent_reset(self):
        """兼容单智能体接口的重置方法"""
        self.reset()
        return self.state_collector.get_state_vector_for_ppo()
