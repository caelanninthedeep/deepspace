"""
收集系统状态的模块 - 多智能体优化版

增强了状态表示，支持归一化、分类特征抽取和多智能体状态分发
支持内存回收的新指标：回收页面数、kswapd CPU使用率和页面错误比率
"""

import os
import time
import psutil
import numpy as np
import logging
import subprocess
from collections import deque
from typing import Dict, List, Optional, Union, Any

class MultiAgentStateCollector:
    def __init__(self, history_length=5, normalize=True, agent_feature_groups=None):
        """
        初始化状态收集器
        
        Args:
            history_length: 保存历史状态的数量，用于计算趋势
            normalize: 是否归一化状态值
            agent_feature_groups: 每个智能体关注的特征组，字典格式 {agent_id: [特征名列表]}
        """
        # 设置日志
        logging.basicConfig(level=logging.INFO, 
                           format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger('MultiAgentStateCollector')
        
        # 状态历史，用于计算趋势
        self.state_history = deque(maxlen=history_length)
        self.normalize = normalize
        
        # 归一化范围配置
        self.normalization_ranges = {
            'major_page_faults_per_sec': (0, 1000),
            'minor_page_faults_per_sec': (0, 50000),
            'memory_total_MB': (1024, 128 * 1024),  # 1GB - 128GB
            'free_memory_MB': (0, 64 * 1024),       # 0 - 64GB
            'memory_usage_percent': (0, 100),
            'swap_total_MB': (0, 64 * 1024),        # 0 - 64GB
            'swap_used_MB': (0, 32 * 1024),         # 0 - 32GB
            'swap_percent': (0, 100),
            'swap_in_per_sec': (0, 1000),
            'swap_out_per_sec': (0, 1000),
            'slab_memory_MB': (0, 8 * 1024),        # 0 - 8GB
            'cached_memory_MB': (0, 32 * 1024),     # 0 - 32GB
            'buffers_memory_MB': (0, 4 * 1024),     # 0 - 4GB
            'active_memory_MB': (0, 64 * 1024),     # 0 - 64GB
            'inactive_memory_MB': (0, 64 * 1024),   # 0 - 64GB
            'system_loadavg_1min': (0, 32),         # 0 - 32 (32核系统)
            'system_loadavg_5min': (0, 32),
            'cpu_usage_percent': (0, 100),
            'cpu_iowait_percent': (0, 100),
            'current_swappiness': (0, 100),
            'current_cache_pressure': (0, 500),
            'current_dirty_ratio': (1, 60),
            'current_dirty_bg_ratio': (1, 50),
            'current_min_free_kbytes': (1024, 1048576),  # 1MB - 1GB
            'current_watermark_scale_factor': (10, 1000),
            # 新增指标的归一化范围
            'reclaimed_pages_per_sec': (0, 10000),       # 0-10000页/秒
            'kswapd_cpu_usage': (0, 100),               # 0-100%
            'pgmajfault_to_pgfault_ratio': (0, 1),      # 0-1比例
            'direct_reclaim_pages_per_sec': (0, 5000),   # 0-5000页/秒
            'kswapd_reclaim_pages_per_sec': (0, 10000),  # 0-10000页/秒
            'kswapd_reclaim_ratio': (0, 1)              # 0-1比例
        }
        
        # 缓存CPU核心数，避免重复查询
        self.cpu_count = psutil.cpu_count()
        
        # 多智能体相关配置 - 定义每个智能体关注的特征组
        self.default_agent_feature_groups = {
            "page_cache": [
                'cached_memory_MB',
                'active_file_MB', 
                'inactive_file_MB',
                'memory_usage_percent',
                'minor_page_faults_per_sec',
                'cache_ratio',
                'memory_pressure',
                'current_cache_pressure',
                'free_memory_MB',
                'memory_fragmentation',
                # 全局性能指标
                'cpu_usage_percent',
                'system_loadavg_1min',
                'io_pressure'
            ],
            "memory_reclaim": [
                'free_memory_MB',
                'memory_usage_percent',
                'swap_percent',
                'swap_in_per_sec',
                'swap_out_per_sec',
                'major_page_faults_per_sec',
                'current_swappiness',
                'memory_pressure',
                'swap_efficiency',
                'active_memory_MB',
                'inactive_memory_MB',
                # 新增内存回收指标
                'reclaimed_pages_per_sec',
                'kswapd_cpu_usage',
                'pgmajfault_to_pgfault_ratio',
                'direct_reclaim_pages_per_sec',
                'kswapd_reclaim_pages_per_sec',
                'kswapd_reclaim_ratio',
                # 全局性能指标
                'cpu_usage_percent',
                'system_loadavg_1min',
                'io_pressure'
            ],
            "memory_scheduler": [
                'memory_fragmentation',
                'slab_memory_MB',
                'active_anon_MB',
                'inactive_anon_MB',
                'current_min_free_kbytes',
                'current_watermark_scale_factor',
                'relative_load',
                'memory_pressure',
                'cpu_iowait_percent',
                # 全局性能指标
                'cpu_usage_percent',
                'system_loadavg_1min',
                'io_pressure'
            ]
        }
        
        # 使用传入的智能体特征组或默认配置
        self.agent_feature_groups = agent_feature_groups or self.default_agent_feature_groups
        
        # 缓存每个智能体的特征索引，用于快速查找
        self.agent_feature_indices = {}
        
        # 缓存最新收集的状态，避免重复收集
        self.latest_state = None
        self.last_collection_time = 0
        self.collection_interval = 0.5  # 最小收集间隔，秒
        
        # 初始化新指标的历史数据
        self._last_pgsteal_total = 0
        self._last_pgsteal_time = time.time()
        self._last_pgsteal_direct = 0
        self._last_pgsteal_direct_time = time.time()
        self._last_pgsteal_kswapd = 0
        self._last_pgsteal_kswapd_time = time.time()
        self._last_pgfault = 0
        self._last_pgmajfault = 0
        self._last_kswapd_cpu_time = 0
        self._last_kswapd_cpu_time_stamp = time.time()
        self._last_pswpout = 0
        self._last_pswpout_time = time.time()
        
        # 初次调用，填充历史数据
        self._initialize_history()
        
    def _initialize_history(self):
        """初始化历史数据"""
        # 获取初始状态并填充历史队列
        initial_state = self._collect_all_metrics()
        for _ in range(self.state_history.maxlen):
            self.state_history.append(initial_state.copy())
    
    def get_state(self, force_collect=False):
        """
        获取当前系统状态，融合所有优化目标的指标
        
        Args:
            force_collect: 是否强制重新收集，忽略缓存
            
        Returns:
            dict: 包含系统各项指标的字典
        """
        current_time = time.time()
        
        # 使用缓存避免频繁收集
        if not force_collect and self.latest_state is not None and \
           (current_time - self.last_collection_time) < self.collection_interval:
            return self.latest_state
        
        # 收集基础指标
        state = self._collect_all_metrics()
        
        # 添加趋势指标
        self._add_trend_metrics(state)
        
        # 添加派生指标
        self._add_derived_metrics(state)
        
        # 保存到历史记录
        self.state_history.append(state.copy())
        
        # 更新缓存
        self.latest_state = state
        self.last_collection_time = current_time
        
        return state
    
    def get_agent_state(self, agent_id: str, force_collect=False) -> Dict[str, float]:
        """
        获取特定智能体需要的状态子集
        
        Args:
            agent_id: 智能体标识符
            force_collect: 是否强制重新收集状态
            
        Returns:
            包含该智能体需要特征的状态字典
        """
        # 获取完整状态
        full_state = self.get_state(force_collect)
        
        # 如果不是已知智能体，返回完整状态
        if agent_id not in self.agent_feature_groups:
            self.logger.warning(f"Unknown agent_id: {agent_id}, returning full state")
            return full_state
        
        # 提取该智能体关注的特征
        agent_features = self.agent_feature_groups[agent_id]
        agent_state = {feature: full_state.get(feature, 0.0) for feature in agent_features}
        
        return agent_state
    
    def get_multiple_agent_states(self, agent_ids: List[str], force_collect=False) -> Dict[str, Dict[str, float]]:
        """
        同时获取多个智能体的状态
        
        Args:
            agent_ids: 智能体ID列表
            force_collect: 是否强制重新收集
            
        Returns:
            字典，键为智能体ID，值为该智能体的状态字典
        """
        # 获取完整状态（只收集一次）
        full_state = self.get_state(force_collect)
        
        # 为每个智能体提取状态子集
        result = {}
        for agent_id in agent_ids:
            if agent_id in self.agent_feature_groups:
                agent_features = self.agent_feature_groups[agent_id]
                agent_state = {feature: full_state.get(feature, 0.0) for feature in agent_features}
                result[agent_id] = agent_state
            else:
                # 未知智能体，返回完整状态
                self.logger.warning(f"Unknown agent_id: {agent_id}, returning full state")
                result[agent_id] = full_state
                
        return result
    
    def get_agent_state_array(self, agent_id: str, force_collect=False) -> np.ndarray:
        """
        获取特定智能体的状态数组
        
        Args:
            agent_id: 智能体ID
            force_collect: 是否强制重新收集
            
        Returns:
            包含该智能体需要特征的归一化状态数组
        """
        # 获取智能体状态字典
        agent_state = self.get_agent_state(agent_id, force_collect)
        
        # 转换为数组
        features = sorted(agent_state.keys())
        values = []
        
        for feature in features:
            value = agent_state[feature]
            
            # 归一化
            if self.normalize and feature in self.normalization_ranges:
                min_val, max_val = self.normalization_ranges[feature]
                # 将值归一化到[-1, 1]范围
                norm_value = 2 * (value - min_val) / (max_val - min_val) - 1
                # 限制在[-1, 1]范围内
                norm_value = max(-1, min(norm_value, 1))
                values.append(norm_value)
            else:
                # 对于趋势指标，已经是比率形式
                if 'trend' in feature:
                    value = max(-1, min(value, 1))
                    values.append(value)
                else:
                    # 简单缩放
                    values.append(value / 1000.0)
        
        return np.array(values, dtype=np.float32)
    
    def get_agent_state_dimension(self, agent_id: str) -> int:
        """
        获取特定智能体状态向量的维度
        - 返回实际可获取的特征维度，与get_agent_optimized_vector一致
        """
        if agent_id in self.agent_feature_groups:
            # 获取一个样本向量并返回其维度
            sample_vector = self.get_agent_optimized_vector(agent_id)
            dim = len(sample_vector)
            self.logger.info(f"智能体 {agent_id} 的实际观察空间维度: {dim}")
            return dim
        else:
            # 未知智能体，返回完整状态维度
            sample_state = self.get_state()
            return len(sample_state)
    
    def _collect_all_metrics(self):
        """收集所有基本指标"""
        state = {}
        
        # 收集各类指标
        self._collect_page_fault_metrics(state)
        self._collect_memory_metrics(state)
        self._collect_swap_metrics(state)
        self._collect_cache_metrics(state)
        self._collect_system_load(state)
        self._collect_current_parameters(state)
        
        # 新增: 收集内存回收相关指标
        self._collect_memory_reclaim_metrics(state)
        
        # 收集CPU信息
        state['cpu_count'] = self.cpu_count
        
        return state
    
    def _add_trend_metrics(self, state):
        """添加趋势指标"""
        if len(self.state_history) < 2:
            return
            
        # 计算主要指标的变化率
        trend_metrics = [
            'major_page_faults_per_sec',
            'free_memory_MB',
            'swap_used_MB',
            'swap_in_per_sec',
            'swap_out_per_sec',
            'system_loadavg_1min',
            # 新增内存回收指标趋势
            'reclaimed_pages_per_sec',
            'kswapd_cpu_usage',
            'pgmajfault_to_pgfault_ratio'
        ]
        
        for metric in trend_metrics:
            if metric in state and metric in self.state_history[-1]:
                # 计算变化率 (当前值 - 历史平均值)/历史平均值
                history_values = [h.get(metric, state[metric]) for h in self.state_history]
                history_avg = sum(history_values) / len(history_values)
                
                if history_avg != 0:  # 避免除以零
                    change_rate = (state[metric] - history_avg) / (abs(history_avg) + 1e-6)
                    state[f'{metric}_trend'] = change_rate
                else:
                    state[f'{metric}_trend'] = 0.0
    
    def _add_derived_metrics(self, state):
        """添加派生的复合指标"""
        # 内存压力指标 (结合使用率和swap活动)
        if all(k in state for k in ['memory_usage_percent', 'swap_in_per_sec', 'swap_out_per_sec']):
            # 将新增的内存回收指标纳入内存压力计算
            memory_usage_factor = state['memory_usage_percent'] / 100.0
            swap_activity_factor = min(1.0, (state['swap_in_per_sec'] + state['swap_out_per_sec']) / 100.0)
            
            # 新增: 使用kswapd活动和页面错误比例增强内存压力评估
            kswapd_activity = state.get('kswapd_cpu_usage', 0) / 100.0
            fault_ratio = state.get('pgmajfault_to_pgfault_ratio', 0)
            
            # 加权计算内存压力，增加新指标的权重
            memory_pressure = (
                0.4 * memory_usage_factor + 
                0.3 * swap_activity_factor + 
                0.2 * kswapd_activity +
                0.1 * fault_ratio
            )
            
            state['memory_pressure'] = min(1.0, memory_pressure)  # 确保在0-1范围内
        
        # 计算内存碎片化指标
        if all(k in state for k in ['free_memory_MB', 'memory_total_MB', 'cached_memory_MB']):
            # 活跃内存比例
            active_ratio = state.get('active_memory_MB', 0) / state['memory_total_MB'] if state['memory_total_MB'] > 0 else 0
            # 非活跃内存比例
            inactive_ratio = state.get('inactive_memory_MB', 0) / state['memory_total_MB'] if state['memory_total_MB'] > 0 else 0
            # 计算碎片化指标 (根据活跃/非活跃内存比例估算)
            fragmentation = 1.0 - (active_ratio / (active_ratio + inactive_ratio + 0.01)) if (active_ratio + inactive_ratio) > 0 else 0
            state['memory_fragmentation'] = fragmentation
        
        # IO等待与系统负载关系指标
        if all(k in state for k in ['cpu_iowait_percent', 'system_loadavg_1min', 'cpu_count']):
            io_load_correlation = (
                state['cpu_iowait_percent'] / 100.0 * 
                min(3.0, state['system_loadavg_1min'] / state['cpu_count'])
            )
            state['io_pressure'] = io_load_correlation
    
    def get_state_dimension(self):
        """
        返回完整状态向量的维度
        
        Returns:
            int: 状态向量的维度
        """
        # 获取一个样本状态并返回维度
        sample_state = self.get_state()
        return len(sample_state)
        
    def get_state_as_array(self, flatten=True, include_raw=False):
        """
        将状态转换为numpy数组格式
        
        Args:
            flatten: 是否将状态扁平化为一维数组
            include_raw: 是否包含原始未归一化的值
            
        Returns:
            np.array: 状态数组
        """
        state_dict = self.get_state()
        
        # 保持一致的特征顺序
        keys = sorted(state_dict.keys())
        
        if self.normalize:
            # 获取归一化的值
            norm_values = []
            for k in keys:
                if k in self.normalization_ranges:
                    min_val, max_val = self.normalization_ranges[k]
                    # 将值归一化到[-1, 1]范围
                    norm_value = 2 * (state_dict[k] - min_val) / (max_val - min_val) - 1
                    # 限制在[-1, 1]范围内
                    norm_value = max(-1, min(norm_value, 1))
                    norm_values.append(norm_value)
                else:
                    # 对于未定义范围的指标，简单地除以一个大数
                    norm_value = state_dict[k] / 1000.0
                    norm_values.append(norm_value)
            
            if include_raw:
                # 如果需要原始值，连接归一化值和原始值
                raw_values = [state_dict[k] for k in keys]
                all_values = np.concatenate([np.array(norm_values), np.array(raw_values)])
                return all_values
            else:
                return np.array(norm_values, dtype=np.float32)
        else:
            # 不归一化，直接返回原始值
            values = [state_dict[k] for k in keys]
            return np.array(values, dtype=np.float32)
    
    def get_state_vector_for_ppo(self):
        """
        获取专为PPO优化的状态向量
        
        Returns:
            np.array: 优化后的状态向量
        """
        # 获取当前状态
        state = self.get_state()
        
        # 选择关键指标，忽略冗余信息
        key_metrics = [
            'major_page_faults_per_sec',
            'minor_page_faults_per_sec',
            'memory_usage_percent',
            'swap_percent',
            'swap_in_per_sec',
            'swap_out_per_sec',
            'cached_memory_MB',
            'system_loadavg_1min',
            'cpu_usage_percent',
            'cpu_iowait_percent',
            # 当前参数
            'current_swappiness',
            'current_cache_pressure',
            'current_dirty_ratio',
            'current_dirty_bg_ratio',
            # 趋势指标
            'major_page_faults_per_sec_trend',
            'free_memory_MB_trend',
            'swap_used_MB_trend',
            'system_loadavg_1min_trend',
            # 派生指标
            'memory_pressure',
            'memory_fragmentation',
            'io_pressure',
            # 新增内存回收指标
            'reclaimed_pages_per_sec',
            'kswapd_cpu_usage',
            'pgmajfault_to_pgfault_ratio',
            'kswapd_reclaim_ratio'
        ]
        
        # 提取关键指标并归一化
        vector = []
        for metric in key_metrics:
            if metric in state:
                # 归一化
                if self.normalize and metric in self.normalization_ranges:
                    min_val, max_val = self.normalization_ranges[metric]
                    norm_value = 2 * (state[metric] - min_val) / (max_val - min_val) - 1
                    norm_value = max(-1, min(norm_value, 1))
                    vector.append(norm_value)
                else:
                    # 对于趋势指标，已经是比率形式，限制在[-1,1]范围
                    if 'trend' in metric:
                        value = max(-1, min(state.get(metric, 0), 1))
                    else:
                        value = state.get(metric, 0) / 1000.0  # 简单缩放
                    vector.append(value)
            else:
                vector.append(0.0)  # 缺失特征填0
        
        return np.array(vector, dtype=np.float32)
    
    def get_agent_optimized_vector(self, agent_id: str) -> np.ndarray:
        """
        获取针对特定智能体优化的状态向量
        
        Args:
            agent_id: 智能体ID
        
        Returns:
            np.array: 针对该智能体优化的状态向量
        """
        # 获取该智能体关注的状态
        agent_state = self.get_agent_state(agent_id)
        
        # 转换为数组并归一化
        agent_vector = []
        
        # 确保顺序一致性
        features = sorted(agent_state.keys())
        
        for feature in features:
            value = agent_state[feature]
            
            # 归一化处理
            if self.normalize and feature in self.normalization_ranges:
                min_val, max_val = self.normalization_ranges[feature]
                norm_value = 2 * (value - min_val) / (max_val - min_val) - 1
                norm_value = max(-1, min(norm_value, 1))
                agent_vector.append(norm_value)
            else:
                # 对于趋势类指标
                if 'trend' in feature:
                    value = max(-1, min(value, 1))
                else:
                    value = value / 1000.0  # 简单缩放
                agent_vector.append(value)
        
        return np.array(agent_vector, dtype=np.float32)
    
    # 以下为原有方法
    
    def _collect_page_fault_metrics(self, state):
        """收集页面错误指标"""
        try:
            # 使用两次采样计算每秒错误率
            with open('/proc/vmstat', 'r') as f:
                vmstat1 = {}
                for line in f:
                    parts = line.split()
                    if len(parts) == 2 and ('pgfault' in parts[0] or 'pgmajfault' in parts[0]):
                        vmstat1[parts[0]] = int(parts[1])
            
            time.sleep(0.5)  # 等待0.5秒，减少采样延迟
            
            with open('/proc/vmstat', 'r') as f:
                vmstat2 = {}
                for line in f:
                    parts = line.split()
                    if len(parts) == 2 and ('pgfault' in parts[0] or 'pgmajfault' in parts[0]):
                        vmstat2[parts[0]] = int(parts[1])
            
            # 计算每秒错误率 (乘2因为采样时间为0.5秒)
            major_faults = (vmstat2.get('pgmajfault', 0) - vmstat1.get('pgmajfault', 0)) * 2
            state['major_page_faults_per_sec'] = major_faults
            
            total_faults = (vmstat2.get('pgfault', 0) - vmstat1.get('pgfault', 0)) * 2
            state['minor_page_faults_per_sec'] = total_faults - major_faults
        except Exception as e:
            self.logger.error(f"Error collecting page fault data: {e}")
            state['major_page_faults_per_sec'] = 0
            state['minor_page_faults_per_sec'] = 0
    
    def _collect_memory_metrics(self, state):
        """收集内存使用指标"""
        try:
            vm = psutil.virtual_memory()
            state['memory_total_MB'] = vm.total / (1024 * 1024)
            state['free_memory_MB'] = vm.available / (1024 * 1024)
            state['memory_usage_percent'] = vm.percent
            
            # 添加每个进程组的内存使用量
            process_memory = {}
            try:
                for proc in psutil.process_iter(['pid', 'name', 'username', 'memory_info']):
                    try:
                        process = proc.info
                        if 'memory_info' in process and process['memory_info']:
                            mem_mb = process['memory_info'].rss / (1024 * 1024)
                            if mem_mb > 50:  # 只关注内存使用超过50MB的进程
                                process_memory[process['name']] = process_memory.get(process['name'], 0) + mem_mb
                    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                        pass
                
                # 找出前5个内存使用最高的进程组
                top_processes = sorted(process_memory.items(), key=lambda x: x[1], reverse=True)[:5]
                for i, (name, mem) in enumerate(top_processes):
                    state[f'top_process_{i+1}_memory_MB'] = mem
                    state[f'top_process_{i+1}_name'] = name
                    
            except Exception as e:
                self.logger.warning(f"Error collecting process memory data: {e}")
        
        except Exception as e:
            self.logger.error(f"Error collecting memory metrics: {e}")
    
    def _collect_swap_metrics(self, state):
        """收集swap使用指标"""
        try:
            swap = psutil.swap_memory()
            state['swap_total_MB'] = swap.total / (1024 * 1024)
            state['swap_used_MB'] = swap.used / (1024 * 1024)
            state['swap_percent'] = swap.percent
            
            # 获取swap换入/换出速率
            with open('/proc/vmstat', 'r') as f:
                vmstat1 = {}
                for line in f:
                    parts = line.split()
                    if len(parts) == 2 and ('pswpin' in parts[0] or 'pswpout' in parts[0]):
                        vmstat1[parts[0]] = int(parts[1])
            
            time.sleep(0.5)  # 与前面的等待合并，总等待时间为0.5秒
            
            with open('/proc/vmstat', 'r') as f:
                vmstat2 = {}
                for line in f:
                    parts = line.split()
                    if len(parts) == 2 and ('pswpin' in parts[0] or 'pswpout' in parts[0]):
                        vmstat2[parts[0]] = int(parts[1])
            
            # 乘2因为采样时间为0.5秒
            state['swap_in_per_sec'] = (vmstat2.get('pswpin', 0) - vmstat1.get('pswpin', 0)) * 2
            state['swap_out_per_sec'] = (vmstat2.get('pswpout', 0) - vmstat1.get('pswpout', 0)) * 2
            
            # 计算swap效率 (换入/换出比率)
            total_swap_io = state['swap_in_per_sec'] + state['swap_out_per_sec']
            if total_swap_io > 0:
                state['swap_efficiency'] = state['swap_in_per_sec'] / total_swap_io
            else:
                state['swap_efficiency'] = 1.0  # 无swap活动视为高效
                
        except Exception as e:
            self.logger.error(f"Error collecting swap metrics: {e}")
            state['swap_in_per_sec'] = 0
            state['swap_out_per_sec'] = 0
    
    def _collect_cache_metrics(self, state):
        """收集缓存和slab指标"""
        try:
            with open('/proc/meminfo', 'r') as f:
                meminfo = {}
                for line in f:
                    if ':' in line:
                        parts = line.split(':')
                        if len(parts) == 2:
                            key = parts[0].strip()
                            value_parts = parts[1].strip().split()
                            if len(value_parts) >= 1:
                                value = float(value_parts[0])
                                if len(value_parts) > 1 and value_parts[1] == 'kB':
                                    value = value / 1024  # 转换为MB
                                meminfo[key] = value
            
            state['slab_memory_MB'] = meminfo.get('Slab', 0)
            state['cached_memory_MB'] = meminfo.get('Cached', 0)
            state['buffers_memory_MB'] = meminfo.get('Buffers', 0)
            state['active_memory_MB'] = meminfo.get('Active', 0)
            state['inactive_memory_MB'] = meminfo.get('Inactive', 0)
            
            # 添加额外的内存指标
            state['active_anon_MB'] = meminfo.get('Active(anon)', 0)
            state['inactive_anon_MB'] = meminfo.get('Inactive(anon)', 0)
            state['active_file_MB'] = meminfo.get('Active(file)', 0)
            state['inactive_file_MB'] = meminfo.get('Inactive(file)', 0)
            
            # 计算缓存使用效率指标
            if 'Cached' in meminfo and 'Buffers' in meminfo and 'MemTotal' in meminfo:
                cache_ratio = (meminfo['Cached'] + meminfo['Buffers']) / meminfo['MemTotal']
                state['cache_ratio'] = cache_ratio
            
        except Exception as e:
            self.logger.error(f"Error collecting cache metrics: {e}")
    
    def _collect_system_load(self, state):
        """收集系统负载信息"""
        try:
            load1, load5, load15 = os.getloadavg()
            state['system_loadavg_1min'] = load1
            state['system_loadavg_5min'] = load5
            state['system_loadavg_15min'] = load15
            
            # 负载相对于CPU核心数的比率
            state['relative_load'] = load1 / self.cpu_count if self.cpu_count else load1
            
            state['cpu_usage_percent'] = psutil.cpu_percent(interval=0.1)
            
            cpu_times_percent = psutil.cpu_times_percent(interval=0.1)
            state['cpu_user_percent'] = cpu_times_percent.user
            state['cpu_system_percent'] = cpu_times_percent.system
            state['cpu_idle_percent'] = cpu_times_percent.idle
            state['cpu_iowait_percent'] = getattr(cpu_times_percent, 'iowait', 0)
            
            # IO统计
            try:
                disk_io = psutil.disk_io_counters()
                state['disk_read_MB'] = disk_io.read_bytes / (1024 * 1024)
                state['disk_write_MB'] = disk_io.write_bytes / (1024 * 1024)
            except:
                pass
            
        except Exception as e:
            self.logger.error(f"Error collecting system load: {e}")
    
    def _collect_current_parameters(self, state):
        """收集当前内存参数设置"""
        try:
            # 扩展支持的参数列表
            param_paths = {
                'current_swappiness': '/proc/sys/vm/swappiness',
                'current_cache_pressure': '/proc/sys/vm/vfs_cache_pressure',
                'current_dirty_ratio': '/proc/sys/vm/dirty_ratio',
                'current_dirty_bg_ratio': '/proc/sys/vm/dirty_background_ratio',
                'current_min_free_kbytes': '/proc/sys/vm/min_free_kbytes',
                'current_watermark_scale_factor': '/proc/sys/vm/watermark_scale_factor'
            }
            
            for param_name, path in param_paths.items():
                try:
                    with open(path, 'r') as f:
                        state[param_name] = int(f.read().strip())
                except (FileNotFoundError, IOError):
                    # 某些内核版本可能缺少特定参数
                    self.logger.debug(f"Parameter file not found: {path}")
            
        except Exception as e:
            self.logger.error(f"Error reading memory parameters: {e}")
    
    # 以下是新增的内存回收相关指标收集方法
    
    def _collect_memory_reclaim_metrics(self, state):
        """收集内存回收相关指标"""
        try:
            # 1. 收集每秒回收的页面数
            state['reclaimed_pages_per_sec'] = self._collect_reclaimed_pages()
            
            # 2. 收集直接回收和kswapd回收的页面数
            direct_reclaim, kswapd_reclaim = self._collect_reclaim_types()
            state['direct_reclaim_pages_per_sec'] = direct_reclaim
            state['kswapd_reclaim_pages_per_sec'] = kswapd_reclaim
            
            # 3. 计算kswapd回收比例
            total_reclaim = direct_reclaim + kswapd_reclaim
            if total_reclaim > 0:
                state['kswapd_reclaim_ratio'] = kswapd_reclaim / total_reclaim
            else:
                state['kswapd_reclaim_ratio'] = 1.0  # 无回收活动时默认为1
            
            # 4. 收集kswapd CPU使用率
            state['kswapd_cpu_usage'] = self._collect_kswapd_cpu_usage()
            
            # 5. 收集页面错误比例
            state['pgmajfault_to_pgfault_ratio'] = self._collect_fault_ratio()
            
        except Exception as e:
            self.logger.error(f"Error collecting memory reclaim metrics: {e}")
            # 设置默认值
            state['reclaimed_pages_per_sec'] = 0
            state['direct_reclaim_pages_per_sec'] = 0
            state['kswapd_reclaim_pages_per_sec'] = 0
            state['kswapd_reclaim_ratio'] = 1.0
            state['kswapd_cpu_usage'] = 0
            state['pgmajfault_to_pgfault_ratio'] = 0
    
    def _collect_reclaimed_pages(self):
        """收集每秒回收的页面数"""
        try:
            # 从/proc/vmstat读取pgsteal_*数据
            with open('/proc/vmstat', 'r') as f:
                vmstat_lines = f.readlines()
            
            current_time = time.time()
            pgsteal_total = 0
            
            # 累加所有pgsteal_*计数器
            for line in vmstat_lines:
                if line.startswith('pgsteal_'):
                    parts = line.strip().split()
                    if len(parts) >= 2:
                        pgsteal_total += int(parts[1])
            
            # 计算差值和速率
            if hasattr(self, '_last_pgsteal_total'):
                time_diff = current_time - self._last_pgsteal_time
                if time_diff > 0:
                    rate = (pgsteal_total - self._last_pgsteal_total) / time_diff
                else:
                    rate = 0
            else:
                rate = 0
            
            # 保存当前值为下次计算基准
            self._last_pgsteal_total = pgsteal_total
            self._last_pgsteal_time = current_time
            
            return rate
        except Exception as e:
            self.logger.error(f"Error collecting reclaimed pages: {e}")
            return 0
    
    def _collect_reclaim_types(self):
        """收集直接回收和kswapd回收的页面数"""
        try:
            # 读取pgsteal_kswapd和pgsteal_direct
            with open('/proc/vmstat', 'r') as f:
                vmstat_lines = f.readlines()
            
            current_time = time.time()
            pgsteal_direct = 0
            pgsteal_kswapd = 0
            
            for line in vmstat_lines:
                if line.startswith('pgsteal_direct '):
                    pgsteal_direct = int(line.strip().split()[1])
                elif line.startswith('pgsteal_kswapd '):
                    pgsteal_kswapd = int(line.strip().split()[1])
            
            # 计算直接回收速率
            if hasattr(self, '_last_pgsteal_direct'):
                time_diff = current_time - self._last_pgsteal_direct_time
                if time_diff > 0:
                    direct_rate = (pgsteal_direct - self._last_pgsteal_direct) / time_diff
                else:
                    direct_rate = 0
            else:
                direct_rate = 0
            
            # 计算kswapd回收速率
            if hasattr(self, '_last_pgsteal_kswapd'):
                time_diff = current_time - self._last_pgsteal_kswapd_time
                if time_diff > 0:
                    kswapd_rate = (pgsteal_kswapd - self._last_pgsteal_kswapd) / time_diff
                else:
                    kswapd_rate = 0
            else:
                kswapd_rate = 0
            
            # 保存当前值
            self._last_pgsteal_direct = pgsteal_direct
            self._last_pgsteal_direct_time = current_time
            self._last_pgsteal_kswapd = pgsteal_kswapd
            self._last_pgsteal_kswapd_time = current_time
            
            return direct_rate, kswapd_rate
        except Exception as e:
            self.logger.error(f"Error collecting reclaim types: {e}")
            return 0, 0
    
    def _collect_kswapd_cpu_usage(self):
        """收集kswapd内核线程的CPU使用率"""
        try:
            # 方法1: 使用ps命令
            kswapd_pid = self._find_kswapd_pid()
            if kswapd_pid:
                try:
                    result = subprocess.run(
                        ["ps", "-p", str(kswapd_pid), "-o", "%cpu", "--no-headers"],
                        capture_output=True, text=True, timeout=1
                    )
                    if result.returncode == 0 and result.stdout.strip():
                        return float(result.stdout.strip())
                except Exception:
                    # 如果ps命令失败，尝试方法2
                    pass
            
            # 方法2: 直接读取/proc/[pid]/stat
            if kswapd_pid:
                try:
                    # 获取进程的CPU使用时间
                    with open(f"/proc/{kswapd_pid}/stat", "r") as f:
                        stats = f.read().split()
                        
                    # utime是第14项，stime是第15项（从1开始计数）
                    utime = int(stats[13])
                    stime = int(stats[14])
                    current_time = time.time()
                    
                    # 计算自上次采样以来的CPU使用率
                    if hasattr(self, '_last_kswapd_cpu_time'):
                        # 计算时间差
                        elapsed = current_time - self._last_kswapd_cpu_time_stamp
                        
                        # 计算CPU时间差（以jiffies为单位）
                        cpu_time_diff = (utime + stime) - self._last_kswapd_cpu_time
                        
                        # 转换为CPU使用率百分比
                        if elapsed > 0:
                            # 系统jiffies与实际时间的转换
                            jiffies_per_sec = os.sysconf(os.sysconf_names['SC_CLK_TCK'])
                            cpu_usage = (cpu_time_diff / jiffies_per_sec) / elapsed * 100
                        else:
                            cpu_usage = 0
                    else:
                        cpu_usage = 0
                    
                    # 更新历史数据
                    self._last_kswapd_cpu_time = utime + stime
                    self._last_kswapd_cpu_time_stamp = current_time
                    
                    return cpu_usage
                except Exception as e:
                    self.logger.warning(f"Failed to read kswapd CPU usage from /proc: {e}")
            
            # 方法3: 使用top命令
            try:
                result = subprocess.run(
                    ["top", "-b", "-n", "1", "-p", str(kswapd_pid or "$(pidof kswapd0)")],
                    capture_output=True, text=True, timeout=2
                )
                output = result.stdout.strip().split('\n')
                
                # 查找kswapd行
                for line in output:
                    if 'kswapd' in line:
                        # 拆分行并提取CPU使用率
                        parts = line.split()
                        if len(parts) >= 9:  # top命令输出格式中，CPU使用率通常在第9列
                            try:
                                return float(parts[8])
                            except ValueError:
                                return 0
                
                return 0  # 如果找不到kswapd行
            except Exception:
                return 0  # 如果top命令失败
        
        except Exception as e:
            self.logger.error(f"Error collecting kswapd CPU usage: {e}")
            return 0
    
    def _find_kswapd_pid(self):
        """查找kswapd进程的PID"""
        try:
            # 方法1: 使用pidof命令
            try:
                result = subprocess.run(
                    ["pidof", "kswapd0"], 
                    capture_output=True, text=True, timeout=1
                )
                if result.returncode == 0 and result.stdout.strip():
                    return int(result.stdout.strip().split()[0])
            except Exception:
                pass
            
            # 方法2: 扫描/proc目录
            for pid in os.listdir('/proc'):
                if pid.isdigit():
                    try:
                        with open(f"/proc/{pid}/comm", "r") as f:
                            comm = f.read().strip()
                            if comm in ("kswapd0", "kswapd"):
                                return int(pid)
                    except (IOError, PermissionError):
                        continue
            
            return None  # 如果找不到kswapd进程
        except Exception as e:
            self.logger.error(f"Error finding kswapd PID: {e}")
            return None
    
    def _collect_fault_ratio(self):
        """收集主页面错误与总页面错误的比例"""
        try:
            # 从/proc/vmstat读取页面错误数据
            with open('/proc/vmstat', 'r') as f:
                vmstat_lines = f.readlines()
            
            pgfault = None
            pgmajfault = None
            
            # 提取页面错误计数器
            for line in vmstat_lines:
                if line.startswith('pgfault '):
                    pgfault = int(line.strip().split()[1])
                elif line.startswith('pgmajfault '):
                    pgmajfault = int(line.strip().split()[1])
            
            # 检查是否找到了计数器
            if pgfault is None or pgmajfault is None:
                return 0
            
            # 计算差值比例
            if hasattr(self, '_last_pgfault') and hasattr(self, '_last_pgmajfault'):
                pgfault_diff = pgfault - self._last_pgfault
                pgmajfault_diff = pgmajfault - self._last_pgmajfault
                
                # 计算比例，确保不除零
                if pgfault_diff > 0:
                    ratio = pgmajfault_diff / pgfault_diff
                else:
                    ratio = 0 if pgmajfault_diff == 0 else 1  # 如果没有总错误但有主错误，设为1
            else:
                ratio = 0
            
            # 保存当前值
            self._last_pgfault = pgfault
            self._last_pgmajfault = pgmajfault
            
            # 确保比例在合理范围内
            return min(1, max(0, ratio))
            
        except Exception as e:
            self.logger.error(f"Error collecting page fault ratio: {e}")
            return 0
