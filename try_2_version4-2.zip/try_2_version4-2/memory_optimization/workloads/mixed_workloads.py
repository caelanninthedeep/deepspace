"""
混合类工作负载模块 - 针对3.5GB可用内存优化
"""

import os
import random
import time
import subprocess
import psutil
import numpy as np

class MixedWorkload:
    # 定义难度等级
    DIFFICULTY_LEVELS = ["easy", "medium", "hard", "extreme"]
    
    def __init__(self):
        self.temp_root = "/tmp/rl_mem_test"
        os.makedirs(self.temp_root, exist_ok=True)
        # 获取系统内存信息
        self.update_memory_info()
    
    def update_memory_info(self):
        """更新当前内存信息"""
        memory = psutil.virtual_memory()
        self.total_memory = memory.total / (1024 * 1024)  # 总内存(MB)
        self.available_memory = memory.available / (1024 * 1024)  # 可用内存(MB)
        self.used_percent = memory.percent
        self.buffer_cache = (psutil.virtual_memory().buffers + 
                            psutil.virtual_memory().cached) / (1024 * 1024)  # 缓冲与缓存(MB)
        
        print(f"[Mixed] 系统总内存: {self.total_memory:.0f}MB")
        print(f"[Mixed] 当前可用内存: {self.available_memory:.0f}MB")
        print(f"[Mixed] 当前缓冲/缓存: {self.buffer_cache:.0f}MB")
    
    def calculate_safe_memory(self, difficulty=None):
        """
        计算安全的内存分配量，基于当前可用内存
        
        参数:
            difficulty: 难度级别
        返回:
            size_mb: 计算出的安全内存分配量(MB)
        """
        self.update_memory_info()
        
        # 基于可用内存的目标范围
        if difficulty == "easy":
            min_percent, max_percent = 15, 25  # 可用内存的15-25%
        elif difficulty == "medium":
            min_percent, max_percent = 30, 40  # 可用内存的30-40%
        elif difficulty == "hard":
            min_percent, max_percent = 45, 55  # 可用内存的45-55%
        elif difficulty == "extreme":
            min_percent, max_percent = 60, 70  # 可用内存的60-70%
        else:
            min_percent, max_percent = 15, 25  # 默认为easy
        
        # 计算目标值范围 (MB)
        min_size = int(self.available_memory * min_percent / 100)
        max_size = int(self.available_memory * max_percent / 100)
        
        # 添加安全检查，确保至少保留500MB可用内存
        safe_limit = self.available_memory - 500
        if max_size > safe_limit:
            max_size = int(safe_limit) if safe_limit > 0 else min_size
            if min_size > max_size:
                min_size = max_size
        
        # 随机选择范围内的值
        if min_size >= max_size:
            size_mb = min_size
        else:
            size_mb = random.randint(min_size, max_size)
        
        return size_mb
    
    def run_mixed_workload(self, difficulty=None):
        """
        混合型工作负载，结合内存和IO操作
        
        参数:
            difficulty: 难度级别，可选值为 "easy", "medium", "hard", "extreme"
        返回:
            工作负载难度级别、内存大小和IO参数
        """
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 计算安全的内存分配量
        size_mb = self.calculate_safe_memory(difficulty)
        
        # 基于可用内存的3.5GB具体分配值:
        # Easy: ~537MB到895MB (15-25%)
        # Medium: ~1075MB到1433MB (30-40%) 
        # Hard: ~1612MB到1971MB (45-55%)
        # Extreme: ~2150MB到2508MB (60-70%)
        
        # 根据难度级别确定IO参数
        if difficulty == "easy":
            num_files = random.randint(3, 6)
            file_size_mb = random.randint(20, 50)
            iterations = 30
            memory_ops = 1500
        elif difficulty == "medium":
            num_files = random.randint(6, 9)
            file_size_mb = random.randint(50, 100)
            iterations = 50
            memory_ops = 3000
        elif difficulty == "hard":
            num_files = random.randint(8, 12)
            file_size_mb = random.randint(100, 150)
            iterations = 70
            memory_ops = 5000
        elif difficulty == "extreme":
            num_files = random.randint(12, 15)
            file_size_mb = random.randint(150, 200)
            iterations = 100
            memory_ops = 8000
        
        print(f"[Mixed Workload] 难度: {difficulty}, 运行混合负载:")
        print(f"[Mixed Workload] 内存: {size_mb}MB (可用内存的{size_mb/self.available_memory*100:.1f}%)")
        print(f"[Mixed Workload] IO: {num_files}个文件 x {file_size_mb}MB")
        print(f"[Mixed Workload] 迭代次数: {iterations}, 内存操作: {memory_ops}/迭代")
        
        try:
            # 内存部分
            memory_data = bytearray(size_mb * 1024 * 1024)
            
            # IO部分
            temp_dir = os.path.join(self.temp_root, f"mixed_test_{difficulty}")
            os.makedirs(temp_dir, exist_ok=True)
            
            # 创建文件
            files = []
            total_io_mb = 0
            
            for i in range(num_files):
                filename = f"{temp_dir}/test_file_mixed_{i}.dat"
                print(f"[Mixed] 创建文件 {i+1}/{num_files} ({file_size_mb}MB)...")
                
                # 分块写入大文件
                with open(filename, 'wb') as f:
                    chunk_size = 10 * 1024 * 1024  # 10MB块
                    remaining = file_size_mb * 1024 * 1024
                    while remaining > 0:
                        write_size = min(chunk_size, remaining)
                        f.write(os.urandom(write_size))
                        remaining -= write_size
                
                files.append(filename)
                total_io_mb += file_size_mb
                
                # 每创建2个文件检查一次内存状态
                if (i + 1) % 2 == 0:
                    self.update_memory_info()
                    if self.available_memory < 800:  # 少于800MB可用内存时减少文件数量
                        print("[Mixed] 可用内存不足，减少文件数量")
                        num_files = i + 1
                        break
            
            print(f"[Mixed] 所有文件创建完成 (总计 {total_io_mb}MB)")
            print(f"[Mixed] 开始交替执行内存和IO操作...")
            
            # 交替执行内存和IO操作
            for i in range(iterations):
                if i > 0 and i % 10 == 0:
                    print(f"[Mixed] 完成 {i}/{iterations} 次迭代")
                    self.update_memory_info()
                
                # 内存访问 - 随机读写
                for j in range(memory_ops):
                    # 每1000次操作更新一次进度
                    if j > 0 and j % 1000 == 0 and i % 10 == 0:
                        print(f"[Mixed] 内存操作: {j}/{memory_ops}")
                    
                    index = random.randint(0, len(memory_data) - 1)
                    memory_data[index] = random.randint(0, 255)
                
                # 文件访问 - 随机读取多个位置
                if files:
                    filename = random.choice(files)
                    file_size = os.path.getsize(filename)
                    
                    with open(filename, 'rb') as f:
                        # 多次随机读取
                        for _ in range(5):  # 每次迭代读取5个位置
                            pos = random.randint(0, file_size - 102400)
                            f.seek(pos)
                            _ = f.read(102400)  # 读取100KB
            
            # 迭代结束后更新内存状态
            self.update_memory_info()
            
        except Exception as e:
            print(f"[Mixed] 错误: {e}")
        finally:
            # 清理文件
            print("[Mixed] 清理文件...")
            for filename in files:
                try:
                    os.remove(filename)
                except Exception as e:
                    print(f"[Mixed] 删除文件时出错: {e}")
            
            try:
                os.rmdir(temp_dir)
            except Exception as e:
                print(f"[Mixed] 删除目录时出错: {e}")
            
            # 释放内存
            try:
                del memory_data
                print("[Mixed] 内存已释放")
            except:
                pass
        
        return difficulty, size_mb, len(files), file_size_mb
    
    def run_network_memory_workload(self, difficulty=None):
        """
        网络和内存混合负载
        
        参数:
            difficulty: 难度级别，可选值为 "easy", "medium", "hard", "extreme"
        返回:
            工作负载难度级别、内存大小和ping次数
        """
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 计算安全的内存分配量
        size_mb = self.calculate_safe_memory(difficulty)
        
        # 根据难度级别确定网络参数
        if difficulty == "easy":
            ping_count = random.randint(10, 20)
            ping_targets = ["google.com", "github.com"]
            memory_ops = 5000
        elif difficulty == "medium":
            ping_count = random.randint(20, 40)
            ping_targets = ["google.com", "github.com", "microsoft.com"]
            memory_ops = 10000
        elif difficulty == "hard":
            ping_count = random.randint(40, 60)
            ping_targets = ["google.com", "github.com", "microsoft.com", "amazon.com"]
            memory_ops = 15000
        elif difficulty == "extreme":
            ping_count = random.randint(60, 80)
            ping_targets = ["google.com", "github.com", "microsoft.com", "amazon.com", "cloudflare.com"]
            memory_ops = 20000
        
        print(f"[Network Mixed] 难度: {difficulty}")
        print(f"[Network Mixed] 内存: {size_mb}MB (可用内存的{size_mb/self.available_memory*100:.1f}%)")
        print(f"[Network Mixed] 网络: {ping_count} pings 到 {len(ping_targets)} 个目标")
        
        try:
            # 内存部分
            memory_data = bytearray(size_mb * 1024 * 1024)
            
            # 内存初始化
            print("[Network Mixed] 初始化内存...")
            for i in range(0, len(memory_data), 4096):
                memory_data[i] = 1
                
                if i % (100 * 1024 * 1024) == 0 and i > 0:  # 每100MB报告一次
                    print(f"[Network Mixed] 已初始化 {i/(1024*1024):.0f}/{size_mb}MB")
            
            # 网络部分
            print(f"[Network Mixed] 开始网络操作...")
            for target in ping_targets:
                print(f"[Network Mixed] Ping {target} {ping_count} 次...")
                try:
                    subprocess.run(['ping', '-c', str(ping_count), target],
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                except Exception as e:
                    print(f"[Network Mixed] 网络操作错误: {e}")
                
                # 网络操作后访问一部分内存
                print(f"[Network Mixed] 执行内存操作...")
                for _ in range(memory_ops // len(ping_targets)):
                    index = random.randint(0, len(memory_data) - 1)
                    memory_data[index] = random.randint(0, 255)
            
            # 最后的内存操作
            print(f"[Network Mixed] 执行最终内存操作...")
            for i in range(memory_ops):
                if i % 5000 == 0 and i > 0:
                    print(f"[Network Mixed] 已完成 {i}/{memory_ops} 次内存操作")
                
                index = random.randint(0, len(memory_data) - 1)
                memory_data[index] = random.randint(0, 255)
            
            # 更新内存状态
            self.update_memory_info()
            
        except Exception as e:
            print(f"[Network Mixed] 错误: {e}")
        finally:
            # 释放内存
            try:
                del memory_data
                print("[Network Mixed] 内存已释放")
            except:
                pass
        
        return difficulty, size_mb, ping_count
    
    def run_cpu_memory_workload(self, difficulty=None):
        """
        CPU和内存混合负载 - 使用NumPy进行高效计算
        
        参数:
            difficulty: 难度级别，可选值为 "easy", "medium", "hard", "extreme"
        返回:
            工作负载难度级别、内存大小和矩阵计算规模
        """
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 计算安全的内存分配量
        size_mb = self.calculate_safe_memory(difficulty)
        
        # 根据难度级别确定计算参数
        if difficulty == "easy":
            matrix_size = 1000
            compute_iterations = 5
            memory_intervals = 2  # 每隔多少次计算访问一次内存
            memory_ops_per_interval = 5000
        elif difficulty == "medium":
            matrix_size = 1500
            compute_iterations = 8
            memory_intervals = 2
            memory_ops_per_interval = 8000
        elif difficulty == "hard":
            matrix_size = 2000
            compute_iterations = 12
            memory_intervals = 1
            memory_ops_per_interval = 12000
        elif difficulty == "extreme":
            matrix_size = 2500
            compute_iterations = 15
            memory_intervals = 1
            memory_ops_per_interval = 15000
        
        print(f"[CPU Mixed] 难度: {difficulty}")
        print(f"[CPU Mixed] 内存: {size_mb}MB (可用内存的{size_mb/self.available_memory*100:.1f}%)")
        print(f"[CPU Mixed] CPU: 矩阵大小 {matrix_size}x{matrix_size}, {compute_iterations} 次迭代")
        
        try:
            # 内存部分
            memory_data = bytearray(size_mb * 1024 * 1024)
            
            # 内存初始化
            print("[CPU Mixed] 初始化内存...")
            for i in range(0, len(memory_data), 4096):
                memory_data[i] = 1
                
                if i % (100 * 1024 * 1024) == 0 and i > 0:  # 每100MB报告一次
                    print(f"[CPU Mixed] 已初始化 {i/(1024*1024):.0f}/{size_mb}MB")
            
            # CPU计算部分
            print(f"[CPU Mixed] 创建矩阵 ({matrix_size}x{matrix_size})...")
            try:
                # 使用NumPy进行高效计算
                matrix_a = np.random.random((matrix_size, matrix_size))
                matrix_b = np.random.random((matrix_size, matrix_size))
                
                print(f"[CPU Mixed] 开始矩阵计算...")
                for i in range(compute_iterations):
                    print(f"[CPU Mixed] 计算迭代 {i+1}/{compute_iterations}...")
                    result = np.matmul(matrix_a, matrix_b)
                    
                    # 内存访问
                    if (i+1) % memory_intervals == 0:
                        print(f"[CPU Mixed] 执行内存操作...")
                        for j in range(memory_ops_per_interval):
                            if j % 5000 == 0 and j > 0:
                                print(f"[CPU Mixed] 已完成 {j}/{memory_ops_per_interval} 次内存操作")
                            
                            index = random.randint(0, len(memory_data) - 1)
                            memory_data[index] = random.randint(0, 255)
                
                # 更新内存状态
                self.update_memory_info()
                
            except ImportError:
                print("[CPU Mixed] NumPy不可用，使用备选方案...")
                
                # 使用纯Python计算（如果NumPy不可用）
                # 使用较小的矩阵以减少计算时间
                smaller_size = min(matrix_size // 5, 500)
                print(f"[CPU Mixed] 使用较小的矩阵大小: {smaller_size}")
                
                matrix_a = [[random.random() for _ in range(smaller_size)] for _ in range(smaller_size)]
                matrix_b = [[random.random() for _ in range(smaller_size)] for _ in range(smaller_size)]
                
                # 简化的矩阵乘法
                for i in range(compute_iterations):
                    print(f"[CPU Mixed] 计算迭代 {i+1}/{compute_iterations}...")
                    result = [[0 for _ in range(smaller_size)] for _ in range(smaller_size)]
                    
                    # 只计算部分矩阵乘法以节省时间
                    compute_range = min(smaller_size, 100)
                    for x in range(compute_range):
                        for y in range(compute_range):
                            result[x][y] = sum(matrix_a[x][k] * matrix_b[k][y] for k in range(smaller_size))
                            
                            # 同时访问内存
                            if x % 10 == 0 and y % 10 == 0:
                                for _ in range(1000):  # 减少操作次数
                                    index = random.randint(0, len(memory_data) - 1)
                                    memory_data[index] = random.randint(0, 255)
            
        except Exception as e:
            print(f"[CPU Mixed] 错误: {e}")
        finally:
            # 释放内存和计算资源
            try:
                del memory_data
                if 'matrix_a' in locals(): del matrix_a
                if 'matrix_b' in locals(): del matrix_b
                if 'result' in locals(): del result
                print("[CPU Mixed] 资源已释放")
            except:
                pass
        
        return difficulty, size_mb, matrix_size
    
    def run_intensive_mixed_sequence(self, duration_seconds=180):
        """
        执行一系列混合负载，旨在触发内存回收
        
        参数:
            duration_seconds: 运行时间(秒)
        返回:
            完成的阶段数
        """
        print(f"[Sequence] 开始执行混合负载序列，计划时间: {duration_seconds}秒...")
        start_time = time.time()
        stages_completed = 0
        
        try:
            # 阶段1: 填充页面缓存
            if time.time() - start_time < duration_seconds:
                print("\n[Sequence] 阶段1: 填充页面缓存")
                self.run_file_operations("medium", file_count=30)
                stages_completed += 1
            
            # 阶段2: 内存+IO混合负载
            if time.time() - start_time < duration_seconds:
                print("\n[Sequence] 阶段2: 内存+IO混合负载")
                self.run_mixed_workload("hard")
                stages_completed += 1
            
            # 阶段3: CPU+内存负载
            if time.time() - start_time < duration_seconds:
                print("\n[Sequence] 阶段3: CPU+内存负载")
                self.run_cpu_memory_workload("medium")
                stages_completed += 1
                
            # 阶段4: 高内存压力
            if time.time() - start_time < duration_seconds:
                print("\n[Sequence] 阶段4: 高内存压力")
                self.create_memory_pressure(percent=60, duration=30)  # 使用60%可用内存，持续30秒
                stages_completed += 1
            
            # 阶段5: 内存+网络负载
            if time.time() - start_time < duration_seconds:
                print("\n[Sequence] 阶段5: 内存+网络负载")
                self.run_network_memory_workload("hard")
                stages_completed += 1
            
            # 阶段6: 最终高强度混合负载
            if time.time() - start_time < duration_seconds:
                print("\n[Sequence] 阶段6: 最终高强度混合负载")
                self.run_mixed_workload("extreme")
                stages_completed += 1
                
            elapsed = time.time() - start_time
            print(f"\n[Sequence] 混合负载序列完成! 用时: {elapsed:.1f}秒, 完成 {stages_completed} 个阶段")
            
        except Exception as e:
            print(f"[Sequence] 错误: {e}")
            print(f"[Sequence] 已完成 {stages_completed} 个阶段")
        
        return stages_completed
    
    def run_file_operations(self, difficulty=None, file_count=None):
        """
        文件操作负载 - 创建、读取和删除文件
        
        参数:
            difficulty: 难度级别
            file_count: 可选的文件数量覆盖
        返回:
            工作负载难度级别和文件数量
        """
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 根据难度级别确定参数
        if file_count is None:
            if difficulty == "easy":
                file_count = random.randint(20, 50)
                file_size_kb = random.randint(100, 500)
            elif difficulty == "medium":
                file_count = random.randint(50, 100)
                file_size_kb = random.randint(500, 1000)
            elif difficulty == "hard":
                file_count = random.randint(100, 200)
                file_size_kb = random.randint(1000, 2000)
            elif difficulty == "extreme":
                file_count = random.randint(200, 300)
                file_size_kb = random.randint(2000, 4000)
        else:
            # 如果指定了文件数量，根据难度设置文件大小
            if difficulty == "easy":
                file_size_kb = random.randint(100, 500)
            elif difficulty == "medium":
                file_size_kb = random.randint(500, 1000)
            elif difficulty == "hard":
                file_size_kb = random.randint(1000, 2000)
            elif difficulty == "extreme":
                file_size_kb = random.randint(2000, 4000)
        
        total_size_mb = file_count * file_size_kb / 1024
        
        print(f"[Files] 难度: {difficulty}, 创建 {file_count} 个文件 (每个 {file_size_kb}KB)")
        print(f"[Files] 总计: {total_size_mb:.1f}MB")
        
        # 创建临时文件夹
        temp_dir = os.path.join(self.temp_root, f"files_test_{difficulty}")
        os.makedirs(temp_dir, exist_ok=True)
        
        try:
            # 创建文件
            files = []
            for i in range(file_count):
                filename = f"{temp_dir}/file_{i}.dat"
                with open(filename, 'wb') as f:
                    f.write(os.urandom(file_size_kb * 1024))
                files.append(filename)
                
                # 进度报告
                if (i+1) % 20 == 0 or i+1 == file_count:
                    print(f"[Files] 已创建 {i+1}/{file_count} 个文件")
            
            # 随机读取文件
            read_count = min(file_count, 50)
            print(f"[Files] 随机读取 {read_count} 个文件...")
            
            for i in range(read_count):
                filename = random.choice(files)
                with open(filename, 'rb') as f:
                    _ = f.read()
                
                # 进度报告
                if (i+1) % 10 == 0 or i+1 == read_count:
                    print(f"[Files] 已读取 {i+1}/{read_count} 个文件")
            
            # 更新内存状态
            self.update_memory_info()
            
        except Exception as e:
            print(f"[Files] 错误: {e}")
        finally:
            # 清理文件
            print("[Files] 清理文件...")
            for filename in files:
                try:
                    os.remove(filename)
                except:
                    pass
            
            try:
                os.rmdir(temp_dir)
            except:
                pass
        
        return difficulty, file_count
    
    def create_memory_pressure(self, percent=50, duration=30):
        """
        创建持续的内存压力
        
        参数:
            percent: 使用可用内存的百分比
            duration: 持续时间(秒)
        返回:
            分配的内存大小(MB)
        """
        self.update_memory_info()
        
        # 计算要分配的内存大小
        size_mb = int(self.available_memory * percent / 100)
        print(f"[Pressure] 创建内存压力: {size_mb}MB (可用内存的{percent}%), 持续 {duration} 秒")
        
        try:
            # 分配内存
            memory_data = bytearray(size_mb * 1024 * 1024)
            
            # 初始化内存以确保实际分配
            for i in range(0, len(memory_data), 4096):
                memory_data[i] = 1
                
                if i % (100 * 1024 * 1024) == 0 and i > 0:  # 每100MB报告一次
                    print(f"[Pressure] 已初始化 {i/(1024*1024):.0f}/{size_mb}MB")
            
            # 更新内存状态
            self.update_memory_info()
            
            # 维持指定时间
            print(f"[Pressure] 维持内存压力 {duration} 秒...")
            start_time = time.time()
            
            # 每5秒访问一次内存，防止被回收
            while time.time() - start_time < duration:
                # 计算已经过时间
                elapsed = time.time() - start_time
                remaining = duration - elapsed
                
                # 随机访问一些内存位置
                for _ in range(1000):
                    index = random.randint(0, len(memory_data) - 1)
                    memory_data[index] = random.randint(0, 255)
                
                # 只休眠较短时间，确保能被中断
                sleep_time = min(5, remaining)
                if sleep_time > 0:
                    print(f"[Pressure] 已持续 {elapsed:.1f}/{duration} 秒")
                    time.sleep(sleep_time)
            
            # 更新最终内存状态
            self.update_memory_info()
            
        except Exception as e:
            print(f"[Pressure] 错误: {e}")
            size_mb = 0
        finally:
            # 释放内存
            if 'memory_data' in locals():
                del memory_data
                print("[Pressure] 内存已释放")
        
        return size_mb
