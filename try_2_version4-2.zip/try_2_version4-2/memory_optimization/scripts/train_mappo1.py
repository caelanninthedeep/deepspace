#!/usr/bin/env python3

"""
训练专门化内存管理智能体脚本

这个脚本用于训练专门化的内存管理智能体，包括：
1. 页面缓存智能体（Page Cache Agent）
2. 内存回收智能体（Memory Reclaim Agent）
3. 内存调度智能体（Memory Scheduler Agent）

支持使用 MAPPO 进行联合训练或使用 PPO 分别训练每个智能体
"""

import os
import sys
import time
import argparse
import yaml
import numpy as np
import torch
from datetime import datetime
from collections import defaultdict

# 导入项目组件
from ..algorithms.network import create_memory_management_networks
from ..algorithms.buffer import MultiAgentRolloutBuffer
from ..algorithms.mappo1 import MAPPO, MAPPOTrainer
from ..algorithms.ppo import PPO
from .reward_tracker import RewardTracker

# 训练开始前初始化奖励追踪器
reward_tracker = RewardTracker(save_dir='./memory_rl_logs')

def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description="Train specialized memory management agents")
    parser.add_argument("--config", type=str, required=True, help="Path to config file")
    parser.add_argument("--checkpoint", type=str, default=None, help="Path to checkpoint to resume training")
    parser.add_argument("--mode", type=str, default="joint", choices=["joint", "separate"], 
                       help="Training mode: joint (MAPPO) or separate (individual PPO)")
    parser.add_argument("--seed", type=int, default=None, help="Random seed")
    parser.add_argument("--debug", action="store_true", help="启用详细调试输出")
    return parser.parse_args()

def load_config(config_path):
    """加载配置文件"""
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    return config

def set_seed(seed):
    """设置随机种子"""
    if seed is None:
        return
        
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    # 设置确定性
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def create_save_dir(config):
    """创建保存目录"""
    # 创建基础目录
    base_dir = config.get("save_dir", "saved_models")
    os.makedirs(base_dir, exist_ok=True)
    
    # 创建特定实验目录
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    exp_name = config.get("exp_name", "memory_management")
    save_dir = os.path.join(base_dir, f"{exp_name}_{timestamp}")
    os.makedirs(save_dir, exist_ok=True)
    
    # 创建模型和日志子目录
    models_dir = os.path.join(save_dir, "models")
    logs_dir = os.path.join(save_dir, "logs")
    os.makedirs(models_dir, exist_ok=True)
    os.makedirs(logs_dir, exist_ok=True)
    
    return save_dir, models_dir, logs_dir

def create_environment(env_config):
    """创建环境实例"""
    try:
        # 确保 env_config 是字典类型
        if not isinstance(env_config, dict):
            print(f"警告: env_config不是字典类型，而是 {type(env_config)}")
            
            # 将列表转换为字典
            if isinstance(env_config, list):
                print("尝试将env_config列表转换为字典...")
                env_config_dict = {}
                for item in env_config:
                    if isinstance(item, dict):
                        env_config_dict.update(item)
                env_config = env_config_dict
                print(f"转换后的env_config: {env_config}")
            else:
                # 创建默认字典
                print("无法转换，使用默认env_config")
                env_config = {
                    "env_type": "memory_management",
                    "scenario": "memory_management",
                    "normalize_observations": True,
                    "normalize_rewards": False,
                    "render_mode": None
                }
        
        # 添加最大回合步数到环境配置
        if "max_episode_steps" not in env_config and "training" in config and "max_steps" in config["training"]:
            env_config["max_episode_steps"] = config["training"]["max_steps"]
            print(f"设置环境最大回合步数: {env_config['max_episode_steps']}")
        
        # 尝试导入环境
        from ..environment.mem_env import MultiAgentMemoryEnv
        # 创建环境实例
        env = MultiAgentMemoryEnv(params=env_config)
        return env
    except ImportError as e:
        print(f"Error importing environment: {e}")
        print("Please make sure the environment module is available in your PYTHONPATH")
        sys.exit(1)

def get_environment_dimensions(env, debug_print=print):
    """获取环境的观察和动作维度信息"""
    obs_dims = {}
    action_dims = {}
    try:
        debug_print("正在获取环境维度信息...")
        
        # 1. 尝试从环境获取观察维度
        debug_print("步骤1: 获取观察维度")
        
        # 1.1 从observation_space属性获取
        if hasattr(env, 'observation_space'):
            debug_print("  环境具有observation_space属性")
            for agent_id in env.agent_ids:
                if isinstance(env.observation_space, dict) and agent_id in env.observation_space:
                    if hasattr(env.observation_space[agent_id], 'shape'):
                        obs_dims[agent_id] = env.observation_space[agent_id].shape[0]
                        debug_print(f"  从observation_space获取智能体 {agent_id} 的观察维度: {obs_dims[agent_id]}")
        
        # 1.2 从state_collector获取（更准确）
        if hasattr(env, 'state_collector'):
            debug_print("  环境具有state_collector属性")
            for agent_id in env.agent_ids:
                try:
                    # 先尝试获取维度函数
                    if hasattr(env.state_collector, 'get_agent_state_dimension'):
                        dim = env.state_collector.get_agent_state_dimension(agent_id)
                        obs_dims[agent_id] = dim
                        debug_print(f"  从state_collector.get_agent_state_dimension获取智能体 {agent_id} 的观察维度: {dim}")
                    # 如果没有维度函数，直接获取向量并计算长度
                    else:
                        state_vector = env.state_collector.get_agent_optimized_vector(agent_id)
                        real_obs_dim = len(state_vector)
                        obs_dims[agent_id] = real_obs_dim
                        debug_print(f"  从state_collector.get_agent_optimized_vector计算智能体 {agent_id} 的观察维度: {real_obs_dim}")
                except Exception as e:
                    debug_print(f"  获取智能体 {agent_id} 的观察维度时出错: {e}")
        
        # 2. 尝试多种方法获取动作维度
        debug_print("步骤2: 获取动作维度")
        
        # 2.1 从action_space属性获取
        if hasattr(env, 'action_space'):
            debug_print("  环境具有action_space属性")
            for agent_id in env.agent_ids:
                if isinstance(env.action_space, dict) and agent_id in env.action_space:
                    if hasattr(env.action_space[agent_id], 'shape'):
                        action_dims[agent_id] = env.action_space[agent_id].shape[0]
                        debug_print(f"  从action_space.shape获取智能体 {agent_id} 的动作维度: {action_dims[agent_id]}")
                    elif hasattr(env.action_space[agent_id], 'n'):
                        action_dims[agent_id] = env.action_space[agent_id].n
                        debug_print(f"  从action_space.n获取智能体 {agent_id} 的动作维度: {action_dims[agent_id]}")
        
        # 2.2 尝试从环境的方法获取
        if not all(agent_id in action_dims for agent_id in env.agent_ids):
            debug_print("  尝试从环境的方法获取动作维度")
            
            # 尝试调用可能的方法
            potential_methods = ['get_action_dimensions', 'get_action_dims', 'action_dimensions', 'action_dims']
            for method_name in potential_methods:
                if hasattr(env, method_name) and callable(getattr(env, method_name)):
                    try:
                        debug_print(f"  尝试调用env.{method_name}方法")
                        method = getattr(env, method_name)
                        result = method()
                        
                        if isinstance(result, dict):
                            for agent_id, dim in result.items():
                                if agent_id not in action_dims:
                                    action_dims[agent_id] = dim
                                    debug_print(f"  从env.{method_name}获取智能体 {agent_id} 的动作维度: {dim}")
                        break
                    except Exception as e:
                        debug_print(f"  调用env.{method_name}时出错: {e}")
        
        # 2.3 使用默认值
        default_action_dims = {
            'page_cache': 3,
            'memory_reclaim': 2,
            'memory_scheduler': 2
        }
        
        # 检查已获取的动作维度是否与默认值一致
        consistent = True
        for agent_id, dim in action_dims.items():
            if agent_id in default_action_dims and default_action_dims[agent_id] != dim:
                debug_print(f"  警告：获取的 {agent_id} 动作维度 ({dim}) 与默认值 ({default_action_dims[agent_id]}) 不一致")
                consistent = False
        
        if not consistent:
            debug_print("  警告：检测到动作维度不一致，请确认默认值是否正确")
        
        # 3. 填充缺失的维度信息
        debug_print("步骤3: 填充缺失的维度信息")
        
        # 3.1 填充默认动作维度
        for agent_id in env.agent_ids:
            if agent_id not in action_dims:
                if agent_id in default_action_dims:
                    action_dims[agent_id] = default_action_dims[agent_id]
                    debug_print(f"  使用默认值设置智能体 {agent_id} 动作维度: {action_dims[agent_id]}")
                else:
                    debug_print(f"  警告：无法确定智能体 {agent_id} 的动作维度，且没有默认值")
                    # 使用合理的默认值而不是抛出错误
                    action_dims[agent_id] = 2  # 假设最小动作维度为2
                    debug_print(f"  使用应急默认值设置智能体 {agent_id} 动作维度: 2")
        
        # 3.2 检查观察维度是否已获取
        for agent_id in env.agent_ids:
            if agent_id not in obs_dims:
                debug_print(f"  错误：无法确定智能体 {agent_id} 的观察维度")
                # 尝试使用最小合理值
                obs_dims[agent_id] = 10  # 假设最小观察维度为10
                debug_print(f"  使用应急默认值设置智能体 {agent_id} 观察维度: 10")
        
        # 4. 验证并汇总维度信息
        debug_print("步骤4: 验证维度信息")
        
        for agent_id in env.agent_ids:
            debug_print(f"  {agent_id}: 观察维度={obs_dims[agent_id]}, 动作维度={action_dims[agent_id]}")
            
            # 对观察维度进行简单验证
            if obs_dims[agent_id] <= 0:
                debug_print(f"  错误：智能体 {agent_id} 的观察维度 ({obs_dims[agent_id]}) 无效")
                obs_dims[agent_id] = 10  # 设置最小合理值
                debug_print(f"  将观察维度更正为: {obs_dims[agent_id]}")
            
            # 对动作维度进行简单验证
            if action_dims[agent_id] <= 0:
                debug_print(f"  错误：智能体 {agent_id} 的动作维度 ({action_dims[agent_id]}) 无效")
                action_dims[agent_id] = 2  # 设置最小合理值
                debug_print(f"  将动作维度更正为: {action_dims[agent_id]}")
        
        debug_print("维度信息获取完成！")
        return obs_dims, action_dims

    except Exception as e:
        print(f"获取环境维度信息时出错: {e}")
        debug_print(f"获取环境维度信息时出错: {e}")
        import traceback
        debug_print(traceback.format_exc())
        
        # 使用完整的默认值作为后备方案
        obs_dims = {
            'page_cache': 13,
            'memory_reclaim': 19,  # 更新为包含新指标的维度
            'memory_scheduler': 12
        }
        action_dims = {
            'page_cache': 3,
            'memory_reclaim': 2,
            'memory_scheduler': 2
        }
        
        # 检查默认值是否覆盖所有智能体
        missing_agents = [agent_id for agent_id in env.agent_ids 
                         if agent_id not in obs_dims or agent_id not in action_dims]
        
        if missing_agents:
            print(f"警告：默认值中缺少以下智能体: {missing_agents}")
            # 为缺失的智能体添加默认值
            for agent_id in missing_agents:
                obs_dims[agent_id] = 12  # 假设的默认观察维度
                action_dims[agent_id] = 2  # 假设的默认动作维度
                debug_print(f"为缺失智能体 {agent_id} 设置默认维度: 观察={obs_dims[agent_id]}, 动作={action_dims[agent_id]}")
        
        print("使用默认维度信息:")
        for agent_id in env.agent_ids:
            print(f"  {agent_id}: 观察维度={obs_dims[agent_id]}, 动作维度={action_dims[agent_id]}")
        
        return obs_dims, action_dims

def train_with_mappo(config, save_dir, models_dir, logs_dir, debug_mode=False):
    """使用MAPPO联合训练所有智能体"""
    print("\n" + "="*60)
    print("         开始使用 MAPPO 联合训练所有智能体")
    print("="*60)
    
    # 设置调试日志
    debug_log_file = None
    if debug_mode:
        debug_log_file = os.path.join(logs_dir, "debug.log")
        
    def debug_print(message):
        if debug_mode:
            timestamp = datetime.now().strftime("%H:%M:%S")
            full_message = f"[{timestamp}] [DEBUG] {message}"
            print(full_message)
            if debug_log_file:
                with open(debug_log_file, "a") as f:
                    f.write(f"{full_message}\n")
    
    # 打印配置结构（调试用）
    debug_print(f"配置结构: {list(config.keys())}")
    
    # 设置设备
    device = torch.device("cuda" if torch.cuda.is_available() and config.get("use_cuda", True) else "cpu")
    print(f"使用设备: {device}")
    debug_print(f"CUDA是否可用: {torch.cuda.is_available()}")
    
    # 创建环境
    env_config = config.get("env_config", {})
    
    # 添加最大回合步数到环境配置
    if "training" in config and "max_steps" in config["training"]:
        env_config["max_episode_steps"] = config["training"]["max_steps"]
        debug_print(f"设置环境最大回合步数: {env_config['max_episode_steps']}")
    
    debug_print(f"环境配置: {env_config}")
    
    try:
        env = create_environment(env_config)
        debug_print("环境创建成功")
        
        # 打印环境信息
        if hasattr(env, 'agent_ids'):
            debug_print(f"智能体IDs: {env.agent_ids}")
            print(f"智能体IDs: {env.agent_ids}")
        if hasattr(env, 'observation_space'):
            debug_print(f"观察空间: {env.observation_space}")
        if hasattr(env, 'action_space'):
            debug_print(f"动作空间: {env.action_space}")
    except Exception as e:
        print(f"环境创建失败: {e}")
        import traceback
        traceback.print_exc()
        return None
    
    # 获取环境维度信息
    try:
        obs_dims, action_dims = get_environment_dimensions(env, debug_print)
        
        print("成功获取所有智能体的维度信息:")
        for agent_id in env.agent_ids:
            print(f"  {agent_id}: 观察维度={obs_dims[agent_id]}, 动作维度={action_dims[agent_id]}")
        
        # 新增: 检查并更新memory_reclaim智能体的观察维度
        if hasattr(env, 'state_collector') and 'memory_reclaim' in env.agent_ids:
            memory_reclaim_dims_before = obs_dims.get('memory_reclaim', 0)
            try:
                # 检查是否已经包含新指标
                memory_reclaim_features = env.state_collector.get_agent_state('memory_reclaim')
                expected_new_dims = [
                    'reclaimed_pages_per_sec',
                    'kswapd_cpu_usage', 
                    'pgmajfault_to_pgfault_ratio',
                    'direct_reclaim_pages_per_sec',
                    'kswapd_reclaim_pages_per_sec',
                    'kswapd_reclaim_ratio'
                ]
                
                new_features_count = sum(1 for f in expected_new_dims if f in memory_reclaim_features)
                debug_print(f"检测到memory_reclaim的新特征数量: {new_features_count}")
                
                # 获取实际维度
                memory_reclaim_dims_actual = env.state_collector.get_agent_state_dimension('memory_reclaim')
                
                # 如果实际维度与之前的不同，更新维度
                if memory_reclaim_dims_actual != memory_reclaim_dims_before:
                    debug_print(f"更新memory_reclaim观察维度: {memory_reclaim_dims_before} -> {memory_reclaim_dims_actual}")
                    obs_dims['memory_reclaim'] = memory_reclaim_dims_actual
                    print(f"已更新memory_reclaim智能体的观察维度: {memory_reclaim_dims_actual}")
            except Exception as e:
                debug_print(f"检查memory_reclaim维度时出错: {e}")
                import traceback
                debug_print(traceback.format_exc())
        
    except Exception as e:
        print(f"获取环境维度信息时出错: {e}")
        debug_print(f"获取环境维度信息时出错: {e}")
        import traceback
        debug_print(traceback.format_exc())
        return None
    
    # 创建网络管理器
    try:
        # 关键修改：将维度信息传递给网络创建函数
        network_manager = create_memory_management_networks(
            obs_dims=obs_dims,
            action_dims=action_dims,
            device=device
        )
        debug_print("网络管理器创建成功")
    except Exception as e:
        print(f"网络管理器创建失败: {e}")
        import traceback
        traceback.print_exc()
        return None
    
    # 获取MAPPO配置
    mappo_config = config.get("mappo_config", {})
    debug_print(f"原始MAPPO配置: {mappo_config}")
    
    # 将维度信息添加到配置中
    if "agent_dims" not in mappo_config:
        mappo_config["agent_dims"] = {}
    
    for agent_id in env.agent_ids:
        if agent_id not in mappo_config["agent_dims"]:
            mappo_config["agent_dims"][agent_id] = {}
        
        if agent_id in obs_dims:
            mappo_config["agent_dims"][agent_id]["obs_dim"] = obs_dims[agent_id]
        
        if agent_id in action_dims:
            mappo_config["agent_dims"][agent_id]["action_dim"] = action_dims[agent_id]
    
    # 设置设备到MAPPO配置中，确保设备信息传递
    if "device" not in mappo_config:
        mappo_config["device"] = str(device)
    
    debug_print(f"更新后的MAPPO配置: {mappo_config}")
    
    # 创建MAPPO训练器 - 直接传递整个配置字典
    try:
        trainer = MAPPOTrainer(
            env=env,
            network_manager=network_manager,
            config=mappo_config,  # 直接传递整个配置字典
            device=device
        )
        debug_print("MAPPO训练器创建成功")
    except Exception as e:
        print(f"MAPPO训练器创建失败: {e}")
        import traceback
        traceback.print_exc()
        return None
    
    # 加载检查点（如果有）
    checkpoint_path = config.get("checkpoint", None)
    if checkpoint_path is not None and os.path.exists(checkpoint_path):
        try:
            trainer.load(checkpoint_path)
            print(f"加载检查点成功: {checkpoint_path}")
            debug_print(f"加载检查点: {checkpoint_path}")
            
            # 获取当前回合计数
            if hasattr(trainer, 'total_episodes'):
                episode_count = trainer.total_episodes
                print(f"从检查点恢复训练，当前回合数: {episode_count}")
                debug_print(f"从检查点恢复，当前回合数: {episode_count}")
        except Exception as e:
            print(f"加载检查点失败: {e}")
            debug_print(f"加载检查点失败: {e}")
    
    # 获取训练配置
    training_config = config.get("training", {})
    debug_print(f"训练配置: {training_config}")
    
    # 打印训练配置
    print("\n" + "-"*40)
    print("训练配置:")
    print(f"总回合数: {training_config.get('num_episodes', 10)}")
    print(f"更新间隔步数: {training_config.get('steps_per_update', 32)}")
    print(f"每次采集后更新次数: {training_config.get('num_updates', 2)}")
    print(f"K epochs: {training_config.get('k_epochs', 2)}")
    print(f"批次大小: {mappo_config.get('batch_size', 32)}")
    print(f"保存间隔: {training_config.get('save_interval', 5)} 回合")
    print(f"日志间隔: {training_config.get('log_interval', 1)} 回合")
    print("-"*40 + "\n")
    
    # 训练循环
    total_start_time = time.time()
    episode_count = 0 if not hasattr(trainer, 'total_episodes') else trainer.total_episodes
    update_count = 0
    
    # 保存训练统计
    training_stats = {
        "episode_rewards": defaultdict(list),
        "episode_lengths": [],
        "actor_losses": defaultdict(list),
        "critic_losses": defaultdict(list),
        "timestamps": []
    }
    
    # 新增: 内存回收指标统计
    memory_reclaim_metrics = defaultdict(list)
    
    print(f"开始训练 {training_config.get('num_episodes', 50)} 回合...")
    print(f"每次更新步数: {training_config.get('steps_per_update', 32)}, 每次采集后更新次数: {training_config.get('num_updates', 2)}")
    print("-" * 60)
    
    try:
        while episode_count < training_config.get("num_episodes", 50):
            # 收集轨迹配置
            collect_config = {
                "steps_per_update": training_config.get("steps_per_update", 32),
                "max_steps": training_config.get("max_steps", 50)  # 添加最大步数限制
            }
            
            # 收集轨迹
            collect_start_time = time.time()
            debug_print(f"开始采集轨迹, 目标步数: {collect_config['steps_per_update']}")
            
            try:
                # 使用配置参数收集轨迹 - 注意这里接收三个返回值
                episode_rewards, episode_lengths, completed_episodes = trainer.collect_trajectories(config=collect_config)
                collect_time = time.time() - collect_start_time
                debug_print(f"轨迹采集完成, 用时: {collect_time:.2f}秒, 完成回合数: {completed_episodes}")
                
                # 更新回合计数 - 使用完成的回合数
                if completed_episodes > 0:
                    episode_count = trainer.total_episodes  # 使用训练器中的总回合数
                    debug_print(f"当前总回合数更新为: {episode_count}")
                    
            except Exception as e:
                print(f"轨迹采集失败: {e}")
                debug_print(f"轨迹采集失败: {e}")
                import traceback
                debug_print(traceback.format_exc())
                continue
            
            # 如果没有采集到足够的数据，跳过此次更新
            if len(episode_lengths) == 0:
                debug_print("没有采集到完整回合，跳过此次更新")
                continue
            
            # 执行多次策略更新
            update_start_time = time.time()
            debug_print(f"开始执行 {training_config.get('num_updates', 2)} 次策略更新")
            
            update_errors = 0
            for update_idx in range(training_config.get("num_updates", 2)):
                try:
                    # 创建更新配置
                    update_config = {
                        "k_epochs": training_config.get("k_epochs", 2),
                        "batch_size": mappo_config.get("batch_size", 32),
                        "gamma": mappo_config.get("gamma", 0.99),
                        "gae_lambda": mappo_config.get("gae_lambda", 0.95),
                        "clip_param": mappo_config.get("clip_param", 0.2),
                        "value_loss_coef": mappo_config.get("value_loss_coef", 0.5),
                        "entropy_coef": mappo_config.get("entropy_coef", 0.01),
                        "max_grad_norm": mappo_config.get("max_grad_norm", 0.5),
                        "use_clipped_value_loss": mappo_config.get("use_clipped_value_loss", True),
                        "normalize_advantages": mappo_config.get("normalize_advantages", True)
                    }
                    
                    debug_print(f"更新配置: {update_config}")
                    update_stats = trainer.mappo.update(config=update_config)
                    update_count += 1
                    
                    # 记录训练统计
                    for agent_id in trainer.agent_ids:
                        if agent_id in update_stats["actor_losses"]:
                            training_stats["actor_losses"][agent_id].extend(update_stats["actor_losses"][agent_id])
                        if agent_id in update_stats["critic_losses"]:
                            training_stats["critic_losses"][agent_id].extend(update_stats["critic_losses"][agent_id])
                    
                    debug_print(f"更新 {update_idx+1}/{training_config.get('num_updates', 2)} 完成")
                except Exception as e:
                    print(f"策略更新 {update_idx+1} 失败: {e}")
                    debug_print(f"策略更新失败: {e}")
                    import traceback
                    debug_print(traceback.format_exc())
                    update_errors += 1
            
            if update_errors == training_config.get("num_updates", 2):
                print("所有策略更新失败，跳过此轮更新")
                continue
                
            update_time = time.time() - update_start_time
            
            # 记录训练统计
            for agent_id in trainer.agent_ids:
                if len(trainer.episode_rewards[agent_id]) >= len(episode_lengths):
                    training_stats["episode_rewards"][agent_id].extend(trainer.episode_rewards[agent_id][-len(episode_lengths):])
                else:
                    debug_print(f"警告: agent_id {agent_id} 的奖励记录长度不足，跳过记录")
            
            training_stats["episode_lengths"].extend(episode_lengths)
            training_stats["timestamps"].append(time.time() - total_start_time)
            
            # 添加奖励追踪记录
            debug_print("记录奖励追踪数据")
            
            # 只处理实际完成的回合
            if completed_episodes > 0:
                for i in range(completed_episodes):
                    # 获取最近完成的episode索引
                    rewards_dict = {}
                    
                    # 获取每个智能体的奖励
                    for agent_id in trainer.agent_ids:
                        if len(trainer.episode_rewards[agent_id]) >= completed_episodes:
                            idx = len(trainer.episode_rewards[agent_id]) - completed_episodes + i
                            if idx >= 0 and idx < len(trainer.episode_rewards[agent_id]):
                                rewards_dict[agent_id] = trainer.episode_rewards[agent_id][idx]
                    
                    # 如果没有获取到任何奖励，跳过此次记录
                    if not rewards_dict:
                        continue
                    
                    # 计算全局奖励（所有智能体奖励总和）
                    global_reward = sum(rewards_dict.values())
                    
                    # 获取环境信息（如果可用）
                    workload_type = getattr(env, 'current_workload_type', 'unknown')
                    difficulty = getattr(env, 'current_difficulty', 'unknown')
                    runtime = getattr(env, 'last_workload_runtime', 0.0)
                    prev_runtime = getattr(env, 'previous_workload_runtime', None)
                    
                    # 计算当前episode编号
                    episode_num = episode_count - completed_episodes + i + 1
                    
                    # 记录到奖励追踪器
                    reward_tracker.add_record(
                        episode=episode_num,  # episode从1开始
                        rewards_dict=rewards_dict,
                        global_reward=global_reward,
                        runtime=runtime,
                        prev_runtime=prev_runtime,
                        workload_type=workload_type,
                        difficulty=difficulty
                    )
                    
                    # 新增: 记录内存回收指标
                    if hasattr(env, 'state_collector') and 'memory_reclaim' in trainer.agent_ids:
                        try:
                            # 获取最新状态
                            state = env.state_collector.get_state()
                            
                            # 提取内存回收指标
                            reclaim_metrics = {
                                'reclaimed_pages_per_sec': state.get('reclaimed_pages_per_sec', 0),
                                'kswapd_cpu_usage': state.get('kswapd_cpu_usage', 0),
                                'pgmajfault_to_pgfault_ratio': state.get('pgmajfault_to_pgfault_ratio', 0),
                                'kswapd_reclaim_ratio': state.get('kswapd_reclaim_ratio', 0)
                            }
                            
                            # 记录指标
                            for metric_name, value in reclaim_metrics.items():
                                memory_reclaim_metrics[metric_name].append(value)
                                
                            # 增强奖励追踪器以支持指标记录
                            if hasattr(reward_tracker, 'add_agent_metrics'):
                                reward_tracker.add_agent_metrics(
                                    episode=episode_num,
                                    agent_id='memory_reclaim',
                                    metrics=reclaim_metrics
                                )
                        except Exception as e:
                            debug_print(f"记录内存回收指标时出错: {e}")
            
            # 定期打印摘要
            if episode_count % training_config.get("summary_interval", 1) == 0:
                reward_tracker.print_summary(episode_count)
                debug_print("打印奖励追踪摘要")
            
            # 检查是否收敛
            if episode_count % training_config.get("convergence_check_interval", 5) == 0 and episode_count >= training_config.get("convergence_min_episodes", 3):
                converged, change = reward_tracker.check_convergence()
                if converged:
                    print(f"\n模型似乎已经收敛于回合 {episode_count}!")
                    print(f"奖励相对变化: {change:.6f}")
                    print("考虑停止训练或降低学习率。")
                    debug_print(f"检测到收敛, 相对变化: {change:.6f}")
            
            # 打印训练信息
            if episode_count % training_config.get("log_interval", 1) == 0:
                # 计算最近N回合的平均奖励和长度
                recent_episodes = training_config.get("recent_episodes_stats", 3)
                
                # 获取每个智能体的最近奖励
                recent_rewards = {}
                for agent_id in trainer.agent_ids:
                    if agent_id in trainer.episode_rewards:
                        recent_rewards[agent_id] = trainer.episode_rewards[agent_id][-min(recent_episodes, len(trainer.episode_rewards[agent_id])):]
                
                # 计算平均奖励
                avg_rewards = {agent_id: np.mean(rewards) if len(rewards) > 0 else 0.0
                              for agent_id, rewards in recent_rewards.items()}
                
                # 计算平均回合长度
                recent_lengths = trainer.episode_lengths[-min(recent_episodes, len(trainer.episode_lengths)):]
                avg_length = np.mean(recent_lengths) if recent_lengths else 0.0
                
                # 计算智能体奖励统计
                agent_reward_stats = {}
                for agent_id in trainer.agent_ids:
                    if agent_id in recent_rewards and len(recent_rewards[agent_id]) > 0:
                        rewards = recent_rewards[agent_id]
                        agent_reward_stats[agent_id] = {
                            "min": np.min(rewards),
                            "max": np.max(rewards),
                            "std": np.std(rewards)
                        }
                
                # 打印详细信息
                print("\n" + "-"*60)
                print(f"回合: {episode_count}/{training_config.get('num_episodes', 10)} | 更新次数: {update_count}")
                print(f"采集用时: {collect_time:.2f}秒 | 更新用时: {update_time:.2f}秒")
                print(f"平均回合长度: {avg_length:.1f} 步")
                
                # 打印每个智能体的奖励详情
                print(f"\n智能体奖励统计 (最近{recent_episodes}回合):")
                for agent_id, avg_reward in avg_rewards.items():
                    stats = agent_reward_stats.get(agent_id, {})
                    stats_str = ""
                    if stats:
                        stats_str = f" [最小: {stats.get('min', 0):.2f}, 最大: {stats.get('max', 0):.2f}, 标准差: {stats.get('std', 0):.2f}]"
                    print(f"  智能体 {agent_id}: {avg_reward:.2f}{stats_str}")
                
                # 新增: 打印内存回收指标统计
                if 'memory_reclaim' in trainer.agent_ids and any(memory_reclaim_metrics.values()):
                    recent_metrics = {}
                    for metric_name, values in memory_reclaim_metrics.items():
                        if len(values) > 0:
                            recent_values = values[-min(recent_episodes, len(values)):]
                            if recent_values:
                                recent_metrics[metric_name] = {
                                    "mean": np.mean(recent_values),
                                    "max": np.max(recent_values)
                                }
                    
                    if recent_metrics:
                        print("\n内存回收指标统计 (最近回合):")
                        for metric_name, stats in recent_metrics.items():
                            print(f"  {metric_name}: 平均={stats['mean']:.2f}, 最大={stats['max']:.2f}")
                
                # 计算总体奖励
                total_avg_reward = sum(avg_rewards.values())
                print(f"\n总体平均奖励: {total_avg_reward:.2f}")
                
                # 打印训练进度
                elapsed_time = time.time() - total_start_time
                remaining_episodes = training_config.get("num_episodes", 10) - episode_count
                estimated_time_remaining = (elapsed_time / max(1, episode_count)) * remaining_episodes
                
                time_format = lambda seconds: f"{int(seconds//3600)}时{int((seconds%3600)//60)}分{int(seconds%60)}秒"
                
                print(f"\n训练进度: {episode_count/training_config.get('num_episodes', 10)*100:.1f}% 完成")
                print(f"已用时间: {time_format(elapsed_time)}")
                print(f"预计剩余: {time_format(estimated_time_remaining)}")
                print("-"*60)
            
            # 定期保存模型
            if episode_count % training_config.get("save_interval", 5) == 0:
                checkpoint_path = os.path.join(models_dir, f"checkpoint_ep{episode_count}")
                try:
                    trainer.save(checkpoint_path)
                    print(f"\n检查点已保存: {checkpoint_path}")
                    debug_print(f"保存检查点: {checkpoint_path}")
                    
                    # 保存训练统计
                    stats_path = os.path.join(logs_dir, f"training_stats_ep{episode_count}.yaml")
                    with open(stats_path, 'w') as f:
                        yaml.dump(training_stats, f)
                    debug_print(f"保存训练统计: {stats_path}")
                    
                    # 新增: 保存内存回收指标
                    if any(memory_reclaim_metrics.values()):
                        reclaim_metrics_path = os.path.join(logs_dir, f"memory_reclaim_metrics_ep{episode_count}.yaml")
                        with open(reclaim_metrics_path, 'w') as f:
                            yaml.dump(dict(memory_reclaim_metrics), f)
                        debug_print(f"保存内存回收指标: {reclaim_metrics_path}")
                except Exception as e:
                    print(f"保存模型失败: {e}")
                    debug_print(f"保存模型失败: {e}")
                    import traceback
                    debug_print(traceback.format_exc())
            
            # 检查是否已完成所有回合
            if episode_count >= training_config.get("num_episodes", 10):
                print(f"已达到目标回合数 {episode_count}/{training_config.get('num_episodes', 10)}，训练结束")
                break
    
    except KeyboardInterrupt:
        print("\n\n训练被用户中断")
        debug_print("训练被用户中断")
    
    except Exception as e:
        print(f"\n\n训练过程中出现错误: {e}")
        debug_print(f"训练错误: {e}")
        import traceback
        traceback.print_exc()
        debug_print(traceback.format_exc())
    
    # 训练结束，保存最终模型和统计
    try:
        final_checkpoint_path = os.path.join(models_dir, "final_checkpoint")
        trainer.save(final_checkpoint_path)
        
        final_stats_path = os.path.join(logs_dir, "final_training_stats.yaml")
        with open(final_stats_path, 'w') as f:
            yaml.dump(training_stats, f)
        
        # 新增: 保存最终内存回收指标
        if any(memory_reclaim_metrics.values()):
            final_reclaim_metrics_path = os.path.join(logs_dir, "final_memory_reclaim_metrics.yaml")
            with open(final_reclaim_metrics_path, 'w') as f:
                yaml.dump(dict(memory_reclaim_metrics), f)
        
        total_time = time.time() - total_start_time
        print(f"\n\n训练完成，总用时: {total_time:.2f} 秒")
        print(f"总回合数: {episode_count}, 总更新次数: {update_count}")
        print(f"最终模型已保存至: {final_checkpoint_path}")
        print(f"训练统计已保存至: {final_stats_path}")
        debug_print("训练完成并保存最终结果")
    except Exception as e:
        print(f"保存最终模型和统计失败: {e}")
        debug_print(f"保存最终结果失败: {e}")
    
    return trainer

def main():
    """主函数"""
    # 解析命令行参数
    args = parse_args()
    
    # 加载配置文件
    config = load_config(args.config)
    
    # 检查并修正 env_config
    if "env_config" in config and not isinstance(config["env_config"], dict):
        print(f"警告: 配置文件中的env_config不是字典类型，而是 {type(config['env_config'])}")
        if isinstance(config["env_config"], list):
            # 将列表转换为字典
            print("尝试将env_config列表转换为字典...")
            env_config_dict = {}
            for item in config["env_config"]:
                if isinstance(item, dict):
                    env_config_dict.update(item)
                elif isinstance(item, (str, int, float, bool)) and item is not None:
                    # 如果是基本类型，使用值本身作为键
                    env_config_dict[str(item)] = True
            config["env_config"] = env_config_dict
            print(f"转换后的env_config: {config['env_config']}")
        else:
            # 创建默认字典
            print("无法转换，使用默认env_config")
            config["env_config"] = {
                "env_type": "memory_management",
                "scenario": "memory_management",
                "normalize_observations": True,
                "normalize_rewards": False,
                "render_mode": None,
                "max_episode_steps": config.get("training", {}).get("max_steps", 30)
            }
    
    # 设置随机种子
    set_seed(args.seed or config.get("seed", 1))
    
    # 如果指定了检查点，更新配置
    if args.checkpoint:
        config["checkpoint"] = args.checkpoint
    
    # 创建保存目录
    save_dir, models_dir, logs_dir = create_save_dir(config)
    
    # 保存配置副本
    config_copy_path = os.path.join(save_dir, "config.yaml")
    with open(config_copy_path, 'w') as f:
        yaml.dump(config, f)
    
    # 更新配置中的保存频率
    if "training" not in config:
        config["training"] = {}
    
    # 如果指定了命令行参数，更新配置
    if hasattr(args, "save_freq") and args.save_freq is not None:
        config["training"]["save_interval"] = args.save_freq
    
    # 打印配置信息
    print("\n" + "="*60)
    print("           内存管理智能体训练系统")
    print("="*60)
    print(f"配置文件: {args.config}")
    print(f"训练模式: {'联合训练 (MAPPO)' if args.mode == 'joint' else '单独训练 (PPO)'}")
    print(f"随机种子: {args.seed if args.seed else config.get('seed', '未设置')}")
    print(f"调试模式: {'启用' if args.debug else '禁用'}")
    
    if "training" in config:
        training_config = config["training"]
        print("\n训练配置:")
        print(f"  保存频率: 每 {training_config.get('save_interval')} 回合")
    
    print(f"\n保存目录: {save_dir}")
    print("="*60 + "\n")
    
    # 联合训练所有智能体
    trainer = train_with_mappo(config, save_dir, models_dir, logs_dir, debug_mode=args.debug)

if __name__ == "__main__":
    main()
