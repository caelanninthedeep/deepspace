import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

class ActorCriticNetwork(nn.Module):
    """基础Actor-Critic网络结构，适用于PPO算法"""
    def __init__(self, obs_dim, action_dim, action_std_init=0.6, hidden_dims=[256, 256]):
        super(ActorCriticNetwork, self).__init__()
        
        # 记录输入维度用于调试
        self.obs_dim = obs_dim
        self.action_dim = action_dim
        
        # Actor网络 - 使用明确的输入维度
        self.actor = nn.Sequential(
            nn.Linear(obs_dim, hidden_dims[0]),  # 指定输入维度
            nn.ReLU(),
            nn.Linear(hidden_dims[0], hidden_dims[1]),
            nn.ReLU(),
            nn.Linear(hidden_dims[1], action_dim),
            nn.Tanh()  # 输出范围为[-1, 1]
        )
        
        # Critic网络 - 使用明确的输入维度
        self.critic = nn.Sequential(
            nn.Linear(obs_dim, hidden_dims[0]),  # 指定输入维度
            nn.ReLU(),
            nn.Linear(hidden_dims[0], hidden_dims[1]),
            nn.ReLU(),
            nn.Linear(hidden_dims[1], 1)
        )
        
        # 动作标准差
        self.action_var = torch.full((action_dim,), action_std_init * action_std_init)
        
    def update_action_std(self, action_std):
        """更新动作标准差"""
        self.action_var = torch.full(self.action_var.shape, action_std * action_std).to(self.action_var.device)
        
    def forward(self, state):
        """前向传播"""
        # 检查输入维度
        if state.dim() == 1:
            state = state.unsqueeze(0)  # 将[obs_dim]转换为[1, obs_dim]
            
        # Actor部分
        action_mean = self.actor(state)
        action_var = self.action_var.expand_as(action_mean).to(state.device)
        action_std = torch.sqrt(action_var)
        
        # Critic部分
        value = self.critic(state)
        
        return action_mean, action_std, value
    
    def get_action(self, state):
        """获取动作、对数概率和状态价值"""
        action_mean, action_std, value = self.forward(state)
        
        # 创建正态分布
        dist = torch.distributions.Normal(action_mean, action_std)
        
        # 采样动作
        action = dist.sample()
        action_log_prob = dist.log_prob(action).sum(dim=-1)
        
        return action, action_log_prob, value
    
    def evaluate(self, state, action):
        """评估动作"""
        action_mean, action_std, value = self.forward(state)
        
        # 创建正态分布
        dist = torch.distributions.Normal(action_mean, action_std)
        
        # 计算对数概率
        action_log_prob = dist.log_prob(action).sum(dim=-1)
        
        # 计算熵
        entropy = dist.entropy().sum(dim=-1)
        
        return action_log_prob, value.squeeze(), entropy
    
    def get_input_dim(self):
        """返回输入维度，用于调试"""
        return self.obs_dim

# 专门化网络结构
class PageCacheNetwork(nn.Module):
    """页面缓存智能体的专门化网络"""
    def __init__(self, obs_dim, action_dim, action_std_init=0.6, hidden_dims=[128, 128]):
        super(PageCacheNetwork, self).__init__()
        
        # 记录输入维度
        self.obs_dim = obs_dim
        self.action_dim = action_dim
        
        print(f"为PageCacheNetwork创建网络，输入维度：{obs_dim}，动作维度：{action_dim}")
        
        # 基础层 - 提取缓存相关特征
        self.base = nn.Sequential(
            nn.Linear(obs_dim, hidden_dims[0]),
            nn.ReLU(),
            nn.Linear(hidden_dims[0], hidden_dims[1]),
            nn.ReLU()
        )
        
        # 缓存参数注意力层 - 关注不同缓存参数的重要性
        self.attention = nn.Sequential(
            nn.Linear(hidden_dims[1], action_dim),
            nn.Softmax(dim=-1)
        )
        
        # Actor头部 - 输出动作均值
        self.actor_mean = nn.Linear(hidden_dims[1], action_dim)
        
        # 动作标准差
        self.actor_std = nn.Parameter(torch.ones(action_dim) * np.log(action_std_init))
        
        # Critic网络
        self.critic = nn.Sequential(
            nn.Linear(obs_dim, hidden_dims[0]),
            nn.ReLU(),
            nn.Linear(hidden_dims[0], 1)
        )
    
    def forward(self, state):
        """前向传播"""
        # 检查输入维度
        if state.dim() == 1:
            state = state.unsqueeze(0)  # 将[obs_dim]转换为[1, obs_dim]
            
        features = self.base(state)
        
        # 计算注意力权重
        attention_weights = self.attention(features)
        
        # Actor输出
        action_mean = torch.tanh(self.actor_mean(features))  # 范围为[-1, 1]
        action_std = torch.exp(self.actor_std).expand_as(action_mean).to(state.device)
        
        # Critic输出
        value = self.critic(state)
        
        return action_mean, action_std, value, attention_weights
    
    def get_input_dim(self):
        """返回输入维度，用于调试"""
        return self.obs_dim

class MemoryReclaimNetwork(nn.Module):
    """内存回收智能体的专门化网络"""
    def __init__(self, obs_dim, action_dim, action_std_init=0.6, hidden_dims=[128, 128]):
        super(MemoryReclaimNetwork, self).__init__()
        
        # 记录输入维度
        self.obs_dim = obs_dim
        self.action_dim = action_dim
        
        print(f"为MemoryReclaimNetwork创建网络，输入维度：{obs_dim}，动作维度：{action_dim}")
        
        # 内存压力感知层
        self.pressure_encoder = nn.Sequential(
            nn.Linear(obs_dim, hidden_dims[0]),
            nn.ReLU()
        )
        
        # 主干网络
        self.backbone = nn.Sequential(
            nn.Linear(hidden_dims[0], hidden_dims[1]),
            nn.ReLU()
        )
        
        # Actor头部 - 输出动作均值
        self.actor_mean = nn.Linear(hidden_dims[1], action_dim)
        
        # 根据内存压力调整动作标准差
        self.pressure_to_std = nn.Sequential(
            nn.Linear(hidden_dims[0], action_dim),
            nn.Softplus()  # 确保标准差为正
        )
        
        # 基础动作标准差
        self.base_std = action_std_init
        
        # Critic网络
        self.critic = nn.Sequential(
            nn.Linear(obs_dim, hidden_dims[0]),
            nn.ReLU(),
            nn.Linear(hidden_dims[0], 1)
        )
    
    def forward(self, state):
        """前向传播"""
        # 检查输入维度
        if state.dim() == 1:
            state = state.unsqueeze(0)  # 将[obs_dim]转换为[1, obs_dim]
            
        # 编码内存压力
        pressure_features = self.pressure_encoder(state)
        
        # 主干特征
        features = self.backbone(pressure_features)
        
        # Actor输出
        action_mean = torch.tanh(self.actor_mean(features))  # 范围为[-1, 1]
        
        # 根据内存压力调整标准差
        pressure_std = self.pressure_to_std(pressure_features)
        action_std = self.base_std * pressure_std
        
        # Critic输出
        value = self.critic(state)
        
        return action_mean, action_std, value, pressure_features
    
    def get_input_dim(self):
        """返回输入维度，用于调试"""
        return self.obs_dim

class MemorySchedulerNetwork(nn.Module):
    """内存调度智能体的专门化网络，使用LSTM捕捉时间序列特性"""
    def __init__(self, obs_dim, action_dim, action_std_init=0.6, 
                 hidden_dims=[128, 128], lstm_hidden=64, lstm_layers=1):
        super(MemorySchedulerNetwork, self).__init__()
        
        # 记录输入维度
        self.obs_dim = obs_dim
        self.action_dim = action_dim
        
        print(f"为MemorySchedulerNetwork创建网络，输入维度：{obs_dim}，动作维度：{action_dim}")
        
        # 保存参数以便动态创建LSTM
        self.lstm_hidden = lstm_hidden
        self.lstm_layers = lstm_layers
        
        # LSTM 的输入维度默认设置为 obs_dim
        self.lstm_input_size = obs_dim
        
        # 使用固定维度初始化LSTM
        self.lstm = nn.LSTM(
            input_size=self.lstm_input_size,
            hidden_size=lstm_hidden,
            num_layers=lstm_layers,
            batch_first=True
        )
        
        # 添加维度适配层，从LSTM隐藏维度到特征提取器输入维度
        self.dim_adapter = nn.Linear(lstm_hidden, hidden_dims[0])
        print(f"创建维度适配层: {lstm_hidden} -> {hidden_dims[0]}")
        
        # 特征提取层
        self.feature_extractor = nn.Sequential(
            nn.Linear(hidden_dims[0], hidden_dims[0]),
            nn.ReLU(),
            nn.Linear(hidden_dims[0], hidden_dims[1]),
            nn.ReLU()
        )
        
        # Actor头部 - 输出动作均值
        self.actor_mean = nn.Linear(hidden_dims[1], action_dim)
        
        # 动作标准差
        self.actor_std = nn.Parameter(torch.ones(action_dim) * np.log(action_std_init))
        
        # 记录Critic网络的预期输入维度
        self.critic_input_size = obs_dim
        
        # Critic网络
        self.critic = nn.Sequential(
            nn.Linear(obs_dim, hidden_dims[0]),
            nn.ReLU(),
            nn.Linear(hidden_dims[0], 1)
        )
        
        # 动态输入适配器 - 初始为None
        self.input_adapter = None
        self.critic_adapter = None
        
        # 隐藏状态
        self.hidden = None
        
        # 记录当前的输入维度，用于检测变化
        self.current_input_dim = obs_dim
        
    def reset_hidden(self, batch_size=1):
        """重置LSTM隐藏状态"""
        device = next(self.parameters()).device
        h = torch.zeros(self.lstm_layers, batch_size, self.lstm_hidden).to(device)
        c = torch.zeros(self.lstm_layers, batch_size, self.lstm_hidden).to(device)
        self.hidden = (h, c)
    
    def create_or_update_adapters(self, actual_input_dim, device):
        """创建或更新适配器，避免在forward中动态创建"""
        if actual_input_dim != self.current_input_dim:
            print(f"输入维度变化: {self.current_input_dim} -> {actual_input_dim}")
            self.current_input_dim = actual_input_dim
            
            # LSTM适配器
            if self.input_adapter is None or self.input_adapter.in_features != actual_input_dim:
                print(f"创建LSTM输入维度适配层: {actual_input_dim} -> {self.lstm_input_size}")
                self.input_adapter = nn.Linear(actual_input_dim, self.lstm_input_size).to(device)
            
            # Critic适配器
            if self.critic_adapter is None or self.critic_adapter.in_features != actual_input_dim:
                print(f"创建Critic输入维度适配层: {actual_input_dim} -> {self.critic_input_size}")
                self.critic_adapter = nn.Linear(actual_input_dim, self.critic_input_size).to(device)
    
    def forward(self, state, seq_length=1):
        """前向传播，支持序列输入，动态适应输入维度，避免原地操作"""
        # 检查输入维度
        if state.dim() == 1:
            state = state.unsqueeze(0)  # 将[obs_dim]转换为[1, obs_dim]
            
        batch_size = state.size(0)
        actual_input_dim = state.size(-1)
        device = state.device
        
        # 初始化隐藏状态（如果需要）
        if self.hidden is None or self.hidden[0].size(1) != batch_size:
            self.reset_hidden(batch_size)
        
        # 在训练前创建或更新适配器
        self.create_or_update_adapters(actual_input_dim, device)
        
        # ===== LSTM输入维度处理 =====
        lstm_ready_input = state
        if actual_input_dim != self.lstm_input_size and self.input_adapter is not None:
            # 使用输入适配器，避免动态创建
            lstm_ready_input = self.input_adapter(state)
        
        # 调整输入形状用于LSTM - 创建新张量而不是原地修改
        lstm_in = lstm_ready_input.unsqueeze(1)  # [batch, seq_len=1, adjusted_dim]
        
        # 通过LSTM
        lstm_out, new_hidden = self.lstm(lstm_in, self.hidden)
        # 更新隐藏状态 - 使用新变量而非原地修改
        self.hidden = (new_hidden[0].detach(), new_hidden[1].detach())  # 分离隐藏状态，避免梯度累积
        lstm_features = lstm_out[:, -1]  # 取序列最后一步的输出
        
        # 使用维度适配层调整LSTM输出维度
        adapted_features = self.dim_adapter(lstm_features)
        
        # 特征提取
        features = self.feature_extractor(adapted_features)
        
        # Actor输出
        action_mean = torch.tanh(self.actor_mean(features))  # 范围为[-1, 1]
        # 创建新张量而不是原地修改
        action_std = torch.exp(self.actor_std)
        action_std_expanded = action_std.expand_as(action_mean)
        
        # ===== Critic输入维度处理 =====
        value = None
        if self.critic_adapter is not None and actual_input_dim != self.critic_input_size:
            # 使用Critic适配器
            adapted_state = self.critic_adapter(state)
            value = self.critic(adapted_state)
        else:
            # 直接使用原始状态
            value = self.critic(state)
        
        return action_mean, action_std_expanded, value
    
    def get_input_dim(self):
        """返回输入维度，用于调试"""
        return self.obs_dim
# 添加MAPPO支持
class MAPPONetworkManager:
    """管理多个内存智能体的网络，支持MAPPO训练"""
    
    def __init__(self, agent_configs, use_centralized_critic=True, global_state_dim=None, device='cpu'):
        """
        初始化MAPPO网络管理器
        
        参数:
            agent_configs: 字典，键为智能体ID，值为字典包含网络配置
                例如: {'page_cache': {'type': 'page_cache', 'obs_dim': 13, 'action_dim': 3}}
            use_centralized_critic: 是否使用中央化Critic
            global_state_dim: 全局状态维度
            device: 计算设备
        """
        self.device = device
        self.use_centralized_critic = use_centralized_critic
        self.agent_ids = list(agent_configs.keys())
        self.agent_configs = agent_configs  # 保存配置以供后续使用
        
        print(f"\n初始化MAPPO网络，智能体数量：{len(self.agent_ids)}")
        
        # 创建智能体网络
        self.actor_networks = {}
        
        for agent_id, config in agent_configs.items():
            network_type = config.get('type', 'actor_critic')
            obs_dim = config['obs_dim']
            action_dim = config['action_dim']
            hidden_dims = config.get('hidden_dims', [128, 128])
            action_std_init = config.get('action_std_init', 0.6)
            
            print(f"创建智能体 {agent_id} 的网络，类型：{network_type}，输入维度：{obs_dim}，动作维度：{action_dim}")
            
            # 根据网络类型创建对应的网络
            if network_type == 'page_cache':
                self.actor_networks[agent_id] = PageCacheNetwork(
                    obs_dim, action_dim, action_std_init, hidden_dims
                ).to(device)
            elif network_type == 'memory_reclaim':
                self.actor_networks[agent_id] = MemoryReclaimNetwork(
                    obs_dim, action_dim, action_std_init, hidden_dims
                ).to(device)
            elif network_type == 'memory_scheduler':
                lstm_hidden = config.get('lstm_hidden', 64)
                lstm_layers = config.get('lstm_layers', 1)
                self.actor_networks[agent_id] = MemorySchedulerNetwork(
                    obs_dim, action_dim, action_std_init, hidden_dims, 
                    lstm_hidden, lstm_layers
                ).to(device)
            else:
                # 默认使用基础Actor-Critic网络
                self.actor_networks[agent_id] = ActorCriticNetwork(
                    obs_dim, action_dim, action_std_init, hidden_dims
                ).to(device)
        
        # 如果使用中央化Critic，创建一个共享的Critic网络
        if use_centralized_critic:
            if global_state_dim is None:
                # 默认将所有智能体的状态连接起来作为全局状态
                global_state_dim = sum(config['obs_dim'] for config in agent_configs.values())
                
            print(f"创建中央化Critic，全局状态维度：{global_state_dim}")
            
            self.central_critic = nn.Sequential(
                nn.Linear(global_state_dim, 256),  # 使用明确的输入维度
                nn.ReLU(),
                nn.Linear(256, 256),
                nn.ReLU(),
                nn.Linear(256, 1)
            ).to(device)
    
    def get_action(self, agent_id, state, deterministic=False):
        """
        获取指定智能体的动作
        
        参数:
            agent_id: 智能体ID
            state: 状态输入
            deterministic: 是否使用确定性策略
            
        返回:
            action: 动作
            log_prob: 对数概率
            value: 状态价值（如果支持）
        """
        if agent_id not in self.actor_networks:
            raise ValueError(f"Agent {agent_id} not found in networks")
            
        network = self.actor_networks[agent_id]
        
        # 确保状态是PyTorch张量
        if not isinstance(state, torch.Tensor):
            state = torch.FloatTensor(state).to(self.device)
            
        # 打印调试信息
        print(f"获取智能体 {agent_id} 的动作，状态维度: {state.shape}")
        
        # 根据网络类型获取动作
        with torch.no_grad():
            try:
                if isinstance(network, PageCacheNetwork):
                    action_mean, action_std, value, _ = network(state)
                elif isinstance(network, MemoryReclaimNetwork):
                    action_mean, action_std, value, _ = network(state)
                elif isinstance(network, MemorySchedulerNetwork):
                    action_mean, action_std, value = network(state)
                else:
                    action_mean, action_std, value = network(state)
                    
                # 创建动作分布
                dist = torch.distributions.Normal(action_mean, action_std)
                
                # 获取动作
                if deterministic:
                    action = action_mean
                else:
                    action = dist.sample()
                    
                # 计算对数概率
                log_prob = dist.log_prob(action).sum(dim=-1)
                
                # 将动作从 [batch_size, action_dim] 变为 [action_dim]
                if action.dim() > 1 and action.shape[0] == 1:
                    action = action.squeeze(0)
                
                print(f"智能体 {agent_id} - 动作形状: {action.shape}, 动作值: {action}")
                
            except Exception as e:
                print(f"错误: {e}")
                print(f"智能体: {agent_id}")
                print(f"网络类型: {type(network).__name__}")
                print(f"状态形状: {state.shape}")
                print(f"网络输入维度: {network.get_input_dim()}")
                if 'action_mean' in locals():
                    print(f"动作均值形状: {action_mean.shape}")
                raise
        
        return action, log_prob, value
    
    def evaluate_action(self, agent_id, state, action):
        """
        评估给定状态-动作对
        
        参数:
            agent_id: 智能体ID
            state: 状态
            action: 动作
            
        返回:
            log_prob: 对数概率
            value: 状态价值
            entropy: 熵
        """
        if agent_id not in self.actor_networks:
            raise ValueError(f"Agent {agent_id} not found in networks")
            
        network = self.actor_networks[agent_id]
        
        # 确保输入维度正确
        if state.dim() == 1:
            state = state.unsqueeze(0)  # 添加批次维度
            
        if action.dim() == 1:
            action = action.unsqueeze(0)  # 添加批次维度
        
        # 根据网络类型评估动作
        try:
            if isinstance(network, PageCacheNetwork):
                action_mean, action_std, value, _ = network(state)
            elif isinstance(network, MemoryReclaimNetwork):
                action_mean, action_std, value, _ = network(state)
            elif isinstance(network, MemorySchedulerNetwork):
                action_mean, action_std, value = network(state)
            else:
                action_mean, action_std, value = network(state)
                
            # 创建动作分布
            dist = torch.distributions.Normal(action_mean, action_std)
            
            # 计算对数概率
            log_prob = dist.log_prob(action).sum(dim=-1)
            
            # 计算熵
            entropy = dist.entropy().sum(dim=-1)
        except Exception as e:
            print(f"评估动作时出错: {e}")
            print(f"智能体: {agent_id}")
            print(f"网络类型: {type(network).__name__}")
            print(f"状态形状: {state.shape}")
            print(f"动作形状: {action.shape}")
            if 'action_mean' in locals():
                print(f"动作均值形状: {action_mean.shape}")
            raise
        
        return log_prob, value, entropy
    
    def get_central_value(self, global_state):
        """
        使用中央化Critic评估全局状态
        
        参数:
            global_state: 全局状态
            
        返回:
            value: 状态价值
        """
        if not self.use_centralized_critic:
            raise ValueError("Centralized critic is not enabled")
            
        # 确保全局状态是PyTorch张量
        if not isinstance(global_state, torch.Tensor):
            global_state = torch.FloatTensor(global_state).to(self.device)
            
        if global_state.dim() == 1:
            global_state = global_state.unsqueeze(0)  # 添加批次维度
                
        # 获取中央化评估
        try:
            with torch.no_grad():
                print(f"评估全局状态，维度: {global_state.shape}")
                value = self.central_critic(global_state)
        except Exception as e:
            print(f"中央化评估错误: {e}")
            print(f"全局状态形状: {global_state.shape}")
            # 检查中央化Critic的第一层维度
            first_layer = list(self.central_critic.children())[0]
            if hasattr(first_layer, 'in_features'):
                print(f"中央化Critic第一层输入维度: {first_layer.in_features}")
            raise
            
        return value
    
    def reset_lstm_states(self):
        """重置所有LSTM网络的隐藏状态"""
        for agent_id, network in self.actor_networks.items():
            if isinstance(network, MemorySchedulerNetwork):
                network.reset_hidden()
    
    def update_action_std(self, agent_id, new_action_std):
        """
        更新指定智能体的动作标准差
        
        参数:
            agent_id: 智能体ID
            new_action_std: 新的动作标准差
        """
        if agent_id not in self.actor_networks:
            raise ValueError(f"Agent {agent_id} not found in networks")
        
        network = self.actor_networks[agent_id]
        
        if isinstance(network, ActorCriticNetwork):
            network.update_action_std(new_action_std)
        elif hasattr(network, 'actor_std'):
            # 对于使用nn.Parameter的网络
            network.actor_std.data = torch.ones_like(network.actor_std.data) * np.log(new_action_std)
        elif isinstance(network, MemoryReclaimNetwork):
            # MemoryReclaimNetwork有特殊的标准差机制
            network.base_std = new_action_std

def create_memory_management_networks(obs_dims, action_dims, device='cpu'):
    """
    创建内存管理系统的专门化网络
    
    参数:
        obs_dims: 字典，键为智能体ID，值为观察维度
        action_dims: 字典，键为智能体ID，值为动作维度
        device: 计算设备
        
    返回:
        MAPPONetworkManager: 网络管理器实例
    """
    # 配置各个智能体网络
    agent_configs = {}
    
    for agent_id in obs_dims:
        # 根据智能体类型选择合适的网络配置
        if agent_id == 'page_cache':
            agent_configs[agent_id] = {
                'type': 'page_cache',
                'obs_dim': obs_dims[agent_id],
                'action_dim': action_dims[agent_id],
                'hidden_dims': [128, 128],
                'action_std_init': 0.5
            }
        elif agent_id == 'memory_reclaim':
            agent_configs[agent_id] = {
                'type': 'memory_reclaim',
                'obs_dim': obs_dims[agent_id],
                'action_dim': action_dims[agent_id],
                'hidden_dims': [128, 128],
                'action_std_init': 0.5
            }
        elif agent_id == 'memory_scheduler':
            agent_configs[agent_id] = {
                'type': 'memory_scheduler',
                'obs_dim': obs_dims[agent_id],
                'action_dim': action_dims[agent_id],
                'hidden_dims': [128, 128],
                'lstm_hidden': 64,
                'lstm_layers': 1,
                'action_std_init': 0.5
            }
        else:
            # 默认配置
            agent_configs[agent_id] = {
                'type': 'actor_critic',
                'obs_dim': obs_dims[agent_id],
                'action_dim': action_dims[agent_id],
                'hidden_dims': [128, 128],
                'action_std_init': 0.5
            }
    
    # 计算全局状态维度
    global_state_dim = sum(obs_dims.values())
    print(f"计算的全局状态维度: {global_state_dim}")
    
    # 创建网络管理器，使用中央化Critic
    network_manager = MAPPONetworkManager(
        agent_configs=agent_configs,
        use_centralized_critic=True,
        global_state_dim=global_state_dim,  # 使用计算的全局状态维度
        device=device
    )
    
    return network_manager

# 使用示例
if __name__ == "__main__":
    # 创建内存管理网络
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # 定义真实的观察维度和动作维度
    obs_dims = {
        'page_cache': 13,
        'memory_reclaim': 14,
        'memory_scheduler': 12
    }
    
    action_dims = {
        'page_cache': 3,
        'memory_reclaim': 2,
        'memory_scheduler': 2
    }
    
    networks = create_memory_management_networks(obs_dims, action_dims, device)
    
    # 为页面缓存智能体获取动作
    state = torch.randn(1, obs_dims['page_cache']).to(device)  # 使用正确的维度
    action, log_prob, value = networks.get_action('page_cache', state)
    
    print(f"页面缓存动作: {action}")
    print(f"动作对数概率: {log_prob}")
    print(f"状态价值: {value}")
    
    # 重置LSTM状态（用于新的episode）
    networks.reset_lstm_states()
    
    # 使用中央化Critic评估全局状态
    global_state = torch.randn(1, sum(obs_dims.values())).to(device)  # 使用正确的全局状态维度
    global_value = networks.get_central_value(global_state)
    print(f"全局状态价值: {global_value}")
