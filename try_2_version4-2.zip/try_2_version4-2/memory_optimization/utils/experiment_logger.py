import os
import json
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
from typing import Dict, List, Any, Optional
from .config import ConfigManager

class ExperimentLogger:
    """实验记录器"""
    def __init__(self, log_dir: str = "logs"):
        self.log_dir = log_dir
        self.experiment_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.current_experiment_dir = os.path.join(log_dir, self.experiment_id)
        
        # 创建日志目录
        os.makedirs(self.current_experiment_dir, exist_ok=True)
        
        # 初始化数据存储
        self.metrics = {
            "episode_rewards": [],
            "episode_lengths": [],
            "hit_rates": [],
            "memory_usage": [],
            "fragmentation": []
        }
        
        # 记录实验开始时间
        self.start_time = time.time()
    
    def log_metrics(self, metrics: Dict[str, float]):
        """记录训练指标"""
        for key, value in metrics.items():
            if key in self.metrics:
                self.metrics[key].append(value)
    
    def log_config(self, config_manager: ConfigManager):
        """记录实验配置"""
        config = {
            "environment": config_manager.get_env_config().__dict__,
            "training": config_manager.get_train_config().__dict__
        }
        
        with open(os.path.join(self.current_experiment_dir, "config.json"), "w") as f:
            json.dump(config, f, indent=4)
    
    def save_metrics(self):
        """保存指标数据"""
        # 转换为DataFrame
        df = pd.DataFrame(self.metrics)
        
        # 保存为CSV
        df.to_csv(os.path.join(self.current_experiment_dir, "metrics.csv"), index=False)
        
        # 保存为JSON
        with open(os.path.join(self.current_experiment_dir, "metrics.json"), "w") as f:
            json.dump(self.metrics, f, indent=4)
    
    def plot_metrics(self, save: bool = True):
        """绘制训练指标图表"""
        # 创建图表
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        fig.suptitle(f"训练指标 - 实验ID: {self.experiment_id}")
        
        # 绘制奖励曲线
        axes[0, 0].plot(self.metrics["episode_rewards"])
        axes[0, 0].set_title("回合奖励")
        axes[0, 0].set_xlabel("回合")
        axes[0, 0].set_ylabel("奖励")
        
        # 绘制回合长度曲线
        axes[0, 1].plot(self.metrics["episode_lengths"])
        axes[0, 1].set_title("回合长度")
        axes[0, 1].set_xlabel("回合")
        axes[0, 1].set_ylabel("步数")
        
        # 绘制命中率曲线
        axes[1, 0].plot(self.metrics["hit_rates"])
        axes[1, 0].set_title("命中率")
        axes[1, 0].set_xlabel("回合")
        axes[1, 0].set_ylabel("命中率")
        
        # 绘制内存使用率曲线
        axes[1, 1].plot(self.metrics["memory_usage"])
        axes[1, 1].set_title("内存使用率")
        axes[1, 1].set_xlabel("回合")
        axes[1, 1].set_ylabel("使用率")
        
        plt.tight_layout()
        
        if save:
            plt.savefig(os.path.join(self.current_experiment_dir, "training_metrics.png"))
        plt.close()
    
    def compare_experiments(self, experiment_ids: List[str], metrics: List[str]):
        """比较多个实验的结果"""
        fig, axes = plt.subplots(len(metrics), 1, figsize=(10, 5*len(metrics)))
        fig.suptitle("实验比较")
        
        for i, metric in enumerate(metrics):
            for exp_id in experiment_ids:
                # 加载实验数据
                with open(os.path.join(self.log_dir, exp_id, "metrics.json"), "r") as f:
                    exp_metrics = json.load(f)
                
                # 绘制指标曲线
                axes[i].plot(exp_metrics[metric], label=exp_id)
                axes[i].set_title(metric)
                axes[i].set_xlabel("回合")
                axes[i].set_ylabel(metric)
                axes[i].legend()
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.current_experiment_dir, "experiment_comparison.png"))
        plt.close()
    
    def generate_report(self):
        """生成实验报告"""
        report = {
            "experiment_id": self.experiment_id,
            "duration": time.time() - self.start_time,
            "final_metrics": {
                key: values[-1] if values else None
                for key, values in self.metrics.items()
            },
            "average_metrics": {
                key: np.mean(values) if values else None
                for key, values in self.metrics.items()
            }
        }
        
        # 保存报告
        with open(os.path.join(self.current_experiment_dir, "report.json"), "w") as f:
            json.dump(report, f, indent=4)
        
        return report 