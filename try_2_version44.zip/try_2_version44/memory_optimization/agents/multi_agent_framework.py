"""
多智能体强化学习框架 - 用于内存优化系统
支持MAPPO (Multi-Agent PPO)和其他多智能体算法
"""

import os
import time
import random
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Normal
from collections import deque, defaultdict

class MultiAgentController:
    """
    多智能体系统的协调器
    负责管理多个智能体的策略和训练过程
    """
    def __init__(self, agent_ids=None, shared_critic=True, gamma=0.99, 
                 lr_actor=3e-4, lr_critic=1e-3, device=None):
        """
        初始化多智能体控制器
        
        Args:
            agent_ids: 智能体ID列表，如["page_cache", "memory_reclaim", "memory_scheduler"]
            shared_critic: 是否使用共享的价值网络
            gamma: 折扣因子
            lr_actor: Actor网络学习率
            lr_critic: Critic网络学习率
            device: 计算设备(CPU/CUDA)
        """
        # 设置默认智能体
        self.agent_ids = agent_ids or ["page_cache", "memory_reclaim", "memory_scheduler"]
        self.num_agents = len(self.agent_ids)
        self.shared_critic = shared_critic
        self.gamma = gamma
        
        # 设置设备
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {self.device}")
        
        # 智能体策略映射
        self.agents = {}
        
        # 如果使用共享critic，则创建一个全局critic
        self.global_critic = None
        if shared_critic:
            self.global_critic = Critic(input_dim=64).to(self.device)  # 输入维度需要根据全局状态调整
            self.critic_optimizer = optim.Adam(self.global_critic.parameters(), lr=lr_critic)
        
        # 学习率
        self.lr_actor = lr_actor
        self.lr_critic = lr_critic
        
        # 训练信息
        self.stats = {
            "rewards": defaultdict(list),
            "losses": defaultdict(list),
            "value_estimates": defaultdict(list),
            "entropies": defaultdict(list)
        }
        
        # 经验回放缓冲区
        self.buffer = MultiAgentReplayBuffer(capacity=10000, num_agents=self.num_agents)
    
    def create_agents(self, obs_dims, action_dims):
        """
        创建所有智能体
        
        Args:
            obs_dims: 字典，键为智能体ID，值为观察维度
            action_dims: 字典，键为智能体ID，值为动作维度
        """
        for agent_id in self.agent_ids:
            obs_dim = obs_dims.get(agent_id, 0)
            act_dim = action_dims.get(agent_id, 0)
            
            if obs_dim > 0 and act_dim > 0:
                # 创建智能体的策略网络
                self.agents[agent_id] = Agent(
                    agent_id=agent_id,
                    obs_dim=obs_dim,
                    act_dim=act_dim,
                    shared_critic=self.shared_critic,
                    lr_actor=self.lr_actor,
                    lr_critic=self.lr_critic,
                    device=self.device
                )
            else:
                print(f"Warning: Invalid dimensions for agent {agent_id}: obs_dim={obs_dim}, act_dim={act_dim}")
    
    def get_actions(self, observations, deterministic=False):
        """
        获取所有智能体的动作
        
        Args:
            observations: 字典，键为智能体ID，值为观察向量
            deterministic: 是否使用确定性策略(用于评估)
            
        Returns:
            actions_dict: 字典，键为智能体ID，值为动作向量
            log_probs_dict: 字典，键为智能体ID，值为对数概率
            entropy_dict: 字典，键为智能体ID，值为熵
        """
        actions_dict = {}
        log_probs_dict = {}
        entropy_dict = {}
        
        for agent_id, agent in self.agents.items():
            if agent_id in observations:
                obs = observations[agent_id]
                action, log_prob, entropy = agent.get_action(obs, deterministic)
                actions_dict[agent_id] = action
                log_probs_dict[agent_id] = log_prob
                entropy_dict[agent_id] = entropy
        
        return actions_dict, log_probs_dict, entropy_dict
    
    def evaluate_actions(self, observations, actions):
        """
        评估动作的价值和对数概率
        
        Args:
            observations: 字典，键为智能体ID，值为观察向量
            actions: 字典，键为智能体ID，值为动作向量
            
        Returns:
            values_dict: 字典，键为智能体ID，值为价值估计
            log_probs_dict: 字典，键为智能体ID，值为对数概率
            entropy_dict: 字典，键为智能体ID，值为熵
        """
        values_dict = {}
        log_probs_dict = {}
        entropy_dict = {}
        
        for agent_id, agent in self.agents.items():
            if agent_id in observations and agent_id in actions:
                obs = observations[agent_id]
                action = actions[agent_id]
                value, log_prob, entropy = agent.evaluate_action(obs, action)
                values_dict[agent_id] = value
                log_probs_dict[agent_id] = log_prob
                entropy_dict[agent_id] = entropy
        
        return values_dict, log_probs_dict, entropy_dict
    
    def get_values(self, observations, global_state=None):
        """
        获取观察的价值估计
        
        Args:
            observations: 字典，键为智能体ID，值为观察向量
            global_state: 全局状态向量，用于共享critic
            
        Returns:
            values_dict: 字典，键为智能体ID，值为价值估计
        """
        values_dict = {}
        
        if self.shared_critic and global_state is not None:
            # 使用全局critic计算价值
            global_state_tensor = torch.FloatTensor(global_state).to(self.device)
            global_value = self.global_critic(global_state_tensor).item()
            
            # 为每个智能体分配相同的全局价值
            for agent_id in self.agents:
                values_dict[agent_id] = global_value
        else:
            # 使用各智能体自己的critic
            for agent_id, agent in self.agents.items():
                if agent_id in observations:
                    obs = observations[agent_id]
                    value = agent.get_value(obs)
                    values_dict[agent_id] = value
        
        return values_dict
    
    def update(self, batch_size=64, epochs=10, clip_param=0.2, 
               value_coef=0.5, entropy_coef=0.01):
        """
        更新所有智能体的策略
        
        Args:
            batch_size: 批量大小
            epochs: 每次更新的epoch数
            clip_param: PPO裁剪参数
            value_coef: 价值损失系数
            entropy_coef: 熵系数
            
        Returns:
            stats: 包含训练统计信息的字典
        """
        if len(self.buffer) < batch_size:
            return {agent_id: {"actor_loss": 0, "critic_loss": 0, "entropy": 0} for agent_id in self.agents}
        
        stats = {}
        
        # 如果使用共享critic，则一起训练
        if self.shared_critic:
            # 获取全局状态批次
            global_states, _, _, _, _, _, dones, _ = self.buffer.sample_global(batch_size)
            
            # 计算目标价值
            with torch.no_grad():
                next_global_states = np.roll(global_states, -1, axis=0)
                next_global_states_tensor = torch.FloatTensor(next_global_states).to(self.device)
                next_values = self.global_critic(next_global_states_tensor).squeeze(-1)
                
                # 处理终止状态
                next_values = next_values * (1 - torch.FloatTensor(dones).to(self.device))
                
                # 计算回报
                global_returns = torch.FloatTensor(self.buffer.compute_returns(
                    self.get_values(None, global_states[0]), 
                    self.gamma
                )).to(self.device)
            
            # 训练全局critic
            global_states_tensor = torch.FloatTensor(global_states).to(self.device)
            predicted_values = self.global_critic(global_states_tensor).squeeze(-1)
            
            value_loss = nn.MSELoss()(predicted_values, global_returns)
            
            self.critic_optimizer.zero_grad()
            value_loss.backward()
            nn.utils.clip_grad_norm_(self.global_critic.parameters(), max_norm=0.5)
            self.critic_optimizer.step()
            
            # 记录全局critic损失
            stats["global_critic"] = {"loss": value_loss.item()}
        
        # 为每个智能体进行更新
        for agent_id, agent in self.agents.items():
            # 从缓冲区采样数据
            states, actions, rewards, next_states, old_log_probs, old_values, dones, _ = self.buffer.sample(agent_id, batch_size)
            
            # 计算目标价值
            with torch.no_grad():
                if self.shared_critic:
                    # 使用全局critic的价值
                    returns = torch.FloatTensor(self.buffer.compute_returns(
                        rewards, self.gamma
                    )).to(self.device)
                else:
                    # 使用智能体自己的critic
                    next_states_tensor = torch.FloatTensor(next_states).to(self.device)
                    next_values = agent.critic(next_states_tensor).squeeze(-1)
                    
                    # 处理终止状态
                    next_values = next_values * (1 - torch.FloatTensor(dones).to(self.device))
                    
                    # 计算回报
                    returns = torch.FloatTensor(self.buffer.compute_returns(
                        rewards, self.gamma
                    )).to(self.device)
            
            # 转换为张量
            states_tensor = torch.FloatTensor(states).to(self.device)
            actions_tensor = torch.FloatTensor(actions).to(self.device)
            old_log_probs_tensor = torch.FloatTensor(old_log_probs).to(self.device)
            
            # 多个epoch的策略优化
            for _ in range(epochs):
                # 重新评估动作
                if self.shared_critic:
                    # 只需要actor的输出
                    _, log_probs, entropy = agent.evaluate_action_actor_only(states_tensor, actions_tensor)
                    values = self.global_critic(global_states_tensor).squeeze(-1).detach()
                else:
                    values, log_probs, entropy = agent.evaluate_action(states_tensor, actions_tensor)
                
                # 计算比率
                ratios = torch.exp(log_probs - old_log_probs_tensor)
                
                # 计算优势
                advantages = returns - values.detach()
                
                # 归一化优势
                advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)
                
                # 计算PPO损失
                surr1 = ratios * advantages
                surr2 = torch.clamp(ratios, 1.0 - clip_param, 1.0 + clip_param) * advantages
                actor_loss = -torch.min(surr1, surr2).mean()
                
                # Critic损失（如果不使用共享critic）
                if not self.shared_critic:
                    critic_loss = nn.MSELoss()(values, returns)
                else:
                    critic_loss = torch.tensor(0.0)
                
                # 熵奖励
                entropy_loss = -entropy.mean()
                
                # 总损失
                loss = actor_loss + value_coef * critic_loss + entropy_coef * entropy_loss
                
                # 更新网络
                agent.optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(agent.parameters(), max_norm=0.5)
                agent.optimizer.step()
            
            # 记录统计信息
            stats[agent_id] = {
                "actor_loss": actor_loss.item(),
                "critic_loss": critic_loss.item() if not self.shared_critic else 0,
                "entropy": entropy.mean().item(),
                "value_mean": values.mean().item(),
                "returns_mean": returns.mean().item()
            }
        
        # 清空缓冲区
        self.buffer.clear()
        
        return stats
    
    def save_models(self, path):
        """保存所有智能体的模型"""
        os.makedirs(path, exist_ok=True)
        
        # 保存全局critic（如果有）
        if self.shared_critic and self.global_critic is not None:
            torch.save(self.global_critic.state_dict(), f"{path}/global_critic.pt")
        
        # 保存每个智能体的模型
        for agent_id, agent in self.agents.items():
            agent_path = f"{path}/{agent_id}"
            os.makedirs(agent_path, exist_ok=True)
            
            torch.save(agent.actor.state_dict(), f"{agent_path}/actor.pt")
            if not self.shared_critic and agent.critic is not None:
                torch.save(agent.critic.state_dict(), f"{agent_path}/critic.pt")
    
    def load_models(self, path):
        """加载所有智能体的模型"""
        # 加载全局critic（如果有）
        if self.shared_critic and self.global_critic is not None:
            try:
                self.global_critic.load_state_dict(torch.load(f"{path}/global_critic.pt", map_location=self.device))
                print("Loaded global critic model")
            except:
                print("Failed to load global critic model")
        
        # 加载每个智能体的模型
        for agent_id, agent in self.agents.items():
            agent_path = f"{path}/{agent_id}"
            
            try:
                agent.actor.load_state_dict(torch.load(f"{agent_path}/actor.pt", map_location=self.device))
                print(f"Loaded actor model for agent {agent_id}")
                
                if not self.shared_critic and agent.critic is not None:
                    agent.critic.load_state_dict(torch.load(f"{agent_path}/critic.pt", map_location=self.device))
                    print(f"Loaded critic model for agent {agent_id}")
            except:
                print(f"Failed to load models for agent {agent_id}")


class Agent:
    """单个智能体的策略网络"""
    def __init__(self, agent_id, obs_dim, act_dim, shared_critic=False, 
                 lr_actor=3e-4, lr_critic=1e-3, hidden_dim=256, device=None):
        """
        初始化智能体
        
        Args:
            agent_id: 智能体ID
            obs_dim: 观察空间维度
            act_dim: 动作空间维度
            shared_critic: 是否使用共享的价值网络
            lr_actor: Actor网络学习率
            lr_critic: Critic网络学习率
            hidden_dim: 隐藏层维度
            device: 计算设备
        """
        self.agent_id = agent_id
        self.obs_dim = obs_dim
        self.act_dim = act_dim
        self.shared_critic = shared_critic
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # 创建Actor网络
        self.actor = Actor(obs_dim, act_dim, hidden_dim).to(self.device)
        
        # 如果不使用共享critic，则为每个智能体创建自己的critic
        self.critic = None
        if not shared_critic:
            self.critic = Critic(obs_dim, hidden_dim).to(self.device)
            
            # 合并actor和critic的参数进行优化
            self.optimizer = optim.Adam(
                list(self.actor.parameters()) + list(self.critic.parameters()),
                lr=lr_actor
            )
        else:
            # 只优化actor
            self.optimizer = optim.Adam(self.actor.parameters(), lr=lr_actor)
    
    def get_action(self, observation, deterministic=False):
        """
        根据观察获取动作
        
        Args:
            observation: 观察向量
            deterministic: 是否使用确定性策略
            
        Returns:
            action: 动作向量
            log_prob: 动作的对数概率
            entropy: 策略熵
        """
        # 转换为张量
        if isinstance(observation, np.ndarray):
            observation = torch.FloatTensor(observation).to(self.device)
        
        with torch.no_grad():
            # 获取策略分布
            mu, sigma = self.actor(observation)
            
            # 创建正态分布
            dist = Normal(mu, sigma)
            
            if deterministic:
                # 使用均值作为确定性动作
                action = mu
                log_prob = dist.log_prob(action).sum(dim=-1)
                entropy = dist.entropy().sum(dim=-1)
            else:
                # 从分布中采样
                action = dist.sample()
                log_prob = dist.log_prob(action).sum(dim=-1)
                entropy = dist.entropy().sum(dim=-1)
        
        return action.cpu().numpy(), log_prob.cpu().item(), entropy.cpu().item()
    
    def evaluate_action(self, observation, action):
        """
        评估动作的价值和对数概率
        
        Args:
            observation: 观察向量
            action: 动作向量
            
        Returns:
            value: 价值估计
            log_prob: 动作的对数概率
            entropy: 策略熵
        """
        # 获取策略分布
        mu, sigma = self.actor(observation)
        dist = Normal(mu, sigma)
        
        # 计算对数概率和熵
        log_prob = dist.log_prob(action).sum(dim=-1)
        entropy = dist.entropy().sum(dim=-1)
        
        # 计算价值（如果有critic）
        value = self.critic(observation).squeeze(-1) if self.critic is not None else torch.zeros_like(log_prob)
        
        return value, log_prob, entropy
    
    def evaluate_action_actor_only(self, observation, action):
        """
        仅使用actor评估动作（用于共享critic的情况）
        
        Args:
            observation: 观察向量
            action: 动作向量
            
        Returns:
            log_prob: 动作的对数概率
            entropy: 策略熵
        """
        # 获取策略分布
        mu, sigma = self.actor(observation)
        dist = Normal(mu, sigma)
        
        # 计算对数概率和熵
        log_prob = dist.log_prob(action).sum(dim=-1)
        entropy = dist.entropy().sum(dim=-1)
        
        return None, log_prob, entropy
    
    def get_value(self, observation):
        """
        获取观察的价值估计
        
        Args:
            observation: 观察向量
            
        Returns:
            value: 价值估计
        """
        if self.critic is None:
            return 0.0
            
        # 转换为张量
        if isinstance(observation, np.ndarray):
            observation = torch.FloatTensor(observation).to(self.device)
        
        with torch.no_grad():
            value = self.critic(observation).item()
        
        return value
    
    def parameters(self):
        """获取网络参数"""
        if self.critic is not None:
            return list(self.actor.parameters()) + list(self.critic.parameters())
        return self.actor.parameters()


class Actor(nn.Module):
    """Actor网络"""
    def __init__(self, input_dim, output_dim, hidden_dim=256):
        super(Actor, self).__init__()
        
        self.network = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU()
        )
        
        # 均值和标准差输出
        self.mu_head = nn.Linear(hidden_dim, output_dim)
        self.sigma_head = nn.Linear(hidden_dim, output_dim)
    
    def forward(self, x):
        features = self.network(x)
        mu = self.mu_head(features)
        
        # 使用softplus确保标准差为正
        sigma = torch.nn.functional.softplus(self.sigma_head(features)) + 1e-5
        
        return mu, sigma


class Critic(nn.Module):
    """Critic网络"""
    def __init__(self, input_dim, hidden_dim=256):
        super(Critic, self).__init__()
        
        self.network = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1)
        )
    
    def forward(self, x):
        return self.network(x)


class MultiAgentReplayBuffer:
    """多智能体经验回放缓冲区"""
    def __init__(self, capacity=10000, num_agents=3):
        self.capacity = capacity
        self.num_agents = num_agents
        self.buffers = {}
        self.global_buffer = deque(maxlen=capacity)
        self.position = 0
        self.size = 0
    
    def add(self, agent_id, state, action, reward, next_state, log_prob, value, done, global_state=None):
        """添加经验到缓冲区"""
        # 如果这个智能体的缓冲区不存在，则创建
        if agent_id not in self.buffers:
            self.buffers[agent_id] = deque(maxlen=self.capacity)
        
        # 添加经验
        self.buffers[agent_id].append((state, action, reward, next_state, log_prob, value, done))
        
        # 添加全局经验（如果提供）
        if global_state is not None:
            self.global_buffer.append((global_state, None, reward, None, log_prob, value, done, agent_id))
    
    def sample(self, agent_id, batch_size):
        """从特定智能体的缓冲区采样批次"""
        if agent_id not in self.buffers or len(self.buffers[agent_id]) == 0:
            return np.zeros((0,)), np.zeros((0,)), np.zeros((0,)), np.zeros((0,)), np.zeros((0,)), np.zeros((0,)), np.zeros((0,), dtype=bool), []
        
        # 确保批次大小不超过缓冲区大小
        batch_size = min(batch_size, len(self.buffers[agent_id]))
        
        # 随机选择索引
        indices = np.random.choice(len(self.buffers[agent_id]), batch_size)
        
        # 解压经验
        experiences = [self.buffers[agent_id][i] for i in indices]
        states, actions, rewards, next_states, log_probs, values, dones = zip(*experiences)
        
        return (
            np.array(states),
            np.array(actions),
            np.array(rewards),
            np.array(next_states),
            np.array(log_probs),
            np.array(values),
            np.array(dones),
            indices
        )
    
    def sample_global(self, batch_size):
        """从全局缓冲区采样批次"""
        if len(self.global_buffer) == 0:
            return (
                np.zeros((0,)), np.zeros((0,)), np.zeros((0,)), np.zeros((0,)),
                np.zeros((0,)), np.zeros((0,)), np.zeros((0,), dtype=bool), []
            )
        
        # 确保批次大小不超过缓冲区大小
        batch_size = min(batch_size, len(self.global_buffer))
        
        # 随机选择索引
        indices = np.random.choice(len(self.global_buffer), batch_size)
        
        # 解压经验
        experiences = [self.global_buffer[i] for i in indices]
        states, actions, rewards, next_states, log_probs, values, dones, agent_ids = zip(*experiences)
        
        return (
            np.array(states),
            np.array(actions),
            np.array(rewards),
            np.array(next_states),
            np.array(log_probs),
            np.array(values),
            np.array(dones),
            agent_ids
        )
    
    def compute_returns(self, rewards, gamma=0.99, last_value=0, use_gae=False, gae_lambda=0.95):
        """计算折扣回报"""
        returns = []
        R = last_value
        
        for r in reversed(rewards):
            R = r + gamma * R
            returns.insert(0, R)
            
        return returns
    
    def __len__(self):
        """缓冲区长度"""
        lengths = [len(buffer) for buffer in self.buffers.values()]
        return min(lengths) if lengths else 0
    
    def clear(self):
        """清空缓冲区"""
        for agent_id in self.buffers:
            self.buffers[agent_id].clear()
        self.global_buffer.clear()
