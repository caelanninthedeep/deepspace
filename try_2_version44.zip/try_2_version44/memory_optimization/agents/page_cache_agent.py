"""
页面缓存智能体 - 负责文件缓存和页面缓存参数优化
"""

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from torch.distributions import Normal

class PageCacheAgent(nn.Module):
    """
    页面缓存智能体 - 负责优化Linux文件缓存相关参数
    调整vfs_cache_pressure、dirty_ratio和dirty_background_ratio
    """
    def __init__(self, input_dim, hidden_dim=128, device=None):
        super(PageCacheAgent, self).__init__()
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # 输出维度: 3 (vfs_cache_pressure, dirty_ratio, dirty_background_ratio)
        self.output_dim = 3
        
        # Actor网络 - 确定性部分
        self.actor_backbone = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
        )
        
        # 输出均值
        self.mu_head = nn.Linear(hidden_dim, self.output_dim)
        
        # 输出标准差
        self.sigma_head = nn.Linear(hidden_dim, self.output_dim)
        
        # Critic网络
        self.critic = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1)
        )
        
        # 为缓存参数定义合理的动作幅度
        self.action_scales = torch.tensor([
            2.0,  # vfs_cache_pressure变化幅度较大
            0.5,  # dirty_ratio变化幅度较小
            0.5   # dirty_background_ratio变化幅度较小
        ]).to(self.device)
        
        # 初始化网络参数
        self._init_weights()
    
    def _init_weights(self):
        """初始化网络权重"""
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.orthogonal_(module.weight, gain=1)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
    
    def forward(self, state):
        """前向传播，返回动作分布参数和状态值"""
        if isinstance(state, np.ndarray):
            state = torch.FloatTensor(state).to(self.device)
            
        # 获取共享特征
        features = self.actor_backbone(state)
        
        # 动作分布参数
        mu = torch.tanh(self.mu_head(features))  # 范围限制在[-1, 1]
        
        # 使用softplus确保标准差为正，并根据缓存操作适当缩放
        sigma = torch.nn.functional.softplus(self.sigma_head(features)) * 0.1 + 0.01
        
        # 计算状态值
        value = self.critic(state)
        
        return mu, sigma, value
    
    def get_action(self, state, deterministic=False):
        """获取动作，可选择确定性或随机策略"""
        mu, sigma, value = self.forward(state)
        
        if deterministic:
            # 确定性策略直接返回均值
            action = mu
        else:
            # 创建正态分布并采样
            dist = Normal(mu, sigma)
            action = dist.sample()
            
            # 根据不同参数使用不同缩放
            action = action * self.action_scales
        
        # 限制动作在[-1, 1]范围内
        action = torch.clamp(action, -1.0, 1.0)
        
        # 计算对数概率
        if deterministic:
            log_prob = torch.zeros(1).to(self.device)
            entropy = torch.zeros(1).to(self.device)
        else:
            dist = Normal(mu, sigma)
            log_prob = dist.log_prob(action).sum(-1)
            entropy = dist.entropy().sum(-1)
        
        return action, log_prob, entropy, value
    
    def evaluate_action(self, state, action):
        """评估已经采取的动作"""
        mu, sigma, value = self.forward(state)
        
        dist = Normal(mu, sigma)
        log_prob = dist.log_prob(action).sum(-1)
        entropy = dist.entropy().sum(-1)
        
        return value, log_prob, entropy
    
    def cache_analysis(self, state):
        """
        分析缓存相关指标，为决策提供额外信息
        
        Args:
            state: 系统状态
            
        Returns:
            dict: 缓存分析结果
        """
        with torch.no_grad():
            # 提取关键缓存指标
            if isinstance(state, torch.Tensor):
                state_np = state.cpu().numpy()
            else:
                state_np = state
                
            # 这里假设状态向量的特定索引对应特定指标
            # 在实际应用中，您需要确保这些索引是正确的
            
            # 计算缓存压力指标
            cache_pressure = np.mean(state_np[:4])  # 示例，使用前4个值的平均值表示缓存压力
            
            # 估算脏页比例最佳值
            optimal_dirty_ratio = 10 + 30 * sigmoid(cache_pressure)  # 根据缓存压力调整最优脏页比例
            optimal_bg_ratio = optimal_dirty_ratio * 0.4  # 后台脏页比例通常是主比例的40%左右
            
            return {
                "cache_pressure": float(cache_pressure),
                "optimal_dirty_ratio": float(optimal_dirty_ratio),
                "optimal_dirty_bg_ratio": float(optimal_bg_ratio),
                "vfs_pressure_adjustment": float(2 * (cache_pressure - 0.5))  # 缓存压力对vfs_cache_pressure的建议调整
            }

def sigmoid(x):
    """Sigmoid函数"""
    return 1 / (1 + np.exp(-x))
