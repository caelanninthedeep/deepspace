"""
内存调度智能体 - 负责内存水位线和碎片整理参数优化
"""

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from torch.distributions import Normal

class MemorySchedulerAgent(nn.Module):
    """
    内存调度智能体 - 负责优化Linux内存水位线和碎片整理策略
    调整watermark_scale_factor和compaction_proactiveness
    """
    def __init__(self, input_dim, hidden_dim=128, device=None):
        super(MemorySchedulerAgent, self).__init__()
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # 输出维度: 2 (watermark_scale_factor, compaction_proactiveness)
        self.output_dim = 2
        
        # Actor网络使用LSTM来捕捉时序特性
        self.lstm = nn.LSTM(input_dim, hidden_dim, batch_first=True)
        self.actor_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU()
        )
        
        # 输出均值
        self.mu_head = nn.Linear(hidden_dim, self.output_dim)
        
        # 输出标准差
        self.sigma_head = nn.Linear(hidden_dim, self.output_dim)
        
        # Critic网络
        self.critic = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1)
        )
        
        # 为调度参数定义合理的动作幅度
        self.action_scales = torch.tensor([
            3.0,  # watermark_scale_factor变化幅度较大
            1.0   # compaction_proactiveness变化幅度中等
        ]).to(self.device)
        
        # 历史状态缓存
        self.state_history = []
        self.history_length = 5
        
        # LSTM隐藏状态
        self.hidden = None
        
        # 初始化网络参数
        self._init_weights()
    
    def _init_weights(self):
        """初始化网络权重"""
        for name, param in self.named_parameters():
            if 'lstm' in name:
                if 'weight_ih' in name:
                    nn.init.xavier_uniform_(param.data)
                elif 'weight_hh' in name:
                    nn.init.orthogonal_(param.data)
                elif 'bias' in name:
                    param.data.fill_(0)
            elif 'linear' in name or isinstance(param, nn.Linear):
                if 'weight' in name:
                    nn.init.orthogonal_(param.data, gain=1)
                elif 'bias' in name:
                    param.data.fill_(0)
    
    def reset_hidden(self, batch_size=1):
        """重置LSTM隐藏状态"""
        h0 = torch.zeros(1, batch_size, self.lstm.hidden_size).to(self.device)
        c0 = torch.zeros(1, batch_size, self.lstm.hidden_size).to(self.device)
        self.hidden = (h0, c0)
        self.state_history = []
    
    def forward(self, state):
        """前向传播，返回动作分布参数和状态值"""
        if isinstance(state, np.ndarray):
            state = torch.FloatTensor(state).to(self.device)
        
        # 更新状态历史
        self.state_history.append(state.clone())
        if len(self.state_history) > self.history_length:
            self.state_history.pop(0)
        
        # 准备LSTM输入序列
        if len(self.state_history) < self.history_length:
            # 如果历史不够长，用当前状态填充
            sequence = torch.stack([state] * self.history_length)
        else:
            sequence = torch.stack(self.state_history)
        
        # 调整序列形状为[batch_size, seq_len, features]
        sequence = sequence.unsqueeze(0)
        
        # 通过LSTM处理序列
        if self.hidden is None:
            self.reset_hidden()
        
        lstm_out, self.hidden = self.lstm(sequence, self.hidden)
        
        # 使用最后一个时间步的输出
        features = self.actor_head(lstm_out[:, -1])
        
        # 动作分布参数
        mu = torch.tanh(self.mu_head(features))  # 范围限制在[-1, 1]
        
        # 使用softplus确保标准差为正
        sigma = torch.nn.functional.softplus(self.sigma_head(features)) * 0.1 + 0.01
        
        # 计算状态值
        value = self.critic(state)
        
        return mu, sigma, value
    
    def get_action(self, state, deterministic=False):
        """获取动作，可选择确定性或随机策略"""
        mu, sigma, value = self.forward(state)
        
        if deterministic:
            # 确定性策略直接返回均值
            action = mu
        else:
            # 创建正态分布并采样
            dist = Normal(mu, sigma)
            action = dist.sample()
            
            # 根据不同参数使用不同缩放
            action = action * self.action_scales
        
        # 限制动作在[-1, 1]范围内
        action = torch.clamp(action, -1.0, 1.0)
        
        # 计算对数概率
        if deterministic:
            log_prob = torch.zeros(1).to(self.device)
            entropy = torch.zeros(1).to(self.device)
        else:
            dist = Normal(mu, sigma)
            log_prob = dist.log_prob(action).sum(-1)
            entropy = dist.entropy().sum(-1)
        
        return action, log_prob, entropy, value
    
    def evaluate_action(self, state, action):
        """评估已经采取的动作"""
        mu, sigma, value = self.forward(state)
        
        dist = Normal(mu, sigma)
        log_prob = dist.log_prob(action).sum(-1)
        entropy = dist.entropy().sum(-1)
        
        return value, log_prob, entropy
    
    def scheduler_analysis(self, state):
        """
        分析内存调度相关指标，为决策提供额外信息
        
        Args:
            state: 系统状态
            
        Returns:
            dict: 内存调度分析结果
        """
        with torch.no_grad():
            # 提取关键内存调度指标
            if isinstance(state, torch.Tensor):
                state_np = state.cpu().numpy()
            else:
                state_np = state
            
            # 计算碎片化指标
            fragmentation = np.mean(state_np[:2])  # 示例，使用前2个值的平均值表示内存碎片化
            
            # 计算系统负载
            system_load = np.mean(state_np[2:4])  # 示例，使用索引2-3的值表示系统负载
            
            # 根据碎片化和负载计算最佳水位线因子
            optimal_watermark = 100 + int(fragmentation * 300)  # 范围在100-400之间
            
            # 根据碎片化计算最佳碎片整理积极性
            if fragmentation > 0.7:  # 高碎片化
                optimal_compaction = 80  # 非常积极的碎片整理
            elif fragmentation > 0.4:  # 中等碎片化
                optimal_compaction = 50  # 中等积极的碎片整理
            else:  # 低碎片化
                optimal_compaction = 20  # 较少的碎片整理
            
            # 根据系统负载调整碎片整理策略
            if system_load > 0.8:  # 高负载
                optimal_compaction = max(10, optimal_compaction - 30)  # 降低碎片整理积极性
            
            return {
                "fragmentation": float(fragmentation),
                "system_load": float(system_load),
                "optimal_watermark_factor": int(optimal_watermark),
                "optimal_compaction": int(optimal_compaction),
                "trend": self._calculate_trend()
            }
    
    def _calculate_trend(self):
        """计算关键指标的趋势"""
        if len(self.state_history) < 2:
            return {"fragmentation": 0, "load": 0}
        
        # 假设state_history中的状态包含碎片化和负载指标
        # 这里简化处理，实际使用时需要确保索引正确
        frag_history = [s[0].item() for s in self.state_history]  # 假设索引0是碎片化指标
        load_history = [s[2].item() for s in self.state_history]  # 假设索引2是负载指标
        
        # 计算趋势（简单使用最近两个值的差）
        frag_trend = frag_history[-1] - frag_history[0]
        load_trend = load_history[-1] - load_history[0]
        
        return {
            "fragmentation": float(frag_trend),
            "load": float(load_trend)
        }
