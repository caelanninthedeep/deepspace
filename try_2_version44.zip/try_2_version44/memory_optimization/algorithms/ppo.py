"""
PPO算法实现 - 支持连续动作空间
"""

import os
import time
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.tensorboard import SummaryWriter
from .buffer import RolloutBuffer

class PPO:
    """
    PPO算法实现，用于内存子系统参数优化
    支持连续动作空间
    """
    
    def __init__(self, state_dim, action_dim, network_class=None, config=None):
        """
        初始化PPO算法
        
        参数:
            state_dim: 状态维度
            action_dim: 动作维度
            network_class: 网络类，如果为None则使用ActorCriticNetwork
            config: 配置字典
        """
        # 默认配置
        default_config = {
            'lr': 0.0003,                      # 学习率
            'gamma': 0.99,                     # 折扣因子
            'gae_lambda': 0.95,                # GAE参数
            'clip_ratio': 0.2,                 # PPO截断参数
            'batch_size': 64,                  # 训练批次大小
            'epochs': 10,                      # 每次更新的训练轮数
            'buffer_size': 2048,               # 缓冲区大小
            'action_std_init': 0.6,            # 初始动作标准差
            'entropy_coef': 0.01,              # 熵正则化系数
            'value_coef': 0.5,                 # 价值函数损失系数
            'max_grad_norm': 0.5,              # 梯度裁剪值
            'hidden_dims': [256, 256],         # 隐藏层维度
            'device': 'cuda' if torch.cuda.is_available() else 'cpu',  # 训练设备
            'save_dir': 'models/ppo',          # 模型保存目录
            'log_dir': 'logs/ppo',             # 日志目录
            'network_type': 'actor_critic'     # 网络类型: 'actor_critic', 'page_cache', 'memory_reclaim', 'memory_scheduler'
        }
        
        # 更新配置
        self.config = default_config
        if config:
            self.config.update(config)
        
        # 确保目录存在
        os.makedirs(self.config['save_dir'], exist_ok=True)
        os.makedirs(self.config['log_dir'], exist_ok=True)
        
        # 设置设备
        self.device = torch.device(self.config['device'])
        
        # 如果未提供网络类，根据配置选择
        if network_class is None:
            from .network import ActorCriticNetwork, PageCacheNetwork, MemoryReclaimNetwork, MemorySchedulerNetwork
            
            network_type = self.config['network_type'].lower()
            
            if network_type == 'page_cache':
                self.network_class = PageCacheNetwork
            elif network_type == 'memory_reclaim':
                self.network_class = MemoryReclaimNetwork
            elif network_type == 'memory_scheduler':
                self.network_class = MemorySchedulerNetwork
            else:
                self.network_class = ActorCriticNetwork
        else:
            self.network_class = network_class
        
        # 创建网络
        if self.network_class.__name__ == 'MemorySchedulerNetwork':
            # MemorySchedulerNetwork需要额外的参数
            self.model = self.network_class(
                state_dim, 
                action_dim, 
                action_std_init=self.config['action_std_init'],
                hidden_dims=self.config['hidden_dims'],
                lstm_hidden=self.config.get('lstm_hidden', 64),
                lstm_layers=self.config.get('lstm_layers', 1)
            ).to(self.device)
        else:
            # 其他网络使用标准参数
            self.model = self.network_class(
                state_dim, 
                action_dim, 
                action_std_init=self.config['action_std_init'],
                hidden_dims=self.config['hidden_dims']
            ).to(self.device)
        
        # 设置优化器
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.config['lr'])
        
        # 创建经验回放缓冲区
        self.buffer = RolloutBuffer(
            self.config['buffer_size'],
            state_dim,
            action_dim,
            gamma=self.config['gamma'],
            gae_lambda=self.config['gae_lambda'],
            device=self.device
        )
        
        # 记录训练统计信息
        self.training_step = 0
        self.writer = SummaryWriter(self.config['log_dir'])
        
        # 记录动作标准差的衰减
        self.action_std = self.config['action_std_init']
        self.action_std_decay_rate = 0.05  # 标准差衰减率
        self.min_action_std = 0.1         # 最小标准差
        
        # 如果使用LSTM，记录隐藏状态
        self.is_lstm_network = hasattr(self.model, 'reset_hidden')
    
    def select_action(self, state):
        """
        根据状态选择动作
        
        参数:
            state: 环境状态
            
        返回:
            action: 选择的动作(numpy数组)
            log_prob: 动作的对数概率
            value: 状态的价值估计
        """
        with torch.no_grad():
            # 转换为PyTorch张量
            state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            
            # 根据网络类型处理动作选择
            if hasattr(self.model, 'get_action'):
                action, log_prob, value = self.model.get_action(state_tensor)
            else:
                # 处理不同类型的网络输出
                if hasattr(self.model, 'forward') and len(self.model.forward.__code__.co_varnames) > 2:
                    # 特殊网络可能有额外参数
                    action_mean, action_std, value = self.model(state_tensor)
                else:
                    # 标准网络
                    action_mean, action_std, value = self.model(state_tensor)
                
                # 采样动作
                dist = torch.distributions.Normal(action_mean, action_std)
                action = dist.sample()
                log_prob = dist.log_prob(action).sum(dim=-1)
            
            # 转换为numpy数组
            action_np = action.cpu().numpy().flatten()
            log_prob_np = log_prob.cpu().numpy()
            value_np = value.cpu().numpy()
        
        return action_np, log_prob_np, value_np
    
    def get_value(self, state):
        """获取状态价值"""
        with torch.no_grad():
            state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            
            # 根据网络类型获取价值
            if hasattr(self.model, 'critic'):
                value = self.model.critic(state_tensor)
            else:
                # 如果网络没有独立的critic方法，使用forward
                _, _, value = self.model(state_tensor)
        return value.cpu().numpy()
    
    def reset_lstm_state(self, batch_size=1):
        """如果使用LSTM网络，重置隐藏状态"""
        if self.is_lstm_network:
            self.model.reset_hidden(batch_size)
    
    def store(self, state, action, reward, done, next_state, value, log_prob):
        """
        存储经验到缓冲区
        
        参数:
            state: 状态
            action: 动作
            reward: 奖励
            done: 是否终止
            next_state: 下一状态
            value: 状态价值估计
            log_prob: 动作对数概率
        """
        # 简单缩放和剪切奖励
        reward = np.clip(reward, -10.0, 10.0)
        
        # 存储到缓冲区
        self.buffer.store(state, action, reward, done, next_state, value, log_prob)
    
    def update(self):
        """
        更新策略和价值网络
        
        返回:
            train_info: 包含训练信息的字典
        """
        # 如果缓冲区为空，直接返回
        if self.buffer.size == 0:
            return None
        
        # 计算最后状态的价值(如果路径未结束)
        last_value = self.get_value(self.buffer.next_states[self.buffer.size-1])
        
        # 计算优势和回报
        advantages, returns = self.buffer.compute_advantages(last_value)
        
        # 记录训练信息
        train_info = {
            'value_loss': 0,
            'policy_loss': 0,
            'entropy': 0,
            'approx_kl': 0,
            'clipfrac': 0
        }
        
        # 多轮更新
        for _ in range(self.config['epochs']):
            # 获取随机批次
            batch_data = self.buffer.get_batch(self.config['batch_size'])
            
            # 遍历批次数据
            for _, data in batch_data.items():
                # 获取批次数据
                states = data['states']
                actions = data['actions']
                returns = data['returns']
                advantages = data['advantages']
                old_log_probs = data['old_log_probs']
                
                # 估计当前动作的对数概率、状态价值和熵
                if hasattr(self.model, 'evaluate'):
                    log_probs, values, entropy = self.model.evaluate(states, actions)
                else:
                    # 如果网络没有evaluate方法，手动计算
                    if isinstance(self.model, (PageCacheNetwork, MemoryReclaimNetwork)):
                        # 对于特殊网络，可能需要额外处理
                        action_mean, action_std, values, _ = self.model(states)
                    else:
                        # 标准网络
                        action_mean, action_std, values = self.model(states)
                    
                    # 创建分布并计算对数概率和熵
                    dist = torch.distributions.Normal(action_mean, action_std)
                    log_probs = dist.log_prob(actions).sum(dim=-1)
                    entropy = dist.entropy().sum(dim=-1)
                
                # 计算策略比率
                ratios = torch.exp(log_probs - old_log_probs)
                
                # 计算替代目标(surrogate objective)
                surr1 = ratios * advantages
                surr2 = torch.clamp(ratios, 1 - self.config['clip_ratio'], 1 + self.config['clip_ratio']) * advantages
                
                # 计算策略损失
                policy_loss = -torch.min(surr1, surr2).mean()
                
                # 计算价值损失
                value_loss = nn.MSELoss()(values, returns)
                
                # 计算熵损失(用于鼓励探索)
                entropy_loss = -entropy.mean()
                
                # 计算总损失
                loss = policy_loss + \
                       self.config['value_coef'] * value_loss + \
                       self.config['entropy_coef'] * entropy_loss
                
                # 梯度清零、反向传播和梯度裁剪
                self.optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(self.model.parameters(), self.config['max_grad_norm'])
                self.optimizer.step()
                
                # 计算指标
                with torch.no_grad():
                    # 计算近似KL散度(用于监控)
                    log_ratio = log_probs - old_log_probs
                    approx_kl = ((torch.exp(log_ratio) - 1) - log_ratio).mean().item()
                    
                    # 计算截断比例
                    clipfrac = ((ratios - 1.0).abs() > self.config['clip_ratio']).float().mean().item()
                
                # 更新训练信息
                train_info['value_loss'] += value_loss.item()
                train_info['policy_loss'] += policy_loss.item()
                train_info['entropy'] += entropy.mean().item()
                train_info['approx_kl'] += approx_kl
                train_info['clipfrac'] += clipfrac
        
        # 计算平均值
        num_batches = len(batch_data)
        for key in train_info:
            train_info[key] /= (num_batches * self.config['epochs'])
        
        # 清空缓冲区
        self.buffer.reset()
        
        # 记录训练信息到TensorBoard
        self.training_step += 1
        for key, value in train_info.items():
            self.writer.add_scalar(f'training/{key}', value, self.training_step)
        
        return train_info
    
    def decay_action_std(self, decay_rate=None):
        """
        衰减动作标准差，用于减少探索
        
        参数:
            decay_rate: 衰减率，如果为None则使用默认值
        """
        if decay_rate is None:
            decay_rate = self.action_std_decay_rate
        
        self.action_std = max(self.min_action_std, self.action_std - decay_rate)
        
        # 更新网络的动作标准差
        if hasattr(self.model, 'update_action_std'):
            self.model.update_action_std(self.action_std)
        elif hasattr(self.model, 'actor_std'):
            # 对于使用参数的网络
            with torch.no_grad():
                self.model.actor_std.fill_(np.log(self.action_std))
        
        self.writer.add_scalar('training/action_std', self.action_std, self.training_step)
    
    def save(self, path=None):
        """
        保存模型
        
        参数:
            path: 保存路径，如果为None则使用默认路径
        """
        if path is None:
            path = os.path.join(self.config['save_dir'], f'ppo_model_{int(time.time())}')
        
        # 创建模型状态字典
        model_state = {
            'model': self.model.state_dict(),
            'optimizer': self.optimizer.state_dict(),
            'action_std': self.action_std,
            'config': self.config,
            'training_step': self.training_step,
            'network_class': self.network_class.__name__
        }
        
        # 保存模型
        torch.save(model_state, path + '.pt')
        print(f"Model saved to {path}.pt")
    
    def load(self, path):
        """
        加载模型
        
        参数:
            path: 模型路径
        """
        # 加载模型
        model_state = torch.load(path, map_location=self.device)
        
        # 更新配置
        self.config.update(model_state['config'])
        
        # 重新创建模型(如果需要)
        if model_state['model']:
            self.model.load_state_dict(model_state['model'])
        
        # 加载优化器状态
        if model_state['optimizer']:
            self.optimizer.load_state_dict(model_state['optimizer'])
        
        # 恢复其他状态
        self.action_std = model_state['action_std']
        self.training_step = model_state.get('training_step', 0)
        
        # 更新模型的动作标准差
        if hasattr(self.model, 'update_action_std'):
            self.model.update_action_std(self.action_std)
        elif hasattr(self.model, 'actor_std'):
            with torch.no_grad():
                self.model.actor_std.fill_(np.log(self.action_std))
        
        print(f"Model loaded from {path}")
