"""
测试训练好的内存优化代理 - 支持连续动作空间
"""
import torch
import numpy as np
import argparse
import time
from memory_optimization.environment.mem_env import MemoryOptimizationEnv
from memory_optimization.algorithms.ppo import PPO

def test_agent(model_path, episodes=10, render=True, save_metrics=True, run_baseline=True):
    """
    测试训练好的代理
    
    Args:
        model_path (str): 模型路径
        episodes (int): 测试回合数
        render (bool): 是否渲染环境
        save_metrics (bool): 是否保存指标
        run_baseline (bool): 是否运行基线比较
    """
    # 创建环境
    env = MemoryOptimizationEnv()
    
    # 获取状态和动作维度
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]  # 连续动作空间
    
    # 初始化代理
    agent = PPO(state_dim, action_dim)
    
    # 加载模型
    agent.load(model_path)
    print(f"加载模型: {model_path}")
    
    # 保存测试指标
    metrics = {
        'rewards': [],
        'runtimes': [],
        'parameters': [],
        'workloads': [],
        'difficulties': []
    }
    
    # 如果需要，先运行基线测试
    baseline_metrics = None
    if run_baseline:
        print("\n===== 运行基线测试 (默认参数) =====")
        baseline_metrics = run_baseline_test(env, episodes=episodes)
    
    # 测试循环
    print("\n===== 运行代理测试 =====")
    total_rewards = []
    
    for episode in range(1, episodes + 1):
        state = env.reset()
        episode_reward = 0
        done = False
        step = 0
        
        # 记录参数变化
        episode_params = []
        episode_runtimes = []
        episode_workloads = []
        episode_difficulties = []
        
        print(f"\n开始回合 {episode}/{episodes}")
        
        while not done and step < 50:  # 限制每个回合的步数
            # 根据策略选择动作
            action, _, _ = agent.select_action(state)
            
            # 执行动作
            next_state, reward, done, info = env.step(action)
            
            # 收集指标
            params = info.get('applied_params', {})
            episode_params.append(params)
            episode_runtimes.append(info.get('runtime', 0))
            episode_workloads.append(info.get('workload_type', ''))
            episode_difficulties.append(info.get('difficulty', ''))
            
            # 渲染环境
            if render and step % 5 == 0:  # 减少渲染频率，提高性能
                env.render()
                
            # 更新状态和奖励
            state = next_state
            episode_reward += reward
            step += 1
            
            # 打印步骤信息
            if step % 10 == 0:
                print(f"步骤 {step}: 奖励 = {reward:.2f}, 累计奖励 = {episode_reward:.2f}")
        
        # 记录总奖励和指标
        total_rewards.append(episode_reward)
        metrics['rewards'].append(episode_reward)
        metrics['runtimes'].append(episode_runtimes)
        metrics['parameters'].append(episode_params)
        metrics['workloads'].append(episode_workloads)
        metrics['difficulties'].append(episode_difficulties)
        
        # 输出回合总结
        print(f"回合 {episode}/{episodes} | 总奖励: {episode_reward:.2f} | 步数: {step}")
        print(f"最终参数配置: {params}")
        print(f"最终工作负载运行时间: {episode_runtimes[-1]:.2f}s")
    
    # 打印平均奖励
    avg_reward = np.mean(total_rewards)
    print(f"\n===== 测试结果 =====")
    print(f"平均奖励: {avg_reward:.2f} ± {np.std(total_rewards):.2f}")
    
    # 打印代理性能与基线比较
    if baseline_metrics:
        compare_with_baseline(metrics, baseline_metrics)
    
    # 保存指标
    if save_metrics:
        save_test_metrics(metrics, baseline_metrics, model_path)
    
    # 返回测试指标
    return metrics, baseline_metrics

def run_baseline_test(env, episodes=5):
    """
    使用默认参数运行测试以建立基线
    """
    # 保存基线测试指标
    baseline_metrics = {
        'rewards': [],
        'runtimes': [],
        'workloads': [],
        'difficulties': []
    }
    
    # 保存原始参数
    original_params = env.action_handler.get_current_parameters()
    
    for episode in range(1, episodes + 1):
        # 重置环境但保留默认参数
        state = env.reset()
        
        # 恢复默认参数
        for param, value in original_params.items():
            env.action_handler.set_parameter(param, value)
        
        episode_runtimes = []
        episode_workloads = []
        episode_difficulties = []
        
        # 运行多个工作负载以获取平均性能
        for step in range(20):
            # 选择工作负载类型和难度
            workload_type = env._select_workload_type()
            difficulty = env.difficulty_strategy.select_difficulty()
            
            # 记录开始前的指标
            env.current_workload_type = workload_type
            env.current_difficulty = difficulty
            
            # 运行工作负载
            env.run_test_workload()
            
            # 记录指标
            episode_runtimes.append(env.last_workload_runtime)
            episode_workloads.append(workload_type)
            episode_difficulties.append(difficulty)
            
            # 间隔
            time.sleep(0.5)
        
        # 记录基线指标
        avg_runtime = np.mean(episode_runtimes)
        baseline_metrics['runtimes'].append(episode_runtimes)
        baseline_metrics['workloads'].append(episode_workloads)
        baseline_metrics['difficulties'].append(episode_difficulties)
        
        print(f"基线回合 {episode}/{episodes} | 平均运行时间: {avg_runtime:.2f}s")
    
    return baseline_metrics

def compare_with_baseline(agent_metrics, baseline_metrics):
    """比较代理和基线性能"""
    # 计算平均运行时间
    agent_avg_runtime = np.mean([np.mean(runtimes) for runtimes in agent_metrics['runtimes']])
    baseline_avg_runtime = np.mean([np.mean(runtimes) for runtimes in baseline_metrics['runtimes']])
    
    # 计算性能改进
    improvement = (baseline_avg_runtime - agent_avg_runtime) / baseline_avg_runtime * 100
    
    print("\n===== 与基线比较 =====")
    print(f"基线平均运行时间: {baseline_avg_runtime:.2f}s")
    print(f"代理平均运行时间: {agent_avg_runtime:.2f}s")
    print(f"性能改进: {improvement:.1f}%")
    
    # 按难度级别比较
    difficulty_levels = ['easy', 'medium', 'hard', 'extreme']
    print("\n按难度级别比较:")
    
    for difficulty in difficulty_levels:
        # 找出代理在该难度下的运行时间
        agent_runtimes = []
        for i, episode_difficulties in enumerate(agent_metrics['difficulties']):
            for j, diff in enumerate(episode_difficulties):
                if diff == difficulty:
                    agent_runtimes.append(agent_metrics['runtimes'][i][j])
        
        # 找出基线在该难度下的运行时间
        baseline_runtimes = []
        for i, episode_difficulties in enumerate(baseline_metrics['difficulties']):
            for j, diff in enumerate(episode_difficulties):
                if diff == difficulty:
                    baseline_runtimes.append(baseline_metrics['runtimes'][i][j])
        
        if agent_runtimes and baseline_runtimes:
            agent_avg = np.mean(agent_runtimes)
            baseline_avg = np.mean(baseline_runtimes)
            improvement = (baseline_avg - agent_avg) / baseline_avg * 100
            print(f"难度 '{difficulty}': 基线 = {baseline_avg:.2f}s, 代理 = {agent_avg:.2f}s, 改进 = {improvement:.1f}%")

def save_test_metrics(metrics, baseline_metrics, model_path):
    """保存测试指标到文件"""
    import json
    import os
    from datetime import datetime
    
    # 创建结果目录
    results_dir = "results"
    os.makedirs(results_dir, exist_ok=True)
    
    # 构建文件名
    model_name = os.path.basename(model_path).split('.')[0]
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{results_dir}/test_{model_name}_{timestamp}.json"
    
    # 准备数据
    data = {
        'model': model_path,
        'timestamp': timestamp,
        'agent': metrics,
    }
    
    if baseline_metrics:
        data['baseline'] = baseline_metrics
    
    # 将NumPy数组转换为列表
    def convert_np_to_list(obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, dict):
            return {k: convert_np_to_list(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_np_to_list(item) for item in obj]
        else:
            return obj
    
    data = convert_np_to_list(data)
    
    # 保存到文件
    with open(filename, 'w') as f:
        json.dump(data, f, indent=2)
    
    print(f"\n测试指标已保存至: {filename}")

if __name__ == "__main__":
    # 解析命令行参数
    parser = argparse.ArgumentParser(description="测试内存优化代理")
    parser.add_argument("--model", type=str, required=True, help="模型路径")
    parser.add_argument("--episodes", type=int, default=50, help="测试回合数")
    parser.add_argument("--no-render", action="store_true", help="不渲染环境")
    parser.add_argument("--no-baseline", action="store_true", help="不运行基线测试")
    parser.add_argument("--no-save", action="store_true", help="不保存测试指标")
    
    args = parser.parse_args()
    
    # 测试代理
    metrics, baseline = test_agent(
        model_path=args.model,
        episodes=args.episodes,
        render=not args.no_render,
        save_metrics=not args.no_save,
        run_baseline=not args.no_baseline
    )
