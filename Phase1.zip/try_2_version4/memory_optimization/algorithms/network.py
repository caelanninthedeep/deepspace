"""
PPO神经网络模型 - 支持连续动作空间
"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Normal

class ActorCriticNetwork(nn.Module):
    """
    ActorCritic网络 - 同时具有策略(Actor)和价值(Critic)网络
    支持连续动作空间
    """
    
    def __init__(self, state_dim, action_dim, action_std_init=0.6, hidden_dims=[256, 256]):
        super(ActorCriticNetwork, self).__init__()
        
        # 共享特征提取层
        self.feature_extractor = nn.Sequential(
            nn.Linear(state_dim, hidden_dims[0]),
            nn.Tanh(),
            nn.Linear(hidden_dims[0], hidden_dims[1]),
            nn.Tanh()
        )
        
        # Actor网络 - 输出动作的均值
        self.actor_mean = nn.Linear(hidden_dims[1], action_dim)
        
        # 动作标准差(可学习)
        self.action_log_std = nn.Parameter(torch.ones(1, action_dim) * np.log(action_std_init))
        
        # Critic网络 - 输出状态价值
        self.critic_network = nn.Sequential(
            nn.Linear(hidden_dims[1], 128),
            nn.Tanh(),
            nn.Linear(128, 1)
        )
        
        # 初始化权重
        self._init_weights()
    
    def _init_weights(self):
        """初始化网络权重"""
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight, gain=np.sqrt(2))
                nn.init.constant_(m.bias, 0.0)
    
    def forward(self):
        """前向传播方法(占位符，不直接使用)"""
        raise NotImplementedError("Use actor and critic methods instead")
    
    def actor(self, state):
        """
        策略网络前向传播，返回动作分布
        
        参数:
            state: 状态输入张量
            
        返回:
            action_dist: 动作概率分布
        """
        features = self.feature_extractor(state)
        
        # 动作均值，使用tanh确保在[-1,1]范围内
        action_mean = torch.tanh(self.actor_mean(features))
        
        # 动作标准差
        action_std = torch.exp(self.action_log_std)
        
        # 创建正态分布
        dist = Normal(action_mean, action_std)
        
        return dist
    
   
    def critic(self, state):
        """
         价值网络前向传播
    
         参数:
        state: 状态输入张量
        
         返回:
        value: 状态价值估计
        """
        features = self.feature_extractor(state)
    # 将 self.critic(features) 改为 self.critic_network(features) 或使用不同的方式调用
        value = self.critic_network(features)  # 使用不同的名称
        return value
        
    
    def get_action(self, state, action=None):
        """
        根据状态获取动作、对数概率和状态价值
        
        参数:
            state: 状态输入张量
            action: 如果提供，则计算此动作的对数概率
            
        返回:
            action: 采样的动作
            log_prob: 动作的对数概率 
            value: 状态价值估计
        """
        # 确保状态是PyTorch张量
        if not isinstance(state, torch.Tensor):
            state = torch.FloatTensor(state).unsqueeze(0)
        
        # 获取动作分布
        action_dist = self.actor(state)
        
        # 获取状态价值
        value = self.critic(state)
        
        # 如果没有提供动作，则从分布中采样
        if action is None:
            action = action_dist.sample()
        
        # 计算动作的对数概率
        log_prob = action_dist.log_prob(action)
        log_prob = log_prob.sum(dim=-1, keepdim=True)  # 多维动作时求和
        
        return action, log_prob, value
    
    def evaluate(self, state, action):
        """
        评估给定状态-动作对的对数概率和状态价值
        
        参数:
            state: 状态输入张量
            action: 动作输入张量
            
        返回:
            log_prob: 动作的对数概率
            value: 状态价值
            entropy: 策略熵
        """
        # 获取动作分布
        action_dist = self.actor(state)
        
        # 计算动作的对数概率
        log_prob = action_dist.log_prob(action)
        log_prob = log_prob.sum(dim=-1, keepdim=True)  # 多维动作时求和
        
        # 获取熵
        entropy = action_dist.entropy().mean()
        
        # 获取状态价值
        value = self.critic(state)
        
        return log_prob, value, entropy
    
    def update_action_std(self, new_action_std):
        """更新动作标准差"""
        self.action_log_std.data = torch.ones_like(self.action_log_std.data) * np.log(new_action_std)


class SeparateActorCritic:
    """
    分离的Actor-Critic架构 - 维护单独的Actor和Critic网络
    """
    def __init__(self, state_dim, action_dim, action_std_init=0.6, hidden_dims=[256, 256]):
        # Actor网络 - 输出动作
        self.actor = ActorNetwork(state_dim, action_dim, action_std_init, hidden_dims)
        
        # Critic网络 - 输出状态价值
        self.critic = CriticNetwork(state_dim, hidden_dims)
    
    def to(self, device):
        """将网络移至指定设备"""
        self.actor = self.actor.to(device)
        self.critic = self.critic.to(device)
        return self
    
    def get_action(self, state, action=None):
        """根据状态获取动作、对数概率"""
        # 从Actor获取动作和对数概率
        if action is None:
            action, log_prob = self.actor(state)
        else:
            action, log_prob = self.actor.evaluate(state, action)
            
        # 从Critic获取状态价值
        value = self.critic(state)
        
        return action, log_prob, value
    
    def evaluate(self, state, action):
        """评估给定状态-动作对"""
        # 从Actor评估动作
        log_prob, entropy = self.actor.evaluate(state, action)
        
        # 从Critic获取状态价值
        value = self.critic(state)
        
        return log_prob, value, entropy


class ActorNetwork(nn.Module):
    """Actor网络 - 策略函数"""
    def __init__(self, state_dim, action_dim, action_std_init=0.6, hidden_dims=[256, 256]):
        super(ActorNetwork, self).__init__()
        
        # 网络层
        self.network = nn.Sequential(
            nn.Linear(state_dim, hidden_dims[0]),
            nn.Tanh(),
            nn.Linear(hidden_dims[0], hidden_dims[1]),
            nn.Tanh(),
            nn.Linear(hidden_dims[1], action_dim),
            nn.Tanh()  # 输出范围限制在[-1,1]
        )
        
        # 动作标准差(可学习)
        self.action_log_std = nn.Parameter(torch.ones(1, action_dim) * np.log(action_std_init))
        
        # 初始化权重
        self._init_weights()
    
    def _init_weights(self):
        """初始化网络权重"""
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight, gain=np.sqrt(2))
                nn.init.constant_(m.bias, 0.0)
    
    def forward(self, state):
        """
        前向传播 - 获取动作和对数概率
        
        参数:
            state: 状态输入张量
            
        返回:
            action: 采样的动作
            log_prob: 动作的对数概率
        """
        # 确保状态是PyTorch张量
        if not isinstance(state, torch.Tensor):
            state = torch.FloatTensor(state).unsqueeze(0)
        
        # 获取动作均值
        action_mean = self.network(state)
        
        # 动作标准差
        action_std = torch.exp(self.action_log_std)
        
        # 创建正态分布
        dist = Normal(action_mean, action_std)
        
        # 采样动作
        action = dist.sample()
        
        # 计算对数概率
        log_prob = dist.log_prob(action)
        log_prob = log_prob.sum(dim=-1, keepdim=True)  # 多维动作时求和
        
        return action, log_prob
    
    def evaluate(self, state, action):
        """
        评估给定动作的对数概率和熵
        
        参数:
            state: 状态输入张量
            action: 动作输入张量
            
        返回:
            log_prob: 动作的对数概率
            entropy: 策略熵
        """
        # 获取动作均值
        action_mean = self.network(state)
        
        # 动作标准差
        action_std = torch.exp(self.action_log_std)
        
        # 创建正态分布
        dist = Normal(action_mean, action_std)
        
        # 计算对数概率
        log_prob = dist.log_prob(action)
        log_prob = log_prob.sum(dim=-1, keepdim=True)
        
        # 计算熵
        entropy = dist.entropy().mean()
        
        return log_prob, entropy
    
    def update_action_std(self, new_action_std):
        """更新动作标准差"""
        self.action_log_std.data = torch.ones_like(self.action_log_std.data) * np.log(new_action_std)


class CriticNetwork(nn.Module):
    """Critic网络 - 价值函数"""
    def __init__(self, state_dim, hidden_dims=[256, 256]):
        super(CriticNetwork, self).__init__()
        
        # 网络层
        self.network = nn.Sequential(
            nn.Linear(state_dim, hidden_dims[0]),
            nn.Tanh(),
            nn.Linear(hidden_dims[0], hidden_dims[1]),
            nn.Tanh(),
            nn.Linear(hidden_dims[1], 1)
        )
        
        # 初始化权重
        self._init_weights()
    
    def _init_weights(self):
        """初始化网络权重"""
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight, gain=np.sqrt(2))
                nn.init.constant_(m.bias, 0.0)
    
    def forward(self, state):
        """
        前向传播 - 获取状态价值
        
        参数:
            state: 状态输入张量
            
        返回:
            value: 状态价值
        """
        # 确保状态是PyTorch张量
        if not isinstance(state, torch.Tensor):
            state = torch.FloatTensor(state).unsqueeze(0)
        
        value = self.network(state)
        return value
