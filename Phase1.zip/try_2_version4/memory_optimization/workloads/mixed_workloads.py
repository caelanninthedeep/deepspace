"""
混合类工作负载模块
"""

import os
import random
import time
import subprocess

class MixedWorkload:
    # 定义难度等级
    DIFFICULTY_LEVELS = ["easy", "medium", "hard", "extreme"]
    
    def __init__(self):
        self.temp_root = "/tmp/rl_mem_test"
        os.makedirs(self.temp_root, exist_ok=True)
    
    def run_mixed_workload(self, difficulty=None):
        """
        混合型工作负载，结合内存和IO操作
        
        参数:
            difficulty: 难度级别，可选值为 "easy", "medium", "hard", "extreme"
        返回:
            工作负载难度级别、内存大小和IO参数
        """
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 根据难度级别确定参数
        if difficulty == "easy":
            size_mb = random.randint(50, 150)
            num_files = random.randint(2, 4)
            file_size_mb = random.randint(5, 15)
            iterations = 20
            memory_ops = 500
        elif difficulty == "medium":
            size_mb = random.randint(151, 250)
            num_files = random.randint(5, 6)
            file_size_mb = random.randint(16, 30)
            iterations = 40
            memory_ops = 1000
        elif difficulty == "hard":
            size_mb = random.randint(251, 400)
            num_files = random.randint(7, 8)
            file_size_mb = random.randint(31, 40)
            iterations = 60
            memory_ops = 1500
        elif difficulty == "extreme":
            size_mb = random.randint(401, 600)
            num_files = random.randint(9, 12)
            file_size_mb = random.randint(41, 60)
            iterations = 80
            memory_ops = 2000
        
        print(f"[Mixed Workload] Difficulty: {difficulty}, Running mixed memory({size_mb}MB)+IO({num_files}x{file_size_mb}MB) workload...")
        
        # 内存部分
        memory_data = bytearray(size_mb * 1024 * 1024)
        
        # IO部分
        temp_dir = os.path.join(self.temp_root, f"mixed_test_{difficulty}")
        os.makedirs(temp_dir, exist_ok=True)
        
        # 创建文件
        files = []
        for i in range(num_files):
            filename = f"{temp_dir}/test_file_mixed_{i}.dat"
            with open(filename, 'wb') as f:
                f.write(os.urandom(file_size_mb * 1024 * 1024))
            files.append(filename)
        
        # 交替执行内存和IO操作
        for _ in range(iterations):
            # 内存访问
            for _ in range(memory_ops):
                index = random.randint(0, len(memory_data) - 1)
                memory_data[index] = random.randint(0, 255)
            
            # 文件访问
            filename = random.choice(files)
            with open(filename, 'rb') as f:
                f.seek(random.randint(0, file_size_mb * 1024 * 1024 - 1024))
                _ = f.read(1024)
        
        # 清理文件
        for filename in files:
            try:
                os.remove(filename)
            except:
                pass
        
        try:
            os.rmdir(temp_dir)
        except:
            pass
        
        # 释放内存
        del memory_data
        
        return difficulty, size_mb, num_files, file_size_mb
    
    def run_network_memory_workload(self, difficulty=None):
        """
        网络和内存混合负载
        
        参数:
            difficulty: 难度级别，可选值为 "easy", "medium", "hard", "extreme"
        返回:
            工作负载难度级别、内存大小和ping次数
        """
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 根据难度级别确定参数
        if difficulty == "easy":
            size_mb = random.randint(50, 100)
            ping_count = random.randint(5, 8)
            memory_ops = 2000
        elif difficulty == "medium":
            size_mb = random.randint(101, 200)
            ping_count = random.randint(9, 12)
            memory_ops = 4000
        elif difficulty == "hard":
            size_mb = random.randint(201, 300)
            ping_count = random.randint(13, 16)
            memory_ops = 6000
        elif difficulty == "extreme":
            size_mb = random.randint(301, 400)
            ping_count = random.randint(17, 25)
            memory_ops = 8000
        
        print(f"[Mixed] Difficulty: {difficulty}, Network({ping_count} pings) + Memory({size_mb}MB) workload...")
        
        # 内存部分
        memory_data = bytearray(size_mb * 1024 * 1024)
        
        # 网络部分（模拟，实际效果可能不明显）
        try:
            subprocess.run(['ping', '-c', str(ping_count), 'google.com'],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:
            print(f"Network operation error: {e}")
        
        # 访问内存
        for _ in range(memory_ops):
            index = random.randint(0, len(memory_data) - 1)
            memory_data[index] = random.randint(0, 255)
        
        # 释放内存
        del memory_data
        
        return difficulty, size_mb, ping_count
    
    def run_cpu_memory_workload(self, difficulty=None):
        """
        CPU和内存混合负载
        
        参数:
            difficulty: 难度级别，可选值为 "easy", "medium", "hard", "extreme"
        返回:
            工作负载难度级别、内存大小和矩阵计算规模
        """
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 根据难度级别确定参数
        if difficulty == "easy":
            size_mb = random.randint(50, 150)
            matrix_size = 300
            compute_range = 50
            memory_iterations = 500
        elif difficulty == "medium":
            size_mb = random.randint(151, 250)
            matrix_size = 500
            compute_range = 70
            memory_iterations = 1000
        elif difficulty == "hard":
            size_mb = random.randint(251, 350)
            matrix_size = 700
            compute_range = 90
            memory_iterations = 1500
        elif difficulty == "extreme":
            size_mb = random.randint(351, 450)
            matrix_size = 900
            compute_range = 120
            memory_iterations = 2000
        
        print(f"[Mixed] Difficulty: {difficulty}, CPU(matrix {matrix_size}x{matrix_size}) + Memory({size_mb}MB) workload...")
        
        # 内存部分
        memory_data = bytearray(size_mb * 1024 * 1024)
        
        # CPU密集计算
        # 使用较小的矩阵以减少初始化时间，但增加计算次数
        matrix_a = [[random.random() for _ in range(matrix_size)] for _ in range(matrix_size)]
        matrix_b = [[random.random() for _ in range(matrix_size)] for _ in range(matrix_size)]
        
        # 计算部分矩阵乘法
        for i in range(compute_range):
            for j in range(compute_range):
                result = sum(matrix_a[i][k] * matrix_b[k][j] for k in range(matrix_size))
                
                # 同时访问内存
                if i % 10 == 0:
                    for _ in range(memory_iterations):
                        index = random.randint(0, len(memory_data) - 1)
                        memory_data[index] = random.randint(0, 255)
        
        # 释放内存
        del memory_data
        del matrix_a
        del matrix_b
        
        return difficulty, size_mb, matrix_size
