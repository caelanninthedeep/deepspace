"""
I/O相关工作负载模块
"""

import os
import random
import time
import mmap
import subprocess

class IOWorkload:
    # 定义难度等级
    DIFFICULTY_LEVELS = ["easy", "medium", "hard", "extreme"]
    
    def __init__(self):
        self.temp_root = "/tmp/rl_mem_test"
        os.makedirs(self.temp_root, exist_ok=True)
    
    def run_io_intensive(self, difficulty=None):
        """
        I/O密集型工作负载
        
        参数:
            difficulty: 难度级别，可选值为 "easy", "medium", "hard", "extreme"。
                        如果不指定，则随机选择一个难度级别。
        返回:
            工作负载难度级别、文件数量和每个文件的大小
        """
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 根据难度级别确定文件数量和大小
        if difficulty == "easy":
            num_files = random.randint(3, 7)
            file_size_mb = random.randint(5, 20)
            read_operations = 20
        elif difficulty == "medium":
            num_files = random.randint(8, 12)
            file_size_mb = random.randint(30, 50)
            read_operations = 50
        elif difficulty == "hard":
            num_files = random.randint(13, 18)
            file_size_mb = random.randint(60, 80)
            read_operations = 100
        elif difficulty == "extreme":
            num_files = random.randint(19, 25)
            file_size_mb = random.randint(90, 120)
            read_operations = 150
        
        # 创建临时文件夹
        temp_dir = os.path.join(self.temp_root, f"io_test_{difficulty}")
        os.makedirs(temp_dir, exist_ok=True)
        
        print(f"[IO Workload] Difficulty: {difficulty}, Creating {num_files} files of {file_size_mb}MB each...")
        
        # 创建文件
        files = []
        for i in range(num_files):
            filename = f"{temp_dir}/test_file_{i}.dat"
            with open(filename, 'wb') as f:
                f.write(os.urandom(file_size_mb * 1024 * 1024))
            files.append(filename)
        
        # 随机读取文件
        for _ in range(read_operations):
            filename = random.choice(files)
            with open(filename, 'rb') as f:
                # 随机读取位置
                f.seek(random.randint(0, file_size_mb * 1024 * 1024 - 1024))
                _ = f.read(1024)
        
        # 清理文件
        for filename in files:
            try:
                os.remove(filename)
            except:
                pass
        
        try:
            os.rmdir(temp_dir)
        except:
            pass
        
        return difficulty, num_files, file_size_mb
    
    def run_file_cache_intensive(self, difficulty=None):
        """
        文件缓存密集型工作负载
        
        参数:
            difficulty: 难度级别，可选值为 "easy", "medium", "hard", "extreme"
        返回:
            工作负载难度级别和文件数量
        """
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 根据难度级别确定文件数量
        if difficulty == "easy":
            num_files = random.randint(300, 800)
            access_ops = min(500, num_files)
            reaccess_ops = min(200, num_files // 2)
        elif difficulty == "medium":
            num_files = random.randint(801, 1500)
            access_ops = min(1000, num_files)
            reaccess_ops = min(400, num_files // 2)
        elif difficulty == "hard":
            num_files = random.randint(1501, 2500)
            access_ops = min(1500, num_files)
            reaccess_ops = min(600, num_files // 2)
        elif difficulty == "extreme":
            num_files = random.randint(2501, 4000)
            access_ops = min(2000, num_files)
            reaccess_ops = min(1000, num_files // 2)
        
        temp_dir = os.path.join(self.temp_root, f"cache_test_{difficulty}")
        os.makedirs(temp_dir, exist_ok=True)
        
        print(f"[Cache Workload] Difficulty: {difficulty}, Creating and accessing {num_files} small files...")
        
        # 创建文件
        filenames = []
        for i in range(num_files):
            filename = f"{temp_dir}/small_file_{i}.txt"
            with open(filename, 'w') as f:
                f.write(f"test content {i}")
            filenames.append(filename)
        
        # 随机访问文件
        for _ in range(access_ops):
            filename = random.choice(filenames)
            with open(filename, 'r') as f:
                _ = f.read()
        
        # 清理一半的文件
        for filename in random.sample(filenames, num_files // 2):
            try:
                os.remove(filename)
                filenames.remove(filename)
            except:
                pass
        
        # 再次随机访问剩余文件
        for _ in range(reaccess_ops):
            filename = random.choice(filenames)
            with open(filename, 'r') as f:
                _ = f.read()
        
        # 清理所有文件
        for filename in filenames:
            try:
                os.remove(filename)
            except:
                pass
        
        try:
            os.rmdir(temp_dir)
        except:
            pass
            
        file_size_kb=0
        
        return difficulty, num_files,file_size_kb
    
    def mmap_test(self, difficulty=None):
        """
        mmap文件模拟测试
        
        参数:
            difficulty: 难度级别，可选值为 "easy", "medium", "hard", "extreme"
        返回:
            工作负载难度级别和文件大小(MB)
        """
        # 如果未指定难度，随机选择一个
        if difficulty is None:
            difficulty = random.choice(self.DIFFICULTY_LEVELS)
        
        # 根据难度级别确定mmap文件大小和操作次数
        if difficulty == "easy":
            file_size_mb = 10
            operations = 25000
        elif difficulty == "medium":
            file_size_mb = 50
            operations = 75000
        elif difficulty == "hard":
            file_size_mb = 100
            operations = 150000
        elif difficulty == "extreme":
            file_size_mb = 200
            operations = 250000
        
        print(f"[mmap] Difficulty: {difficulty}, Accessing {file_size_mb}MB file via mmap...")
        mmap_file = os.path.join(self.temp_root, f"mmap_test_{difficulty}")
        
        with open(mmap_file, "wb") as f:
            f.write(b'\x00' * file_size_mb * 1024 * 1024)
        
        with open(mmap_file, "r+b") as f:
            mm = mmap.mmap(f.fileno(), 0)
            for _ in range(operations):
                mm[random.randint(0, file_size_mb * 1024 * 1024 - 1)] = b'\x01'[0]
            mm.close()
        
        try:
            os.remove(mmap_file)
        except:
            pass
        
        return difficulty, file_size_mb
    
    def drop_caches(self):
        """清除文件系统缓存"""
        print("[Sys] Dropping filesystem caches...")
        try:
            subprocess.run(['sudo', 'sync'], check=True)
            subprocess.run(['sudo', 'bash', '-c', 'echo 3 > /proc/sys/vm/drop_caches'], 
                           check=True)
            return True
        except subprocess.CalledProcessError as e:
            print(f"Error dropping caches: {e}")
            return False
