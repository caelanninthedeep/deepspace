"""
将优化后的内存参数应用到系统
"""
import os
import sys
import argparse
import subprocess
import json
import logging
from memory_optimization.algorithms.ppo import PPO
from memory_optimization.environment.mem_env import MemoryOptimizationEnv

def setup_logging():
    """设置日志记录"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler("system_integration.log"),
            logging.StreamHandler(sys.stdout)
        ]
    )
    return logging.getLogger("system_integration")

def load_model_parameters(model_path):
    """从训练好的模型中加载优化参数"""
    logger.info(f"加载模型: {model_path}")
    
    # 创建环境
    env = MemoryOptimizationEnv()
    
    # 获取状态和动作维度
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]
    
    # 初始化PPO算法
    agent = PPO(state_dim, action_dim)
    
    # 加载模型
    agent.load(model_path)
    
    # 重置环境
    state = env.reset()
    
    # 获取最佳动作
    action, _, _ = agent.select_action(state)
    
    # 执行动作并获取参数
    _, _, _, info = env.step(action)
    
    # 获取最终参数
    optimized_params = info.get('applied_params', {})
    
    logger.info(f"从模型中提取的优化参数: {optimized_params}")
    return optimized_params

def apply_parameters(params, dry_run=False):
    """
    将参数应用到系统
    
    参数:
        params: 参数字典
        dry_run: 如果为True，只打印命令但不执行
    """
    logger.info(f"{'模拟' if dry_run else ''}应用参数到系统...")
    
    # 需要root权限的参数
    root_required_params = [
        'vm.swappiness',
        'vm.vfs_cache_pressure',
        'vm.dirty_ratio',
        'vm.dirty_background_ratio',
        'kernel.shmmax',
        'vm.min_free_kbytes',
        'vm.overcommit_memory',
        'vm.overcommit_ratio'
    ]
    
    # 检查是否有权限
    is_root = os.geteuid() == 0 if hasattr(os, 'geteuid') else False
    
    if not is_root and not dry_run:
        root_params = [p for p in params if any(p.startswith(r) for r in root_required_params)]
        if root_params:
            logger.warning(f"需要root权限设置以下参数: {root_params}")
            logger.warning("请使用sudo运行此脚本或添加--dry-run参数")
            return False
    
    # 应用每个参数
    success = True
    
    for param_name, value in params.items():
        try:
            # 构建sysctl命令
            if any(param_name.startswith(r) for r in root_required_params):
                cmd = ['sysctl', '-w', f"{param_name}={value}"]
                
                if dry_run:
                    logger.info(f"[DRY RUN] 将执行: {' '.join(cmd)}")
                else:
                    logger.info(f"执行: {' '.join(cmd)}")
                    result = subprocess.run(cmd, capture_output=True, text=True)
                    if result.returncode != 0:
                        logger.error(f"设置 {param_name} 失败: {result.stderr}")
                        success = False
                    else:
                        logger.info(f"成功设置 {param_name} = {value}")
            else:
                # 其他参数可能需要不同的设置方式
                logger.info(f"参数 {param_name} 不是通过sysctl设置的，需要手动处理")
        except Exception as e:
            logger.error(f"设置参数 {param_name} 时出错: {str(e)}")
            success = False
    
    return success

def save_parameters(params, output_file):
    """保存参数到文件"""
    try:
        with open(output_file, 'w') as f:
            json.dump(params, f, indent=2)
        logger.info(f"参数已保存到: {output_file}")
        return True
    except Exception as e:
        logger.error(f"保存参数到文件时出错: {str(e)}")
        return False

def load_parameters_from_file(input_file):
    """从文件加载参数"""
    try:
        with open(input_file, 'r') as f:
            params = json.load(f)
        logger.info(f"从文件加载参数: {input_file}")
        return params
    except Exception as e:
        logger.error(f"从文件加载参数时出错: {str(e)}")
        return None

def create_persist_script(params, output_file):
    """创建持久化脚本"""
    try:
        with open(output_file, 'w') as f:
            f.write("#!/bin/bash\n\n")
            f.write("# 自动生成的内存参数优化脚本\n\n")
            
            for param_name, value in params.items():
                f.write(f"sysctl -w {param_name}={value}\n")
            
            # 添加到/etc/sysctl.conf的说明
            f.write("\n# 要使这些更改永久生效，请将以下行添加到/etc/sysctl.conf:\n\n")
            
            for param_name, value in params.items():
                f.write(f"# {param_name}={value}\n")
        
        # 设置可执行权限
        os.chmod(output_file, 0o755)
        
        logger.info(f"持久化脚本已保存到: {output_file}")
        return True
    except Exception as e:
        logger.error(f"创建持久化脚本时出错: {str(e)}")
        return False

if __name__ == "__main__":
    # 设置日志
    logger = setup_logging()
    
    # 解析命令行参数
    parser = argparse.ArgumentParser(description="将优化后的内存参数应用到系统")
    parser.add_argument("--model", type=str, help="训练好的模型路径")
    parser.add_argument("--params-file", type=str, help="参数JSON文件路径")
    parser.add_argument("--save", type=str, help="保存参数到JSON文件")
    parser.add_argument("--script", type=str, help="生成持久化脚本")
    parser.add_argument("--dry-run", action="store_true", help="只打印命令但不执行")
    
    args = parser.parse_args()
    
    # 获取参数
    params = None
    
    if args.model:
        # 从模型加载参数
        params = load_model_parameters(args.model)
    elif args.params_file:
        # 从文件加载参数
        params = load_parameters_from_file(args.params_file)
    else:
        logger.error("必须提供--model或--params-file参数")
        sys.exit(1)
    
    if not params:
        logger.error("无法获取参数")
        sys.exit(1)
    
    # 保存参数到文件
    if args.save:
        save_parameters(params, args.save)
    
    # 创建持久化脚本
    if args.script:
        create_persist_script(params, args.script)
    
    # 应用参数
    if apply_parameters(params, args.dry_run):
        logger.info("所有参数设置成功")
    else:
        logger.warning("部分参数设置失败")
