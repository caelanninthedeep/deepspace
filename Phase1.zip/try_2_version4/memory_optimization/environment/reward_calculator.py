import numpy as np
from collections import deque

class RewardCalculator:
    def __init__(self, history_length=10):
        # 基础权重配置
        self.weights = {
            'major_page_faults': -5.0,
            'minor_page_faults': -0.01,
            'memory_usage': 1.0,
            'swap_usage': -2.0,
            'swap_io': -3.0,
            'runtime': -10.0,
        }
        
        # 保存状态历史，用于计算趋势
        self.state_history = deque(maxlen=history_length)
        
        # 工作负载适应性权重
        self.workload_weights = {
            'memory_intensive': {
                'major_page_faults': -6.0,
                'memory_usage': 1.5,
                'swap_usage': -3.0,
                'runtime': -8.0
            },
            'io_intensive': {
                'major_page_faults': -4.0,
                'swap_io': -5.0,
                'runtime': -12.0
            },
            'mixed': {}  # 使用默认权重
        }
        
        # 难度特定的权重调整
        self.difficulty_weights = {
            "easy": {
                'runtime': -15.0,  # 简单任务更注重速度
                'memory_usage': 1.5  # 简单任务更注重内存效率
            },
            "medium": {},  # 使用默认权重
            "hard": {
                'major_page_faults': -7.0,  # 困难任务更严格惩罚页面错误
                'swap_io': -4.0  # 困难任务更严格惩罚swap I/O
            },
            "extreme": {
                'major_page_faults': -8.0,  # 极端任务最严格惩罚页面错误
                'swap_io': -5.0,  # 极端任务最严格惩罚swap I/O
                'swap_usage': -3.0  # 极端任务更严格限制swap使用
            }
        }
        
        # 难度乘数
        self.difficulty_multiplier = {
            "easy": 1.0,
            "medium": 1.5,
            "hard": 2.25,
            "extreme": 3.0
        }
        
        # 根据难度调整最佳内存利用率目标
        self.optimal_memory_usage = {
            "easy": 60,    # 简单任务，预留更多内存
            "medium": 70,  # 中等任务，标准内存利用率
            "hard": 80,    # 困难任务，允许更高内存利用
            "extreme": 85  # 极端任务，允许非常高的内存利用
        }
        
        # 正规化常数，用于统一不同指标的量级
        self.normalization_constants = {
            'major_page_faults': 100,  # 假设100是一个显著的fault数量
            'minor_page_faults': 10000,
            'free_memory_percent': 100,  # 百分比
            'swap_used_percent': 100,  # 百分比
            'swap_io': 100,  # 假设每秒100次I/O是高负载
            'load_ratio': 4.0,  # 假设负载达到CPU核心数的4倍是极端情况
            'runtime_improvement': 50  # 百分比改进
        }
        
        # 记录基准性能作为参考
        self.baseline_performance = None

    def update_weights_for_workload(self, workload_type):
        """根据工作负载类型调整权重"""
        if workload_type in self.workload_weights:
            # 只更新特定工作负载定义的权重，其他保持默认
            for key, value in self.workload_weights[workload_type].items():
                self.weights[key] = value

    def update_weights_for_difficulty(self, difficulty):
        """根据难度级别调整权重"""
        if difficulty in self.difficulty_weights:
            # 应用难度特定的权重调整
            for key, value in self.difficulty_weights[difficulty].items():
                self.weights[key] = value

    def set_baseline_performance(self, state):
        """设置基准性能作为参考点"""
        self.baseline_performance = state.copy()

    def sigmoid(self, x, center=0, steepness=1):
        """S形函数，将输入平滑映射到0-1区间"""
        return 1 / (1 + np.exp(-steepness * (x - center)))

    def calculate_trend_bonus(self, current_value, metric_key):
        """计算指标趋势的奖励加成"""
        if len(self.state_history) < 2:
            return 0
        
        # 提取历史值
        historical_values = [
            state.get(metric_key, current_value) 
            for state in self.state_history if metric_key in state
        ]
        
        if not historical_values:
            return 0
        
        # 计算最近3个值的平均变化率
        recent_history = historical_values[-3:]
        if len(recent_history) < 2:
            return 0
            
        # 计算趋势方向和强度
        changes = [recent_history[i] - recent_history[i-1] for i in range(1, len(recent_history))]
        avg_change = np.mean(changes)
        
        # 根据指标类型判断趋势是好是坏
        is_negative_better = metric_key in [
            'major_page_faults_per_sec', 'minor_page_faults_per_sec', 
            'swap_used_MB', 'swap_in_per_sec', 'swap_out_per_sec',
            'system_loadavg_1min'
        ]
        
        # 如果下降趋势对于该指标是好的，则奖励为正
        if (is_negative_better and avg_change < 0) or (not is_negative_better and avg_change > 0):
            return min(10, abs(avg_change) * 2)  # 最多+10的奖励
        else:
            return max(-10, -abs(avg_change) * 2)  # 最多-10的惩罚

    def calculate_memory_efficiency_reward(self, state, difficulty=None):
        """计算内存利用率奖励，可根据难度调整"""
        free_mem = state.get('free_memory_MB', 0)
        total_mem = state.get('memory_total_MB', 1)
        free_mem_percent = (free_mem / total_mem) * 100 if total_mem > 0 else 0
        mem_usage_percent = 100 - free_mem_percent
        
        # 选择目标内存利用率
        if difficulty and difficulty in self.optimal_memory_usage:
            target_usage = self.optimal_memory_usage[difficulty]
        else:
            target_usage = 70  # 默认目标
        
        # 使用钟形曲线，以目标利用率为中心
        return 20 * np.exp(-0.5 * ((mem_usage_percent - target_usage) / 20)**2)

    def calculate_reward(self, state, previous_runtime=None, current_runtime=None, workload_type=None, difficulty=None):
        """
        根据内存子系统性能指标计算奖励，现在整合了难度考量
        
        Args:
            state: 当前系统状态
            previous_runtime: 上一次工作负载运行时间
            current_runtime: 当前工作负载运行时间
            workload_type: 工作负载类型，可以是'memory_intensive', 'io_intensive', 或 'mixed'
            difficulty: 工作负载难度，可以是'easy', 'medium', 'hard', 或 'extreme'
            
        Returns:
            float: 计算得到的奖励值
        """
        # 根据工作负载类型调整权重
        if workload_type:
            self.update_weights_for_workload(workload_type)
        
        # 根据难度级别进一步调整权重
        if difficulty:
            self.update_weights_for_difficulty(difficulty)
        
        reward = 0
        
        # --- 优化目标1：减少页面错误 - 使用连续函数 ---
        # 主页面错误 (使用负指数衰减函数)
        major_faults = state.get('major_page_faults_per_sec', 0)
        major_faults_norm = major_faults / self.normalization_constants['major_page_faults']
        major_faults_reward = 50 * np.exp(-4 * major_faults_norm) - 10 * major_faults_norm
        
        # 对高难度任务适当减轻页面错误惩罚
        if difficulty in ['hard', 'extreme'] and major_faults > 0 and major_faults < 50:
            major_faults_reward += 15
            
        reward += major_faults_reward
        
        # 次要页面错误 (权重较低，使用对数衰减)
        minor_faults = state.get('minor_page_faults_per_sec', 0)
        minor_faults_norm = minor_faults / self.normalization_constants['minor_page_faults']
        minor_faults_reward = 10 * (1 - np.log1p(minor_faults_norm * 10) / np.log(11))
        reward += minor_faults_reward
        
        # --- 内存使用情况 - 连续曲线 ---
        free_mem = state.get('free_memory_MB', 0)
        total_mem = state.get('memory_total_MB', 1)
        free_mem_percent = (free_mem / total_mem) * 100 if total_mem > 0 else 0
        
        # 使用S形函数：低于5%时急剧下降，5-15%平缓增长，15%以上平稳
        memory_reward = 30 * self.sigmoid(free_mem_percent - 10, center=0, steepness=0.2) - 10
        reward += memory_reward
        
        # 内存利用率奖励，根据难度调整目标值
        memory_efficiency = self.calculate_memory_efficiency_reward(state, difficulty)
        reward += memory_efficiency
        
        # --- Swap使用情况 - 连续惩罚函数 ---
        swap_used = state.get('swap_used_MB', 0)
        total_swap = state.get('swap_total_MB', 1)
        swap_used_percent = (swap_used / total_swap) * 100 if total_swap > 0 else 0
        
        # 使用sigmoid函数让惩罚随swap使用增加而逐渐增大
        # 对极端难度任务，允许更多swap使用（移动惩罚阈值）
        swap_threshold = 20
        if difficulty == 'hard':
            swap_threshold = 30
        elif difficulty == 'extreme':
            swap_threshold = 40
            
        swap_penalty = -50 * self.sigmoid(swap_used_percent - swap_threshold, steepness=0.1)
        reward += swap_penalty
        
        # Swap I/O - 对数惩罚
        swap_in = state.get('swap_in_per_sec', 0)
        swap_out = state.get('swap_out_per_sec', 0)
        swap_io = swap_in + swap_out
        swap_io_norm = swap_io / self.normalization_constants['swap_io']
        
        if swap_io == 0:
            swap_io_reward = 40  # 无swap I/O
        else:
            swap_io_reward = -30 * np.log1p(swap_io_norm * 10) / np.log(11)
        reward += swap_io_reward
        
        # --- 系统负载 - 连续评估 ---
        load = state.get('system_loadavg_1min', 0)
        cpu_count = state.get('cpu_count', 1)
        load_ratio = load / cpu_count if cpu_count > 0 else load
        load_ratio_norm = load_ratio / self.normalization_constants['load_ratio']
        
        # 对于高难度任务，提高可接受的负载阈值
        load_threshold = 1.0  # 默认阈值
        if difficulty == 'hard':
            load_threshold = 1.5
        elif difficulty == 'extreme':
            load_threshold = 2.0
        
        # 使用S形曲线，低负载时正奖励，高负载时惩罚
        load_reward = 30 * (1 - self.sigmoid(load_ratio - load_threshold, steepness=2))
        reward += load_reward
        
        # --- 运行时间改进 - 连续比例奖励 ---
        if previous_runtime is not None and current_runtime is not None and previous_runtime > 0:
            # 计算改进百分比
            runtime_change_percent = ((previous_runtime - current_runtime) / previous_runtime) * 100
            
            # 使用arctangent函数提供平滑但有界的奖励
            runtime_reward = 80 * np.arctan(runtime_change_percent / 15) / (np.pi/2)
            reward += runtime_reward
        
        # --- 考虑指标的历史趋势 ---
        trend_metrics = [
            'major_page_faults_per_sec', 
            'free_memory_MB', 
            'swap_used_MB',
            'swap_in_per_sec', 
            'swap_out_per_sec'
        ]
        
        for metric in trend_metrics:
            if metric in state:
                trend_bonus = self.calculate_trend_bonus(state[metric], metric)
                reward += trend_bonus
        
        # 保存当前状态到历史记录
        self.state_history.append(state.copy())
        
        # 应用难度乘数调整最终奖励
        if difficulty and difficulty in self.difficulty_multiplier:
            reward *= self.difficulty_multiplier[difficulty]
        
        return reward
        
    def get_diagnostic_info(self, state, previous_runtime=None, current_runtime=None, workload_type=None, difficulty=None):
        """
        返回详细的奖励计算诊断信息，用于调试和可视化，包括难度调整因素
        """
        diagnostics = {
            "raw_rewards": {},
            "trend_rewards": {},
            "difficulty_adjustments": {}
        }
        
        # 保存当前权重
        original_weights = self.weights.copy()
        
        # 如果指定了工作负载类型，应用相应权重
        if workload_type:
            self.update_weights_for_workload(workload_type)
        
        # 如果指定了难度，应用相应权重
        if difficulty:
            self.update_weights_for_difficulty(difficulty)
            diagnostics["difficulty_adjustments"]["weight_changes"] = {
                k: self.weights[k] - original_weights[k]
                for k in self.weights if self.weights[k] != original_weights[k]
            }
        
        # 计算各部分的原始奖励（不含难度乘数）
        
        # 页面错误奖励
        major_faults = state.get('major_page_faults_per_sec', 0)
        major_faults_norm = major_faults / self.normalization_constants['major_page_faults']
        major_faults_reward = 50 * np.exp(-4 * major_faults_norm) - 10 * major_faults_norm
        
        # 高难度任务的页面错误宽容度调整
        major_faults_difficulty_bonus = 0
        if difficulty in ['hard', 'extreme'] and major_faults > 0 and major_faults < 50:
            major_faults_difficulty_bonus = 15
            
        diagnostics["raw_rewards"]["major_faults_reward"] = major_faults_reward
        diagnostics["difficulty_adjustments"]["major_faults_bonus"] = major_faults_difficulty_bonus
        
        # 次要页面错误
        minor_faults = state.get('minor_page_faults_per_sec', 0)
        minor_faults_norm = minor_faults / self.normalization_constants['minor_page_faults']
        diagnostics["raw_rewards"]["minor_faults_reward"] = 10 * (1 - np.log1p(minor_faults_norm * 10) / np.log(11))
        
        # 内存使用
        free_mem = state.get('free_memory_MB', 0)
        total_mem = state.get('memory_total_MB', 1)
        free_mem_percent = (free_mem / total_mem) * 100 if total_mem > 0 else 0
        diagnostics["raw_rewards"]["memory_reward"] = 30 * self.sigmoid(free_mem_percent - 10, center=0, steepness=0.2) - 10
        
        # 内存利用率 - 难度调整
        diagnostics["raw_rewards"]["memory_efficiency"] = self.calculate_memory_efficiency_reward(state, difficulty)
        if difficulty:
            diagnostics["difficulty_adjustments"]["memory_target"] = self.optimal_memory_usage.get(difficulty, 70)
        
        # Swap使用
        swap_used = state.get('swap_used_MB', 0)
        total_swap = state.get('swap_total_MB', 1)
        swap_used_percent = (swap_used / total_swap) * 100 if total_swap > 0 else 0
        
        swap_threshold = 20
        if difficulty == 'hard':
            swap_threshold = 30
        elif difficulty == 'extreme':
            swap_threshold = 40
            
        diagnostics["raw_rewards"]["swap_penalty"] = -50 * self.sigmoid(swap_used_percent - swap_threshold, steepness=0.1)
        diagnostics["difficulty_adjustments"]["swap_threshold"] = swap_threshold
        
        # Swap I/O
        swap_in = state.get('swap_in_per_sec', 0)
        swap_out = state.get('swap_out_per_sec', 0)
        swap_io = swap_in + swap_out
        swap_io_norm = swap_io / self.normalization_constants['swap_io']
        
        if swap_io == 0:
            diagnostics["raw_rewards"]["swap_io_reward"] = 40
        else:
            diagnostics["raw_rewards"]["swap_io_reward"] = -30 * np.log1p(swap_io_norm * 10) / np.log(11)
        
        # 系统负载
        load = state.get('system_loadavg_1min', 0)
        cpu_count = state.get('cpu_count', 1)
        load_ratio = load / cpu_count if cpu_count > 0 else load
        
        load_threshold = 1.0
        if difficulty == 'hard':
            load_threshold = 1.5
        elif difficulty == 'extreme':
            load_threshold = 2.0
            
        diagnostics["raw_rewards"]["load_reward"] = 30 * (1 - self.sigmoid(load_ratio - load_threshold, steepness=2))
        diagnostics["difficulty_adjustments"]["load_threshold"] = load_threshold
        
        # 运行时间
        if previous_runtime is not None and current_runtime is not None and previous_runtime > 0:
            runtime_change_percent = ((previous_runtime - current_runtime) / previous_runtime) * 100
            diagnostics["raw_rewards"]["runtime_reward"] = 80 * np.arctan(runtime_change_percent / 15) / (np.pi/2)
            diagnostics["runtime_change_percent"] = runtime_change_percent
        else:
            diagnostics["raw_rewards"]["runtime_reward"] = 0
            
        # 趋势奖励
        trend_metrics = [
            'major_page_faults_per_sec', 
            'free_memory_MB', 
            'swap_used_MB',
            'swap_in_per_sec', 
            'swap_out_per_sec'
        ]
        
        for metric in trend_metrics:
            if metric in state:
                diagnostics["trend_rewards"][metric] = self.calculate_trend_bonus(state[metric], metric)
        
        # 计算总奖励（未应用难度乘数）
        base_reward = sum([v for v in diagnostics["raw_rewards"].values()])
        base_reward += major_faults_difficulty_bonus
        base_reward += sum(diagnostics["trend_rewards"].values())
        
        # 应用难度乘数
        difficulty_multiplier = self.difficulty_multiplier.get(difficulty, 1.0)
        final_reward = base_reward * difficulty_multiplier
        
        diagnostics["base_reward"] = base_reward
        diagnostics["difficulty_multiplier"] = difficulty_multiplier
        diagnostics["final_reward"] = final_reward
        
        # 恢复原始权重
        self.weights = original_weights
        
        return diagnostics
