"""
收集系统状态的模块 - 优化版
增强了状态表示，支持归一化和分类特征抽取
"""
import os
import time
import psutil
import numpy as np
import logging
from collections import deque

class StateCollector:
    def __init__(self, history_length=5, normalize=True):
        """
        初始化状态收集器
        
        Args:
            history_length: 保存历史状态的数量，用于计算趋势
            normalize: 是否归一化状态值
        """
        # 设置日志
        logging.basicConfig(level=logging.INFO, 
                           format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger('StateCollector')
        
        # 状态历史，用于计算趋势
        self.state_history = deque(maxlen=history_length)
        self.normalize = normalize
        
        # 归一化范围配置
        self.normalization_ranges = {
            'major_page_faults_per_sec': (0, 1000),
            'minor_page_faults_per_sec': (0, 50000),
            'memory_total_MB': (1024, 128 * 1024),  # 1GB - 128GB
            'free_memory_MB': (0, 64 * 1024),       # 0 - 64GB
            'memory_usage_percent': (0, 100),
            'swap_total_MB': (0, 64 * 1024),        # 0 - 64GB
            'swap_used_MB': (0, 32 * 1024),         # 0 - 32GB
            'swap_percent': (0, 100),
            'swap_in_per_sec': (0, 1000),
            'swap_out_per_sec': (0, 1000),
            'slab_memory_MB': (0, 8 * 1024),        # 0 - 8GB
            'cached_memory_MB': (0, 32 * 1024),     # 0 - 32GB
            'buffers_memory_MB': (0, 4 * 1024),     # 0 - 4GB
            'active_memory_MB': (0, 64 * 1024),     # 0 - 64GB
            'inactive_memory_MB': (0, 64 * 1024),   # 0 - 64GB
            'system_loadavg_1min': (0, 32),         # 0 - 32 (32核系统)
            'system_loadavg_5min': (0, 32),
            'cpu_usage_percent': (0, 100),
            'cpu_iowait_percent': (0, 100),
            'current_swappiness': (0, 100),
            'current_cache_pressure': (0, 500),
            'current_dirty_ratio': (1, 60),
            'current_dirty_bg_ratio': (1, 50),
            'current_min_free_kbytes': (1024, 1048576),  # 1MB - 1GB
            'current_watermark_scale_factor': (10, 1000)
        }
        
        # 缓存CPU核心数，避免重复查询
        self.cpu_count = psutil.cpu_count()
        
        # 初次调用，填充历史数据
        self._initialize_history()
        
    def _initialize_history(self):
        """初始化历史数据"""
        # 获取初始状态并填充历史队列
        initial_state = self._collect_all_metrics()
        for _ in range(self.state_history.maxlen):
            self.state_history.append(initial_state.copy())
    
    def get_state(self):
        """
        获取当前系统状态，融合所有优化目标的指标
        
        Returns:
            dict: 包含系统各项指标的字典
        """
        # 收集基础指标
        state = self._collect_all_metrics()
        
        # 添加趋势指标
        self._add_trend_metrics(state)
        
        # 添加派生指标
        self._add_derived_metrics(state)
        
        # 保存到历史记录
        self.state_history.append(state.copy())
        
        return state
    
    def _collect_all_metrics(self):
        """收集所有基本指标"""
        state = {}
        
        # 收集各类指标
        self._collect_page_fault_metrics(state)
        self._collect_memory_metrics(state)
        self._collect_swap_metrics(state)
        self._collect_cache_metrics(state)
        self._collect_system_load(state)
        self._collect_current_parameters(state)
        
        # 收集CPU信息
        state['cpu_count'] = self.cpu_count
        
        return state
    
    def _add_trend_metrics(self, state):
        """添加趋势指标"""
        if len(self.state_history) < 2:
            return
            
        # 计算主要指标的变化率
        trend_metrics = [
            'major_page_faults_per_sec',
            'free_memory_MB',
            'swap_used_MB',
            'swap_in_per_sec',
            'swap_out_per_sec',
            'system_loadavg_1min'
        ]
        
        for metric in trend_metrics:
            if metric in state and metric in self.state_history[-1]:
                # 计算变化率 (当前值 - 历史平均值)/历史平均值
                history_values = [h.get(metric, state[metric]) for h in self.state_history]
                history_avg = sum(history_values) / len(history_values)
                
                if history_avg != 0:  # 避免除以零
                    change_rate = (state[metric] - history_avg) / (abs(history_avg) + 1e-6)
                    state[f'{metric}_trend'] = change_rate
                else:
                    state[f'{metric}_trend'] = 0.0
    
    def _add_derived_metrics(self, state):
        """添加派生的复合指标"""
        # 内存压力指标 (结合使用率和swap活动)
        if all(k in state for k in ['memory_usage_percent', 'swap_in_per_sec', 'swap_out_per_sec']):
            memory_pressure = (
                state['memory_usage_percent'] / 100.0 + 
                min(1.0, (state['swap_in_per_sec'] + state['swap_out_per_sec']) / 100.0)
            ) / 2.0
            state['memory_pressure'] = memory_pressure
        
        # 计算内存碎片化指标
        if all(k in state for k in ['free_memory_MB', 'memory_total_MB', 'cached_memory_MB']):
            # 活跃内存比例
            active_ratio = state.get('active_memory_MB', 0) / state['memory_total_MB'] if state['memory_total_MB'] > 0 else 0
            # 非活跃内存比例
            inactive_ratio = state.get('inactive_memory_MB', 0) / state['memory_total_MB'] if state['memory_total_MB'] > 0 else 0
            # 计算碎片化指标 (根据活跃/非活跃内存比例估算)
            fragmentation = 1.0 - (active_ratio / (active_ratio + inactive_ratio + 0.01)) if (active_ratio + inactive_ratio) > 0 else 0
            state['memory_fragmentation'] = fragmentation
        
        # IO等待与系统负载关系指标
        if all(k in state for k in ['cpu_iowait_percent', 'system_loadavg_1min', 'cpu_count']):
            io_load_correlation = (
                state['cpu_iowait_percent'] / 100.0 * 
                min(3.0, state['system_loadavg_1min'] / state['cpu_count'])
            )
            state['io_pressure'] = io_load_correlation
    
    def get_state_dimension(self):
        """
        返回状态向量的维度
        
        Returns:
            int: 状态向量的维度
        """
        # 获取一个样本状态并返回维度
        sample_state = self.get_state()
        
        # 如果需要一维化并归一化，则返回扁平化后的维度
        return len(sample_state)
        
    def get_state_as_array(self, flatten=True, include_raw=False):
        """
        将状态转换为numpy数组格式
        
        Args:
            flatten: 是否将状态扁平化为一维数组
            include_raw: 是否包含原始未归一化的值
            
        Returns:
            np.array: 状态数组
        """
        state_dict = self.get_state()
        
        # 保持一致的特征顺序
        keys = sorted(state_dict.keys())
        
        if self.normalize:
            # 获取归一化的值
            norm_values = []
            for k in keys:
                if k in self.normalization_ranges:
                    min_val, max_val = self.normalization_ranges[k]
                    # 将值归一化到[-1, 1]范围
                    norm_value = 2 * (state_dict[k] - min_val) / (max_val - min_val) - 1
                    # 限制在[-1, 1]范围内
                    norm_value = max(-1, min(norm_value, 1))
                    norm_values.append(norm_value)
                else:
                    # 对于未定义范围的指标，简单地除以一个大数
                    norm_value = state_dict[k] / 1000.0
                    norm_values.append(norm_value)
            
            if include_raw:
                # 如果需要原始值，连接归一化值和原始值
                raw_values = [state_dict[k] for k in keys]
                all_values = np.concatenate([np.array(norm_values), np.array(raw_values)])
                return all_values
            else:
                return np.array(norm_values, dtype=np.float32)
        else:
            # 不归一化，直接返回原始值
            values = [state_dict[k] for k in keys]
            return np.array(values, dtype=np.float32)
    
    def get_state_vector_for_ppo(self):
        """
        获取专为PPO优化的状态向量
        
        Returns:
            np.array: 优化后的状态向量
        """
        # 获取当前状态
        state = self.get_state()
        
        # 选择关键指标，忽略冗余信息
        key_metrics = [
            'major_page_faults_per_sec',
            'minor_page_faults_per_sec',
            'memory_usage_percent',
            'swap_percent',
            'swap_in_per_sec',
            'swap_out_per_sec',
            'cached_memory_MB',
            'system_loadavg_1min',
            'cpu_usage_percent',
            'cpu_iowait_percent',
            # 当前参数
            'current_swappiness',
            'current_cache_pressure',
            'current_dirty_ratio',
            'current_dirty_bg_ratio',
            # 趋势指标
            'major_page_faults_per_sec_trend',
            'free_memory_MB_trend',
            'swap_used_MB_trend',
            'system_loadavg_1min_trend',
            # 派生指标
            'memory_pressure',
            'memory_fragmentation',
            'io_pressure'
        ]
        
        # 提取关键指标并归一化
        vector = []
        for metric in key_metrics:
            if metric in state:
                # 归一化
                if self.normalize and metric in self.normalization_ranges:
                    min_val, max_val = self.normalization_ranges[metric]
                    norm_value = 2 * (state[metric] - min_val) / (max_val - min_val) - 1
                    norm_value = max(-1, min(norm_value, 1))
                    vector.append(norm_value)
                else:
                    # 对于趋势指标，已经是比率形式，限制在[-1,1]范围
                    if 'trend' in metric:
                        value = max(-1, min(state.get(metric, 0), 1))
                    else:
                        value = state.get(metric, 0) / 1000.0  # 简单缩放
                    vector.append(value)
            else:
                vector.append(0.0)  # 缺失特征填0
        
        return np.array(vector, dtype=np.float32)

    def _collect_page_fault_metrics(self, state):
        """收集页面错误指标"""
        try:
            # 使用两次采样计算每秒错误率
            with open('/proc/vmstat', 'r') as f:
                vmstat1 = {}
                for line in f:
                    parts = line.split()
                    if len(parts) == 2 and ('pgfault' in parts[0] or 'pgmajfault' in parts[0]):
                        vmstat1[parts[0]] = int(parts[1])
            
            time.sleep(0.5)  # 等待0.5秒，减少采样延迟
            
            with open('/proc/vmstat', 'r') as f:
                vmstat2 = {}
                for line in f:
                    parts = line.split()
                    if len(parts) == 2 and ('pgfault' in parts[0] or 'pgmajfault' in parts[0]):
                        vmstat2[parts[0]] = int(parts[1])
            
            # 计算每秒错误率 (乘2因为采样时间为0.5秒)
            major_faults = (vmstat2.get('pgmajfault', 0) - vmstat1.get('pgmajfault', 0)) * 2
            state['major_page_faults_per_sec'] = major_faults
            
            total_faults = (vmstat2.get('pgfault', 0) - vmstat1.get('pgfault', 0)) * 2
            state['minor_page_faults_per_sec'] = total_faults - major_faults
        except Exception as e:
            self.logger.error(f"Error collecting page fault data: {e}")
            state['major_page_faults_per_sec'] = 0
            state['minor_page_faults_per_sec'] = 0
    
    def _collect_memory_metrics(self, state):
        """收集内存使用指标"""
        try:
            vm = psutil.virtual_memory()
            state['memory_total_MB'] = vm.total / (1024 * 1024)
            state['free_memory_MB'] = vm.available / (1024 * 1024)
            state['memory_usage_percent'] = vm.percent
            
            # 添加每个进程组的内存使用量
            process_memory = {}
            try:
                for proc in psutil.process_iter(['pid', 'name', 'username', 'memory_info']):
                    try:
                        process = proc.info
                        if 'memory_info' in process and process['memory_info']:
                            mem_mb = process['memory_info'].rss / (1024 * 1024)
                            if mem_mb > 50:  # 只关注内存使用超过50MB的进程
                                process_memory[process['name']] = process_memory.get(process['name'], 0) + mem_mb
                    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                        pass
                
                # 找出前5个内存使用最高的进程组
                top_processes = sorted(process_memory.items(), key=lambda x: x[1], reverse=True)[:5]
                for i, (name, mem) in enumerate(top_processes):
                    state[f'top_process_{i+1}_memory_MB'] = mem
                    state[f'top_process_{i+1}_name'] = name
                    
            except Exception as e:
                self.logger.warning(f"Error collecting process memory data: {e}")
        
        except Exception as e:
            self.logger.error(f"Error collecting memory metrics: {e}")
    
    def _collect_swap_metrics(self, state):
        """收集swap使用指标"""
        try:
            swap = psutil.swap_memory()
            state['swap_total_MB'] = swap.total / (1024 * 1024)
            state['swap_used_MB'] = swap.used / (1024 * 1024)
            state['swap_percent'] = swap.percent
            
            # 获取swap换入/换出速率
            with open('/proc/vmstat', 'r') as f:
                vmstat1 = {}
                for line in f:
                    parts = line.split()
                    if len(parts) == 2 and ('pswpin' in parts[0] or 'pswpout' in parts[0]):
                        vmstat1[parts[0]] = int(parts[1])
            
            time.sleep(0.5)  # 与前面的等待合并，总等待时间为0.5秒
            
            with open('/proc/vmstat', 'r') as f:
                vmstat2 = {}
                for line in f:
                    parts = line.split()
                    if len(parts) == 2 and ('pswpin' in parts[0] or 'pswpout' in parts[0]):
                        vmstat2[parts[0]] = int(parts[1])
            
            # 乘2因为采样时间为0.5秒
            state['swap_in_per_sec'] = (vmstat2.get('pswpin', 0) - vmstat1.get('pswpin', 0)) * 2
            state['swap_out_per_sec'] = (vmstat2.get('pswpout', 0) - vmstat1.get('pswpout', 0)) * 2
            
            # 计算swap效率 (换入/换出比率)
            total_swap_io = state['swap_in_per_sec'] + state['swap_out_per_sec']
            if total_swap_io > 0:
                state['swap_efficiency'] = state['swap_in_per_sec'] / total_swap_io
            else:
                state['swap_efficiency'] = 1.0  # 无swap活动视为高效
                
        except Exception as e:
            self.logger.error(f"Error collecting swap metrics: {e}")
            state['swap_in_per_sec'] = 0
            state['swap_out_per_sec'] = 0
    
    def _collect_cache_metrics(self, state):
        """收集缓存和slab指标"""
        try:
            with open('/proc/meminfo', 'r') as f:
                meminfo = {}
                for line in f:
                    if ':' in line:
                        parts = line.split(':')
                        if len(parts) == 2:
                            key = parts[0].strip()
                            value_parts = parts[1].strip().split()
                            if len(value_parts) >= 1:
                                value = float(value_parts[0])
                                if len(value_parts) > 1 and value_parts[1] == 'kB':
                                    value = value / 1024  # 转换为MB
                                meminfo[key] = value
            
            state['slab_memory_MB'] = meminfo.get('Slab', 0)
            state['cached_memory_MB'] = meminfo.get('Cached', 0)
            state['buffers_memory_MB'] = meminfo.get('Buffers', 0)
            state['active_memory_MB'] = meminfo.get('Active', 0)
            state['inactive_memory_MB'] = meminfo.get('Inactive', 0)
            
            # 添加额外的内存指标
            state['active_anon_MB'] = meminfo.get('Active(anon)', 0)
            state['inactive_anon_MB'] = meminfo.get('Inactive(anon)', 0)
            state['active_file_MB'] = meminfo.get('Active(file)', 0)
            state['inactive_file_MB'] = meminfo.get('Inactive(file)', 0)
            
            # 计算缓存使用效率指标
            if 'Cached' in meminfo and 'Buffers' in meminfo and 'MemTotal' in meminfo:
                cache_ratio = (meminfo['Cached'] + meminfo['Buffers']) / meminfo['MemTotal']
                state['cache_ratio'] = cache_ratio
            
        except Exception as e:
            self.logger.error(f"Error collecting cache metrics: {e}")
    
    def _collect_system_load(self, state):
        """收集系统负载信息"""
        try:
            load1, load5, load15 = os.getloadavg()
            state['system_loadavg_1min'] = load1
            state['system_loadavg_5min'] = load5
            state['system_loadavg_15min'] = load15
            
            # 负载相对于CPU核心数的比率
            state['relative_load'] = load1 / self.cpu_count if self.cpu_count else load1
            
            state['cpu_usage_percent'] = psutil.cpu_percent(interval=0.1)
            
            cpu_times_percent = psutil.cpu_times_percent(interval=0.1)
            state['cpu_user_percent'] = cpu_times_percent.user
            state['cpu_system_percent'] = cpu_times_percent.system
            state['cpu_idle_percent'] = cpu_times_percent.idle
            state['cpu_iowait_percent'] = getattr(cpu_times_percent, 'iowait', 0)
            
            # IO统计
            try:
                disk_io = psutil.disk_io_counters()
                state['disk_read_MB'] = disk_io.read_bytes / (1024 * 1024)
                state['disk_write_MB'] = disk_io.write_bytes / (1024 * 1024)
            except:
                pass
            
        except Exception as e:
            self.logger.error(f"Error collecting system load: {e}")
    
    def _collect_current_parameters(self, state):
        """收集当前内存参数设置"""
        try:
            # 扩展支持的参数列表
            param_paths = {
                'current_swappiness': '/proc/sys/vm/swappiness',
                'current_cache_pressure': '/proc/sys/vm/vfs_cache_pressure',
                'current_dirty_ratio': '/proc/sys/vm/dirty_ratio',
                'current_dirty_bg_ratio': '/proc/sys/vm/dirty_background_ratio',
                'current_min_free_kbytes': '/proc/sys/vm/min_free_kbytes',
                'current_watermark_scale_factor': '/proc/sys/vm/watermark_scale_factor'
            }
            
            for param_name, path in param_paths.items():
                try:
                    with open(path, 'r') as f:
                        state[param_name] = int(f.read().strip())
                except (FileNotFoundError, IOError):
                    # 某些内核版本可能缺少特定参数
                    self.logger.debug(f"Parameter file not found: {path}")
            
        except Exception as e:
            self.logger.error(f"Error reading memory parameters: {e}")
