"""
系统安全检查工具
"""

import psutil
import os
import time

class SafetyChecker:
    def __init__(self):
        # 安全阈值
        self.thresholds = {
            'max_memory_percent': 95,    # 最大内存使用率
            'max_swap_percent': 90,      # 最大swap使用率
            'max_load_factor': 2.0,      # 最大负载因子（相对于CPU核心数）
        }
        
    def is_safe_to_proceed(self, state=None):
        """检查系统资源是否足够安全执行下一步操作
        
        Args:
            state: 当前系统状态，如果为None则重新获取
            
        Returns:
            bool: 如果安全则返回True，否则返回False
        """
        # 如果没有提供状态，则获取系统状态
        if state is None:
            state = self._get_current_state()
            
        # 检查内存使用率
        if state.get('memory_usage_percent', 0) > self.thresholds['max_memory_percent']:
            print("[SAFETY] Memory usage critical. Pausing operations.")
            time.sleep(10)  # 等待一段时间让系统恢复
            return False
            
        # 检查swap使用率
        if state.get('swap_percent', 0) > self.thresholds['max_swap_percent']:
            print("[SAFETY] Swap usage critical. Pausing operations.")
            time.sleep(5)
            return False
            
        # 检查系统负载
        cpu_count = os.cpu_count() or 1
        if state.get('system_loadavg_1min', 0) > cpu_count * self.thresholds['max_load_factor']:
            print("[SAFETY] System load too high. Pausing operations.")
            time.sleep(5)
            return False
            
        return True
        
    def _get_current_state(self):
        """获取当前系统状态（简化版）"""
        state = {}
        
        # 内存状态
        vm = psutil.virtual_memory()
        state['memory_usage_percent'] = vm.percent
        
        # Swap状态
        swap = psutil.swap_memory()
        state['swap_percent'] = swap.percent
        
        # 系统负载
        state['system_loadavg_1min'] = os.getloadavg()[0]
        
        return state
        
    def set_threshold(self, key, value):
        """设置安全阈值
        
        Args:
            key: 阈值名称
            value: 新阈值值
        """
        if key in self.thresholds:
            self.thresholds[key] = value