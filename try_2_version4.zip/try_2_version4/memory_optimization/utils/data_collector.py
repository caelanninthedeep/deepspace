import numpy as np
from collections import defaultdict

class DataCollector:
    def __init__(self, env, num_episodes=1000):
        self.env = env
        self.num_episodes = num_episodes
        self.state_buffer = []
        self.reward_buffer = []
        self.transition_buffer = []
        
    def collect_random_data(self):
        """使用随机策略收集数据"""
        for episode in range(self.num_episodes):
            state = self.env.reset()
            done = False
            episode_rewards = []
            episode_states = []
            
            while not done:
                # 随机动作
                action = self.env.action_space.sample()
                next_state, reward, done, info = self.env.step(action)
                
                # 存储数据
                self.state_buffer.append(state)
                episode_rewards.append(reward)
                episode_states.append(state)
                self.transition_buffer.append((state, action, reward, next_state, done))
                
                state = next_state
            
            self.reward_buffer.append(sum(episode_rewards))
            
        return self.analyze_data()
    
    def analyze_data(self):
        """分析收集的数据"""
        analysis = {
            'state_stats': self._analyze_states(),
            'reward_stats': self._analyze_rewards(),
            'transition_stats': self._analyze_transitions()
        }
        return analysis
    
    def _analyze_states(self):
        """分析状态分布"""
        states = np.array(self.state_buffer)
        return {
            'mean': np.mean(states, axis=0),
            'std': np.std(states, axis=0),
            'min': np.min(states, axis=0),
            'max': np.max(states, axis=0)
        }
    
    def _analyze_rewards(self):
        """分析奖励分布"""
        rewards = np.array(self.reward_buffer)
        return {
            'mean': np.mean(rewards),
            'std': np.std(rewards),
            'min': np.min(rewards),
            'max': np.max(rewards)
        }
    
    def _analyze_transitions(self):
        """分析状态转移"""
        transitions = np.array(self.transition_buffer)
        return {
            'unique_states': len(np.unique(transitions[:, 0], axis=0)),
            'unique_actions': len(np.unique(transitions[:, 1])),
            'success_rate': np.mean(transitions[:, 4])  # 完成率
        } 